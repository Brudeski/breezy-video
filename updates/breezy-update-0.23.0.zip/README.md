# Breezy Video

A Windows toolbox for video files, built so new features can be added over time.
Current version: see the window title (and **Settings → What's new**).

## Getting started

1. Keep this folder somewhere permanent (e.g. `Documents\BreezyVideoEdit`).
2. Double-click **`run.bat`**. The first run installs what it needs (Python and FFmpeg via
   winget if missing, then the app's libraries). After an update that needs new components,
   `run.bat` installs them automatically the next time it's started.
3. Optional: **`build_exe.bat`** makes a standalone `BreezyVideoEdit.exe`.

**Self-repair:** at every start the AI models are checked (SHA-256) and any missing or damaged
file is downloaded again; if FFmpeg is missing a filter the modules need, a complete FFmpeg build
(BtbN, GPL) is downloaded into `bin`. Downloads run as a task with progress. Turn it off or run
it by hand in **Settings → Repair**.

Everything the app makes goes into one **Breezy Output** folder (you pick where the first time;
change it in Settings), with a subfolder per module. Each page can also save next to the source
videos or to a custom folder instead. Original videos are never changed.

## Global quality

At the top of the sidebar, one choice sets every module - nine levels from **Max Quality** to
**Max Performance (no AI)** (default **Balanced**, the middle). Hover over a level in the open list for
what it does, what it leaves out, when to use it and how long it takes on this PC. Levels 1-4 run large AI
models (upscaling, AI deblur, AI noise clean-up), each about twice as long as the next; levels 5-6 use only
small AI steps; levels 7-9 use no AI. The levels are the same on every PC; only hardware speed-ups
(graphics-card encoding/decoding, AI on the graphics card, half-precision AI on newer NVIDIA cards, GPU
filters) follow what the PC supports, and are on whenever possible. Changing any setting on a page makes it **Custom**
(your choices are kept until you pick a level again); **⋯** saves the current settings of every module
under your own name (★) or deletes one.
Leaving Custom asks whether to save your settings first. Enhance's recommendation can also suggest
a level (a faster one when the videos would take longer than *Suggest a faster quality from*, 8 h by default) - it is never switched by itself.

Hover over any control for an explanation and when to use it (turn off in Settings → Look).

## Tasks

Every long job (scanning, stitching, finding motion, trimming, tracking) is a **task**:

- Tasks run side by side when they don't compete (Settings → Tasks); others wait in the queue
  (reorder them on the **Tasks** page).
- Progress is shown in the bar at the bottom of the window, with the step being worked on (e.g.
  *Enhancing (AI upscaling to 1920x1080) - part 3 of 12*); the **Tasks** page has a detailed panel
  for the selected task: overall and current-file progress, the step, time worked, time left, finish
  time, speed (× real-time), every file's state and the results. Double-click a finished task to open
  its result (the video when it made one file, the folder when it made several).
- **Time left** is measured from the files already finished (weighed by how much work each file is:
  size and AI steps, not just length); before the first file is done it comes from how fast earlier tasks
  of the same kind went on this PC (learned automatically) and the progress so far. The bar also shows how
  far into the current video the step has got and the video's length.
- **Pause / resume** instantly. Closing the app while tasks run asks whether to finish first,
  pause & save them for next time, or quit. Saved tasks pick up where they left off (finished
  files are kept; the file in progress starts again).
- **Use output from…** on every page adds files made by any module, or queues work on the
  *future* output of a task that hasn't finished yet (e.g. stitch → trim motion → track people).

## Pipelines

Save several steps under one name - e.g. Trim Ends → Stabilizer → Enhance - and run them on ticked
videos with one click. Adding a step (or 'Update from its page') saves that page's current settings
into the step. Each next step works on the files the previous one made. In-between files are made
in a hidden working folder and deleted when the pipeline is done, unless 'Keep the in-between files'
is ticked. The last step's results go to the Pipelines page's output folder.

**Watch folders** (Settings): new videos in a folder run through a chosen pipeline automatically,
once they've stopped growing (finished copying). Files Breezy made are never picked up again, and
handled files are remembered across restarts. Breezy can start with Windows and stays in the tray
while it watches (close the window to keep it running; right-click the tray icon to pause or quit).

**When done** (bottom bar or Tasks page): close Breezy, sleep, hibernate or shut down once every
task is finished, after a 60-second countdown you can cancel.

## Updates and installing on another PC

Breezy looks for a new version once a day (Settings → Updates; can be turned off) in its public
GitHub releases repository and asks before installing. The download is checked against its SHA-256,
the old program files are backed up, and new components install on the next start. The Windows
installer (`BreezyVideoSetup-x.y.z.exe`, per user, no administrator rights) installs Breezy for other
PCs; the first start sets everything up. Releases are built with `python tools/make_release.py <out>`
(needs NSIS).

## Stitcher

Finds videos that are pieces of one recording and joins them, losslessly when possible
(stream copy; re-encodes only if the pieces' formats differ). Recognises time-named clips
(HitPaw/dashcam names, using each clip's real length plus a **max gap**), GoPro chapters,
"part 1 / part 2", DVD VOBs and byte-split `.001` files, and compares scenes (end of one clip
vs start of the next) to raise or lower confidence. Groups above the auto-tick confidence are
ticked; you can rename, reorder, remove or group pieces by hand. Optional audio-drift fix.
**Keep different cameras apart** (on): clips are never joined across cameras - when the files name
different cameras, or when two still cameras show different backgrounds - and clips from two
cameras whose times interleave or overlap become one recording per camera.

Every module: **Add files…** picks one or more videos, **Clear** empties the list, and **Open output
folder** always works. Files are made in a hidden `.breezy-working` folder and appear in the output
folder only when complete. The bottom bar shows processor and graphics-card load.
Tasks run side by side when they don't compete (a graphics-card job next to a processor job;
Settings → Tasks).

## Convert & Compress

Change format (MP4 H.264 or H.265, MKV, MOV, WebM, or sound only as MP3/M4A), or just move the video
into MP4 without re-encoding. Shrink videos: by quality, to a target file size (quick sizes for
common upload limits; if a result comes out too big it's made again a little smaller; videos already
under the target keep normal quality), or to a percent of the original. Resolution and frame rate
only ever go down (measured on the short side, so upright phone video works). Keeps the original's
date. Each row shows the expected new size.

## Motion Trimmer

Finds the parts of each video with motion and makes trimmed copies. Small areas that change
all the time (clocks, date stamps, flicker) are ignored automatically. Sensitivity, padding,
merge and minimum-motion settings update the list instantly; each motion part has a thumbnail
strip and a built-in player (or VLC). Cuts are smart: the video is copied and only the frames
at each cut are re-encoded. Exact sound cuts and audio-drift fix are options. Each motion part has
its own tick box, so you can keep only the parts you want, and they can be saved as one joined
video or as a separate file per part. Unticked parts can be remembered between sessions.
Pauses shorter than 30 s (by default) are merged into one part.

## Trim Ends

Cuts the start and/or end off videos. Set the same amounts for a whole batch, or click a video
and set its start and end by hand with the built-in player (drag the timeline handles, use
'Start here' / 'End here', or type the times; Space, I, O and the arrow keys work too). The exact
first and last kept frames are shown, and 'Preview cuts' plays both ends. Cuts are exact (only the
frames at the new start are re-encoded) or, with 'Fastest', instant and fully lossless with the
start moved to the nearest keyframe. It can also cut another task's output when it finishes.

## Rotate & Crop

Turn video 90° either way or 180°, mirror it, and crop it - free, or to a shape (16:9, 9:16, 4:3,
1:1, 4:5) drawn on a frame of the video (move the box, drag its corners). Turning alone is done
instantly and losslessly by changing the video's rotation flag (optional). The settings apply to
every ticked video (the crop box is a share of the picture, so it fits other sizes too); tick
**Own turn & crop for this video** to give one video different ones (optionally remembered).

## Stabilizer

Steadies shaky video with two-pass vid.stab: *smooth it* (keeps the camera's intended moves) or
*lock it still* (like a tripod), at Light / Medium / Strong. Edges: zoom in to hide them, zoom only
as needed, or keep the whole picture with black edges. Also fixes rolling-shutter wobble (the
lean/jelly of phone and action-camera video, using the camera motion per band of lines) and levels
a tilted horizon. 'Make preview' stabilises a few seconds from any point and plays it side by side
with the original. Long videos are made in resumable 1-minute parts; the measured shake is kept.
(These fixes moved here from Enhance in 0.20.0.)

## Subtitles

Whisper AI (faster-whisper; base / small / medium, downloaded on first use) writes captions from the
speech in any language, optionally translated into English. Makes a .srt file (next to the video so
players load it automatically, or in the output folder), a copy with a switchable subtitle track
(nothing re-encoded), and/or a copy with the subtitles burned into the picture (size, optional dark
box). Line length is adjustable. (Moved here from Enhance in 0.21.0.)

With **Check the text before saving** (on by default) 'Write subtitles' only writes the text: click a
video to read it next to the playing video, correct words and times in the table (add, delete, join,
split lines, move them all earlier/later), then 'Save ticked'. Corrections are kept straight away and
survive closing the program. A .srt already next to a video can be loaded and corrected too.

## Subject Tracker

Finds people (or any of 80 kinds of things: dogs, cars, bikes…) using a YOLOv10 AI model
(Fast / Balanced / Accurate; runs on the graphics card through DirectML when possible). For each
video it can make:

- a **reframed video** - a smooth virtual camera zooms and pans to keep the subjects framed
  (fit all / largest / most central, border size, smoothness, max zoom, hold-then-ease-out when
  nobody is visible, output shape and resolution);
- a copy with **only the parts with subjects** (combined with the reframing, or as a separate
  losslessly cut file);
- a **.csv list** of when subjects appear.

**Find subjects** is optional: it lets you scrub through a video in the preview with the
detections boxed and the camera's crop window drawn (or the reframed result), while changing
settings live. Detection results are remembered, so only the detector and its rate need a
re-run when changed.

The YOLOv10 models (`breezy/models`) are © Ultralytics/THU-MIG, AGPL-3.0, used here for
personal use.

## Enhance

Improves and restores videos, especially old or low-quality ones. Videos are **scanned when added**
(interlacing, black borders, dark or noisy footage, sound drift, black & white, phone sound…). The
settings start from the global quality level plus **What to fix** (General, Old film & VHS, Phone &
action camera, Night & security camera, Upscale only), and the page **recommends** a content type
and settings for the selected (or first scanned) video - **Apply recommendation** uses it. Every
setting is on the page, and it shows how long the current settings take per minute of video:

- **Size & AI** - 2×/3×/4× or 720p-4K; AI upscaling with Real-ESRGAN (*fast*: compact general
  model made for video; *best*: full x2/x4 model, very slow) or classic Lanczos; AI strength mixes
  in a plain upscale for a more natural look. At "same size" the AI still cleans up the picture.
- **Clean-up** - deinterlace, crop black borders, remove noise
  (fast hqdn3d or slow non-local means), remove compression blocks, smooth banding.
- **Light & colour** - auto exposure (smoothed over time), auto white balance, shadows,
  highlights, brightness, contrast, midtones, saturation, vibrance.
- **Detail & motion** - sharpen (contrast-adaptive), film grain, 30/60 fps or double frame rate
  (motion interpolation or blending).
- **AI extras** - restore faces (GFPGAN v1.4 + YuNet face finder), colourise black & white video
  (DDColor; automatically only for B&W videos, or always), AI frame interpolation (RIFE v4.9).
- **More clean-up** - remove flicker, haze/fog (dark-channel dehaze), old film dust & specks, fix
  stutter (rebuild frozen frames with RIFE or blending).
- **Lens** - straighten fisheye bend, fix colour fringes, brighten dark corners.
- **Light & colour extras** - low-light AI (Zero-DCE), looks (6 built-in LUTs or your own .cube),
  match colours to another checked video, HDR → SDR or SDR → HDR10.
- **Hide & privacy** - drag boxes on the preview around stamps/logos (AI fill with LaMa, blur or
  black box); blur/pixelate faces (YuNet) and licence plates (YOLOv11 plate model).
- **Motion** - slow motion 2×/4×/8× (RIFE in-between frames).
- **AI deblur** - NAFNet (trained on real camera-shake blur) sharpens blurred frames (very slow).
- **Picture shape** - fixes squashed/stretched video: automatic (non-square pixels in the file, or
  faces whose shape is off by a 4:3 ↔ 16:9 stretch) or a chosen shape, with optional black bars.
- **Per scene** - finds cuts and gives each scene its own levels and white balance (from its
  near-grey pixels).
- **AI denoise** - SCUNet removes noise and compression mess far better than the classic filters
  (slow), with a steadiness setting that follows the motion so leftover noise doesn't crawl.
- **Remove from the video** - people, vehicles or animals (YOLO11 segmentation) are filled in
  automatically with the background seen in other frames while the camera is still, or AI (LaMa)
  while it moves (both also selectable).
- **Voices & music** - MDX-Net AI (UVR-MDX-NET Voc FT) keeps only the voices, turns the music
  down or keeps only the music. **Repair distorted sound** (declip/declick) and **wind noise**
  removal (high-pass plus a gust compressor on the low end).
- **Sound** - AI sound rebuild (AP-BWE: 8 kHz → 48 kHz, for phone-like sound), widen sound, AI voice
  clean-up (RNNoise), noise reduction, 50/60 Hz hum removal, even loudness, drift fix.

*Adjust each video to its own check* applies the scan's suggestions per video when enhancing. **File size** can be set by quality or aimed at a size in MB.
An optional **before/after video** (side by side or split
screen) is saved next to the result.

The **before/after** preview renders any moment with the current settings (drag the divider,
zoom to 100-400%). It updates quickly without the AI steps; **Preview with AI** shows the full
result and estimates how long the AI will take. AI upscaling is skipped for videos already 4K
(option). Models in `breezy/models` (Real-ESRGAN BSD-3, GFPGAN Apache-2.0 trained on FFHQ, DDColor
Apache-2.0, RIFE MIT, YuNet MIT, RNNoise models, SCUNet Apache-2.0, YOLO11-seg AGPL-3.0, LaMa Apache-2.0, NAFNet MIT, UVR MDX-Net) run on the graphics card through DirectML when
possible.

## Organise

**Rename & sort**: new names and folders from patterns (`{date} {time}`, `{camera}`, `{year}/{year}-{month}`…)
using the time in the file name, else the date stored in the video, else the file date. A preview shows
where every video goes; nothing changes until you press *Rename & sort*, and **Undo last move** puts
everything back. Move in place, or move/copy into another folder.

## Duplicates

Its own module under Stitcher. Identical files (same size and content samples) and the same footage in other files
(re-encoded or resized copies: same length and the same pictures at 9 points) are grouped; the best
copy (most pixels, then highest quality) is ticked to keep, the others go to a *Duplicates* folder or
the Recycle Bin.

## Speed

- **AI engine** (Settings): on an NVIDIA card the CUDA build of ONNX Runtime plus NVIDIA's CUDA/cuDNN
  libraries (~1.8 GB) are downloaded once into `.venv/ai-cuda`, self-tested, and used from the next
  start; otherwise DirectML (any graphics card). The subtitle AI uses the same NVIDIA libraries.
- Enhance runs every step in its own thread, works on several videos at once (Automatic: 2 with 8 GB+,
  3 with 12 GB+ graphics memory), runs the best-quality noise filter on the graphics card (OpenCL) when available, and
  makes long videos in 1-minute parts so a stopped render continues where it was (also with stabilising, slow
  motion and new frame rates).
- **Reuse AI results** (fixed cameras): parts of the picture that didn't change keep their AI result instead
  of running the AI again (refreshed at least every 60 frames) - often 2-5x faster on security footage.
- **TensorRT** (Settings → AI engine): on RTX 20xx / GTX 16xx and newer the big AI models are compiled for the
  card (about 1.2 GB download, tested once) - usually 2-3x faster than CUDA; each model is prepared once per
  tile size (a few minutes).
- The AI works on equal-size pieces, several per call; bigger pieces when the graphics memory allows.
- Encoder speed follows the quality level (thorough on the quality levels, quick on the performance levels).
- Tasks run side by side when they don't compete (Settings → Tasks).
- **Computer use** (Settings): *Full speed*, or *Spare power only* - the app and every tool it starts run at
  the lowest processor and graphics-card priority so your own work comes first. Optionally tasks pause while
  you use the keyboard/mouse and continue after the PC has been idle for a few minutes. The bottom bar has a
  one-click *Full speed / Spare power* switch.

## Everyday

Drag & drop files or folders onto any page. Right-click a file list for Play / Show in folder / Copy path
/ Remove from list (keys: Enter, Delete, F5). The Tasks page can notify you and sleep, hibernate or shut
down the PC when everything is done (60 s countdown).

## Adding features

Each feature is a folder with an `__init__.py` defining a `Feature` subclass. Copy
`plugins/_template` to `plugins/my_feature`, edit it, restart; it appears in the sidebar.
Built-in features are in `breezy/features/`; shared page parts in `breezy/core/ui.py`; the task
engine in `breezy/core/tasks.py`.

## Project layout

```
main.py                      entry point
breezy/app.py                main window, sidebar, startup / close dialogs
breezy/changelog.py          version history ("What's new")
breezy/core/                 ffmpeg, tasks + proc (queue, pause), outputs, encoders (GPU),
                             theme + icons + ui (look), sync (audio drift), settings
breezy/features/stitcher/    detector · scenes · joiner · tasks · widget
breezy/features/motion/      analyzer · cutter · thumbs · preview · tasks · widget
breezy/features/tracker/     detector (YOLO) · framing (camera path) · render · preview · tasks · widget
breezy/features/enhance/     filters · analysis (check) · ai (Real-ESRGAN) · render · preview · tasks · widget
breezy/features/tasks/       Tasks page
breezy/features/settings/    Settings page
breezy/models/               YOLOv10 N / S / M, Real-ESRGAN general x4v3 / x2plus / x4plus (ONNX)
tests/                       python -m pytest tests
```

Settings, task queue, caches and the log live in `%APPDATA%\BreezyVideoEdit`.
