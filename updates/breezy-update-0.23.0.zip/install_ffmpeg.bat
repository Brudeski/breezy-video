@echo off
rem Installs FFmpeg (which includes ffprobe) using Windows' built-in package manager.
echo Installing FFmpeg via winget...
winget install -e --id Gyan.FFmpeg --accept-package-agreements --accept-source-agreements
if errorlevel 1 (
  echo.
  echo winget could not install FFmpeg automatically.
  echo Manual option: download a "release essentials" build from https://www.gyan.dev/ffmpeg/builds/
  echo and copy ffmpeg.exe and ffprobe.exe into the "bin" folder next to run.bat.
  pause
  exit /b 1
)
echo FFmpeg installed. The app will find it automatically.
