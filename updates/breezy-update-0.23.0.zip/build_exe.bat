@echo off
rem Builds a standalone dist\BreezyVideoEdit\BreezyVideoEdit.exe (no Python needed to run it).
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (echo Run run.bat once first. & pause & exit /b 1)
".venv\Scripts\python.exe" -m pip install pyinstaller
".venv\Scripts\python.exe" -m PyInstaller --noconfirm --windowed --name BreezyVideoEdit ^
  --collect-submodules breezy.features --collect-all onnxruntime ^
  --add-data "breezy\models;breezy\models" ^
  --icon breezy\assets\icon.ico --add-data "breezy\assets;breezy\assets" main.py || (pause & exit /b 1)
xcopy /E /I /Y plugins dist\BreezyVideoEdit\plugins >nul
if exist bin xcopy /E /I /Y bin dist\BreezyVideoEdit\bin >nul
echo.
echo Done: dist\BreezyVideoEdit\BreezyVideoEdit.exe
echo Tip: put ffmpeg.exe and ffprobe.exe in dist\BreezyVideoEdit\bin to make it fully portable.
pause
