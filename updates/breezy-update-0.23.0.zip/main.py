from breezy.bootstrap import ensure_components

if __name__ == "__main__":
    ensure_components()          # after an update: install any new components first
    try:                          # NVIDIA CUDA or DirectML for the AI - must be chosen before it loads
        from breezy.core import ai_engine
        from breezy.core.settings import Settings
        ai_engine.activate(Settings())
    except Exception:
        pass
    from breezy.app import main
    main()
