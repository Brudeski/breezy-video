@echo off
setlocal
cd /d "%~dp0"

rem ---- find Python ----------------------------------------------------------
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY (where python >nul 2>nul && set "PY=python")
if not defined PY (
  echo Python 3.10+ is required. Installing it with winget...
  winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
  echo.
  echo Python installed. Please close this window and double-click run.bat again.
  pause
  exit /b 1
)

rem ---- first run: create a private environment -------------------------------
if not exist ".venv\Scripts\python.exe" (
  echo First run: setting up, this takes a few minutes...
  %PY% -m venv .venv || (echo Failed to create virtual environment & pause & exit /b 1)
  ".venv\Scripts\python.exe" -m pip install --upgrade pip >nul
)

rem ---- install / update components whenever the requirements change --------
".venv\Scripts\python.exe" -m breezy.bootstrap || (echo Failed to install requirements & pause & exit /b 1)

rem ---- FFmpeg ----------------------------------------------------------------
if not exist "bin\ffmpeg.exe" (
  where ffmpeg >nul 2>nul || (
    echo FFmpeg not found - installing it now.
    call install_ffmpeg.bat
  )
)

rem ---- desktop shortcut (once) ---------------------------------------------
if not exist ".shortcut_created" (
  powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0create_shortcut.ps1" && type nul > ".shortcut_created"
)

start "" ".venv\Scripts\pythonw.exe" main.py
