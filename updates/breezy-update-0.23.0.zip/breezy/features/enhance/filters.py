"""Enhance settings -> FFmpeg filter chains, presets and capability checks.

The picture goes through three stages:
    pre   (FFmpeg)  deinterlace, crop borders, stabilise, denoise, deblock, deband, light & colour
    ai    (Python)  optional AI upscale / enhance (Real-ESRGAN, ONNX Runtime)
    post  (FFmpeg)  resize to the output size, sharpen, film grain, frame rate
Without AI, pre + post run in one FFmpeg command.
"""
from __future__ import annotations

import subprocess
import sys
from dataclasses import asdict, dataclass, field, fields

NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0

SIZES = [("Same as source", "same"), ("2× larger", "x2"), ("3× larger", "x3"), ("4× larger", "x4"),
         ("720p", "720"), ("1080p (Full HD)", "1080"), ("1440p", "1440"), ("2160p (4K)", "2160")]
LEVELS = [("Off", 0), ("Light", 1), ("Medium", 2), ("Strong", 3)]


@dataclass
class EnhanceSettings:
    # size & AI
    size: str = "x2"
    upscaler: str = "ai_fast"      # ai_fast | ai_best | lanczos
    ai_strength: int = 70          # % of the AI result blended over a plain upscale (100 looks painted)
    same_size_ai: bool = True      # at "same size", still run the AI (upscale 4x, shrink back)
    ai_skip_4k: bool = True        # videos already 4K get the classic path (AI there is impractically slow)
    # AI extras
    faces: bool = False            # restore faces (GFPGAN)
    face_strength: int = 80
    face_min: int = 32             # only faces at least this many pixels tall
    colourise: str = "off"         # off | auto (only black & white videos) | on
    colour_strength: int = 100
    # clean-up
    deinterlace: str = "auto"      # off | auto | on
    crop: str = "off"              # off | auto
    stabilize: int = 0             # 0..3   (set on the Stabilizer page since 0.20.0)
    stab_mode: str = "smooth"      # smooth (keep the camera's own moves) | lock (hold the view still, tripod)
    stab_edges: str = "zoom"       # zoom (hide the moving edges) | adaptive (zoom only as needed) | black
    denoise: int = 2               # 0..3
    denoise_method: str = "hqdn3d"  # hqdn3d (fast) | nlmeans (best)
    denoise_ai: int = 0            # 0..100 % - SCUNet AI denoise (very slow)
    denoise_ai_temporal: int = 1   # 0..3 steadiness over time (uses neighbouring frames)
    deblock: int = 1               # 0..3 compression blocks
    deband: bool = True
    deflicker: int = 0             # 0..3
    dehaze: int = 0                # 0..100
    dust: int = 0                  # 0..3 old film dust & specks
    stutter: str = "off"           # off | ai | blend   rebuild frozen/duplicated frames
    stutter_max: int = 12          # longer runs of repeated frames are deliberate pauses (kept)
    deblur: int = 0                # 0..100 % NAFNet AI deblur (camera shake / motion blur, very slow)
    rs_fix: bool = False           # fix the 'jelly' lean/wobble of phones & action cameras
    rolling_shutter: int = 3       # 1..3 how slowly the camera reads out (light / medium / strong)
    shape: str = "off"             # off | auto (file info + faces) | 4:3 | 16:9 | 21:9 | 1:1 | 9:16
    shape_bars: bool = False       # keep the frame size and add black bars instead
    # lens
    lens: int = 0                  # 0..100 straighten fisheye / wide-angle bend
    fringes: int = 0               # 0..100 colour fringes (chromatic aberration)
    vignette: int = 0              # 0..100 brighten dark corners
    # hide & privacy
    stamps: list = field(default_factory=list)   # [[x, y, w, h], ...] fractions of the picture
    stamp_method: str = "ai"       # ai | blur | box
    privacy_faces: bool = False
    privacy_plates: bool = False
    privacy_style: str = "blur"    # blur | pixelate | black
    remove_objects: str = "off"    # off | people | vehicles | people_vehicles | animals
    remove_method: str = "auto"    # auto (background while the camera is still) | ai | background
    remove_grow: int = 12          # px (at 1080p) added around each object
    # subtitles
    subtitles: bool = False
    sub_model: str = "medium"
    sub_language: str = ""
    sub_translate: bool = False    # translate to English
    sub_save_srt: bool = True
    sub_embed: bool = True
    sub_burn: bool = False
    sub_size: int = 22
    # extra outputs / automation
    compare: str = "off"           # off | side | split
    auto_suggest: bool = False     # adjust each video to its check result
    # light & colour
    auto_levels: int = 50          # 0..100 %
    white_balance: bool = False    # gray-world auto white balance
    per_scene: int = 0             # 0..100 % levels & white balance worked out per scene (replaces the two above)
    brightness: int = 0            # -100..100
    contrast: int = 0              # -100..100
    midtones: int = 0              # -100..100 (gamma)
    shadows: int = 20              # 0..100 lift
    highlights: int = 0            # 0..100 recover
    saturation: int = 0            # -100..100
    vibrance: int = 10             # 0..100
    low_light: int = 0             # 0..100 Zero-DCE AI
    low_light_auto: bool = True    # only for videos the check found dark
    lut: str = "none"              # none | builtin name | custom
    lut_custom: str = ""
    lut_strength: int = 100
    colour_ref: list = field(default_factory=list)   # reference RGB means+stds (from the check of another video)
    colour_ref_name: str = ""
    colour_match_strength: int = 100
    hdr: str = "off"               # off | to_sdr (HDR sources to normal video) | to_hdr (make HDR10)
    # detail
    sharpen: int = 1               # 0..3
    grain: int = 0                 # 0..3
    # motion
    frame_rate: str = "same"       # same | 30 | 60 | double
    fr_method: str = "rife"        # set by the quality level: rife (AI, best) | interpolate (classic, slow) | blend (fast)
    fr_choice: str = "auto"        # the user's choice next to the frame rate: auto (= fr_method) | rife | interpolate | blend
    slowmo: int = 1                # 1 | 2 | 4 | 8
    slowmo_sound: str = "slow"     # slow (pitch kept) | mute
    horizon: int = 0               # 0..100 level the horizon
    # sound
    voice: str = "off"             # off | std | sh | bd   (RNNoise voice clean-up)
    separate: str = "off"          # off | voices (remove music) | quieter (music down) | music (remove voices)
    music_level: int = 25          # % of the music kept with "quieter"
    declip: int = 0                # 0..3 repair distorted (clipped) sound
    wind: int = 0                  # 0..3 remove wind rumble
    sound_ai: str = "auto"         # off | auto (only low-quality sound, 16 kHz or less) | on   AP-BWE
    stereo: int = 0                # 0..100 widen (mono becomes stereo)
    audio_denoise: int = 1         # 0..3
    hum: str = "off"               # off | 50 | 60
    loudness: bool = True
    fix_drift: bool = True
    drift_threshold: float = 0.1
    audio_bitrate: str = ""
    # encoding
    codec: str = "same"            # same | h264 | hevc
    crf: int = 16
    size_mode: str = "quality"     # quality (CRF) | target (file size)
    target_mb: float = 25.0
    enc_gpu: bool = True
    ten_bit: bool = False
    ai_gpu: bool = True
    ai_half: bool = True           # half precision for the big AI models on NVIDIA cards that are fast at it
    ai_reuse: bool = True          # keep a tile's AI result while its picture doesn't change (fixed cameras)
    enc_speed: str = "balanced"    # set by the quality level: quality | balanced | fast encoder presets
    hwaccel: bool = True
    gpu_filters: bool = True       # graphics-card versions of slow filters when this PC supports them
    tile: int = 384
    videos_at_once: str = "auto"   # auto | 1 | 2 | 3   (several videos on the graphics card together)
    resume_parts: bool = True      # long videos are made in 1-minute parts that survive a stop/crash

    @classmethod
    def from_spec(cls, spec: dict) -> "EnhanceSettings":
        names = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in spec.items() if k in names})

    def to_spec(self) -> dict:
        return asdict(self)


def tier_settings(tier: str = "max_quality", content: str = "general") -> "EnhanceSettings":
    """Enhance settings for a global Quality level (and content type) - see breezy.core.quality."""
    from breezy.core.quality import TABLE, content_overlay
    vals = {k: col[tier] for k, col in TABLE["enhance"].items()}
    vals.update(content_overlay(content, vals))
    return EnhanceSettings(**vals)



# ------------------------------------------------------------------ capability
_filters: set[str] | None = None


def available_filters(ffmpeg_exe: str) -> set[str]:
    """FFmpeg's filters, plus "@opencl" when graphics-card (OpenCL) filters really work on this PC."""
    global _filters
    if _filters is None:
        try:
            out = subprocess.run([ffmpeg_exe, "-hide_banner", "-filters"], capture_output=True, text=True,
                                 timeout=30, creationflags=NO_WINDOW).stdout
            _filters = {ln.split()[1] for ln in out.splitlines() if len(ln.split()) > 2 and ln[:1] == " "}
        except Exception:
            _filters = set()
        if "nlmeans_opencl" in _filters and _opencl_works(ffmpeg_exe):
            _filters.add("@opencl")
    return _filters


OPENCL_ARGS = ["-init_hw_device", "opencl=ocl", "-filter_hw_device", "ocl"]


def _opencl_works(ffmpeg_exe: str) -> bool:
    try:
        r = subprocess.run([ffmpeg_exe, "-v", "error", "-nostdin", *OPENCL_ARGS, "-f", "lavfi", "-i",
                            "testsrc2=s=64x64", "-vf", "format=yuv420p,hwupload,nlmeans_opencl,hwdownload,"
                            "format=yuv420p", "-frames:v", "1", "-f", "null", "-"],
                           capture_output=True, timeout=60, creationflags=NO_WINDOW)
        return r.returncode == 0
    except Exception:
        return False


def hw_args(vf: str) -> list[str]:
    """Extra FFmpeg arguments a filter chain needs (the OpenCL device for graphics-card filters)."""
    return list(OPENCL_ARGS) if "_opencl" in vf else []


# ------------------------------------------------------------------ geometry
def output_size(width: int, height: int, s: EnhanceSettings, crop: tuple | None = None) -> tuple[int, int]:
    if crop:
        width, height = crop[0], crop[1]
    if s.size.startswith("x"):
        f = float(s.size[1:])
        w, h = width * f, height * f
    elif s.size.isdigit():
        h = float(s.size)
        w = width * h / height
    else:
        w, h = width, height
    return max(2, int(round(w / 2)) * 2), max(2, int(round(h / 2)) * 2)


def is_4k(w: int, h: int) -> bool:
    return h >= 2000 or w >= 3800


def ai_factor(in_w: int, in_h: int, out_w: int, out_h: int, s: EnhanceSettings) -> int:
    """Which AI model factor to run (0 = no AI)."""
    if s.upscaler == "lanczos":
        return 0
    if s.ai_skip_4k and is_4k(in_w, in_h):
        return 0
    if s.size == "same" and not s.same_size_ai:
        return 0
    if s.upscaler == "ai_fast":
        return 4                       # only a 4x fast model; the result is resized to the output size
    need = max(out_w / in_w, out_h / in_h)
    return 2 if need <= 2.01 else 4


# ------------------------------------------------------------------ picture shape
SHAPES = [("Keep as it is", "off"), ("Automatic (file info & faces)", "auto"), ("4:3", "4:3"), ("16:9", "16:9"),
          ("21:9 (cinema)", "21:9"), ("1:1 (square)", "1:1"), ("9:16 (vertical)", "9:16")]
_SHAPE_DAR = {"4:3": 4 / 3, "16:9": 16 / 9, "21:9": 2.39, "1:1": 1.0, "9:16": 9 / 16}


def shape_factor(s: EnhanceSettings, w: int, h: int, sar: float, ana: dict) -> float:
    """How much wider (>1) or narrower (<1) the picture should be to have the right shape."""
    if s.shape == "off" or not w or not h:
        return 1.0
    if s.shape == "auto":
        if sar and abs(sar - 1) > 0.01:
            return float(sar)                      # the file says its pixels aren't square
        st = ana.get("stretch")
        return float(st) if st else 1.0
    dar = _SHAPE_DAR.get(s.shape)
    return dar / (w / h) if dar else 1.0


def shaped_size(s: EnhanceSettings, w: int, h: int, sar: float, ana: dict) -> tuple[int, int, int, int] | None:
    """(picture w, h, frame w, h) after fixing the shape, or None when the shape is already right.
    Without bars the frame is the picture."""
    f = shape_factor(s, w, h, sar, ana)
    if abs(f - 1) < 0.01:
        return None
    pw, ph = w * f, float(h)
    if s.shape_bars:
        k = min(w / pw, h / ph)
        pw, ph = pw * k, ph * k
        fw, fh = w, h
    else:
        fw, fh = None, None
    pw, ph = max(2, int(round(pw / 2)) * 2), max(2, int(round(ph / 2)) * 2)
    return (pw, ph, fw or pw, fh or ph)


def shape_filter(shape: tuple | None) -> str:
    if not shape:
        return ""
    pw, ph, fw, fh = shape[:4]
    f = f"scale={pw}:{ph}:flags=lanczos,setsar=1"
    if (pw, ph) != (fw, fh):
        f += f",pad={fw}:{fh}:(ow-iw)/2:(oh-ih)/2:black"
    return f


# ------------------------------------------------------------------ chains
def _f(x: float) -> str:
    return f"{x:.4f}".rstrip("0").rstrip(".")


def pre_filters(s: EnhanceSettings, ana: dict, have: set[str], stab_file: str | None = None,
                single_frame: bool = False, shape: tuple | None = None, colour_only: bool = False) -> list[str]:
    """Clean-up + light & colour, on the source-size picture. shape = (w, h, frame w, frame h, changed)
    from shaped_size; colour_only = just the steps that change light & colour (for the scene scan)."""
    f: list[str] = []
    if s.deinterlace == "on" or (s.deinterlace == "auto" and ana.get("interlaced")):
        f.append("bwdif=mode=send_frame:parity=auto:deint=all" if "bwdif" in have else "yadif")
    if s.hdr == "to_sdr" and ana.get("hdr") and "zscale" in have and "tonemap" in have:
        f.append("zscale=t=linear:npl=100,format=gbrpf32le,zscale=p=bt709,tonemap=tonemap=hable:desat=0,"
                 "zscale=t=bt709:m=bt709:r=tv,format=yuv420p,setparams=color_primaries=bt709:color_trc=bt709:"
                 "colorspace=bt709")
    if s.crop == "auto" and ana.get("crop"):
        w, h, x, y = ana["crop"]
        f.append(f"crop={w}:{h}:{x}:{y}")
    if s.deflicker and "deflicker" in have and not single_frame:
        f.append(f"deflicker=size={ {1: 5, 2: 9, 3: 15}[s.deflicker] }:mode=pm")
    if s.lens and "lenscorrection" in have:
        k = s.lens / 100
        f.append(f"lenscorrection=k1={_f(-0.32 * k)}:k2={_f(-0.06 * k)}:i=bilinear")
    if s.vignette and "vignette" in have:
        f.append(f"vignette=angle={_f(0.15 + 0.5 * s.vignette / 100)}:mode=backward")
    if s.stabilize and not single_frame:
        smooth = {1: 10, 2: 20, 3: 40}[s.stabilize]
        if stab_file and "vidstabtransform" in have:
            edges = {"zoom": "optzoom=1", "adaptive": "optzoom=2:zoomspeed=0.2",
                     "black": "optzoom=0:crop=black"}.get(s.stab_edges, "optzoom=1")
            how = "tripod=1" if s.stab_mode == "lock" else f"smoothing={smooth}"
            f.append(f"vidstabtransform=input='{_esc(stab_file)}':{how}:zoom=0:{edges}")
        elif "deshake" in have:
            f.append("deshake")
    if s.denoise:
        if s.denoise_method == "nlmeans" and s.gpu_filters and "@opencl" in have:
            # the same filter on the graphics card: many times faster than on the processor
            f.append(f"format=yuv420p,hwupload,nlmeans_opencl=s={_f({1: 1.5, 2: 3.0, 3: 5.0}[s.denoise])}:"
                     f"p=7:r=15,hwdownload,format=yuv420p")
        elif s.denoise_method == "nlmeans" and "nlmeans" in have:
            f.append(f"nlmeans=s={_f({1: 1.5, 2: 3.0, 3: 5.0}[s.denoise])}:p=7:r=15")
        else:
            ls, cs, lt, ct = {1: (2, 1.5, 3, 2.5), 2: (4, 3, 6, 4.5), 3: (7, 5, 10, 7.5)}[s.denoise]
            f.append(f"hqdn3d={ls}:{cs}:{lt}:{ct}")
    if s.deblock and "deblock" in have:
        a, b = {1: (0.098, 0.05), 2: (0.15, 0.08), 3: (0.22, 0.12)}[s.deblock]
        f.append(f"deblock=filter=strong:block=8:alpha={a}:beta={b}")
    if s.deband and "deband" in have:
        f.append("deband=1thr=0.015:2thr=0.015:3thr=0.015:range=16:blur=1")
    sf = shape_filter(shape)
    if sf:
        f.append(sf)
    if colour_only:
        f = [x for x in f if x.startswith(("bwdif", "yadif", "crop", "zscale"))]
    # --- light & colour (per scene replaces auto levels & white balance; it runs after these, in Python)
    if s.auto_levels and "normalize" in have and not s.per_scene:
        st = s.auto_levels / 100
        f.append(f"normalize=smoothing={1 if single_frame else 48}:independence=0:strength={_f(st)}")
    if s.white_balance and "grayworld" in have and not s.per_scene:
        f.append("grayworld")
    if s.shadows or s.highlights:
        sh, hi = s.shadows / 100, s.highlights / 100
        pts = [(0, 0), (0.15, 0.15 + 0.10 * sh), (0.35, 0.35 + 0.08 * sh), (0.65, 0.65 - 0.03 * hi),
               (0.88, 0.88 - 0.08 * hi), (1, 1 - 0.04 * hi)]
        f.append("curves=all='" + " ".join(f"{_f(a)}/{_f(min(1, max(0, b)))}" for a, b in pts) + "'")
    if s.brightness or s.contrast or s.midtones or s.saturation:
        f.append(f"eq=brightness={_f(s.brightness / 400)}:contrast={_f(1 + s.contrast / 200)}:"
                 f"gamma={_f(2 ** (s.midtones / 100))}:saturation={_f(1 + s.saturation / 100)}")
    if s.vibrance and "vibrance" in have:
        f.append(f"vibrance=intensity={_f(s.vibrance / 100 * 0.6)}")
    cm = colour_match_filter(s, ana)
    if cm:
        f.append(cm)
    lut = lut_filter(s, have)
    if lut:
        f.append(lut)
    return f


def colour_match_filter(s: EnhanceSettings, ana: dict) -> str:
    """Per-channel mean/spread matching to a reference video (from both videos' check)."""
    ref, own = s.colour_ref, ana.get("rgb_stats")
    if not ref or not own or len(ref) != 6 or len(own) != 6:
        return ""
    st = s.colour_match_strength / 100
    parts = []
    for i, ch in enumerate("rgb"):
        k = ref[3 + i] / max(own[3 + i], 1.0)
        k = max(0.5, min(2.0, k))
        k = 1 + (k - 1) * st
        m_src, m_dst = own[i], own[i] + (ref[i] - own[i]) * st
        parts.append(f"{ch}='clip((val-{_f(m_src)})*{_f(k)}+{_f(m_dst)},0,255)'")
    return "lutrgb=" + ":".join(parts)


def lut_filter(s: EnhanceSettings, have: set[str]) -> str:
    if s.lut in ("", "none") or "lut3d" not in have:
        return ""
    from .extras import lut_path
    p = lut_path(s.lut, s.lut_custom)
    if not p:
        return ""
    lut = f"lut3d=file='{_esc(str(p))}'"
    st = s.lut_strength / 100
    if st >= 0.999:
        return lut
    return (f"split[lutA][lutB];[lutB]{lut}[lutL];[lutA][lutL]blend=all_expr='A*{_f(1 - st)}+B*{_f(st)}'")


def post_filters(s: EnhanceSettings, out_w: int, out_h: int, src_fps: float, have: set[str],
                 resize: bool = True, single_frame: bool = False, python_retime: bool = False) -> list[str]:
    f: list[str] = []
    if resize:
        f.append(f"scale={out_w}:{out_h}:flags=lanczos+accurate_rnd+full_chroma_int")
    if s.sharpen:
        if "cas" in have:
            f.append(f"cas=strength={_f({1: 0.35, 2: 0.6, 3: 0.85}[s.sharpen])}")
        else:
            f.append(f"unsharp=5:5:{_f({1: 0.5, 2: 0.9, 3: 1.3}[s.sharpen])}")
    if s.grain:
        f.append(f"noise=c0s={ {1: 4, 2: 8, 3: 13}[s.grain] }:c0f=t+u")
    target = target_fps(s, src_fps)
    if target and not single_frame and not uses_rife(s) and not python_retime:
        if frame_method(s) == "interpolate" and "minterpolate" in have:
            f.append(f"minterpolate=fps={_f(target)}:mi_mode=mci:mc_mode=aobmc:me_mode=bidir:vsbmc=1")
        else:
            f.append(f"framerate=fps={_f(target)}")
    if s.hdr == "to_hdr" and not single_frame and "zscale" in have:
        f.append("setparams=color_primaries=bt709:color_trc=bt709:colorspace=bt709,zscale=t=linear:npl=100,"
                 "format=gbrpf32le,zscale=p=bt2020,zscale=t=smpte2084:m=bt2020nc:r=tv:npl=203,format=yuv420p10le")
    return f


def uses_rife(s: EnhanceSettings) -> bool:
    from .ai import rife_available
    return frame_method(s) == "rife" and rife_available()


def frame_method(s) -> str:
    """How new frames are made: the user's choice, or (Automatic) what the quality level says."""
    c = getattr(s, "fr_choice", "auto") or "auto"
    return s.fr_method if c == "auto" else c


def target_fps(s: EnhanceSettings, src_fps: float) -> float | None:
    if s.frame_rate == "same" or not src_fps:
        return None
    t = src_fps * 2 if s.frame_rate == "double" else float(s.frame_rate)
    return t if t > src_fps * 1.01 else None


def audio_filters(s: EnhanceSettings, have: set[str], drift_ratio: float | None, channels: int = 2,
                  skip_drift: bool = False) -> list[str]:
    f: list[str] = []
    if drift_ratio and not skip_drift:
        f.append(f"atempo={drift_ratio:.6f}")
    if s.declip and "adeclip" in have:
        f.append({1: "adeclip", 2: "adeclip=t=8:n=1000", 3: "adeclip=t=4:n=2000"}[s.declip])
        if s.declip >= 2 and "adeclick" in have:
            f.append("adeclick" if s.declip == 2 else "adeclick=t=1.5")
    if s.wind:
        f.append(f"highpass=f={ {1: 80, 2: 110, 3: 150}[s.wind] }:p=2")
        if s.wind >= 2 and "acrossover" in have and "acompressor" in have:
            # gusts: squash the low end hard whenever it suddenly gets loud (the voice band is left alone)
            th, ra = {2: (0.03, 6), 3: (0.015, 12)}[s.wind]
            f.append(f"acrossover=split=250[windlo][windhi];[windlo]acompressor=threshold={th}:ratio={ra}:"
                     f"attack=5:release=150[windlc];[windhi][windlc]amix=inputs=2:normalize=0")
    if s.hum in ("50", "60"):
        base = int(s.hum)
        f.append("highpass=f=70")
        f += [f"bandreject=f={base * k}:width_type=q:w=8" for k in (1, 2, 3)]
    if s.voice in ("std", "sh", "bd") and "arnndn" in have:
        from .ai import voice_model
        m = voice_model(s.voice)
        if m.is_file():
            f.append(f"arnndn=m='{_esc(str(m))}'")
    if s.audio_denoise and "afftdn" in have:
        f.append(f"afftdn=nr={ {1: 8, 2: 14, 3: 22}[s.audio_denoise] }:nf=-40")
    if s.stereo:
        k = s.stereo / 100
        if channels <= 1 and "haas" in have:
            f.append(f"haas=side_gain={_f(0.3 + 0.9 * k)}")
        elif channels > 1 and "extrastereo" in have:
            f.append(f"extrastereo=m={_f(1 + 1.2 * k)}")
    if s.loudness and "loudnorm" in have:
        f.append("loudnorm=I=-16:TP=-1.5:LRA=11,aresample=48000")   # loudnorm works at 192 kHz internally
    if s.slowmo > 1 and s.slowmo_sound == "slow":
        f += ["atempo=0.5"] * {2: 1, 4: 2, 8: 3}.get(s.slowmo, 1)
    return f


def _esc(path: str) -> str:
    """Escape a path for use inside an FFmpeg filter argument."""
    return path.replace("\\", "/").replace(":", "\\:").replace("'", "\\'")


def apply_suggestions(s: EnhanceSettings, info, ana: dict, ai: bool = True,
                      upscale_ai: bool | None = None) -> EnhanceSettings:
    """A copy of the settings adjusted to what the check found for this video.
    ai=False (levels without AI): don't add AI steps. upscale_ai=False (light-AI levels): add the small AI
    steps but not AI upscaling (it costs far more than everything else together)."""
    if upscale_ai is None:
        upscale_ai = ai
    import dataclasses
    if not ana:
        return s
    ch: dict = {}
    v = getattr(info, "video", None)
    a = getattr(info, "audio", None)
    if ana.get("interlaced") and s.deinterlace == "off":
        ch["deinterlace"] = "auto"
    if ana.get("crop"):
        ch["crop"] = "auto"
    b = ana.get("brightness")
    if b is not None and b < 60:
        ch.update(shadows=max(s.shadows, 30), auto_levels=max(s.auto_levels, 50))
        if ai:
            ch["low_light"] = max(s.low_light, 60)
    elif b is not None and b > 190:
        ch["highlights"] = max(s.highlights, 40)
    if s.shape == "off" and (ana.get("stretch") or (v and abs(getattr(v, "sar", 1.0) - 1) > 0.01)):
        ch["shape"] = "auto"
    n = ana.get("noise") if not s.denoise_ai else None      # AI denoise already handles noise
    if n is not None and n > 9:
        ch["denoise"] = 3
    elif n is not None and n > 4.5:
        ch["denoise"] = max(s.denoise, 2)
    if ana.get("grayscale") and s.colourise == "off" and ai:
        ch["colourise"] = "auto"
    if ana.get("hdr") and s.hdr == "off":
        ch["hdr"] = "to_sdr"
    if v and v.height:
        if v.height < 720 and s.size == "same":
            ch["size"] = "x2"
            if s.upscaler == "lanczos" and ai and upscale_ai:
                ch["upscaler"] = "ai_fast"
        elif is_4k(v.width, v.height) and (s.size.startswith("x") or s.size == "2160"):
            ch["size"] = "same"
    if a and a.sample_rate and a.sample_rate <= 16000 and s.sound_ai == "off" and ai:
        ch["sound_ai"] = "auto"
    if not s.fix_drift:
        from breezy.core.sync import needs_fix
        if needs_fix(info, s.drift_threshold):
            ch["fix_drift"] = True
    return dataclasses.replace(s, **ch) if ch else s


def describe(s: EnhanceSettings) -> str:
    bits = []
    size = dict((v, k) for k, v in SIZES).get(s.size, s.size)
    if s.size != "same":
        bits.append(f"{size} ({'AI fast' if s.upscaler == 'ai_fast' else 'AI best' if s.upscaler == 'ai_best' else 'Lanczos'})")
    elif s.upscaler != "lanczos":
        bits.append("AI enhance")
    for name, v in (("denoise", s.denoise), ("deblock", s.deblock), ("stabilise", s.stabilize), ("sharpen", s.sharpen)):
        if v:
            bits.append(name)
    if s.auto_levels or s.shadows or s.highlights or s.white_balance or s.per_scene:
        bits.append("lighting" + (" per scene" if s.per_scene else ""))
    if s.faces:
        bits.append("faces")
    if s.colourise != "off":
        bits.append("colourise" + (" (B&W only)" if s.colourise == "auto" else ""))
    if s.voice != "off":
        bits.append("voice clean-up")
    if s.sound_ai == "on":
        bits.append("AI sound rebuild")
    elif s.sound_ai == "auto":
        bits.append("AI sound rebuild (low-quality sound)")
    for name, v in (("deflicker", s.deflicker), ("dehaze", s.dehaze), ("dust", s.dust), ("lens", s.lens),
                    ("fringes", s.fringes), ("corners", s.vignette), ("low light", s.low_light),
                    ("horizon", s.horizon)):
        if v:
            bits.append(name)
    if s.stutter != "off":
        bits.append("fix stutter")
    if s.stamps:
        bits.append(f"hide {len(s.stamps)} area(s)")
    if s.privacy_faces or s.privacy_plates:
        bits.append("privacy blur")
    if s.lut not in ("", "none"):
        bits.append("look (LUT)")
    if s.colour_ref:
        bits.append("colour match")
    if s.hdr != "off":
        bits.append("HDR→SDR" if s.hdr == "to_sdr" else "make HDR")
    if s.slowmo > 1:
        bits.append(f"{s.slowmo}× slow motion")
    if s.denoise_ai:
        bits.append("AI denoise")
    if s.remove_objects != "off":
        bits.append(f"remove {s.remove_objects.replace('_', ' & ')}")
    for name, v in (("AI deblur", s.deblur), ("rolling-shutter fix", s.rs_fix and s.rolling_shutter),
                    ("repair distorted sound", s.declip), ("wind removal", s.wind)):
        if v:
            bits.append(name)
    if s.shape != "off":
        bits.append("fix shape" + ("" if s.shape == "auto" else f" ({s.shape})"))
    if s.separate != "off":
        bits.append({"voices": "remove music", "quieter": "music down", "music": "remove voices"}[s.separate])
    if s.subtitles:
        bits.append("subtitles")
    if s.size_mode == "target":
        bits.append(f"≤ {s.target_mb:g} MB")
    if s.compare != "off":
        bits.append("+ before/after video")
    if s.auto_suggest:
        bits.append("adjusted per video")
    if target_fps(s, 30) or s.frame_rate != "same":
        bits.append(f"{s.frame_rate} fps" if s.frame_rate != "double" else "2× fps")
    return ", ".join(bits) or "no changes"
