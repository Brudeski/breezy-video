"""Enhance: upscale (AI or classic), clean up, fix lighting and colour, smooth motion, clean sound."""
from breezy.core.plugin import Feature
from . import tasks  # noqa: F401  (registers the task runners)


class EnhanceFeature(Feature):
    id = "enhance"
    name = "Enhance"
    description = ("Improve and restore videos: AI upscaling, noise and compression clean-up, deinterlacing, "
                   "lighting and colour fixes, smoother motion and cleaner sound. Compare before "
                   "and after on any frame. Originals are never changed.")
    order = 30
    icon = "sparkle"

    def create_widget(self):
        from .widget import EnhanceWidget
        self.widget = EnhanceWidget(self)
        return self.widget

    def theme_changed(self):
        self.widget.theme_changed()

    def hardware_scanned(self, result: dict):
        if getattr(self, "widget", None) is not None:
            self.widget.hardware_scanned(result)


FEATURE = EnhanceFeature
