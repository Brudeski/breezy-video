"""Enhance page: check videos, tune settings with a live before/after preview, enhance."""
from __future__ import annotations

from dataclasses import fields
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (QAbstractItemView, QCheckBox, QComboBox, QFileDialog, QHBoxLayout, QLabel,
                               QLineEdit, QMessageBox, QPlainTextEdit, QPushButton, QSplitter, QTreeWidget,
                               QTreeWidgetItem, QVBoxLayout, QWidget)

from breezy.core import theme
from breezy.core.outputs import output_spec
from breezy.core.tasks import Task
from breezy.core.ui import (Card, OutputCard, OutputPicker, SettingsColumn, TaskBar, check, combo,
                            open_in_explorer, spin)
from breezy.features.stitcher.detector import VIDEO_EXTS
from . import ai
from .analysis import load_cache
from .filters import LEVELS, SIZES, EnhanceSettings, describe
from .preview import BeforeAfter
from .render import Enhancer, make_plan
from .tasks import cache_file

ROLE = Qt.UserRole
DEFAULT_FOLDER = "Enhanced"
BITRATES = [("Automatic", ""), ("96 kbps", "96k"), ("128 kbps", "128k"), ("192 kbps", "192k"), ("320 kbps", "320k")]


def _dur(sec: float) -> str:
    sec = int(round(sec))
    return f"{sec // 3600}:{sec % 3600 // 60:02d}:{sec % 60:02d}"


def _fmt_time(sec: float) -> str:
    if sec < 90:
        return f"{sec:.0f} s"
    if sec < 5400:
        return f"{sec / 60:.0f} min"
    return f"{sec / 3600:.1f} h"


class EnhanceWidget(QWidget):
    def __init__(self, feature):
        super().__init__()
        self.feature = feature
        self.ctx = feature.context
        self.ff = self.ctx.ffmpeg
        self.tm = self.ctx.tasks
        self.files: list[Path] = []
        self.extra_files: list[Path] = []
        self.infos: dict = {}
        self.checks: dict[Path, dict] = {}
        self.unchecked: set[Path] = set()
        self.check_task_id = None
        self._applying = False
        self.controls: dict[str, QWidget] = {}
        self._build()
        self.tm.finished.connect(self._task_finished)
        self._update_buttons()
        self._install_tools()

    # ================================================================ layout

    def _build(self):
        st = self.feature.setting
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(14)

        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.setSpacing(8)
        src = Card()
        top = QHBoxLayout()
        self.folder_edit = QLineEdit(st("last_folder", ""))
        self.folder_edit.setPlaceholderText("Folder of videos…")
        self.folder_edit.editingFinished.connect(self._gather_and_list)
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse_folder)
        self.recursive = check("Include subfolders", st("recursive", False))
        self.recursive.toggled.connect(self._gather_and_list)
        self.use_out = QPushButton("Use output from…")
        self.use_out.setToolTip("Add files made by any module - or queue enhancing a task's output "
                                "that hasn't finished yet")
        self.use_out.clicked.connect(self._use_output)
        self.check_btn = QPushButton("Check videos", objectName="primary")
        self.check_btn.setToolTip("Look for interlacing, black borders, darkness, noise and sound drift,\n"
                                  "and suggest what to fix. (Optional - Enhance checks by itself.)")
        self.check_btn.clicked.connect(self.check_all)
        top.addWidget(QLabel("Folder:"))
        top.addWidget(self.folder_edit, 1)
        top.addWidget(browse)
        add_files = QPushButton("Add files…")
        add_files.setToolTip("Choose one or more video files (they're added to the list)")
        add_files.clicked.connect(self._add_files)
        top.addWidget(add_files)
        clear_files = QPushButton("Clear")
        clear_files.setToolTip("Empty the list (folder and added files)")
        clear_files.clicked.connect(self._clear_files)
        top.addWidget(clear_files)
        top.addWidget(self.recursive)
        top.addWidget(self.use_out)
        top.addWidget(self.check_btn)
        src.v.addLayout(top)
        self.extra_label = QLabel("", objectName="muted")
        src.v.addWidget(self.extra_label)
        lv.addWidget(src)

        self.tree = QTreeWidget()
        self.tree.setColumnCount(4)
        self.tree.setHeaderLabels(["Video", "Size", "Length", "Check"])
        self.tree.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tree.setAlternatingRowColors(True)
        self.tree.setRootIsDecorated(False)
        h = self.tree.header()
        h.resizeSection(0, 190)
        h.resizeSection(1, 75)
        h.resizeSection(2, 62)
        h.setStretchLastSection(True)
        self.tree.itemChanged.connect(self._item_changed)
        self.tree.currentItemChanged.connect(self._current_changed)
        self.preview = BeforeAfter()
        self.preview.rendered.connect(self._preview_rendered)
        hsplit = QSplitter(Qt.Horizontal)
        hsplit.addWidget(self.tree)
        hsplit.addWidget(self.preview)
        hsplit.setStretchFactor(0, 2)
        hsplit.setStretchFactor(1, 3)
        hsplit.setSizes([500, 600])
        self.log = QPlainTextEdit(readOnly=True)
        self.log.setMaximumBlockCount(2000)
        self.log.setPlaceholderText("Messages")
        split = QSplitter(Qt.Vertical)
        split.addWidget(hsplit)
        split.addWidget(self.log)
        split.setSizes([580, 80])
        lv.addWidget(split, 1)

        run = Card()
        rh = QHBoxLayout()
        self.taskbar = TaskBar(self.tm, "enhance")
        self.taskbar.hide()                 # progress is shown in the bar at the bottom and on the Tasks page
        rh.addStretch(1)
        self.open_btn = QPushButton("Open output folder")
        self.open_btn.clicked.connect(self._open_output)
        self.run_btn = QPushButton("Enhance selected", objectName="primary")
        self.run_btn.clicked.connect(self.enhance)
        rh.addWidget(self.open_btn)
        rh.addWidget(self.run_btn)
        run.v.addLayout(rh)
        lv.addWidget(run)
        root.addWidget(left, 1)

        # ---------- right: every setting visible
        d = EnhanceSettings()
        if not st("faces_off_v061", False):     # 0.6.1: face restoration is off by default (user's choice)
            self.feature.set_setting("faces", False)
            self.feature.set_setting("faces_off_v061", True)
        saved = {f.name: st(f.name, getattr(d, f.name)) for f in fields(EnhanceSettings)}
        col = SettingsColumn(410)
        P = col.add(Card("What to fix", "The global Quality (top left) decides how much AI; this decides what to fix"))
        from breezy.core.quality import CONTENT
        self.content = P.row("Content type:", combo(CONTENT, st("content", "general")),
                             "General: the Quality setting as it is.\n"
                             "Old film & VHS: deinterlace, crop borders, fix the picture shape, dust & specks,\n"
                             "  flicker, colourise black & white, repair distorted sound.\n"
                             "Phone & action camera: remove wind noise. (Stabilising, the wobble fix and\n"
                             "  levelling the horizon are on the Stabilizer page.)\n"
                             "Night & security camera: low-light AI (dark videos only), stronger noise removal,\n"
                             "  brighter shadows.\n"
                             "Upscale only (AI): just make it bigger with AI, change nothing else.")
        self.content.currentIndexChanged.connect(self._content_chosen)
        self.rec_label = P.note("Select a video to see what's recommended for it.")
        self.rec_label.setWordWrap(True)
        rw = QWidget()
        rh = QHBoxLayout(rw)
        rh.setContentsMargins(0, 0, 0, 0)
        self.rec_btn = QPushButton("Apply recommendation")
        self.rec_btn.setToolTip("Set the page to what's recommended for the selected video: its content type plus\n"
                                "the fixes its scan found (deinterlace, crop, low light, noise, shape, sound…),\n"
                                "at the strength of the global Quality setting")
        self.rec_btn.clicked.connect(self._apply_suggestions)
        self.rec_btn.setEnabled(False)
        rh.addWidget(self.rec_btn)
        rh.addStretch()
        P.full(rw)
        self.limit_h = P.row("Suggest a faster quality from:", spin(1, 72, int(st("suggest_limit_h", 8)), " h of work"),
                             "When the listed videos would take longer than this at the current global quality,\n"
                             "the recommendation suggests a faster level (it's never switched by itself).\n\n"
                             "When to use: 8 h fits one overnight run; lower it if you want results the same day,\n"
                             "raise it if you don't mind long jobs.")
        self.limit_h.valueChanged.connect(lambda v: (self.feature.set_setting("suggest_limit_h", int(v)),
                                                     self._update_rec()))
        self.auto_scan = P.full(check("Scan videos automatically when they're added", st("auto_scan", True),
                                      "Looks at every new video (interlacing, borders, darkness, noise, faces' shape,\n"
                                      "sound…) so recommendations are ready when you select it"))
        self.auto_scan.toggled.connect(lambda on: self.feature.set_setting("auto_scan", on))
        self._add(P, "auto_suggest", "", check("Adjust each video to its own scan automatically",
                                               saved["auto_suggest"],
                                               "When enhancing, every video gets the page settings plus what its own\n"
                                               "scan recommends (e.g. only dark videos get low-light AI)"))
        self.pc_label = P.note("")
        self.pc_label.setWordWrap(True)
        self.summary = P.note("")

        c = col.add(Card("Size & AI", "Bigger, sharper pictures"))
        self._add(c, "size", "Output size:", combo(SIZES, saved["size"]))
        ai_ok = ai.available("ai_fast"), ai.available("ai_best")
        self._add(c, "upscaler", "Upscaling:", combo(
            ([("AI - fast (good for video)", "ai_fast")] if ai_ok[0] else []) +
            ([("AI - best detail (very slow)", "ai_best")] if ai_ok[1] else []) +
            [("Classic (Lanczos, no AI)", "lanczos")], saved["upscaler"]),
            "AI rebuilds detail and removes compression mess; classic just resizes smoothly.\n"
            "With 'Same as source' size, AI still cleans up the picture (enhance only).")
        self._add(c, "ai_strength", "AI strength:", spin(10, 100, int(saved["ai_strength"]), " %", step=10),
                  "Lower mixes in a plain upscale - less 'painted' look, keeps more natural texture")
        self._add(c, "same_size_ai", "At 'Same as source' size:", combo([("AI clean-up", True), ("No AI", False)],
                                                                          saved["same_size_ai"]),
                  "AI clean-up upscales 4x and shrinks back - cleaner, but slow")
        self._add(c, "ai_skip_4k", "", check("Skip AI upscaling for videos already 4K", saved["ai_skip_4k"],
                                             "They get the classic clean-up instead (AI there is extremely slow)"))
        self.speed_note = c.note("")

        k = col.add(Card("Clean-up"))
        self._add(k, "deinterlace", "Deinterlace:", combo([("Automatic", "auto"), ("Always", "on"), ("Off", "off")],
                                                          saved["deinterlace"]),
                  "Removes the comb lines of old TV/camcorder video. Automatic = only when the check finds it")
        self._add(k, "crop", "Black borders:", combo([("Keep", "off"), ("Crop automatically", "auto")], saved["crop"]))
        from .filters import SHAPES
        self._add(k, "shape", "Picture shape:", combo(SHAPES, saved["shape"]),
                  "Fixes squashed or stretched video (e.g. old 4:3 video shown stretched to 16:9).\n"
                  "Automatic uses the file's pixel shape, or the shape of faces found by 'Check videos'")
        self._add(k, "shape_bars", "", check("Keep the frame size (add black bars)", saved["shape_bars"]))
        self._add(k, "denoise", "Remove noise/grain:", combo(LEVELS, saved["denoise"]))
        self._add(k, "denoise_method", "Noise removal method:", combo([("Fast", "hqdn3d"),
                                                                      ("Best quality (slow)", "nlmeans")],
                                                                     saved["denoise_method"]))
        self._add(k, "deblock", "Remove compression blocks:", combo(LEVELS, saved["deblock"]))
        self._add(k, "denoise_ai", "AI denoise (very slow):", spin(0, 100, int(saved["denoise_ai"]), " %", step=10),
                  "SCUNet AI removes noise and compression mess far better than the classic filters,\n"
                  "but is much slower. 0 = off")
        self._add(k, "denoise_ai_temporal", "AI denoise steadiness:", combo(LEVELS, saved["denoise_ai_temporal"]),
                  "Uses the previous frame (following the motion) so leftover noise doesn't crawl")
        self._add(k, "deband", "", check("Smooth out colour banding", saved["deband"]))
        self._add(k, "deflicker", "Remove flicker:", combo(LEVELS, saved["deflicker"]),
                  "Evens out brightness that pulses (fluorescent lights, timelapses, auto exposure)")
        self._add(k, "dehaze", "Remove haze / fog:", spin(0, 100, int(saved["dehaze"]), " %", step=10),
                  "Also helps with a dirty windshield or a washed-out picture")
        self._add(k, "dust", "Old film - dust & specks:", combo(LEVELS, saved["dust"]),
                  "Removes spots that appear for a single frame")
        self._add(k, "stutter_max", "Longest freeze to fix:", spin(1, 300, int(saved["stutter_max"]), " frames", step=1),
                  "Runs of repeated frames longer than this are treated as deliberate pauses and kept")
        self._add(k, "stutter", "Fix stutter:", combo([("Off", "off"), ("Rebuild frozen frames with AI", "ai"),
                                                       ("Rebuild by blending (fast)", "blend")], saved["stutter"]),
                  "Finds frames that repeat while the video should be moving (dropped frames, hiccups)\n"
                  "and replaces them with in-between frames. Deliberate pauses are kept")

        Ln = col.add(Card("Lens"))
        self._add(Ln, "lens", "Straighten fisheye bend:", spin(0, 100, int(saved["lens"]), " %", step=10),
                  "For wide-angle, action and dash cameras: makes bent lines straight again")
        self._add(Ln, "fringes", "Fix colour fringes:", spin(0, 100, int(saved["fringes"]), " %", step=10),
                  "Removes purple/green edges near the sides of the picture")
        self._add(Ln, "vignette", "Brighten dark corners:", spin(0, 100, int(saved["vignette"]), " %", step=10))

        L = col.add(Card("Light & colour"))
        self._add(L, "auto_levels", "Auto exposure:", spin(0, 100, int(saved["auto_levels"]), " %", step=10),
                  "Stretches each scene to use the full range from black to white (smoothly over time)")
        self._add(L, "white_balance", "", check("Auto white balance (remove colour casts)", saved["white_balance"]))
        self._add(L, "per_scene", "Fix lighting & colour per scene:", spin(0, 100, int(saved["per_scene"]), " %",
                                                                         step=10),
                  "Finds the cuts and gives every scene its own exposure and white balance\n"
                  "(replaces auto exposure and auto white balance above). 0 = off")
        self._add(L, "shadows", "Brighten shadows:", spin(0, 100, int(saved["shadows"]), step=5))
        self._add(L, "highlights", "Recover highlights:", spin(0, 100, int(saved["highlights"]), step=5))
        self._add(L, "brightness", "Brightness:", spin(-100, 100, int(saved["brightness"]), step=5))
        self._add(L, "contrast", "Contrast:", spin(-100, 100, int(saved["contrast"]), step=5))
        self._add(L, "midtones", "Midtones:", spin(-100, 100, int(saved["midtones"]), step=5),
                  "Brightens or darkens the middle greys without touching black and white")
        self._add(L, "saturation", "Saturation:", spin(-100, 100, int(saved["saturation"]), step=5))
        self._add(L, "vibrance", "Vibrance:", spin(0, 100, int(saved["vibrance"]), step=5),
                  "Boosts dull colours more than already-strong ones (skin stays natural)")
        self._add(L, "low_light", "Low-light AI:", spin(0, 100, int(saved["low_light"]), " %", step=10),
                  "Brightens night and dark footage with the Zero-DCE AI")
        self._add(L, "low_light_auto", "", check("Low-light AI only for dark videos (from the check)",
                                                 saved["low_light_auto"]))
        from .extras import BUILTIN_LUTS
        self._add(L, "lut", "Look (LUT):", combo([("None", "none")] + [(t, k) for k, t in BUILTIN_LUTS.items()] +
                                                 [("Custom .cube file…", "custom")], saved["lut"]))
        lw = QWidget()
        lh = QHBoxLayout(lw)
        lh.setContentsMargins(0, 0, 0, 0)
        self.lut_edit = QLineEdit(saved["lut_custom"])
        self.lut_edit.setPlaceholderText("Pick a .cube file…")
        lb = QPushButton("Browse…")
        lb.clicked.connect(self._browse_lut)
        lh.addWidget(self.lut_edit, 1)
        lh.addWidget(lb)
        L.row("Custom look file:", lw)
        self.lut_edit.editingFinished.connect(self._changed)
        self._add(L, "lut_strength", "Look strength:", spin(0, 100, int(saved["lut_strength"]), " %", step=10))
        self.colour_ref = list(saved["colour_ref"] or [])
        self.colour_ref_name = saved["colour_ref_name"]
        cw = QWidget()
        chh = QHBoxLayout(cw)
        chh.setContentsMargins(0, 0, 0, 0)
        self.ref_label = QLabel("", objectName="muted")
        use_ref = QPushButton("Use selected video")
        use_ref.setToolTip("Make every video's colours and brightness match the video selected in the list")
        use_ref.clicked.connect(self._use_colour_ref)
        clr_ref = QPushButton("Clear")
        clr_ref.clicked.connect(self._clear_colour_ref)
        chh.addWidget(self.ref_label, 1)
        chh.addWidget(use_ref)
        chh.addWidget(clr_ref)
        L.row("Match colours to:", cw)
        self._add(L, "colour_match_strength", "Match strength:", spin(0, 100, int(saved["colour_match_strength"]),
                                                                       " %", step=10))
        self._add(L, "hdr", "HDR:", combo([("Leave as is", "off"), ("Turn HDR videos into normal video (SDR)", "to_sdr"),
                                           ("Make HDR10 video", "to_hdr")], saved["hdr"]),
                  "SDR: for HDR phone videos that look washed out on normal screens (only changes HDR videos).\n"
                  "HDR10: for HDR TVs/screens - saved as 10-bit H.265. The preview shows it as normal video")

        X = col.add(Card("AI extras"))
        self._add(X, "faces", "", check("Restore faces", saved["faces"],
                                        "Rebuilds blurry faces with GFPGAN. Can change how people look a little -\n"
                                        "check the preview and lower the strength if needed"))
        self._add(X, "face_strength", "Face strength:", spin(10, 100, int(saved["face_strength"]), " %", step=10))
        self._add(X, "face_min", "Only faces at least:", spin(12, 400, int(saved["face_min"]), " px tall", step=4),
                  "Very small faces have too little detail to restore reliably")
        self._add(X, "colourise", "Colourise:", combo([("Off", "off"), ("Only black & white videos", "auto"),
                                                       ("Always", "on")], saved["colourise"]),
                  "Adds colour with the DDColor AI. 'Only black & white' uses the check result")
        self._add(X, "colour_strength", "Colour strength:", spin(10, 150, int(saved["colour_strength"]), " %", step=10))
        if not ai.faces_available():
            self.controls["faces"].setEnabled(False)
        if not ai.colour_available():
            self.controls["colourise"].setEnabled(False)

        Hd = col.add(Card("Hide & privacy"))
        # hidden areas are remembered per video (user's choice)
        self.areas_by_file: dict = dict(self.feature.setting("areas_by_file", {}) or {})
        aw = QWidget()
        ah = QHBoxLayout(aw)
        ah.setContentsMargins(0, 0, 0, 0)
        self.areas_label = QLabel("", objectName="muted")
        self.mark_btn = QPushButton("Mark on preview")
        self.mark_btn.setCheckable(True)
        self.mark_btn.setToolTip("Drag boxes on the preview around date stamps, clocks or logos")
        self.mark_btn.toggled.connect(self._mark_mode)
        clear_areas = QPushButton("Clear")
        clear_areas.clicked.connect(self._clear_areas)
        all_areas = QPushButton("Use on all videos")
        all_areas.setToolTip("Copy this video's boxes to every video in the list (same camera = same stamp)")
        all_areas.clicked.connect(self._areas_to_all)
        ah.addWidget(self.mark_btn)
        ah.addWidget(all_areas)
        ah.addWidget(clear_areas)
        ah.addStretch(1)
        Hd.row("Hide stamps / logos:", aw, "Each video remembers its own boxes - select a video, then mark")
        self.areas_label.setWordWrap(True)
        Hd.full(self.areas_label)
        self._add(Hd, "stamp_method", "Hide them by:", combo([("AI fill (looks like nothing was there)", "ai"),
                                                              ("Blur", "blur"), ("Black box", "box")],
                                                             saved["stamp_method"]))
        self._add(Hd, "privacy_faces", "", check("Blur faces", saved["privacy_faces"]))
        self._add(Hd, "privacy_plates", "", check("Blur licence plates", saved["privacy_plates"]))
        self._add(Hd, "privacy_style", "Blur style:", combo([("Blur", "blur"), ("Pixelate", "pixelate"),
                                                             ("Black box", "black")], saved["privacy_style"]))
        self._add(Hd, "remove_objects", "Remove from the video:", combo(
            [("Nothing", "off"), ("People", "people"), ("Vehicles", "vehicles"), ("People && vehicles", "people_vehicles"),
             ("Animals", "animals")], saved["remove_objects"]),
            "Finds them in every frame and fills the space so it looks like they were never there")
        self._add(Hd, "remove_method", "Fill the space with:", combo(
            [("Automatic (background while the camera is still, else AI)", "auto"), ("AI fill (any camera)", "ai"),
             ("Background from other frames (camera that doesn't move)", "background")],
            saved["remove_method"]),
            "Automatic checks every frame whether the camera moves: while it's still, the real background\n"
            "seen in other frames is used; while it moves, the AI fills the space")
        self._add(Hd, "remove_grow", "Extra margin:", spin(0, 60, int(saved["remove_grow"]), " px", step=2),
                  "Also covers edges and shadows (measured at 1080p)")
        self.preview.area_drawn.connect(self._area_drawn)

        D = col.add(Card("Detail & motion"))
        self._add(D, "sharpen", "Sharpen:", combo(LEVELS, saved["sharpen"]))
        self._add(D, "deblur", "AI deblur (very slow):", spin(0, 100, int(saved["deblur"]), " %", step=10),
                  "NAFNet AI removes blur from camera shake, movement or slightly missed focus.\n0 = off")
        self._add(D, "grain", "Add fine film grain:", combo(LEVELS, saved["grain"]),
                  "A touch of grain hides banding and makes cleaned-up video look natural")
        self._add(D, "frame_rate", "Frame rate:", combo([("Same as source", "same"), ("30 fps", "30"), ("60 fps", "60"),
                                                          ("Double", "double")], saved["frame_rate"]),
                  "Creates in-between frames for smoother motion")
        fr_opts = [("Automatic (the quality level decides)", "auto")] + \
            ([("AI (RIFE) - smoothest, slower", "rife")] if ai.rife_available() else []) + \
            [("Classic motion interpolation (slow)", "interpolate"), ("Blending (fast)", "blend")]
        self._add(D, "fr_choice", "New frames by:", combo(fr_opts, saved["fr_choice"]),
                  "How the in-between frames are made for a new frame rate or slow motion.\n"
                  "Automatic: AI-made frames on the levels from Max Quality to Balanced, blended frames on\n"
                  "Balanced Performance and the levels without AI. Your choice here is kept when the level changes.\n\n"
                  "When to use: AI for the smoothest motion (it can take longer than everything else at\n"
                  "Balanced), blending when speed matters, classic interpolation for a middle ground without AI.")
        self._add(D, "slowmo", "Slow motion:", combo([("Off", 1), ("2× slower", 2), ("4× slower", 4), ("8× slower", 8)],
                                                     int(saved["slowmo"])),
                  "Makes in-between frames so slowed-down video stays smooth")
        self._add(D, "slowmo_sound", "Slow-motion sound:", combo([("Slowed down (same pitch)", "slow"),
                                                                  ("No sound", "mute")], saved["slowmo_sound"]))

        A = col.add(Card("Sound"))
        self._add(A, "voice", "Clean up voices (AI):", combo([("Off", "off"), ("Standard", "std"),
                                                              ("Voices in noisy places", "sh"), ("Strong", "bd")],
                                                             saved["voice"]),
                  "RNNoise keeps speech and removes everything else. Not for music")
        from . import sound_ai
        self._add(A, "sound_ai", "Rebuild sound (AI):", combo([("Off", "off"), ("Only low-quality sound (16 kHz or less)", "auto"),
                                                               ("Always", "on")], saved["sound_ai"]),
                  "AP-BWE AI rebuilds the high tones missing from phone-like sound (like your 8 kHz clips)\n"
                  "and saves full 48 kHz sound")
        if not sound_ai.available():
            self.controls["sound_ai"].setEnabled(False)
        from . import separate
        self._add(A, "separate", "Voices & music (AI):", combo(separate.MODES, saved["separate"]),
                  "MDX-Net AI splits the voices from the music")
        self._add(A, "music_level", "Music kept:", spin(0, 100, int(saved["music_level"]), " %", step=5))
        if not separate.available():
            self.controls["separate"].setToolTip("The AI model is downloaded automatically (Settings → Repair)")
        self._add(A, "declip", "Repair distorted sound:", combo(LEVELS, saved["declip"]),
                  "Rebuilds sound that was recorded too loud (clipping); stronger also removes crackle")
        self._add(A, "wind", "Remove wind noise:", combo(LEVELS, saved["wind"]),
                  "Removes the rumble and gusts of wind on outdoor recordings")
        self._add(A, "stereo", "Widen sound:", spin(0, 100, int(saved["stereo"]), " %", step=10),
                  "Mono sound becomes gentle stereo; stereo gets wider")
        self._add(A, "audio_denoise", "Reduce background noise:", combo(LEVELS, saved["audio_denoise"]))
        self._add(A, "hum", "Remove electrical hum:", combo([("Off", "off"), ("50 Hz (Europe, Asia…)", "50"),
                                                             ("60 Hz (North America…)", "60")], saved["hum"]))
        self._add(A, "loudness", "", check("Even out the loudness", saved["loudness"]))
        self._add(A, "fix_drift", "", check("Fix audio drift (match the sound to the picture)", saved["fix_drift"]))
        self._add(A, "drift_threshold", "Count as drifting from:", spin(0.01, 5.0, float(saved["drift_threshold"]), " s",
                                                                       decimals=2, step=0.05))
        self._add(A, "audio_bitrate", "Sound bitrate:", combo(BITRATES, saved["audio_bitrate"]))

        X2 = col.add(Card("Extra outputs"))
        self._add(X2, "compare", "Before/after video:", combo([("Off", "off"), ("Side by side", "side"),
                                                               ("Split screen", "split")], saved["compare"]),
                  "Also makes '…_compare' showing the original and the result together")

        E = col.add(Card("Encoding"))
        self._add(E, "codec", "Video format:", combo([("Same as source", "same"), ("H.264 - plays everywhere", "h264"),
                                                      ("H.265 - smaller files", "hevc")], saved["codec"]))
        self._add(E, "size_mode", "File size:", combo([("Set by quality", "quality"), ("Aim for a size", "target")],
                                                      saved["size_mode"]),
                  "Aim for a size: e.g. under 25 MB for messaging apps - the quality is worked out automatically")
        self._add(E, "target_mb", "Target size:", spin(1, 100000, float(saved["target_mb"]), " MB", 1, 5))
        self.size_est = QLabel("-", objectName="muted")
        self.size_est.setWordWrap(True)
        E.row("Estimated size:", self.size_est,
              "A rough guess of the finished file's size with 'Set by quality' - for the selected video (or a minute\n"
              "of video when none is selected). Noise and motion change the real size a lot; the guess learns from\n"
              "your finished videos.\n\n"
              "When to use: to check a batch will fit on a drive, or whether to aim for a size instead.")
        self._enc_form = E.form
        QTimer.singleShot(0, self._update_size)          # once every control exists
        self._add(E, "crf", "Quality:", spin(0, 40, int(saved["crf"]), " CRF"),
                  "Lower = better quality, bigger file. 16 looks identical to the original")
        self._add(E, "ten_bit", "", check("10-bit colour (less banding; uses H.265)", saved["ten_bit"]))
        self._add(E, "enc_gpu", "Encoder:", combo([("Graphics card (faster)", True), ("Processor", False)],
                                                  saved["enc_gpu"]))

        R = col.add(Card("Performance"))
        self._add(R, "ai_gpu", "", check("Run the AI on the graphics card", saved["ai_gpu"]))
        self._add(R, "ai_half", "", check("Faster AI on newer NVIDIA cards (half precision)", saved["ai_half"],
                                          "Runs the big AI models (upscaling, AI deblur, AI noise clean-up) in half\n"
                                          "precision on NVIDIA cards that are fast at it (RTX 20xx and newer, GTX 16xx):\n"
                                          "usually 1.5-2x faster. Each model is checked once against full precision and\n"
                                          "used in full precision if the pictures would differ.\n\n"
                                          "When to use: leave on. Turn off only to compare, or if AI results look wrong."))
        self._add(R, "ai_reuse", "", check("Reuse AI results where the picture didn't change (fixed cameras)",
                                           saved["ai_reuse"],
                                           "The big AI models work on the picture in pieces. A piece that hasn't changed\n"
                                           "since its AI result was made keeps that result instead of running the AI again\n"
                                           "(every piece is still redone at least every 60 frames). On fixed cameras -\n"
                                           "security, tripod, webcam - often 2-5x faster; moving cameras gain nothing and\n"
                                           "lose nothing.\n\n"
                                           "When to use: leave on. Turn off if still areas look 'frozen' (e.g. fine noise\n"
                                           "or rain that stops moving)."))
        self._add(R, "hwaccel", "", check("Use the graphics card to decode video", saved["hwaccel"]))
        self._add(R, "gpu_filters", "", check("Use the graphics card for slow filters (best-quality noise removal)",
                                              saved["gpu_filters"],
                                              "Runs the 'best quality' noise filter on the graphics card (OpenCL)\n"
                                              "when this PC supports it - many times faster"))
        self._add(R, "tile", "AI tile size:", combo([("256 px (least memory)", 256), ("384 px", 384),
                                                     ("512 px", 512), ("768 px", 768),
                                                     ("1024 px (fastest, most memory)", 1024)],
                                                    int(saved["tile"])),
                  "The picture is processed in pieces this big. Smaller if the graphics card runs out of memory")
        self._add(R, "videos_at_once", "Videos at once:", combo(
            [("Automatic (2 with 8 GB+ graphics memory, 3 with 12 GB+)", "auto"), ("1", "1"), ("2", "2"), ("3", "3")],
            saved["videos_at_once"]),
            "Several videos on the graphics card together keep it fully busy. Needs enough graphics memory")
        self._add(R, "resume_parts", "", check("Long videos: keep the finished minutes if stopped", saved["resume_parts"],
                                               "Videos over 2 minutes are made in 1-minute parts. If the app is\n"
                                               "stopped (cancel, crash, power cut) it continues after the last\n"
                                               "finished part. (Not with new frames)"))

        self.out = col.add(OutputCard(self.feature, DEFAULT_FOLDER, [("name_pattern", "File name:", "{name}_enhanced")]))
        root.addWidget(col)
        self._update_summary()

    def _add(self, card: Card, key: str, label: str, w: QWidget, tip: str = ""):
        if label:
            card.row(label, w, tip)
        else:
            if tip:
                w.setToolTip(tip)
            card.full(w)
        self.controls[key] = w
        sig = (w.currentIndexChanged if isinstance(w, QComboBox) else w.toggled if isinstance(w, QCheckBox)
               else w.valueChanged)
        sig.connect(lambda *_: self._changed())
        return w

    # ============================================================ settings
    def _value(self, w):
        if isinstance(w, QComboBox):
            return w.currentData()
        if isinstance(w, QCheckBox):
            return w.isChecked()
        return w.value()

    def _set(self, w, v):
        if isinstance(w, QComboBox):
            i = w.findData(v)
            if i >= 0:
                w.setCurrentIndex(i)
        elif isinstance(w, QCheckBox):
            w.setChecked(bool(v))
        else:
            w.setValue(v)

    def settings(self) -> EnhanceSettings:
        vals = {k: self._value(w) for k, w in self.controls.items()}
        vals["fr_method"] = self.feature.setting("fr_method", "rife")      # set by the quality level
        vals["enc_speed"] = self.feature.setting("enc_speed", "balanced") # set by the quality level
        vals.update(stamps=[list(a) for a in self._areas()], colour_ref=list(getattr(self, "colour_ref", [])),
                    colour_ref_name=getattr(self, "colour_ref_name", ""),
                    lut_custom=self.lut_edit.text().strip() if hasattr(self, "lut_edit") else "")
        return EnhanceSettings(**vals)

    def _spec(self) -> dict:
        from breezy.core.quality import speed_class
        spec = self.settings().to_spec()
        return dict(spec, name_pattern=self.out.pattern("name_pattern"), learn_tag=speed_class(spec))

    def reload_settings(self):
        """The global Quality changed: show the new values."""
        self._applying = True
        for k, w in self.controls.items():
            v = self.feature.setting(k)
            if v is not None:
                self._set(w, v)
        self.content.blockSignals(True)
        self.content.setCurrentIndex(max(0, self.content.findData(self.feature.setting("content", "general"))))
        self.content.blockSignals(False)
        self._applying = False
        self._changed()

    def _content_chosen(self, *_):
        """Content type: the tier's settings plus what this kind of video needs fixed."""
        from breezy.core.quality import content_overlay, tier_values
        content = self.content.currentData()
        q = self.feature.context.quality
        self.feature.context.settings.set("enhance", "content", content)
        cur = q.current if q is not None else "custom"
        if cur != "custom":
            base = tier_values(cur, self.feature.context.settings).get("enhance", {})
            base.pop("content", None)
        else:
            base = {}
        vals = {**base, **content_overlay(content, {**self.settings().to_spec(), **base})}
        self._applying = True
        for k, v in vals.items():
            if k in self.controls:
                self._set(self.controls[k], v)
        self._applying = False
        if q is not None:
            q.applying = True
        try:
            self._changed()
        finally:
            if q is not None:
                q.applying = False
        self._say(f"Content type: {self.content.currentText()}")

    def _changed(self, from_preset: bool = False):
        if self._applying:
            return
        s = self.settings()
        for k, v in s.to_spec().items():
            self.feature.set_setting(k, v)
        has_ai = s.upscaler != "lanczos"
        self.controls["ai_strength"].setEnabled(has_ai)
        self.controls["tile"].setEnabled(has_ai)
        self.controls["ai_gpu"].setEnabled(has_ai)
        self.controls["denoise_method"].setEnabled(bool(s.denoise))
        self.controls["fr_choice"].setEnabled(s.frame_rate != "same")
        self.controls["face_strength"].setEnabled(s.faces)
        self.controls["face_min"].setEnabled(s.faces)
        self.controls["colour_strength"].setEnabled(s.colourise != "off")
        self.controls["lut_strength"].setEnabled(s.lut != "none")
        self.lut_edit.parentWidget().setEnabled(s.lut == "custom")
        self.controls["colour_match_strength"].setEnabled(bool(self.colour_ref))
        self.controls["low_light_auto"].setEnabled(bool(s.low_light))
        self.controls["slowmo_sound"].setEnabled(s.slowmo > 1)
        self.controls["denoise_ai_temporal"].setEnabled(bool(s.denoise_ai))
        self.controls["shape_bars"].setEnabled(s.shape != "off")
        self.controls["music_level"].setEnabled(s.separate == "quieter")
        for k in ("auto_levels", "white_balance"):
            self.controls[k].setEnabled(not s.per_scene)
        for k in ("remove_method", "remove_grow"):
            self.controls[k].setEnabled(s.remove_objects != "off")
        self.controls["target_mb"].setEnabled(s.size_mode == "target")
        self.controls["crf"].setEnabled(s.size_mode == "quality")
        self._update_size(s)
        self.controls["privacy_style"].setEnabled(s.privacy_faces or s.privacy_plates)
        self.controls["fr_choice"].setEnabled(s.frame_rate != "same" or s.slowmo > 1)
        n = len(self._areas())
        self.areas_label.setText(f"{n} area(s) on this video" if n else "none on this video")
        self.ref_label.setText(self.colour_ref_name or "off")
        self.preview.set_areas(self._areas())
        self.controls["drift_threshold"].setEnabled(s.fix_drift)
        self._update_summary()
        self._rebuild_tree(keep=True)
        self.preview.refresh()

    def _update_size(self, s: EnhanceSettings | None = None):
        """'Set by quality' shows the estimated size (Target size is hidden); 'Aim for a size' the reverse."""
        if not hasattr(self, "size_est"):
            return
        s = s or self.settings()
        by_quality = s.size_mode == "quality"
        try:
            self._enc_form.setRowVisible(self.controls["target_mb"], not by_quality)
            self._enc_form.setRowVisible(self.size_est, by_quality)
        except AttributeError:                     # older Qt: grey out instead
            self.controls["target_mb"].setEnabled(not by_quality)
        if not by_quality:
            return
        from types import SimpleNamespace
        from .render import estimate_size_mb
        p = self._rec_path() if hasattr(self, "_rec_path") else None
        info = self.infos.get(p) if p else None
        if info is not None and getattr(info, "video", None):
            mb = estimate_size_mb(info, s, self.checks.get(p, {}), self.feature.context.settings)
            what = p.name
        else:
            fake = SimpleNamespace(video=SimpleNamespace(width=1280, height=720, fps=30, duration=60, codec="h264",
                                                         sar=1.0), duration=60,
                                   audio=SimpleNamespace(channels=2, sample_rate=48000))
            mb = estimate_size_mb(fake, s, {}, self.feature.context.settings)
            what = "a minute of 720p video"
        if not mb:
            self.size_est.setText("-")
            return
        txt = f"{mb / 1024:.1f} GB" if mb >= 1024 else f"{mb:.0f} MB" if mb >= 10 else f"{mb:.1f} MB"
        learned = bool((self.feature.context.settings.get("app", "size_factor") or {}))
        self.size_est.setText(f"about {txt} for {what} (rough{'' if learned else ' - improves as videos finish'})")

    # ------------------------------------------------------------ recommendations
    def recommend(self, p: Path):
        """(content type, recommended settings, names of what changes) for a scanned video - the content type
        its scan suggests, the global Quality level's settings for it, and the fixes the scan found."""
        from breezy.core.quality import CONTENT, content_overlay, tier_values
        from .analysis import preset_for
        from .filters import apply_suggestions
        chk, info = self.checks.get(p), self.infos.get(p)
        if chk is None or info is None:
            return None
        cur_content = self.content.currentData()
        content = preset_for(info, chk) or cur_content
        if content not in dict((v, k) for k, v in CONTENT):
            content = cur_content
        q = self.feature.context.quality
        tier = q.current if q is not None else "custom"
        now = self.settings().to_spec()
        base = tier_values(tier, self.feature.context.settings).get("enhance", {}) if tier != "custom" else {}
        base = {k: v for k, v in base.items() if k != "content"}
        vals = {**now, **base}
        vals.update(content_overlay(content, vals))
        from breezy.core.quality import AI_USE, uses_ai
        use = AI_USE.get(tier) if tier in AI_USE else ("full" if vals.get("upscaler") != "lanczos"
                                                         else "light" if uses_ai(vals) else "none")
        rec = apply_suggestions(EnhanceSettings.from_spec(vals), info, chk, ai=use != "none",
                                upscale_ai=use == "full")
        changed = sorted(k for k, v in rec.to_spec().items() if now.get(k) != v and k in self.controls)
        return content, rec, changed

    def suggest_tier(self):
        """(tier key, reason) when another global Quality level would suit the scanned videos better, else None.
        Only a suggestion - nothing is applied."""
        from breezy.core.quality import TIERS, content_overlay, tier_values
        from .bench import estimate_minutes
        q = self.feature.context.quality
        if q is None:
            return None
        cur = q.current
        order = [k for _n, k in TIERS]
        names = dict((k, n) for n, k in TIERS)
        vids = [(f, self.infos.get(f), self.checks.get(f, {})) for f in getattr(self, "files", []) if f in self.checks]
        vids = [(f, i, c) for f, i, c in vids if i is not None and getattr(i, "video", None)]
        if not vids:
            return None
        content = self.content.currentData() or "general"
        st = self.feature.context.settings

        def settings_for(tier):
            vals = {**self.settings().to_spec(), **{k: v for k, v in tier_values(tier, st).get("enhance", {}).items()
                                                     if k != "content"}}
            vals.update(content_overlay(content, vals))
            return EnhanceSettings.from_spec(vals)

        bench = (self._hw() or {}).get("bench", {})
        from breezy.core.hardware import duration_text
        if bench:
            from breezy.core.quality import speed_class
            from .bench import learned_factor

            def total(tier):
                s = settings_for(tier)
                lf = learned_factor(st, speed_class(s.to_spec())) or 1.0
                mins = 0.0
                for _f, info, chk in vids:
                    m = estimate_minutes(s, make_plan(info, s, chk), bench)
                    if m is None:
                        return None
                    mins += m * max(info.duration or info.video.duration or 0, 1) / 60
                return mins * lf
            now = total(cur) if cur in order else None
            limit = float(self.feature.setting("suggest_limit_h", 8) or 8) * 60
            if now is not None and now > limit:
                start = order.index(cur) + 1 if cur in order else 0
                for t in order[start:]:
                    tt = total(t)
                    if tt is not None and tt <= limit:
                        return t, (f"{names[t]} - these videos would take {duration_text(now)} at the current "
                                   f"level, {duration_text(tt)} at {names[t]}")
                return order[-1], f"{names[order[-1]]} - these videos would take {duration_text(now)}"
        # old / small video gains the most from AI - the performance levels skip it
        from breezy.core.quality import AI_USE
        small = all(i.video.height <= 576 for _f, i, _c in vids)
        if small and AI_USE.get(cur) in ("none", "light"):
            return "high_quality", ("High Quality - old or small video gains the most from AI upscaling, "
                                    "which this level skips")
        return None

    def _update_rec(self):
        if not hasattr(self, "rec_label"):
            return
        p = self._rec_path()
        r = self.recommend(p) if p else None
        if r is None:
            self.rec_label.setText("Select a scanned video to see what's recommended for it."
                                   if self.checks else "Videos are scanned when added (or press 'Check videos').")
            self.rec_btn.setEnabled(False)
            return
        from breezy.core.quality import CONTENT
        content, rec, changed = r
        cname = dict((v, k) for k, v in CONTENT).get(content, content)
        same = content == self.content.currentData() and not changed
        tier = None
        try:
            tier = self.suggest_tier()
        except Exception:
            pass
        self.rec_label.setText(f"Recommended for {p.name}: {cname}"
                               + (" - the page already matches." if same else
                                  f" (changes {len(changed)} setting(s): {describe(rec)})")
                               + (f"\nGlobal quality: consider {tier[1]} (change it at the top of the sidebar)."
                                  if tier else ""))
        self.rec_btn.setEnabled(not same)

    def _apply_suggestions(self):
        p = self._rec_path()
        r = self.recommend(p) if p else None
        if r is None:
            QMessageBox.information(self, "Enhance", "Select a video that has been scanned first.")
            return
        content, rec, changed = r
        self.content.blockSignals(True)
        self.content.setCurrentIndex(max(0, self.content.findData(content)))
        self.content.blockSignals(False)
        self.feature.context.settings.set("enhance", "content", content)
        self._applying = True
        for k in changed:
            self._set(self.controls[k], getattr(rec, k))
        self._applying = False
        self._say(f"Applied the recommendation for {p.name}: {self.content.currentText()}"
                  + (f" + {', '.join(changed)}" if changed else ""))
        self._changed()
        self._update_rec()

    # ------------------------------------------------------------ extras
    def _browse_lut(self):
        f, _ = QFileDialog.getOpenFileName(self, "Look (LUT) file", self.lut_edit.text(), "3D LUT (*.cube)")
        if f:
            self.lut_edit.setText(f)
            self._set(self.controls["lut"], "custom")
            self._changed()

    def _use_colour_ref(self):
        p = self._current_path()
        chk = self.checks.get(p) if p else None
        if not p:
            QMessageBox.information(self, "Enhance", "Select the video whose colours the others should match.")
            return
        if not chk or not chk.get("rgb_stats"):
            QMessageBox.information(self, "Enhance", "Press 'Check videos' first, so the colours of this video "
                                                     "are known.")
            return
        self.colour_ref, self.colour_ref_name = list(chk["rgb_stats"]), p.name
        self._changed()

    def _clear_colour_ref(self):
        self.colour_ref, self.colour_ref_name = [], ""
        self._changed()

    def _mark_mode(self, on: bool):
        self.preview.set_mark_mode(on)
        if on and not self.preview.make_fn:
            self._say("Select a video first, then drag boxes on its preview.")

    def _areas(self) -> list:
        p = self._current_path() if hasattr(self, "tree") else None
        return list(self.areas_by_file.get(str(p), [])) if p else []

    def _save_areas(self):
        self.areas_by_file = {k: v for k, v in self.areas_by_file.items() if v}
        self.feature.set_setting("areas_by_file", self.areas_by_file)

    def _areas_to_all(self):
        cur = self._areas()
        if not cur:
            QMessageBox.information(self, "Enhance", "Select a video and mark its areas first.")
            return
        for p in self.files:
            self.areas_by_file[str(p)] = [list(a) for a in cur]
        self._save_areas()
        self._say(f"Copied {len(cur)} area(s) to all {len(self.files)} video(s).")
        self._changed()

    def _area_drawn(self, area: list):
        p = self._current_path()
        if not p:
            return
        self.areas_by_file.setdefault(str(p), []).append(area)
        self._save_areas()
        self._changed()

    def _clear_areas(self):
        p = self._current_path()
        if p:
            self.areas_by_file.pop(str(p), None)
            self._save_areas()
        self.mark_btn.setChecked(False)
        self._changed()

    def _update_summary(self):
        self.summary.setText("Will do: " + describe(self.settings()))
        self._update_pc()

    # ------------------------------------------------------------ this PC
    def _hw(self) -> dict:
        return self.feature.context.settings.get("app", "hardware") or {}

    def _update_pc(self):
        self._update_rec()
        if not hasattr(self, "pc_label"):
            return
        hw = self._hw()
        if not hw:
            self.pc_label.setText("Your PC hasn't been scanned yet (Settings → Your PC).")
            return
        from .bench import estimate_minutes
        from types import SimpleNamespace
        s = self.settings()
        p = self._current_path()
        info = self.infos.get(p) if p else None
        if info is not None and info.video:
            plan, what = make_plan(info, s, self.checks.get(p, {})), p.name
        else:
            fake = SimpleNamespace(video=SimpleNamespace(width=720, height=480, fps=30, duration=60, codec="h264",
                                                         sar=1.0), duration=60, audio=None)
            plan, what = make_plan(fake, s, {}), "a 720x480 video"
        m = estimate_minutes(s, plan, hw.get("bench", {}))
        from breezy.core.quality import speed_class
        from .bench import learned_factor
        lf = learned_factor(self.feature.context.settings, speed_class(s.to_spec()))
        if m and lf:
            m *= lf
        rec = hw.get("rec", {})
        gpu = ", ".join(g["name"] for g in hw.get("hw", {}).get("gpus", [])) or "no graphics card"
        from breezy.core.hardware import duration_text
        t = duration_text(m or 0)
        self.pc_label.setText(f"Your PC: {gpu} - {rec.get('text', '')}.\n"
                              f"These settings: {t} of work per minute of {what} (estimate"
                              + (", corrected by how fast earlier Enhance tasks went" if lf else "") + ").")

    def hardware_scanned(self, result: dict):
        self._say("Your PC was scanned: " + (result.get("rec", {}).get("text", "") or "done"))
        self._update_pc()

    # ============================================================== helpers
    def _say(self, msg: str):
        self.log.appendPlainText(msg)

    def _busy(self) -> bool:
        t = self.tm.get(self.check_task_id) if self.check_task_id else None
        return bool(t and t.status in ("queued", "running", "paused"))

    def _update_buttons(self):
        self.check_btn.setEnabled(not self._busy())
        self.run_btn.setEnabled(bool(self._selected()))
        self.open_btn.setEnabled(True)
        n = len(self.extra_files)
        self.extra_label.setText(f"+ {n} added file(s)" if n else "")
        self.extra_label.setVisible(bool(n))

    def _browse_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Folder of videos", self.folder_edit.text())
        if d:
            self.folder_edit.setText(d)
            self._gather_and_list()

    def _open_output(self):
        from breezy.core.ui import open_module_output
        open_module_output(self, self.tm, "enhance", self.out, self.files[0] if self.files else None)

    def _selected(self) -> list[Path]:
        return [p for p in self.files if p not in self.unchecked]

    # ======================================================= output linking
    def _add_files(self):
        from breezy.core.ui import pick_videos
        files = pick_videos(self, self.folder_edit.text().strip())
        if files:
            self._add_paths(files)

    def _clear_files(self):
        self.folder_edit.setText("")
        self.extra_files = []
        self.removed = set()
        self._gather_and_list()
        self._update_buttons()

    # ------------------------------------------------------------ drag & drop, list menu
    def _install_tools(self):
        from breezy.core.ui import install_drop, install_list_tools
        install_drop(self, self._drop_folder, self._add_paths)
        install_list_tools(self.tree, self._path_of_item, self._remove_paths, self._gather_and_list)

    def _path_of_item(self, it):
        d = it.data(0, ROLE) if it else None
        return Path(d) if isinstance(d, str) else None

    def _drop_folder(self, d):
        self.folder_edit.setText(str(d))
        self._gather_and_list()

    def _add_paths(self, files):
        self.extra_files += [f for f in files if f not in self.extra_files]
        self.removed = getattr(self, "removed", set()) - set(files)
        self._gather_and_list()
        self._say(f"Added {len(files)} file(s).")
        self._update_buttons()

    def _remove_paths(self, paths):
        self.removed = getattr(self, "removed", set()) | set(paths)
        self.extra_files = [f for f in self.extra_files if f not in paths]
        self._gather_and_list()
        self._say(f"Removed {len(paths)} file(s) from the list (nothing is deleted).")
        self._update_buttons()

    def _use_output(self):
        dlg = OutputPicker(self.tm, self, "enhance")
        if not dlg.exec():
            return
        files, future = dlg.selection()
        if files:
            self.extra_files += [Path(f) for f in files if Path(f) not in self.extra_files]
            self._gather_and_list()
            self._say(f"Added {len(files)} file(s).")
        for tid in future:
            self._queue_auto(tid)
        self._update_buttons()

    def _queue_auto(self, task_id: str):
        out = output_spec(self.ctx.settings, "enhance", DEFAULT_FOLDER, self, self.out.values())
        if out is None:
            return
        src = self.tm.get(task_id)
        name = src.title if src else task_id
        t = Task("enhance.auto", "enhance", f"Enhance output of '{name}'", spec=dict(self._spec(), output=out, stamps=[]),
                 input_from=task_id)
        self.tm.submit(t)
        self._say(f"Queued: enhance the files from '{name}' when it finishes (current settings).")

    # ================================================================ files
    def _gather_files(self) -> list[Path]:
        text = self.folder_edit.text().strip()
        folder = Path(text) if text else None
        files = []
        if folder and folder.is_dir():
            it = folder.rglob("*") if self.recursive.isChecked() else folder.glob("*")
            skip = {self.out.values()["folder"].lower(), "breezy output"}
            pat = self.out.pattern("name_pattern")
            tail = pat.split("{name}", 1)[1] if pat.startswith("{name}") and pat != "{name}" else ""
            files = sorted(p for p in it if p.is_file() and p.suffix.lower() in VIDEO_EXTS
                           and not (set(x.lower() for x in p.relative_to(folder).parts[:-1]) & skip)
                           and not (tail and p.stem.endswith(tail)))
        removed = getattr(self, "removed", set())
        return [p for p in files if p not in removed] + \
            [p for p in self.extra_files if p not in files and p.is_file() and p not in removed]

    def _gather_and_list(self, *_):
        self.feature.set_setting("last_folder", self.folder_edit.text().strip())
        self.feature.set_setting("recursive", self.recursive.isChecked())
        self.files = self._gather_files()
        cache = load_cache(cache_file())
        for p in self.files:
            if p not in self.infos and self.ff.available:
                self.infos[p] = self.ff.probe(p)
            info = self.infos.get(p)
            if info and p not in self.checks:
                from .analysis import _cache_key
                hit = cache.get(_cache_key(info))
                if hit:
                    self.checks[p] = hit
        self._rebuild_tree()
        if getattr(self, "auto_scan", None) is not None and self.auto_scan.isChecked() and self.ff.available:
            todo = [p for p in self.files if p not in self.checks and self.infos.get(p) and not self.infos[p].error]
            running = self.check_task_id and (self.tm.get(self.check_task_id) or None)
            if todo and not (running and running.status in ("queued", "running")):
                QTimer.singleShot(0, lambda: self.check_all(quiet=True))

    def check_all(self, quiet: bool = False):
        if not self.ff.available:
            if not quiet:
                QMessageBox.warning(self, "Enhance", "FFmpeg was not found. See the Settings page.")
            return
        if not quiet:
            self._gather_and_list()
        if not self.files:
            if quiet:
                return
            QMessageBox.information(self, "Enhance", "No videos found. Choose a folder, or add files with "
                                                     "'Use output from…'.")
            return
        todo = [p for p in self.files if p not in self.checks]
        if not todo:
            if not quiet:
                self._say("All videos are already checked.")
            return
        t = self.tm.submit(Task("enhance.check", "enhance", f"Scan {len(todo)} video(s) for Enhance",
                                spec={"files": [str(p) for p in todo]}, resumable=False, media=False))
        self.check_task_id = t.id
        self.taskbar.follow(t.id)
        self._say(f"Checking {len(todo)} video(s)…")
        self._update_buttons()

    def _task_finished(self, task_id: str):
        t = self.tm.get(task_id)
        if not t or t.module != "enhance":
            return
        if task_id == self.check_task_id:
            res = self.tm.results.pop(task_id, None)
            if res:
                self.checks.update({Path(k): v for k, v in res.items()})
                n = sum(1 for v in res.values() if v.get("suggest"))
                self._say(f"Scanned {len(res)} video(s); {n} with recommendations (see the Check column).")
            self._rebuild_tree(keep=True)
            self._update_rec()
            cur = self._current_path()
            if cur:
                self._show_preview(cur)
        elif t.kind in ("enhance.run", "enhance.auto"):
            msg = f"{t.title}: {len(t.outputs)} file(s) made"
            if t.errors:
                msg += f"; {len(t.errors)} failed: " + "; ".join(t.errors[:5])
            if t.status == "cancelled":
                msg += " - cancelled"
            self._say(msg)
            self.feature.set_setting("last_outputs", list(t.outputs))
        self._update_buttons()

    # ================================================================= tree
    def _rec_path(self):
        """The selected video, or the first scanned one when nothing is selected."""
        p = self._current_path()
        if p is not None:
            return p
        return next((f for f in getattr(self, "files", []) if f in self.checks), None)

    def _current_path(self):
        it = self.tree.currentItem()
        d = it.data(0, ROLE) if it else None
        return Path(d) if isinstance(d, str) else None

    def _rebuild_tree(self, keep: bool = False):
        c = theme.colors()
        cur = self._current_path()
        s = self.settings()
        self.tree.blockSignals(True)
        self.tree.clear()
        select = None
        for p in self.files:
            info = self.infos.get(p)
            it = QTreeWidgetItem(self.tree)
            it.setData(0, ROLE, str(p))
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(0, Qt.Unchecked if p in self.unchecked else Qt.Checked)
            it.setText(0, p.name)
            it.setToolTip(0, str(p))
            if info and info.video:
                ana = self.checks.get(p, {})
                plan = make_plan(info, s, ana)
                it.setText(1, f"{info.video.width}x{info.video.height}")
                it.setToolTip(1, f"Result: {plan.out_w}x{plan.out_h}")
                it.setText(2, _dur(info.duration))
            elif info and info.error:
                it.setText(3, info.error)
                it.setForeground(3, QBrush(QColor(c["warn"])))
            chk = self.checks.get(p)
            if chk is not None:
                text = "; ".join(chk.get("suggest", [])) or "looks fine"
                it.setText(3, text)
                it.setToolTip(3, text)
                if chk.get("suggest"):
                    it.setForeground(3, QBrush(QColor(c["warn"])))
            elif info and not info.error:
                it.setText(3, "not checked yet")
                it.setForeground(3, QBrush(QColor(c["muted"])))
            if p == cur:
                select = it
        self.tree.blockSignals(False)
        if select is not None:
            self.tree.blockSignals(True)
            self.tree.setCurrentItem(select)
            self.tree.blockSignals(False)
        elif not keep:
            self.preview.clear()
        self._update_buttons()

    def theme_changed(self):
        self._rebuild_tree(keep=True)

    def _item_changed(self, item: QTreeWidgetItem, _col: int):
        key = item.data(0, ROLE)
        if not isinstance(key, str):
            return
        p = Path(key)
        if item.checkState(0) == Qt.Checked:
            self.unchecked.discard(p)
        else:
            self.unchecked.add(p)
        self._update_buttons()

    def _current_changed(self, *_):
        self._update_pc()
        self._update_size()
        p = self._current_path()
        if p:
            n = len(self._areas())
            self.areas_label.setText(f"{n} area(s) on this video" if n else "none on this video")
            self.preview.set_areas(self._areas())
            self._show_preview(p)

    def _show_preview(self, p: Path):
        info = self.infos.get(p)
        if not info or info.error or not info.video:
            self.preview.clear(f"Can't preview: {info.error if info else 'unreadable'}")
            return
        ff = self.ff

        def make(t, use_ai, p=p, info=info):
            ana, s = dict(self.checks.get(p, {})), self.settings()      # snapshot on the UI thread
            return lambda: Enhancer(ff).preview(info, s, ana, t, max_w=1920, use_ai=use_ai)
        cur_t = self.preview.slider.value() / 10 if self.preview.make_fn and \
            self.preview.title.text().find(p.name) >= 0 else None
        self.preview.set_video(p.name, info.video.duration or info.duration, make, cur_t)

    def _preview_rendered(self, ai_sec):
        p = self._current_path()
        info = self.infos.get(p) if p else None
        s = self.settings()
        chk = self.checks.get(p) if p else None
        if chk is not None:
            self.preview.status.setText(self.preview.status.text() + " · check: " +
                                        ("; ".join(chk.get("suggest", [])) or "looks fine"))
        if ai_sec and info and info.video:
            sec, where = ai_sec
            frames = (info.video.duration or info.duration) * float(info.video.fps or 30)
            self.speed_note.setText(f"AI took {sec:.1f} s for this frame on the {where} → about "
                                    f"{_fmt_time(sec * frames)} for this video.")
        elif s.upscaler == "lanczos":
            self.speed_note.setText("")

    # ================================================================ enhance
    def enhance(self):
        self.files = self._gather_files()
        sel = self._selected()
        if not sel:
            return
        s = self.settings()
        if s.upscaler != "lanczos" and not ai.available(s.upscaler):
            QMessageBox.warning(self, "Enhance", "The AI models are missing from this install.")
            return
        big = [p for p in sel if self.infos.get(p) and self.infos[p].video and self.infos[p].video.height >= 2000]
        if s.upscaler != "lanczos" and not s.ai_skip_4k and big:
            r = QMessageBox.question(self, "Enhance",
                                     f"{len(big)} of the selected videos are already 4K or larger. AI on them is "
                                     "extremely slow and the result would be huge.\n\nContinue anyway?")
            if r != QMessageBox.Yes:
                return
        out = output_spec(self.ctx.settings, "enhance", DEFAULT_FOLDER, self, self.out.values())
        if out is None:
            return
        title = f"Enhance {len(sel)} video(s)" if len(sel) > 1 else f"Enhance {sel[0].name}"
        spec = dict(self._spec(), files=[str(p) for p in sel], output=out, stamps=[],
                    stamps_by_file={str(p): self.areas_by_file.get(str(p), []) for p in sel})
        t = self.tm.submit(Task("enhance.run", "enhance", title, spec=spec))
        self.taskbar.follow(t.id)
        self._say(f"Queued: {title} ({describe(s)}).")
        self._update_buttons()
