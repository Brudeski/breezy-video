"""Separate voices from music with the MDX-Net AI (UVR-MDX-NET Voc FT, ONNX).

The model takes the stereo spectrogram (n_fft 7680, hop 1024, 3072 bands, 256 steps ≈ 6 s at 44.1 kHz)
and returns the voices' spectrogram; the music is the mix minus the voices.
"""
from __future__ import annotations

import wave
from pathlib import Path
from typing import Callable

import numpy as np

from breezy.features.tracker.detector import models_dir

MODEL = "UVR-MDX-NET-Voc_FT.onnx"
RATE = 44100
N_FFT, HOP, DIM_F, DIM_T = 7680, 1024, 3072, 256
COMPENSATE = 1.021                 # UVR's level correction for this model
CHUNK = HOP * (DIM_T - 1)          # samples per model run
TRIM = N_FFT // 2
GEN = CHUNK - 2 * TRIM             # useful samples per run (the edges are thrown away)
MODES = [("Off", "off"), ("Keep voices only (remove music)", "voices"),
         ("Turn the music down", "quieter"), ("Keep music only (remove voices)", "music")]


def available() -> bool:
    return (models_dir() / MODEL).is_file()


def _window() -> np.ndarray:
    n = np.arange(N_FFT)
    return (0.5 - 0.5 * np.cos(2 * np.pi * n / N_FFT)).astype(np.float32)   # periodic Hann


def stft(x: np.ndarray) -> np.ndarray:
    """(channels, samples) -> (channels, bins, frames) complex, like torch.stft(center=True, reflect)."""
    w = _window()
    xp = np.pad(x, ((0, 0), (N_FFT // 2, N_FFT // 2)), mode="reflect")
    n = 1 + (xp.shape[1] - N_FFT) // HOP
    idx = np.arange(N_FFT)[None, :] + HOP * np.arange(n)[:, None]
    frames = xp[:, idx] * w                                # (ch, frames, n_fft)
    return np.fft.rfft(frames, axis=-1).transpose(0, 2, 1)


def istft(spec: np.ndarray, length: int) -> np.ndarray:
    """Inverse of stft() (overlap-add with the squared-window normalisation)."""
    w = _window()
    frames = np.fft.irfft(spec.transpose(0, 2, 1), n=N_FFT, axis=-1) * w   # (ch, frames, n_fft)
    n = frames.shape[1]
    total = N_FFT + HOP * (n - 1)
    out = np.zeros((spec.shape[0], total), np.float64)
    norm = np.zeros(total, np.float64)
    for i in range(n):
        out[:, i * HOP:i * HOP + N_FFT] += frames[:, i]
        norm[i * HOP:i * HOP + N_FFT] += w * w
    out /= np.maximum(norm, 1e-8)
    return out[:, N_FFT // 2:N_FFT // 2 + length]


class Separator:
    def __init__(self, use_gpu: bool = True):
        from .ai import _session
        self.session = _session(models_dir() / MODEL, use_gpu)

    def vocals(self, mix: np.ndarray, progress: Callable[[float], None] = lambda f: None,
               cancel: Callable[[], None] = lambda: None) -> np.ndarray:
        """mix: (2, samples) float32 at 44.1 kHz -> the voices, same shape."""
        n = mix.shape[1]
        pad = GEN - n % GEN
        mp = np.concatenate([np.zeros((2, TRIM), np.float32), mix, np.zeros((2, pad + TRIM), np.float32)], axis=1)
        starts = list(range(0, n + pad, GEN))
        out = []
        for k, i in enumerate(starts):
            cancel()
            spec = stft(mp[:, i:i + CHUNK])[:, :DIM_F]                    # (2, 3072, 256)
            x = np.stack([spec.real, spec.imag], axis=1).reshape(1, 4, DIM_F, DIM_T).astype(np.float32)
            y = self.session.run(None, {self.session.get_inputs()[0].name: x})[0].reshape(2, 2, DIM_F, DIM_T)
            full = np.zeros((2, N_FFT // 2 + 1, DIM_T), np.complex64)
            full[:, :DIM_F] = y[:, 0] + 1j * y[:, 1]
            wav = istft(full, CHUNK)
            out.append(wav[:, TRIM:CHUNK - TRIM])
            progress((k + 1) / len(starts))
        return (np.concatenate(out, axis=1)[:, :n] * COMPENSATE).astype(np.float32)


def mix_for(mode: str, music_level: int, mix: np.ndarray, voc: np.ndarray) -> np.ndarray:
    music = mix - voc
    if mode == "voices":
        return voc
    if mode == "music":
        return music
    return voc + music * (music_level / 100)


def separate_file(ffmpeg, src: Path, dst_wav: Path, mode: str, music_level: int, af_before: list[str],
                  use_gpu: bool = True, progress=lambda f: None, cancel=lambda: None) -> None:
    """Decode the sound (with the given filters, e.g. drift fix) to 44.1 kHz stereo, separate, write a WAV."""
    from breezy.core import proc
    chain = ",".join(af_before + [f"aresample={RATE}"])
    r = proc.run([ffmpeg.ffmpeg, "-v", "error", "-nostdin", "-i", str(src), "-map", "0:a:0", "-af", chain,
                  "-ac", "2", "-f", "f32le", "-"], timeout=None)
    if r.returncode != 0 or not r.stdout:
        raise RuntimeError("couldn't read the sound")
    mix = np.frombuffer(r.stdout, np.float32).reshape(-1, 2).T.copy()
    voc = Separator(use_gpu).vocals(mix, progress, cancel)
    out = mix_for(mode, music_level, mix, voc)
    pcm = (np.clip(out.T, -1, 1) * 32767).astype(np.int16)
    with wave.open(str(dst_wav), "wb") as w:
        w.setnchannels(2)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(pcm.tobytes())
