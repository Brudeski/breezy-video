"""Per-frame and frame-sequence helpers for Enhance's extra features (0.7.0).

Per frame:  dust (needs neighbours), stamps/logos, dehaze, low light (Zero-DCE), colour fringes,
            horizon levelling, privacy blur (faces + licence plates)
Sequence:   stutter repair (rebuild frozen/duplicated frames), retiming (RIFE frame rate / slow motion)
"""
from __future__ import annotations

import math
from collections import deque
from pathlib import Path
from typing import Callable, Iterator, Optional

import numpy as np

from breezy.features.tracker.detector import models_dir

LOWLIGHT_MODEL = "zero_dce.onnx"
LAMA_MODEL = "lama_fp32.onnx"
PLATE_MODEL = "license_plate_yolov11n.onnx"


def _cv2():
    import cv2
    return cv2


def have(name: str) -> bool:
    return (models_dir() / name).is_file()


def _session(name: str, use_gpu: bool, tile: int = 0):
    from .ai import _session as s
    return s(models_dir() / name, use_gpu, tile)


# ------------------------------------------------------------------ dust
class DustRemover:
    """Old film dust/specks: a pixel that differs strongly from BOTH neighbouring frames, while those
    two agree with each other, is a one-frame speck - replace it with the neighbours' value."""

    def __init__(self, level: int):
        self.thr = {1: 45, 2: 32, 3: 22}.get(level, 32)

    def clean(self, prev: np.ndarray, cur: np.ndarray, nxt: np.ndarray) -> np.ndarray:
        cv2 = _cv2()
        p, c, n = (x.astype(np.int16) for x in (prev, cur, nxt))
        agree = np.abs(p - n).max(axis=2) < self.thr // 2
        odd = (np.abs(c - p).max(axis=2) > self.thr) & (np.abs(c - n).max(axis=2) > self.thr)
        mask = (agree & odd).astype(np.uint8)
        if not mask.any():
            return cur
        mask = cv2.dilate(mask, np.ones((3, 3), np.uint8))
        fill = ((p + n) // 2).astype(np.uint8)
        out = cur.copy()
        out[mask.astype(bool)] = fill[mask.astype(bool)]
        return out


def dust_stream(frames: Iterator[np.ndarray], level: int) -> Iterator[np.ndarray]:
    d = DustRemover(level)
    buf: deque = deque(maxlen=3)
    first = True
    for f in frames:
        buf.append(f)
        if len(buf) == 2 and first:
            first = False
            yield buf[0]
        elif len(buf) == 3:
            yield d.clean(buf[0], buf[1], buf[2])
    if len(buf) == 1:
        yield buf[0]
    elif len(buf) >= 2:
        yield buf[-1]


# ----------------------------------------------------------- stamps / logos
class StampRemover:
    """Hides fixed areas (date stamps, logos): AI fill (LaMa), blur or a black box.
    boxes: [x, y, w, h] as fractions of the (cropped) picture."""

    def __init__(self, boxes: list, method: str, use_gpu: bool = True):
        self.boxes, self.method = boxes, method
        self.session = _session(LAMA_MODEL, use_gpu) if method == "ai" and have(LAMA_MODEL) else None
        if method == "ai" and self.session is None:
            self.method = "blur"

    def _px(self, b, w, h):
        x0, y0 = int(b[0] * w), int(b[1] * h)
        x1, y1 = int(math.ceil((b[0] + b[2]) * w)), int(math.ceil((b[1] + b[3]) * h))
        return max(0, x0), max(0, y0), min(w, x1), min(h, y1)

    def apply(self, rgb: np.ndarray) -> np.ndarray:
        cv2 = _cv2()
        h, w = rgb.shape[:2]
        out = rgb.copy()
        for b in self.boxes:
            x0, y0, x1, y1 = self._px(b, w, h)
            if x1 - x0 < 2 or y1 - y0 < 2:
                continue
            if self.method == "box":
                out[y0:y1, x0:x1] = 0
            elif self.method == "blur":
                k = max(3, (max(x1 - x0, y1 - y0) // 3) | 1)
                out[y0:y1, x0:x1] = cv2.GaussianBlur(out[y0:y1, x0:x1], (k, k), 0)
            else:
                out = self._inpaint(out, x0, y0, x1, y1)
        return out

    def _inpaint(self, img, x0, y0, x1, y1):
        cv2 = _cv2()
        h, w = img.shape[:2]
        bw, bh = x1 - x0, y1 - y0
        side = int(min(max(256, 2.2 * max(bw, bh)), max(w, h)))
        cx, cy = (x0 + x1) // 2, (y0 + y1) // 2
        ax0 = int(min(max(0, cx - side // 2), max(0, w - side)))
        ay0 = int(min(max(0, cy - side // 2), max(0, h - side)))
        ax1, ay1 = min(w, ax0 + side), min(h, ay0 + side)
        crop = img[ay0:ay1, ax0:ax1]
        mask = np.zeros(crop.shape[:2], np.float32)
        mask[max(0, y0 - ay0 - 2):y1 - ay0 + 2, max(0, x0 - ax0 - 2):x1 - ax0 + 2] = 1
        ci = cv2.resize(crop, (512, 512), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        cm = (cv2.resize(mask, (512, 512), interpolation=cv2.INTER_NEAREST) > 0.5).astype(np.float32)
        y = self.session.run(None, {"image": ci.transpose(2, 0, 1)[None], "mask": cm[None, None]})[0][0]
        y = y.transpose(1, 2, 0)
        if y.max() > 2:            # some exports return 0..255
            y = y / 255
        fill = cv2.resize(np.clip(y, 0, 1), (ax1 - ax0, ay1 - ay0), interpolation=cv2.INTER_CUBIC) * 255
        soft = cv2.GaussianBlur(mask, (0, 0), 2)[:, :, None]
        out = img.copy()
        out[ay0:ay1, ax0:ax1] = (crop * (1 - soft) + fill * soft).astype(np.uint8)
        return out


# ------------------------------------------------------------------ dehaze
def _guided(I: np.ndarray, p: np.ndarray, r: int, eps: float) -> np.ndarray:
    cv2 = _cv2()
    box = lambda x: cv2.boxFilter(x, -1, (r, r))  # noqa: E731
    mI, mp = box(I), box(p)
    a = (box(I * p) - mI * mp) / (box(I * I) - mI * mI + eps)
    b = mp - a * mI
    return box(a) * I + box(b)


class Dehazer:
    """Dark-channel-prior dehazing on a small copy (for speed), refined with a guided filter;
    the haze colour is smoothed over time so the picture doesn't pump."""

    def __init__(self, strength: int):
        self.s = strength / 100
        self.A = None

    def apply(self, rgb: np.ndarray) -> np.ndarray:
        cv2 = _cv2()
        h, w = rgb.shape[:2]
        sc = min(1.0, 640 / max(w, h))
        small = cv2.resize(rgb, (int(w * sc), int(h * sc)), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        dark = cv2.erode(small.min(axis=2), np.ones((15, 15), np.uint8))
        flat = dark.ravel()
        n = max(1, int(flat.size * 0.001))
        idx = np.argpartition(flat, -n)[-n:]
        A = small.reshape(-1, 3)[idx].mean(axis=0)
        self.A = A if self.A is None else 0.95 * self.A + 0.05 * A
        A = np.maximum(self.A, 0.05)
        t = 1 - 0.95 * self.s * cv2.erode((small / A).min(axis=2), np.ones((15, 15), np.uint8))
        gray = cv2.cvtColor(small, cv2.COLOR_RGB2GRAY)
        t = np.clip(_guided(gray, t.astype(np.float32), 31, 1e-3), 0.12, 1)
        t = cv2.resize(t, (w, h), interpolation=cv2.INTER_LINEAR)[:, :, None]
        img = rgb.astype(np.float32) / 255
        J = (img - A) / t + A
        return (np.clip(J, 0, 1) * 255 + 0.5).astype(np.uint8)


# --------------------------------------------------------------- low light
class LowLight:
    """Zero-DCE low-light enhancement (run on a smaller copy; the brightening curve is applied as a
    per-pixel gain at full size so detail stays sharp), mixed in by strength."""

    def __init__(self, strength: int, use_gpu: bool = True):
        self.s = strength / 100
        self.session = _session(LOWLIGHT_MODEL, use_gpu)

    def apply(self, rgb: np.ndarray) -> np.ndarray:
        cv2 = _cv2()
        h, w = rgb.shape[:2]
        sc = min(1.0, 480 / max(w, h))       # the brightening curve is smooth: estimate it small
        sw, sh = max(8, int(w * sc) // 4 * 4), max(8, int(h * sc) // 4 * 4)
        small = cv2.resize(rgb, (sw, sh), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        y = self.session.run(None, {"image": small.transpose(2, 0, 1)[None]})[0][0].transpose(1, 2, 0)
        gain = (np.clip(y, 0, 1) + 1e-3) / (small + 1e-3)
        gain = cv2.GaussianBlur(np.clip(gain, 0.5, 8), (0, 0), 1.5)
        gain = cv2.resize(gain, (w, h), interpolation=cv2.INTER_LINEAR)
        gain = 1 + (gain - 1) * self.s
        return np.clip(rgb.astype(np.float32) * gain + 0.5, 0, 255).astype(np.uint8)


# ------------------------------------------------------------ colour fringes
def fix_fringes(rgb: np.ndarray, amount: int) -> np.ndarray:
    """Lateral chromatic aberration: red is shown slightly too large, blue too small (or the other way)
    - scale them back around the centre."""
    cv2 = _cv2()
    a = amount / 100 * 0.003
    h, w = rgb.shape[:2]
    out = rgb.copy()
    for ch, k in ((0, 1 - a), (2, 1 + a)):
        M = cv2.getRotationMatrix2D((w / 2, h / 2), 0, k)
        out[:, :, ch] = cv2.warpAffine(rgb[:, :, ch], M, (w, h), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
    return out


# ------------------------------------------------------------------ horizon
class Horizon:
    """Finds the tilt of strong near-horizontal lines, smooths it over time, and rotates the picture
    level (zooming in just enough to hide the corners)."""

    def __init__(self, strength: int, max_deg: float = 10.0):
        self.s, self.max = strength / 100, max_deg
        self.angle = 0.0

    def estimate(self, rgb: np.ndarray) -> Optional[float]:
        cv2 = _cv2()
        h, w = rgb.shape[:2]
        sc = min(1.0, 640 / max(w, h))
        g = cv2.cvtColor(cv2.resize(rgb, (int(w * sc), int(h * sc)), interpolation=cv2.INTER_AREA), cv2.COLOR_RGB2GRAY)
        edges = cv2.Canny(g, 60, 160)
        lines = cv2.HoughLinesP(edges, 1, np.pi / 360, 60, minLineLength=int(g.shape[1] * 0.25), maxLineGap=8)
        if lines is None:
            return None
        angs, wts = [], []
        for x1, y1, x2, y2 in np.asarray(lines).reshape(-1, 4):
            a = math.degrees(math.atan2(y2 - y1, x2 - x1))
            if a > 90:
                a -= 180
            if a < -90:
                a += 180
            if abs(a) <= self.max:
                angs.append(a)
                wts.append(math.hypot(x2 - x1, y2 - y1))
        if not angs:
            return None
        order = np.argsort(angs)
        cw = np.cumsum(np.array(wts)[order])
        return float(np.array(angs)[order][np.searchsorted(cw, cw[-1] / 2)])

    def apply(self, rgb: np.ndarray) -> np.ndarray:
        cv2 = _cv2()
        a = self.estimate(rgb)
        if a is not None:
            self.angle += 0.06 * (a - self.angle)
        rot = self.angle * self.s
        if abs(rot) < 0.05:
            return rgb
        h, w = rgb.shape[:2]
        r = math.radians(abs(rot))
        zoom = (w * math.cos(r) + h * math.sin(r)) / w
        zoom = max(zoom, (h * math.cos(r) + w * math.sin(r)) / h)
        M = cv2.getRotationMatrix2D((w / 2, h / 2), rot, zoom)
        return cv2.warpAffine(rgb, M, (w, h), flags=cv2.INTER_CUBIC, borderMode=cv2.BORDER_REFLECT)


# ------------------------------------------------------------------ privacy
class PlateDetector:
    def __init__(self, use_gpu: bool = True, conf: float = 0.35):
        self.session = _session(PLATE_MODEL, use_gpu)
        self.conf = conf

    def find(self, rgb: np.ndarray) -> list[tuple[int, int, int, int]]:
        cv2 = _cv2()
        h, w = rgb.shape[:2]
        s = 640 / max(h, w)
        nh, nw = int(round(h * s)), int(round(w * s))
        canvas = np.full((640, 640, 3), 114, np.uint8)
        top, left = (640 - nh) // 2, (640 - nw) // 2
        canvas[top:top + nh, left:left + nw] = cv2.resize(rgb, (nw, nh), interpolation=cv2.INTER_AREA)
        out = self.session.run(None, {"images": (canvas.transpose(2, 0, 1)[None].astype(np.float32) / 255)})[0][0]
        cx, cy, bw, bh, sc = out
        keep = sc >= self.conf
        if not keep.any():
            return []
        boxes = [[(x - ww / 2 - left) / s, (y - hh / 2 - top) / s, ww / s, hh / s]
                 for x, y, ww, hh in zip(cx[keep], cy[keep], bw[keep], bh[keep])]
        idx = cv2.dnn.NMSBoxes(boxes, sc[keep].tolist(), self.conf, 0.45)
        return [tuple(int(v) for v in boxes[i]) for i in np.array(idx).ravel()]


class PrivacyBlur:
    """Blurs faces and/or licence plates. Areas are widened a little and kept for a few frames so a
    missed detection doesn't flash the face/plate."""

    def __init__(self, faces: bool, plates: bool, style: str = "blur", use_gpu: bool = True, hold: int = 8):
        from .ai import FaceFinder, faces_available
        self.faces = FaceFinder(0.6, 8) if faces and faces_available() else None
        self.plates = PlateDetector(use_gpu) if plates and have(PLATE_MODEL) else None
        self.style, self.hold = style, hold
        self.recent: deque = deque(maxlen=hold)

    def apply(self, rgb: np.ndarray) -> np.ndarray:
        cv2 = _cv2()
        h, w = rgb.shape[:2]
        found = []
        if self.faces is not None:
            for f in self.faces.find(rgb):
                x, y, fw, fh = f[:4]
                found.append((x - 0.15 * fw, y - 0.25 * fh, fw * 1.3, fh * 1.45))
        if self.plates is not None:
            for x, y, pw, ph in self.plates.find(rgb):
                found.append((x - 0.1 * pw, y - 0.2 * ph, pw * 1.2, ph * 1.4))
        self.recent.append(found)
        out = rgb.copy()
        for boxes in self.recent:
            for x, y, bw, bh in boxes:
                x0, y0 = int(max(0, x)), int(max(0, y))
                x1, y1 = int(min(w, x + bw)), int(min(h, y + bh))
                if x1 - x0 < 2 or y1 - y0 < 2:
                    continue
                roi = out[y0:y1, x0:x1]
                if self.style == "black":
                    out[y0:y1, x0:x1] = 0
                elif self.style == "pixelate":
                    k = max(4, max(x1 - x0, y1 - y0) // 10)
                    small = cv2.resize(roi, (max(1, (x1 - x0) // k), max(1, (y1 - y0) // k)), interpolation=cv2.INTER_AREA)
                    out[y0:y1, x0:x1] = cv2.resize(small, (x1 - x0, y1 - y0), interpolation=cv2.INTER_NEAREST)
                else:
                    k = max(3, (max(x1 - x0, y1 - y0) // 2) | 1)
                    out[y0:y1, x0:x1] = cv2.GaussianBlur(roi, (k, k), 0)
        return out


# ---------------------------------------------------------------- sequences
def _diff(a: np.ndarray, b: np.ndarray) -> float:
    s = max(1, a.shape[1] // 160)
    return float(np.abs(a[::s, ::s].astype(np.int16) - b[::s, ::s].astype(np.int16)).mean())


def stutter_stream(frames: Iterator[np.ndarray], between: Callable[[np.ndarray, np.ndarray, float], np.ndarray],
                   threshold: float = 0.6, max_run: int = 12) -> Iterator[np.ndarray]:
    """Frozen/duplicated frames between two moving frames are rebuilt as in-between frames, so motion
    is even and the length (and sound sync) stays the same. Longer freezes (deliberate pauses) stay."""
    last_unique = None
    dupes: list[np.ndarray] = []
    for f in frames:
        if last_unique is None:
            last_unique = f
            yield f
            continue
        if _diff(f, last_unique) < threshold:
            dupes.append(f)
            if len(dupes) > max_run:            # a real pause: let it through unchanged
                for d in dupes:
                    yield d
                dupes = []
            continue
        if dupes:
            n = len(dupes)
            for k in range(n):
                yield between(last_unique, f, (k + 1) / (n + 1))
            dupes = []
        last_unique = f
        yield f
    for d in dupes:
        yield d


def retime_stream(frames: Iterator[np.ndarray], ratio: float,
                  between: Callable[[np.ndarray, np.ndarray, float], np.ndarray]) -> Iterator[np.ndarray]:
    """Output frame k shows source time k*ratio (ratio = source fps / output fps per source second).
    ratio < 1 makes extra frames (higher frame rate or slow motion)."""
    from fractions import Fraction
    r = Fraction(ratio).limit_denominator(100000)   # exact: a resumed run makes exactly the same frames
    prev, n, k = None, 0, 0
    for f in frames:
        if prev is not None:
            while k * r < n:
                t = float(k * r - (n - 1))
                yield prev if t < 1e-3 else between(prev, f, t)
                k += 1
        prev = f
        n += 1
    if prev is not None:
        while k * r < n:
            yield prev
            k += 1


def blend_between(a: np.ndarray, b: np.ndarray, t: float) -> np.ndarray:
    cv2 = _cv2()
    return cv2.addWeighted(a, 1 - t, b, t, 0)


# --------------------------------------------------------------------- LUTs
LUT_DIR = Path(__file__).resolve().parents[2] / "assets" / "luts"
BUILTIN_LUTS = {"warm": "Warm", "cool": "Cool", "teal_orange": "Teal & orange", "vintage": "Vintage film",
                "bw_contrast": "Black & white (contrast)", "vivid": "Vivid"}


def _look(name: str, r, g, b):
    l = 0.2126 * r + 0.7152 * g + 0.0722 * b       # noqa: E741
    if name == "warm":
        return r * 1.06 + 0.01, g * 1.01, b * 0.9
    if name == "cool":
        return r * 0.92, g * 1.0, b * 1.08 + 0.01
    if name == "teal_orange":
        sh = np.clip(1 - l * 2, 0, 1)
        hi = np.clip(l * 2 - 1, 0, 1)
        return r - 0.06 * sh + 0.07 * hi, g + 0.02 * sh + 0.02 * hi, b + 0.07 * sh - 0.07 * hi
    if name == "vintage":
        c = 0.06 + 0.88 * (r * 0.9 + 0.05), 0.05 + 0.88 * (g * 0.92 + 0.04), 0.08 + 0.8 * (b * 0.85 + 0.03)
        m = (c[0] + c[1] + c[2]) / 3
        return tuple(m + 0.75 * (x - m) for x in c)
    if name == "bw_contrast":
        y = np.clip((l - 0.5) * 1.25 + 0.5, 0, 1)
        y = y * y * (3 - 2 * y)
        return y, y, y
    if name == "vivid":
        m = l
        r2, g2, b2 = (m + 1.3 * (x - m) for x in (r, g, b))
        return tuple(np.clip((x - 0.5) * 1.08 + 0.5, 0, 1) for x in (r2, g2, b2))
    return r, g, b


def ensure_builtin_luts(size: int = 33) -> None:
    LUT_DIR.mkdir(parents=True, exist_ok=True)
    grid = np.linspace(0, 1, size)
    b, g, r = np.meshgrid(grid, grid, grid, indexing="ij")     # .cube: red changes fastest
    for name, title in BUILTIN_LUTS.items():
        p = LUT_DIR / f"{name}.cube"
        if p.is_file():
            continue
        R, G, B = (np.clip(x, 0, 1) for x in _look(name, r, g, b))
        lines = [f'TITLE "{title}"', f"LUT_3D_SIZE {size}"]
        lines += [f"{x:.6f} {y:.6f} {z:.6f}" for x, y, z in zip(R.ravel(), G.ravel(), B.ravel())]
        try:
            p.write_text("\n".join(lines) + "\n", "ascii")
        except OSError:
            pass


def lut_path(choice: str, custom: str) -> Optional[Path]:
    if choice == "custom":
        return Path(custom) if custom and Path(custom).is_file() else None
    if choice in BUILTIN_LUTS:
        ensure_builtin_luts()
        p = LUT_DIR / f"{choice}.cube"
        return p if p.is_file() else None
    return None


# ------------------------------------------------------------ video AI denoise
DENOISE_MODEL = "scunet_color_real_psnr.onnx"


class VideoDenoiser:
    """SCUNet (real-world blind denoiser, also cleans compression mess) on each frame, then made
    steady over time: the previous cleaned frame is moved along the motion (optical flow) and mixed
    in wherever it still matches, so leftover noise doesn't crawl from frame to frame."""

    def __init__(self, strength: int = 100, temporal: int = 2, use_gpu: bool = True, tile: int = 512,
                 reuse: bool = False):
        from .ai import TileRunner
        self.session = _session(DENOISE_MODEL, use_gpu, tile + 64)
        self.inp = self.session.get_inputs()[0].name
        self.s, self.tile = strength / 100, tile
        self.runner = TileRunner(self.session, 1, tile, 32, multiple=64, reuse=reuse)
        self.temporal = {0: 0.0, 1: 0.35, 2: 0.55, 3: 0.7}.get(temporal, 0.55)
        self.prev_out = None
        self.prev_gray = None

    def _run(self, x: np.ndarray) -> np.ndarray:
        h, w = x.shape[:2]
        ph, pw = (-h) % 64, (-w) % 64
        xp = np.pad(x, ((0, ph), (0, pw), (0, 0)), mode="reflect") if (ph or pw) else x
        y = self.session.run(None, {self.inp: xp.transpose(2, 0, 1)[None]})[0][0].transpose(1, 2, 0)
        return y[:h, :w]

    def _denoise(self, rgb: np.ndarray) -> np.ndarray:
        y = self.runner.run(rgb)
        out = np.clip(y, 0, 1) * 255
        if self.s < 1:
            out = out * self.s + rgb.astype(np.float32) * (1 - self.s)
        return out

    def apply(self, rgb: np.ndarray) -> np.ndarray:
        cv2 = _cv2()
        cur = self._denoise(rgb)
        gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
        if self.temporal and self.prev_out is not None and self.prev_gray.shape == gray.shape:
            h, w = gray.shape
            sc = min(1.0, 480 / max(w, h))
            g0 = cv2.resize(self.prev_gray, (int(w * sc), int(h * sc)), interpolation=cv2.INTER_AREA)
            g1 = cv2.resize(gray, (int(w * sc), int(h * sc)), interpolation=cv2.INTER_AREA)
            flow = cv2.calcOpticalFlowFarneback(g1, g0, None, 0.5, 3, 15, 3, 5, 1.2, 0)
            flow = cv2.resize(flow, (w, h), interpolation=cv2.INTER_LINEAR) / sc
            gx, gy = np.meshgrid(np.arange(w, dtype=np.float32), np.arange(h, dtype=np.float32))
            warped = cv2.remap(self.prev_out, gx + flow[..., 0], gy + flow[..., 1], cv2.INTER_LINEAR,
                               borderMode=cv2.BORDER_REPLICATE)
            diff = np.abs(warped - cur).mean(axis=2, keepdims=True)
            wgt = self.temporal * np.exp(-diff / 6.0)
            cur = warped * wgt + cur * (1 - wgt)
        self.prev_out, self.prev_gray = cur, gray
        return np.clip(cur + 0.5, 0, 255).astype(np.uint8)


# ------------------------------------------------------------ object removal
SEG_MODEL = "yolo11n-seg.onnx"
REMOVE_GROUPS = {"people": [0], "vehicles": [1, 2, 3, 5, 7], "animals": list(range(14, 24)),
                 "people_vehicles": [0, 1, 2, 3, 5, 7]}


class Segmenter:
    """YOLO11-nano segmentation: pixel masks of people, cars, animals..."""

    def __init__(self, use_gpu: bool = True, conf: float = 0.25):
        self.session = _session(SEG_MODEL, use_gpu)
        self.conf = conf

    def mask(self, rgb: np.ndarray, classes: list[int]) -> np.ndarray:
        cv2 = _cv2()
        h, w = rgb.shape[:2]
        s = 640 / max(h, w)
        nh, nw = int(round(h * s)), int(round(w * s))
        top, left = (640 - nh) // 2, (640 - nw) // 2
        canvas = np.full((640, 640, 3), 114, np.uint8)
        canvas[top:top + nh, left:left + nw] = cv2.resize(rgb, (nw, nh), interpolation=cv2.INTER_AREA)
        pred, proto = self.session.run(None, {self.session.get_inputs()[0].name:
                                              canvas.transpose(2, 0, 1)[None].astype(np.float32) / 255})
        pred, proto = pred[0], proto[0]                     # (116, 8400), (32, 160, 160)
        scores = pred[4:84]
        cls = scores.argmax(axis=0)
        conf = scores.max(axis=0)
        keep = (conf >= self.conf) & np.isin(cls, classes)
        out = np.zeros((h, w), np.uint8)
        if not keep.any():
            return out
        boxes = pred[:4, keep].T
        coeff = pred[84:, keep].T
        xywh = [[float(b[0] - b[2] / 2), float(b[1] - b[3] / 2), float(b[2]), float(b[3])] for b in boxes]
        idx = np.array(cv2.dnn.NMSBoxes(xywh, conf[keep].tolist(), self.conf, 0.5)).ravel()
        if not len(idx):
            return out
        m = 1 / (1 + np.exp(-(coeff[idx] @ proto.reshape(32, -1)))).reshape(-1, 160, 160)
        full = np.zeros((640, 640), np.float32)
        for k, i in enumerate(idx):
            mk = cv2.resize(m[k], (640, 640), interpolation=cv2.INTER_LINEAR)
            x, y, bw, bh = xywh[i]
            box = np.zeros((640, 640), np.float32)
            box[int(max(0, y)):int(min(640, y + bh)), int(max(0, x)):int(min(640, x + bw))] = 1
            full = np.maximum(full, mk * box)
        full = full[top:top + nh, left:left + nw]
        return (cv2.resize(full, (w, h), interpolation=cv2.INTER_LINEAR) > 0.5).astype(np.uint8)


def inpaint_mask(session, img: np.ndarray, mask: np.ndarray) -> np.ndarray:
    """LaMa fill of every blob in mask (uint8 0/1), one 512x512 crop per blob."""
    cv2 = _cv2()
    h, w = img.shape[:2]
    out = img.copy()
    n, labels, stats, _ = cv2.connectedComponentsWithStats(mask, 8)
    for i in range(1, n):
        x, y, bw, bh, area = stats[i]
        if area < 4:
            continue
        side = int(min(max(256, 2.2 * max(bw, bh)), max(w, h)))
        cx, cy = x + bw // 2, y + bh // 2
        ax0 = int(min(max(0, cx - side // 2), max(0, w - side)))
        ay0 = int(min(max(0, cy - side // 2), max(0, h - side)))
        ax1, ay1 = min(w, ax0 + side), min(h, ay0 + side)
        crop = out[ay0:ay1, ax0:ax1]
        cm = mask[ay0:ay1, ax0:ax1].astype(np.float32)
        ci = cv2.resize(crop, (512, 512), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        mm = (cv2.resize(cm, (512, 512), interpolation=cv2.INTER_NEAREST) > 0.5).astype(np.float32)
        y_ = session.run(None, {"image": ci.transpose(2, 0, 1)[None], "mask": mm[None, None]})[0][0].transpose(1, 2, 0)
        if y_.max() > 2:
            y_ = y_ / 255
        fill = cv2.resize(np.clip(y_, 0, 1), (ax1 - ax0, ay1 - ay0), interpolation=cv2.INTER_CUBIC) * 255
        soft = np.clip(cv2.GaussianBlur(cm, (0, 0), 2) * 1.5, 0, 1)[:, :, None]
        out[ay0:ay1, ax0:ax1] = (crop * (1 - soft) + fill * soft).astype(np.uint8)
    return out


class ObjectRemover:
    """Removes people / vehicles / animals: segmentation masks (grown a little to catch edges and
    shadows), then either AI fill (any camera) or the background seen in other frames (still camera),
    falling back to AI fill where the background was never seen."""

    STILL_PX = 0.5          # camera shift per frame (at 256 px wide) still counted as "not moving"

    def __init__(self, group: str, method: str = "auto", grow: int = 12, use_gpu: bool = True):
        self.seg = Segmenter(use_gpu)
        self.prev_small = None
        self.motion = 0.0       # smoothed camera movement
        self.moving = False
        self.classes = REMOVE_GROUPS.get(group, [0])
        self.method, self.grow = method, grow
        self.lama = _session(LAMA_MODEL, use_gpu) if have(LAMA_MODEL) else None
        self.bg = None
        self.seen = None

    def apply(self, rgb: np.ndarray) -> np.ndarray:
        cv2 = _cv2()
        m = self.seg.mask(rgb, self.classes)
        if self.grow:
            k = max(3, int(self.grow * max(rgb.shape[:2]) / 1080) | 1)
            m = cv2.dilate(m, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
        method = self.method
        if method == "auto":
            method = "ai" if self._camera_moving(rgb) else "background"
            if method == "ai":
                self.bg = self.seen = None          # the old background no longer lines up
        if method == "background":
            if self.bg is None:
                self.bg = rgb.copy()
                self.seen = np.zeros(m.shape, bool)
            free = m == 0
            self.bg[free] = (0.8 * self.bg[free] + 0.2 * rgb[free]).astype(np.uint8) if self.seen.any() else rgb[free]
            self.seen |= free
            out = rgb.copy()
            use = (m > 0) & self.seen
            out[use] = self.bg[use]
            rest = ((m > 0) & ~self.seen).astype(np.uint8)
            if rest.any() and self.lama is not None:
                out = inpaint_mask(self.lama, out, rest)
            return out
        if not m.any():
            return rgb
        if self.lama is None:
            return cv2.inpaint(rgb, m, 5, cv2.INPAINT_TELEA)
        return inpaint_mask(self.lama, rgb, m)

    def _camera_moving(self, rgb: np.ndarray) -> bool:
        cv2 = _cv2()
        h, w = rgb.shape[:2]
        small = cv2.cvtColor(cv2.resize(rgb, (256, max(16, int(256 * h / w))), interpolation=cv2.INTER_AREA),
                             cv2.COLOR_RGB2GRAY).astype(np.float32)
        if self.prev_small is not None and self.prev_small.shape == small.shape:
            (dx, dy), _ = cv2.phaseCorrelate(self.prev_small, small)
            self.motion = 0.7 * self.motion + 0.3 * float(np.hypot(dx, dy))
            # hysteresis so it doesn't flip back and forth
            self.moving = self.motion > (self.STILL_PX if not self.moving else self.STILL_PX * 0.6)
        self.prev_small = small
        return self.moving


# ------------------------------------------------------------ helpers shared by the tiled AI steps
def _tiled(run: Callable[[np.ndarray], np.ndarray], x: np.ndarray, tile: int, pad: int = 32) -> np.ndarray:
    """Run an image-to-image model (HWC float in, same size out) in overlapping tiles."""
    h, w = x.shape[:2]
    if h <= tile and w <= tile:
        return run(x)
    y = np.zeros_like(x)
    for y0 in range(0, h, tile):
        for x0 in range(0, w, tile):
            y1, x1 = min(y0 + tile, h), min(x0 + tile, w)
            ay0, ax0, ay1, ax1 = max(0, y0 - pad), max(0, x0 - pad), min(h, y1 + pad), min(w, x1 + pad)
            out = run(np.ascontiguousarray(x[ay0:ay1, ax0:ax1]))
            y[y0:y1, x0:x1] = out[y0 - ay0:y1 - ay0, x0 - ax0:x1 - ax0]
    return y


# ------------------------------------------------------------ AI deblur
DEBLUR_MODEL = "NAFNet-GoPro-width64.onnx"


class Deblurrer:
    """NAFNet trained on GoPro (real camera-shake / motion blur): sharpens blurred frames."""

    def __init__(self, strength: int = 100, use_gpu: bool = True, tile: int = 512, reuse: bool = False):
        from .ai import TileRunner
        self.session = _session(DEBLUR_MODEL, use_gpu, tile + 64)
        self.inp = self.session.get_inputs()[0].name
        self.s, self.tile = strength / 100, tile
        self.runner = TileRunner(self.session, 1, tile, 32, multiple=16, reuse=reuse)

    def _run(self, x: np.ndarray) -> np.ndarray:
        h, w = x.shape[:2]
        ph, pw = (-h) % 16, (-w) % 16
        xp = np.pad(x, ((0, ph), (0, pw), (0, 0)), mode="reflect") if (ph or pw) else x
        y = self.session.run(None, {self.inp: np.ascontiguousarray(xp.transpose(2, 0, 1)[None])})[0][0]
        return y.transpose(1, 2, 0)[:h, :w]

    def apply(self, rgb: np.ndarray) -> np.ndarray:
        y = np.clip(self.runner.run(rgb), 0, 1) * 255
        if self.s < 1:
            y = y * self.s + rgb.astype(np.float32) * (1 - self.s)
        return np.clip(y + 0.5, 0, 255).astype(np.uint8)


# ------------------------------------------------------------ rolling shutter
RS_BANDS = 16
RS_READOUT = {1: 0.35, 2: 0.6, 3: 0.9}       # share of the frame time the sensor takes to read top -> bottom


def band_motion(prev_gray: np.ndarray, gray: np.ndarray, bands: int = RS_BANDS) -> np.ndarray:
    """How the picture moved from one frame to the next, per horizontal band: (bands, 2) dx, dy in pixels
    of these (small) images. Medians, so people walking through don't count as camera movement."""
    cv2 = _cv2()
    flow = cv2.calcOpticalFlowFarneback(prev_gray, gray, None, 0.5, 3, 15, 3, 5, 1.2, 0)
    h = flow.shape[0]
    edges = np.linspace(0, h, bands + 1).astype(int)
    return np.array([np.median(flow[a:b].reshape(-1, 2), axis=0) for a, b in zip(edges[:-1], edges[1:])],
                    np.float32)


class RollingShutterFix:
    """Phones and action cameras read the picture line by line, so when the camera moves, lower lines
    are captured later: verticals lean during pans and the picture wobbles like jelly on vibration.
    Each band of lines is moved back to where it was at the middle of the frame, using the motion
    measured for that band (from the original, unstabilised video when available)."""

    def __init__(self, level: int, motions: Optional[np.ndarray] = None, scale=(1.0, 1.0)):
        self.readout = RS_READOUT.get(level, 0.6)
        self.motions = motions          # (frames, bands, 2) from scan.prepass, or None = measure here
        self.scale = scale              # prepass pixels -> this frame's pixels (x, y)
        self.i = 0
        self.prev_small = None

    def _small(self, rgb: np.ndarray) -> np.ndarray:
        cv2 = _cv2()
        h, w = rgb.shape[:2]
        return cv2.cvtColor(cv2.resize(rgb, (320, max(16, int(round(320 * h / w / 2)) * 2)),
                                       interpolation=cv2.INTER_AREA), cv2.COLOR_RGB2GRAY)

    def motion_for(self, rgb: np.ndarray) -> Optional[np.ndarray]:
        """Band motion in this frame's pixels."""
        h, w = rgb.shape[:2]
        if self.motions is not None:
            if self.i >= len(self.motions):
                return None
            m = self.motions[self.i].copy()
            m[:, 0] *= self.scale[0]
            m[:, 1] *= self.scale[1]
            return m
        small = self._small(rgb)
        prev, self.prev_small = self.prev_small, small
        if prev is None or prev.shape != small.shape:
            return None
        m = band_motion(prev, small)
        m[:, 0] *= w / small.shape[1]
        m[:, 1] *= h / small.shape[0]
        return m

    def apply(self, rgb: np.ndarray) -> np.ndarray:
        m = self.motion_for(rgb)
        self.i += 1
        return rgb if m is None else self.correct(rgb, m)

    def correct(self, rgb: np.ndarray, m: np.ndarray) -> np.ndarray:
        cv2 = _cv2()
        h, w = rgb.shape[:2]
        bands = len(m)
        centres = (np.arange(bands) + 0.5) / bands * h
        rows = np.arange(h, dtype=np.float32)
        vx = np.interp(rows, centres, cv2.GaussianBlur(m[:, 0].reshape(-1, 1), (1, 5), 0).ravel())
        vy = np.interp(rows, centres, cv2.GaussianBlur(m[:, 1].reshape(-1, 1), (1, 5), 0).ravel())
        dt = self.readout * (rows / h - 0.5)            # each line's capture time relative to the middle
        sx, sy = (vx * dt).astype(np.float32), (vy * dt).astype(np.float32)
        if max(np.abs(sx).max(), np.abs(sy).max()) < 0.3:
            return rgb
        gx, gy = np.meshgrid(np.arange(w, dtype=np.float32), rows)
        # the content of line y sits where it would be at the middle time plus v*dt - look it up there
        return cv2.remap(rgb, gx + sx[:, None], gy + sy[:, None], cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)


# ------------------------------------------------------------ per-scene light & colour
def scene_levels(lo: np.ndarray, hi: np.ndarray, grey, strength: float) -> list[np.ndarray]:
    """A scene's lookup tables (one per channel): black & white points from its darkest/brightest
    0.5% brightness (the same for all channels, so colours don't shift), then white balance from the things in
    the scene that should be grey (low-saturation pixels)."""
    a = float(np.min(lo)) * strength
    b = 255 - (255 - float(np.max(hi))) * strength
    if b - a < 255 * 0.45:                         # never stretch more than ~2.2x (night scenes stay night)
        mid = (a + b) / 2
        a, b = max(0.0, mid - 255 * 0.225), min(255.0, mid + 255 * 0.225)
    gains = np.ones(3)
    g = np.asarray(grey, np.float64) if grey is not None else None
    if g is not None and np.all(np.isfinite(g)):
        g = (g - a) * 255 / max(1.0, b - a)          # the grey as it comes out of the levels step
    if g is not None and np.all(np.isfinite(g)) and g.min() > 5:
        gains = np.clip(g.mean() / g, 0.75, 1.33)
        gains = 1 + (gains - 1) * strength
    x = np.arange(256, dtype=np.float32)
    base = (x - a) * 255 / max(1.0, b - a)
    return [np.clip(base * gains[c], 0, 255).astype(np.uint8) for c in range(3)]


def frame_levels(rgb: np.ndarray) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Darkest / brightest 0.5% (brightness), and the average colour of the near-grey pixels (NaN if few)."""
    px = rgb.reshape(-1, 3)[::3]
    y = px @ np.array([0.299, 0.587, 0.114])            # brightness, so strong colours don't hide the range
    lo, hi = np.full(3, np.percentile(y, 0.5)), np.full(3, np.percentile(y, 99.5))
    p = px.astype(np.int16)
    sat = p.max(axis=1) - p.min(axis=1)
    lum = p.mean(axis=1)
    mid = (lum > 30) & (lum < 225)
    if mid.sum() < len(px) * 0.03:
        return lo, hi, np.full(3, np.nan)
    # the least colourful pixels (a colour cast makes even grey things a bit colourful)
    lim = min(60.0, max(20.0, float(np.percentile(sat[mid], 20))))
    grey = p[mid & (sat <= lim)]
    g = grey.mean(axis=0) if len(grey) > len(px) * 0.03 else np.full(3, np.nan)
    return lo, hi, g


class SceneLight:
    """Applies each scene's own levels & white balance (scenes and their statistics from scan.prepass)."""

    def __init__(self, strength: int, scenes: Optional[list] = None):
        self.k = strength / 100
        self.scenes = scenes or []      # [(first_frame, lo[3], hi[3], grey[3])]
        self.i = 0
        self.cur = None
        self.lut = None

    def apply(self, rgb: np.ndarray) -> np.ndarray:
        cv2 = _cv2()
        if self.scenes:
            sc = max((s for s in self.scenes if s[0] <= self.i), key=lambda s: s[0], default=self.scenes[0])
            if sc is not self.cur:
                self.cur = sc
                self.lut = None
            if self.lut is None:
                luts = scene_levels(np.asarray(sc[1]), np.asarray(sc[2]), sc[3], self.k)
                self.lut = np.stack(luts, axis=1).reshape(256, 1, 3)
        else:                            # no scan (preview): this frame is its own scene
            lo, hi, g = frame_levels(rgb)
            self.lut = np.stack(scene_levels(lo, hi, g, self.k), axis=1).reshape(256, 1, 3)
        self.i += 1
        return cv2.LUT(rgb, self.lut)
