"""Quick check of a video: interlacing, black borders, brightness, noise - and what to suggest."""
from __future__ import annotations

import json
import re
import subprocess
import threading
from pathlib import Path

import numpy as np

from breezy.core import proc
from breezy.core.ffmpeg import FFmpeg, MediaInfo
from breezy.core.sync import drift_text, needs_fix

CHECK_VERSION = 5
_lock = threading.Lock()


def _cache_key(info: MediaInfo) -> str:
    return f"{info.path}|{info.size}|{int(info.mtime)}|v{CHECK_VERSION}"


def load_cache(path: Path) -> dict:
    try:
        return json.loads(Path(path).read_text("utf-8"))
    except (OSError, ValueError):
        return {}


def save_cache(path: Path, key: str, value: dict):
    with _lock:
        data = load_cache(path)
        data[key] = value
        if len(data) > 5000:
            data = dict(list(data.items())[-4000:])
        try:
            Path(path).parent.mkdir(parents=True, exist_ok=True)
            Path(path).write_text(json.dumps(data), "utf-8")
        except OSError:
            pass


def check(ffmpeg: FFmpeg, info: MediaInfo, cache_file=None) -> dict:
    if cache_file:
        hit = load_cache(cache_file).get(_cache_key(info))
        if hit:
            return hit
    v = info.video
    out = {"interlaced": False, "crop": None, "brightness": None, "noise": None, "grayscale": False,
           "hdr": False, "rgb_stats": None, "stretch": None, "face_shape": None, "suggest": []}
    if not v or not v.width:
        out["suggest"].append("no video stream")
        return out
    dur = v.duration or info.duration or 0
    r = proc.run([ffmpeg.ffprobe, "-v", "error", "-select_streams", "v:0", "-show_entries",
                  "stream=color_transfer", "-of", "csv=p=0", str(info.path)], timeout=60, text=True)
    out["hdr"] = (r.stdout or "").strip().strip(",") in ("smpte2084", "arib-std-b67")
    mid = max(0.0, dur / 2 - 5)
    # 1) interlacing + black borders on 10 s from the middle
    r = proc.run([ffmpeg.ffmpeg, "-hide_banner", "-nostdin", "-ss", f"{mid:.2f}", "-i", str(info.path), "-t", "10",
                  "-an", "-sn", "-vf", "idet,cropdetect=limit=24:round=2:reset=0", "-f", "null", "-"],
                 timeout=300, text=True)
    err = r.stderr or ""
    m = re.findall(r"Multi frame detection:\s*TFF:\s*(\d+)\s*BFF:\s*(\d+)\s*Progressive:\s*(\d+)", err)
    if m:
        tff, bff, prog = map(int, m[-1])
        out["interlaced"] = (tff + bff) > max(10, 2 * prog)
    crops = re.findall(r"crop=(\d+):(\d+):(\d+):(\d+)", err)
    cand = None
    if crops:
        w, h, x, y = map(int, crops[-1])
        if (w < v.width * 0.98 or h < v.height * 0.98) and w > v.width * 0.4 and h > v.height * 0.4:
            cand = (w, h, x, y)
    # 2) brightness + noise from up to 12 keyframes across the video
    sw = min(960, v.width) // 2 * 2
    sh = max(2, int(round(sw * v.height / v.width / 2)) * 2)
    p = proc.popen([ffmpeg.ffmpeg, "-v", "error", "-nostdin", "-skip_frame", "nokey", "-i", str(info.path),
                    "-an", "-sn", "-vf", f"scale={sw}:{sh}:flags=neighbor,format=yuv444p", "-fps_mode", "passthrough",
                    "-frames:v", "400", "-f", "rawvideo", "-"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    frames = []
    try:
        while True:
            buf = p.stdout.read(sw * sh * 3)
            if len(buf) < sw * sh * 3:
                break
            frames.append(np.frombuffer(buf, np.uint8).reshape(3, sh, sw))
    finally:
        p.stdout.close()
        p.wait()
    if frames:
        pick = [frames[i] for i in np.linspace(0, len(frames) - 1, min(12, len(frames))).astype(int)]
        out["brightness"] = float(np.mean([f[0].mean() for f in pick]))
        out["noise"] = float(np.median([_noise_sigma(f[0]) for f in pick]))
        chroma = np.concatenate([np.abs(f[1:].astype(np.int16) - 128).ravel() for f in pick])
        out["grayscale"] = bool(chroma.mean() < 2.0 and np.percentile(chroma, 99) < 6)
        import cv2
        rgb = np.concatenate([cv2.cvtColor(np.ascontiguousarray(f.transpose(1, 2, 0)), cv2.COLOR_YCrCb2RGB)
                              .reshape(-1, 3)[::7] for f in [np.stack([p[0], p[2], p[1]]) for p in pick]])
        out["rgb_stats"] = [float(x) for x in list(rgb.mean(axis=0)) + list(rgb.std(axis=0))]
        if cand:
            out["crop"] = _confirm_crop(cand, pick, v.width, v.height)
        try:
            sar = getattr(v, "sar", 1.0) or 1.0
            if abs(sar - 1) <= 0.01:          # the file doesn't already say its pixels aren't square
                many = [frames[i] for i in np.linspace(0, len(frames) - 1, min(40, len(frames))).astype(int)]
                rgbs = [cv2.cvtColor(np.ascontiguousarray(np.stack([f[0], f[2], f[1]]).transpose(1, 2, 0)),
                                     cv2.COLOR_YCrCb2RGB) for f in many]
                out["stretch"], out["face_shape"] = face_stretch(rgbs, v.width / sw)
        except Exception:
            pass
    out["suggest"] = suggestions(info, out)
    if cache_file:
        save_cache(cache_file, _cache_key(info), out)
    return out


FACE_RATIO = 0.866     # eye distance / eye-to-mouth height of an average face seen from the front


def face_stretch(rgbs: list, scale: float = 1.0) -> tuple[float | None, dict | None]:
    """Is the picture squashed or stretched? Faces seen from the front have a known shape: if their
    width-to-height (eyes apart vs eyes to mouth) is consistently off by a standard factor (4:3 shown
    as 16:9 or the reverse), return the factor that fixes it."""
    from .ai import FaceFinder, faces_available
    if not faces_available():
        return None, None
    ff = FaceFinder(confidence=0.8, min_size=24)
    ratios = []
    for rgb in rgbs:
        for f in ff.find(rgb):
            (rx, ry), (lx, ly), (nx, ny), (mrx, mry), (mlx, mly) = f[4:14].reshape(5, 2)
            eye_d = abs(lx - rx)
            eye_y, mouth_y = (ry + ly) / 2, (mry + mly) / 2
            down = mouth_y - eye_y
            if eye_d < 8 or down < 6:
                continue
            if abs(ly - ry) > 0.12 * eye_d:                       # head tilted
                continue
            if abs(nx - (rx + lx) / 2) > 0.12 * eye_d:            # head turned (nose off-centre)
                continue
            ratios.append(eye_d / down)
    if len(ratios) < 8:
        return None, {"faces": len(ratios)}
    r = float(np.median(ratios)) / FACE_RATIO
    info = {"faces": len(ratios), "ratio": round(r, 3)}
    for wrong, fix in ((4 / 3, 3 / 4), (3 / 4, 4 / 3)):         # 4:3 stretched to 16:9, or squeezed
        if abs(r / wrong - 1) < 0.1:
            return fix, info
    return None, info


def _confirm_crop(cand, frames, W, H):
    """Keep only the sides whose strips really are black in every sampled frame."""
    w, h, x, y = cand
    sh, sw = frames[0].shape[1:]
    fx, fy = sw / W, sh / H
    stack = np.stack(frames).astype(np.int16)        # (n, 3, h, w) YUV 4:4:4

    def black(region) -> bool:      # dark AND colourless (a dark red picture is not a border)
        if region.size == 0:
            return False
        y, uv = region[:, 0], np.abs(region[:, 1:] - 128)
        return np.percentile(y, 95) < 40 and np.percentile(uv, 95) < 10

    left = x if x > 0 and black(stack[..., :max(1, int(x * fx) - 4)]) else 0
    top = y if y > 0 and black(stack[:, :, :max(1, int(y * fy) - 4), :]) else 0
    rgap = W - (x + w)
    bgap = H - (y + h)
    right = rgap if rgap > 0 and black(stack[..., sw - max(1, int(rgap * fx) - 4):]) else 0
    bottom = bgap if bgap > 0 and black(stack[:, :, sh - max(1, int(bgap * fy) - 4):, :]) else 0
    nw, nh = W - left - right, H - top - bottom
    nw, nh = nw // 2 * 2, nh // 2 * 2
    if nw >= W * 0.98 and nh >= H * 0.98:
        return None
    return [nw, nh, left, top]


def _noise_sigma(gray: np.ndarray) -> float:
    """Immerkaer's fast noise estimate (sigma in 0..255 units)."""
    import cv2
    k = np.array([[1, -2, 1], [-2, 4, -2], [1, -2, 1]], np.float32)
    conv = cv2.filter2D(gray.astype(np.float32), -1, k)
    h, w = gray.shape
    return float(np.sqrt(np.pi / 2) * np.abs(conv[1:-1, 1:-1]).sum() / (6 * (w - 2) * (h - 2)))


def suggestions(info: MediaInfo, c: dict) -> list[str]:
    s = []
    v = info.video
    if v and v.height and v.height < 720:
        s.append(f"low resolution ({v.width}x{v.height}) - upscaling helps")
    elif v and v.height and v.height >= 2000:
        s.append("already 4K - AI upscaling would be very slow")
    if c.get("hdr"):
        s.append("HDR video - can be turned into normal (SDR) video")
    a = info.audio
    if a and a.sample_rate and a.sample_rate <= 16000:
        s.append(f"low-quality sound ({a.sample_rate // 1000} kHz) - AI sound rebuild helps")
    if c.get("grayscale"):
        s.append("black & white - can be colourised")
    if c.get("interlaced"):
        s.append("interlaced - deinterlace")
    if c.get("stretch"):
        s.append("picture looks " + ("stretched wide" if c["stretch"] < 1 else "squashed") + " - fix the shape")
    elif v and abs(getattr(v, "sar", 1.0) - 1) > 0.01:
        s.append("non-square pixels - fix the shape (automatic)")
    if c.get("crop"):
        w, h, _x, _y = c["crop"]
        s.append(f"black borders (picture is {w}x{h}) - crop")
    b = c.get("brightness")
    if b is not None and b < 60:
        s.append("dark - fix lighting")
    elif b is not None and b > 190:
        s.append("very bright - recover highlights")
    n = c.get("noise")
    if n is not None and n > 4.5:
        s.append(f"noisy ({n:.1f}) - denoise {'strong' if n > 9 else 'medium'}")
    if needs_fix(info):
        s.append(drift_text(info) or "sound drifts")
    p = preset_for(info, c)
    if p:
        from breezy.core.quality import CONTENT
        s.append(f"looks like: {dict((v, k) for k, v in CONTENT)[p]}")
    return s


def preset_for(info: MediaInfo, c: dict) -> str | None:
    """A starting preset that suits what the check found (None = the default is fine)."""
    v = info.video
    sd = bool(v and v.height and v.height <= 576)
    b = c.get("brightness")
    if c.get("interlaced") or (sd and (c.get("grayscale") or (c.get("noise") or 0) > 6 or c.get("stretch"))):
        return "oldfilm"
    if b is not None and b < 60:
        return "night"
    return None
