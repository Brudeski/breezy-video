"""Enhance task runners: check videos, enhance them, and enhance another task's output."""
from __future__ import annotations

import threading
from pathlib import Path

from breezy.core.outputs import apply_pattern, output_dir, unique_path
from breezy.core.proc import Cancelled
from breezy.core.settings import app_data_dir
from breezy.core.tasks import Task, TaskContext, register_runner
from .analysis import check
from .filters import EnhanceSettings
from .render import Enhancer


def cache_file() -> Path:
    return app_data_dir() / "enhance_checks.json"


def run_check(task: Task, ctx: TaskContext):
    files = task.spec["files"]
    infos = {}
    for f in files:
        ctx.checkpoint()
        infos[f] = ctx.ffmpeg.probe(Path(f))
    ctx.set_items(files, [1.0] * len(files), [Path(f).name for f in files])
    task.media = False

    def one(_i, f, prog):
        info = infos[f]
        if info.error:
            ctx.log(f"✖ Can't read {Path(f).name}: {info.error}")
            return {"error": info.error, "suggest": []}
        res = check(ctx.ffmpeg, info, cache_file())
        prog(1.0)
        return res

    res = ctx.parallel(one, task.spec.get("workers", 3))
    if ctx.cancel_event.is_set():
        raise Cancelled("Cancelled by user")
    return {files[i]: r for i, r in res.items()}


def videos_at_once(s: EnhanceSettings, settings) -> int:
    """How many videos Enhance works on together. Auto (user's choice): 3 when the AI runs on a graphics
    card with at least 12 GB of memory, 2 with 8 GB (the scan of this PC says), else one."""
    if s.videos_at_once != "auto":
        return max(1, int(s.videos_at_once))
    hw = (settings.get("app", "hardware") or {}) if settings is not None else {}
    vram = max([g.get("vram_gb") or 0 for g in hw.get("hw", {}).get("gpus", [])] or [0])
    gpu_ai = hw.get("bench", {}).get("device") == "graphics card" and s.ai_gpu
    if not gpu_ai:
        return 1
    return 3 if vram >= 12 else 2 if vram >= 8 else 1


_name_lock = threading.Lock()


def _enhance(task: Task, ctx: TaskContext, files: list[str]):
    spec = task.spec
    s = EnhanceSettings.from_spec(spec)
    pattern = spec.get("name_pattern", "{name}_enhanced")
    bench = ((ctx.settings.get("app", "hardware") if ctx.settings else None) or {}).get("bench") or None
    if not task.items:
        infos = {f: ctx.ffmpeg.probe(Path(f)) for f in files}
        costs = []
        for f in files:
            i = infos[f]
            try:
                from .bench import work_units
                from .render import make_plan
                costs.append(work_units(s, make_plan(i, s, {}), i.duration or 1.0, bench) if i.video else 1e-3)
            except Exception:
                costs.append(max(i.duration or 1.0, 1.0))
        ctx.set_items(files, [max(infos[f].duration or 1.0, 1.0) for f in files], [Path(f).name for f in files],
                      costs)
    workers = min(videos_at_once(s, ctx.settings), max(1, len(task.items) - len(task.done_items)))
    if workers > 1:
        ctx.log(f"Working on {workers} videos at once.")
    reserved: set = set()

    def one(_i, f, prog):
        src = Path(f)
        log = ctx.log if workers == 1 else (lambda m, n=src.name: ctx.log(f"[{n}] {m}"))
        try:
            prog(None, "Reading the video")
            info = ctx.ffmpeg.probe(src)
            if info.error:
                raise RuntimeError(info.error)
            prog(None, "Checking the video (interlacing, borders, darkness, noise…)")
            ana = check(ctx.ffmpeg, info, cache_file())
            ext = src.suffix if src.suffix.lower() in (".mp4", ".mov", ".mkv", ".m4v") else ".mp4"
            with _name_lock:                 # two videos at once must not pick the same new name
                out = unique_path(output_dir(spec, src) / (apply_pattern(pattern, src.stem) + ext))
                while str(out).lower() in reserved:
                    out = out.with_name(out.stem + " (b)" + out.suffix)
                reserved.add(str(out).lower())
            log(f"=== {src.name} → {out}")
            if ana.get("suggest"):
                log("Check: " + "; ".join(ana["suggest"]))
            import dataclasses
            areas = spec.get("stamps_by_file", {}).get(str(src))
            vs = dataclasses.replace(s, stamps=areas) if areas is not None else s
            if vs.auto_suggest:
                from .filters import apply_suggestions, describe
                from breezy.core.quality import AI_USE, uses_ai
                use = AI_USE.get(ctx.settings.get("app", "quality", "") if ctx.settings else "") or \
                    ("full" if vs.upscaler != "lanczos" else "light" if uses_ai(vs.to_spec()) else "none")
                adj = apply_suggestions(vs, info, ana, ai=use != "none", upscale_ai=use == "full")
                if adj != vs:
                    log(f"Adjusted to this video's check: {describe(adj)}")
                vs = adj
            enh = Enhancer(ctx.ffmpeg, log, prog, ctx.cancel_event, stage=lambda text: prog(None, text), bench=bench,
                           where=lambda sec: prog(None, None, sec))
            msg = enh.render(info, vs, ana, out)
            if getattr(enh, "compare_path", None):
                ctx.add_output(enh.compare_path)
                log(f"✔ {enh.compare_path.name}: before/after video")
            ctx.add_output(out)
            log(f"✔ {out.name}: {msg}")
            try:
                from .render import learn_size
                learn_size(ctx.settings, info, vs, ana, out)
            except Exception:
                pass
            for side in (out.with_suffix(".srt"), ):
                if vs.subtitles and vs.sub_save_srt and side.is_file():
                    ctx.add_output(side)
        except Cancelled:
            raise
        except Exception as e:  # noqa - keep going with the next video
            ctx.error(f"{src.name}: {str(e).splitlines()[0] if str(e) else type(e).__name__}")

    ctx.parallel(one, workers)
    if ctx.cancel_event.is_set():
        raise Cancelled("Cancelled by user")


def run_enhance(task: Task, ctx: TaskContext):
    _enhance(task, ctx, task.spec["files"])


def run_auto(task: Task, ctx: TaskContext):
    files = task.spec.get("input_files", [])
    if not files:
        ctx.log("No input files.")
        return
    _enhance(task, ctx, files)


register_runner("enhance.check", run_check)
register_runner("enhance.run", run_enhance)
register_runner("enhance.auto", run_auto)
