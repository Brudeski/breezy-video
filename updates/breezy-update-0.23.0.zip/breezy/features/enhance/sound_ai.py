"""AI sound rebuild: AP-BWE turns narrow-band (8 kHz-sampled, phone-like) sound into full 48 kHz sound.

The model works on 21-second windows of the 48 kHz STFT (n_fft 1024, hop 80, window 320).
The original low band is kept exactly; the AI only adds what's above it, cross-faded over 300 Hz.
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable

import numpy as np

from breezy.features.tracker.detector import models_dir

MODEL = "ap_bwe_8k_48k.onnx"
RATE = 48000
N_FFT, HOP, WIN = 1024, 80, 320
WINDOW = 1_008_000           # 21 s
CONTEXT = 24_000             # 0.5 s each side
CHUNK = WINDOW - 2 * CONTEXT
XFADE_HZ, EDGE = 300.0, 0.97
REF_DB = -26.0


def available() -> bool:
    return (models_dir() / MODEL).is_file()


def _window() -> np.ndarray:
    w = 0.5 - 0.5 * np.cos(2 * np.pi * np.arange(WIN) / WIN)     # periodic Hann
    out = np.zeros(N_FFT, np.float64)
    left = (N_FFT - WIN) // 2
    out[left:left + WIN] = w
    return out


_W = _window()


def stft(x: np.ndarray) -> np.ndarray:
    pad = N_FFT // 2
    xp = np.pad(x, pad, mode="reflect")
    n = 1 + (len(xp) - N_FFT) // HOP
    idx = np.arange(N_FFT)[None, :] + HOP * np.arange(n)[:, None]
    frames = xp[idx] * _W[None, :]
    return np.fft.rfft(frames, axis=1).T            # (513, n)


def istft(spec: np.ndarray, length: int) -> np.ndarray:
    frames = np.fft.irfft(spec.T, n=N_FFT, axis=1) * _W[None, :]
    n = frames.shape[0]
    out = np.zeros(N_FFT + HOP * (n - 1))
    norm = np.zeros_like(out)
    w2 = _W ** 2
    for i in range(n):
        s = i * HOP
        out[s:s + N_FFT] += frames[i]
        norm[s:s + N_FFT] += w2
    out /= np.maximum(norm, 1e-8)
    pad = N_FFT // 2
    return out[pad:pad + length]


class BandwidthExtender:
    def __init__(self, use_gpu: bool = True):
        from .ai import _session
        self.session = _session(models_dir() / MODEL, use_gpu)

    def process(self, audio48: np.ndarray, source_rate: int, progress: Callable[[float], None] = lambda f: None,
                cancel: Callable[[], None] = lambda: None) -> np.ndarray:
        """audio48: mono float signal already resampled to 48 kHz from a band-limited source."""
        x = audio48.astype(np.float64)
        rms = np.sqrt(np.mean(x ** 2)) + 1e-9
        gain = 10 ** (REF_DB / 20) / rms
        x = x * gain
        n = len(x)
        out = np.zeros(n)
        cutoff = min(source_rate / 2, 4000.0) * EDGE           # model was trained for 8 kHz sources
        freqs = np.fft.rfftfreq(N_FFT, 1 / RATE)
        lo, hi = cutoff - XFADE_HZ / 2, cutoff + XFADE_HZ / 2
        keep = np.clip((hi - freqs) / (hi - lo), 0, 1)[:, None]  # 1 = original, 0 = AI
        starts = list(range(0, max(n, 1), CHUNK))
        for k, s in enumerate(starts):
            cancel()
            a = s - CONTEXT
            seg = np.zeros(WINDOW)
            src_a, src_b = max(0, a), min(n, a + WINDOW)
            seg[src_a - a:src_b - a] = x[src_a:src_b]
            Z = stft(seg)
            mag = np.log(np.abs(Z) + 1e-4).astype(np.float32)[None]
            pha = np.angle(Z).astype(np.float32)[None]
            mag_wb, pha_wb = self.session.run(None, {"mag_nb": mag, "pha_nb": pha})
            G = np.exp(mag_wb[0].astype(np.float64)) * np.exp(1j * pha_wb[0].astype(np.float64))
            merged = Z * keep + G * (1 - keep)
            y = istft(merged, WINDOW)
            take_a, take_b = s, min(n, s + CHUNK)
            out[take_a:take_b] = y[take_a - a:take_b - a]
            progress((k + 1) / len(starts))
        return (out / gain).astype(np.float32)


def bandwidth_extend_file(ffmpeg, src: Path, dst_wav: Path, source_rate: int, af_before: list[str],
                          use_gpu=True, progress=lambda f: None, cancel=lambda: None) -> None:
    """Decode the sound (with the given filters, e.g. drift fix) to 48 kHz mono, extend, write a WAV."""
    import wave
    from breezy.core import proc
    r = None
    for res in (f"aresample={RATE}:resampler=soxr", f"aresample={RATE}"):
        chain = ",".join(af_before + [res])
        r = proc.run([ffmpeg.ffmpeg, "-v", "error", "-nostdin", "-i", str(src), "-map", "0:a:0", "-af", chain,
                      "-ac", "1", "-f", "f32le", "-"], timeout=None)
        if r.returncode == 0 and r.stdout:
            break
    if r is None or r.returncode != 0:
        raise RuntimeError("couldn't read the sound")
    audio = np.frombuffer(r.stdout, np.float32)
    out = BandwidthExtender(use_gpu).process(audio, source_rate, progress, cancel)
    pcm = (np.clip(out, -1, 1) * 32767).astype(np.int16)
    with wave.open(str(dst_wav), "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(RATE)
        w.writeframes(pcm.tobytes())
