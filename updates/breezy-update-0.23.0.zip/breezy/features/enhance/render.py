"""Run the Enhance pipeline on a whole video, or on one frame for the before/after preview.

Picture:  FFmpeg pre-filters -> [Python steps] -> FFmpeg post-filters -> encoder
          Python steps (only when needed): dust -> per frame (stamps, dehaze, low light, fringes,
          colourise, horizon, AI upscale / resize, faces, privacy blur) -> stutter repair -> retiming
          (RIFE / blend for higher frame rates and slow motion)
Sound:    [AI rebuild of low-quality sound to 48 kHz] -> FFmpeg filters (drift, hum, voice, noise,
          stereo, loudness, slow motion)
"""
from __future__ import annotations

import dataclasses
import queue
import subprocess
import tempfile
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterator, Optional

import numpy as np

from breezy.core import encoders, proc
from breezy.core.ffmpeg import Cancelled, FFmpeg, MediaInfo
from breezy.core.outputs import finish, working_path
from breezy.core.sync import audio_bitrate, needs_fix, tempo
from . import ai, extras, scan, separate, sound_ai, speech
from .filters import (EnhanceSettings, _esc, ai_factor, audio_filters, available_filters, hw_args, output_size,
                      post_filters, pre_filters, shaped_size, target_fps, uses_rife, frame_method)

from collections import OrderedDict

_FRAMES: OrderedDict = OrderedDict()      # preview pictures already decoded: (file, time, filters...) -> frames

HDR10_X265 = ("hdr10=1:repeat-headers=1:colorprim=bt2020:transfer=smpte2084:colormatrix=bt2020nc:"
              "master-display=G(13250,34500)B(7500,3000)R(34000,16000)WP(15635,16450)L(10000000,1):max-cll=1000,203")


class _SegmentEncoder:
    """Looks like one encoder process to the writer, but writes 1-minute parts (parts/00000.mkv, ...) and
    records each finished part, so a stopped render can continue where it was."""

    def __init__(self, raw_in: list[str], args: list[str], seg: dict, on_done):
        self.raw_in, self.args, self.seg, self.on_done = raw_in, args, seg, on_done
        self.idx, self.n, self.p, self.rc = seg["done"], 0, None, 0
        self.errf = tempfile.TemporaryFile()
        self.stdin = self

    def write(self, b: bytes):
        if self.p is None:
            out = self.seg["dir"] / f"{self.idx:05d}.mkv"
            self.p = proc.popen(self.raw_in + self.args + [str(out)], stdin=subprocess.PIPE,
                                stdout=subprocess.DEVNULL, stderr=self.errf)
        self.p.stdin.write(b)
        self.n += 1
        if self.n >= self.seg.get("per_out", self.seg["per"]):
            self._finish()

    def _finish(self):
        self.p.stdin.close()
        rc = self.p.wait()
        self.p = None
        if rc != 0:
            self.rc = rc
            self.errf.seek(0)
            msg = self.errf.read().decode("utf-8", "replace").strip().splitlines()
            raise RuntimeError("encoder failed: " + (msg[-1] if msg else f"exit {rc}"))
        self.idx += 1
        self.n = 0
        self.seg["done"] = self.idx
        self.on_done(self.seg)

    def close(self):
        if self.p is not None:
            self._finish()

    def wait(self) -> int:
        return self.rc

    def kill(self):
        if self.p is not None:
            try:
                self.p.kill()
            except Exception:
                pass


@dataclass
class Plan:
    in_w: int
    in_h: int
    out_w: int
    out_h: int
    factor: int            # AI model factor, 0 = no AI upscaling
    fps: float             # source frame rate
    out_fps: Optional[float]   # new frame rate (None = same)
    faces: bool = False
    colour: bool = False
    rife: bool = False     # out_fps is made in Python (RIFE)
    low_light: bool = False
    privacy: bool = False
    stamps: bool = False
    per_frame_other: bool = False   # dehaze, fringes, horizon
    dust: bool = False
    stutter: bool = False
    slowmo: int = 1
    sound_ai: bool = False
    denoise_ai: bool = False
    remove: bool = False
    deblur: bool = False
    rs: bool = False                 # rolling-shutter fix
    scene: bool = False              # light & colour per scene
    separate: bool = False           # AI voice / music separation
    shape: Optional[tuple] = None    # (picture w, h, frame w, h) when the shape is fixed
    pic_w: int = 0                   # size before the shape fix (after crop)
    pic_h: int = 0

    @property
    def retime(self) -> bool:
        return self.rife or self.slowmo > 1

    @property
    def enc_fps(self) -> float:
        return self.out_fps or self.fps

    @property
    def retime_ratio(self) -> float:
        """Source frames per output frame (before slow motion stretches time)."""
        return self.fps / (self.enc_fps * self.slowmo)

    @property
    def length_factor(self) -> float:
        return float(self.slowmo)

    @property
    def python(self) -> bool:
        return bool(self.factor or self.faces or self.colour or self.retime or self.low_light or self.privacy
                    or self.stamps or self.per_frame_other or self.dust or self.stutter or self.denoise_ai
                    or self.remove or self.deblur or self.rs or self.scene)


def make_plan(info: MediaInfo, s: EnhanceSettings, ana: dict) -> Plan:
    v = info.video
    crop = ana.get("crop") if s.crop == "auto" else None
    pic_w, pic_h = (crop[0], crop[1]) if crop else (v.width, v.height)
    shape = shaped_size(s, pic_w, pic_h, getattr(v, "sar", 1.0) or 1.0, ana)
    in_w, in_h = (shape[2], shape[3]) if shape else (pic_w, pic_h)
    out_w, out_h = output_size(v.width, v.height, s, (in_w, in_h))
    fps = float(v.fps) if v.fps else 30.0
    out_fps = target_fps(s, fps)
    colour = ai.colour_available() and (s.colourise == "on" or (s.colourise == "auto" and bool(ana.get("grayscale"))))
    dark = ana.get("brightness") is None or ana.get("brightness") < 70
    low = bool(s.low_light) and extras.have(extras.LOWLIGHT_MODEL) and (not s.low_light_auto or dark)
    audio = getattr(info, "audio", None)
    rate = audio.sample_rate if audio and audio.sample_rate else 48000
    snd = bool(audio) and sound_ai.available() and (s.sound_ai == "on" or (s.sound_ai == "auto" and rate <= 16000))
    return Plan(in_w, in_h, out_w, out_h, ai_factor(in_w, in_h, out_w, out_h, s), fps, out_fps,
                faces=s.faces and ai.faces_available(), colour=colour, rife=bool(out_fps) and uses_rife(s),
                low_light=low, privacy=s.privacy_faces or s.privacy_plates, stamps=bool(s.stamps),
                per_frame_other=bool(s.dehaze or s.fringes or s.horizon), dust=bool(s.dust),
                stutter=s.stutter != "off", slowmo=max(1, int(s.slowmo)), sound_ai=snd,
                denoise_ai=bool(s.denoise_ai) and extras.have(extras.DENOISE_MODEL),
                remove=s.remove_objects != "off" and extras.have(extras.SEG_MODEL),
                deblur=bool(s.deblur) and extras.have(extras.DEBLUR_MODEL), rs=bool(s.rs_fix and s.rolling_shutter),
                scene=bool(s.per_scene), separate=bool(audio) and s.separate != "off" and separate.available(),
                shape=shape, pic_w=pic_w, pic_h=pic_h)


def _pix_args(codec: str, ten_bit: bool, enc_args: list[str]) -> list[str]:
    name = enc_args[1] if len(enc_args) > 1 else ""
    if ten_bit and codec == "hevc":
        return ["-pix_fmt", "p010le" if name.endswith(("_amf", "_nvenc", "_qsv")) else "yuv420p10le"]
    return ["-pix_fmt", "yuv420p"]


def target_bitrate_kbps(s: EnhanceSettings, out_seconds: float, audio_kbps: int) -> int:
    """Video bitrate that makes the file about target_mb (3% container overhead)."""
    total_kbit = s.target_mb * 8 * 1024 * 0.97
    return max(100, int(total_kbit / max(out_seconds, 0.1) - audio_kbps))


def _bitrate_args(args: list[str], kbps: int) -> list[str]:
    """Turn quality-based encoder arguments into bitrate-based ones (same encoder, same pixel format)."""
    name = args[1]
    pix = args[args.index("-pix_fmt"):args.index("-pix_fmt") + 2] if "-pix_fmt" in args else []
    rate = ["-b:v", f"{kbps}k", "-maxrate", f"{int(kbps * 1.5)}k", "-bufsize", f"{kbps * 2}k"]
    if name.endswith("_nvenc"):
        out = ["-c:v", name, "-preset", encoders.NVENC_PRESET.get(encoders.enc_speed(), "p5"), "-rc", "vbr", *rate]
    elif name.endswith("_amf"):
        out = ["-c:v", name, "-quality", "quality", "-rc", "vbr_peak", *rate]
    elif name.endswith("_qsv"):
        out = ["-c:v", name, *rate]
    else:
        out = ["-c:v", name, "-preset", encoders.X26X_PRESET.get(encoders.enc_speed(), "medium"), *rate]
        if "-x265-params" in args:
            out += ["-x265-params", args[args.index("-x265-params") + 1]]
    extra = [a for a in args if a in ("-color_primaries", "-color_trc", "-colorspace")]
    for a in extra:
        i = args.index(a)
        out += args[i:i + 2]
    return out + pix


def encoder_args(info: MediaInfo, s: EnhanceSettings, out_seconds: float = 0.0,
                 audio_kbps: int = 0) -> tuple[str, list[str]]:
    v = info.video
    hdr = s.hdr == "to_hdr"
    codec = s.codec if s.codec in ("h264", "hevc") else ("hevc" if v.codec == "hevc" else "h264")
    if (s.ten_bit or hdr) and codec == "h264":
        codec = "hevc"                       # 10-bit / HDR means H.265 here
    base = encoders.video_args(codec, s.crf, s.enc_gpu, ["-pix_fmt", "yuv420p"])
    pix = _pix_args(codec, s.ten_bit or hdr, base)
    args = list(base)
    if "-pix_fmt" in args:
        i = args.index("-pix_fmt")
        args[i:i + 2] = pix
    if hdr:
        if "-x265-params" in args:
            i = args.index("-x265-params") + 1
            args[i] = args[i] + ":" + HDR10_X265
        args += ["-color_primaries", "bt2020", "-color_trc", "smpte2084", "-colorspace", "bt2020nc"]
    if s.size_mode == "target" and out_seconds > 0:
        args = _bitrate_args(args, target_bitrate_kbps(s, out_seconds, audio_kbps))
    return codec, args


# ------------------------------------------------------------------ file size estimate
# The source's own bitrate tells how hard the picture is to compress (noise, motion, detail). The result at
# quality (CRF) 18 needs about as many bits per frame as the source (measured 0.9-1.5x); every 6 CRF halves
# it, a bigger picture or more frames add less than proportionally (they are smoother), H.265 needs ~60% of
# H.264, old formats (MPEG-2, DV, MJPEG...) used far more bits for the same picture. Rough by nature - the
# factor learned from finished videos corrects it.
_C18 = 1.1
_OLD_CODECS = {"mpeg2video", "mpeg1video", "mpeg4", "msmpeg4v3", "mjpeg", "dvvideo", "rawvideo", "huffyuv",
               "ffv1", "prores", "dnxhd", "wmv3", "vc1", "h263"}


def size_codec(info: MediaInfo, s: EnhanceSettings) -> str:
    codec = s.codec if s.codec in ("h264", "hevc") else ("hevc" if info.video and info.video.codec == "hevc" else "h264")
    return "hevc" if (s.ten_bit or s.hdr == "to_hdr") else codec


def estimate_size_mb(info: MediaInfo, s: EnhanceSettings, ana: dict | None = None, settings=None) -> float | None:
    """Rough size of the result with 'Set by quality' (MB), corrected by what earlier results really were."""
    v = info.video
    dur = (v.duration if v else 0) or info.duration
    if not v or not dur:
        return None
    plan = make_plan(info, s, ana or {})
    seconds = dur * plan.length_factor
    has_audio = bool(getattr(info, "audio", None))
    try:
        src_bps = Path(info.path).stat().st_size * 8 / dur - (128000 if has_audio else 0)
    except (OSError, TypeError, AttributeError):
        src_bps = 0.0
    if src_bps <= 0:                           # unknown source: ~0.1 bits per pixel at CRF 18
        src_bps = 0.1 * plan.in_w * plan.in_h * (plan.fps or 30)
    codec = size_codec(info, s)
    src_codec = (v.codec or "").lower()
    conv = 0.4 if src_codec in _OLD_CODECS else {("hevc", "h264"): 1.6, ("h264", "hevc"): 0.62}.get(
        (("hevc" if src_codec in ("hevc", "h265", "av1", "vp9") else "h264"), codec), 1.0)
    pixels = (plan.out_w * plan.out_h) / max(1, plan.in_w * plan.in_h)
    frames = (plan.enc_fps * plan.slowmo) / max(1e-6, plan.fps or plan.enc_fps)
    video_bps = src_bps * _C18 * 2 ** ((18 - s.crf) / 6) * conv * pixels ** 0.7 * frames ** 0.5 / plan.slowmo
    abr = 0 if (not has_audio or (plan.slowmo > 1 and s.slowmo_sound == "mute")) else \
        int((s.audio_bitrate or audio_bitrate(info)).rstrip("k"))
    mb = (video_bps * seconds + abr * 1000 * seconds) / 8 / 1048576 * 1.02
    learned = ((settings.get("app", "size_factor") if settings else None) or {}).get(codec)
    return mb * float(learned) if learned else mb


def learn_size(settings, info: MediaInfo, s: EnhanceSettings, ana: dict, out: Path):
    """After a 'Set by quality' result: remember how far off the estimate was (per video format)."""
    if settings is None or s.size_mode != "quality" or not out.is_file():
        return
    raw = estimate_size_mb(info, s, ana, None)
    if not raw:
        return
    ratio = max(0.1, min(10.0, out.stat().st_size / 1048576 / raw))
    table = dict(settings.get("app", "size_factor") or {})
    codec = size_codec(info, s)
    old = table.get(codec)
    table[codec] = ratio if not old else 0.6 * float(old) + 0.4 * ratio
    settings.set("app", "size_factor", table)


class Enhancer:
    def __init__(self, ffmpeg: FFmpeg, log: Callable[[str], None] = print,
                 progress: Callable[[float], None] = lambda f: None, cancel: Optional[threading.Event] = None,
                 stage: Optional[Callable[[str], None]] = None, bench: Optional[dict] = None,
                 where: Optional[Callable[[float], None]] = None):
        self.ff, self.log, self.progress = ffmpeg, log, progress
        self.bench = bench
        self.where = where or (lambda sec: None)     # seconds into the video the current step has reached
        self.stage = stage or (lambda text: None)       # what is being done now (shown on the progress bars)
        self.cancel = cancel or threading.Event()
        self.have = available_filters(ffmpeg.ffmpeg)

    def _shares(self, s: EnhanceSettings, plan: "Plan") -> dict:
        """How much of the progress bar each step before the main render gets, from how much work it is
        compared with the main render (so the bar - and the time left - doesn't race through the quick
        passes and then crawl). Never more than the old fixed shares."""
        from .bench import DEFAULT_BENCH, estimate_minutes
        cap = {"stab": 0.2 if s.stabilize and "vidstabdetect" in self.have else 0.0,
               "scan": 0.05 if (plan.rs or plan.scene) else 0.0,
               "sep": 0.1 if plan.separate else 0.0,
               "sound": 0.1 if plan.sound_ai else 0.0}
        try:
            main = estimate_minutes(s, plan, self.bench or DEFAULT_BENCH) or 0.0
        except Exception:
            return cap
        per_pass = plan.fps * 3.0 * plan.in_w * plan.in_h / 1e6 / 1000     # one decode pass, min per min
        raw = {"stab": 1.5 * per_pass, "scan": 1.0 * per_pass,
               "sep": max(per_pass, 0.05 * main), "sound": max(per_pass, 0.05 * main)}
        raw = {k: (v if cap[k] else 0.0) for k, v in raw.items()}
        total = main + sum(raw.values())
        if total <= 0:
            return cap
        return {k: min(cap[k], raw[k] / total) for k in cap}

    def _check(self):
        if self.cancel.is_set():
            raise Cancelled("Cancelled by user")
        proc.checkpoint()

    # ================================================================ video
    def render(self, info: MediaInfo, s: EnhanceSettings, ana: dict, out: Path) -> str:
        ai.set_half(s.ai_half)
        plan = make_plan(info, s, ana)
        v = info.video
        dur = v.duration or info.duration or 1.0
        out.parent.mkdir(parents=True, exist_ok=True)
        tmp = working_path(out)          # appears in the output folder only when complete
        work = Path(tempfile.mkdtemp(prefix="breezy_enh_"))
        shares = self._shares(s, plan)
        base = sum(shares.values())
        try:
            # ---- stabilisation, pass 1 (motion analysis)
            stab_file = None
            stab_keep = self._stab_cache(info, s, ana, tmp, dur) if shares["stab"] else None
            if stab_keep is not None and stab_keep.is_file():
                stab_file = str(stab_keep)
                self.log("Stabilising: using the camera shake measured in the earlier run.")
            elif shares["stab"]:
                stab_file = str(stab_keep.with_suffix(".tmp")) if stab_keep is not None else str(work / "transforms.trf")
                first = [x for x in pre_filters(s, ana, self.have)[:3] if x.startswith(("bwdif", "yadif", "crop", "zscale"))]
                tripod = ":tripod=1" if s.stab_mode == "lock" else ""
                chain = ",".join(first + [f"vidstabdetect=shakiness={ {1: 4, 2: 6, 3: 9}[s.stabilize] }:accuracy=15"
                                          f"{tripod}:result='{_esc(stab_file)}'"])
                self.log("Stabilising: measuring camera shake…")
                self.stage("Stabilising - measuring the camera shake")
                self.ff.run(["-i", str(info.path), "-map", "0:v:0", "-vf", chain, "-f", "null", "-"], dur,
                            lambda f: (self.progress(shares["stab"] * f), self.where(f * dur)), None, self.cancel)
                if stab_keep is not None:                  # finished: keep it for a resumed run
                    Path(stab_file).replace(stab_keep)
                    stab_file = str(stab_keep)
            pre = pre_filters(s, ana, self.have, stab_file, shape=plan.shape)
            done = shares["stab"]
            # ---- whole-video scan (scenes, camera motion for the rolling-shutter fix)
            self._scan = None
            if shares["scan"]:
                what = " & ".join(x for x, on in (("scenes", plan.scene), ("camera motion", plan.rs)) if on)
                self.log(f"Scanning the video ({what})…")
                self.stage(f"Scanning the whole video ({what})")
                self._scan = scan.prepass(self.ff, info.path, plan.pic_w, plan.pic_h,
                                          pre_filters(s, ana, self.have, colour_only=True), plan.scene, plan.rs,
                                          int(dur * plan.fps), s.hwaccel,
                                          lambda f, d=done: (self.progress(d + shares["scan"] * f),
                                                             self.where(f * dur)), self._check)
                if plan.scene:
                    self.log(f"✔ {len(self._scan['scenes'])} scene(s)")
                done += shares["scan"]
            ratio = tempo(info) if (s.fix_drift and info.audio and needs_fix(info, s.drift_threshold)) else None
            # ---- sound
            audio_src = str(info.path)
            channels = info.audio.channels if info.audio and info.audio.channels else 2
            drift_done = False
            if plan.separate:
                wav = work / "separated.wav"
                msg = {"voices": "Removing the music (AI)", "quieter": "Turning the music down (AI)",
                       "music": "Removing the voices (AI)"}.get(s.separate, "Separating the sound (AI)")
                self.log(msg + "…")
                self.stage(msg)
                separate.separate_file(self.ff, info.path, wav, s.separate, s.music_level,
                                       [f"atempo={ratio:.6f}"] if ratio else [], s.ai_gpu,
                                       lambda f, d=done: (self.progress(d + shares["sep"] * f), self.where(f * dur)),
                                       self._check)
                audio_src, channels, drift_done = str(wav), 2, True
                done += shares["sep"]
            if plan.sound_ai:
                wav = work / "sound.wav"
                self.log(f"Rebuilding the sound with AI ({info.audio.sample_rate // 1000} kHz → 48 kHz)…")
                self.stage("Rebuilding the sound (AI)")
                sound_ai.bandwidth_extend_file(self.ff, Path(audio_src), wav, info.audio.sample_rate,
                                               [f"atempo={ratio:.6f}"] if ratio and not drift_done else [], s.ai_gpu,
                                               lambda f, d=done: (self.progress(d + shares["sound"] * f),
                                                                  self.where(f * dur)),
                                               self._check)
                audio_src, channels, drift_done = str(wav), 1, True
            af = audio_filters(s, self.have, ratio, channels, skip_drift=drift_done) if info.audio else []
            mute = plan.slowmo > 1 and s.slowmo_sound == "mute"
            target = s.size_mode == "target"
            abr = s.audio_bitrate or ("96k" if target else audio_bitrate(info))
            audio_kbps = 0 if (mute or not info.audio) else int(abr.rstrip("k"))
            codec, venc = encoder_args(info, s, dur * plan.length_factor, audio_kbps)
            self._venc = list(venc)
            # ---- subtitles (from the original sound, timed to the result)
            srt = None
            if s.subtitles and info.audio:
                if not speech.available():
                    self.log("Subtitles skipped: the speech component isn't installed yet (restart the app).")
                else:
                    self.log("Writing subtitles from the speech…")
                    self.stage("Writing subtitles from the speech (AI)")
                    segs, lang = speech.transcribe(self.ff, info.path, s.sub_model, s.sub_language, s.sub_translate,
                                                   s.ai_gpu, time_scale=plan.length_factor / (ratio or 1.0),
                                                   log=self.log, cancel=self._check)
                    self._sub_lang = lang
                    srt = work / "subs.srt"
                    speech.write_srt(segs, srt)
                    self.log(f"✔ {len(segs)} subtitle line(s) ({lang})")
            burn = []
            if srt and s.sub_burn and "subtitles" in self.have:
                burn = [f"subtitles=filename='{_esc(str(srt))}':force_style='FontSize={int(s.sub_size)},"
                        f"Outline=2,Shadow=0,MarginV=20'"]
            separate_audio = plan.python or plan.sound_ai or plan.separate
            aargs: list[str] = []
            if info.audio and not mute:
                aargs = ["-map", "1:a:0" if separate_audio else "0:a:0"]
                if af or plan.sound_ai or plan.separate or target:
                    if af:
                        aargs += ["-af", ",".join(af)]
                    aargs += ["-c:a", "aac", "-b:a", abr]
                else:
                    aargs += ["-c:a", "copy"]
            tail = list(venc)
            if codec == "hevc" and out.suffix.lower() in (".mp4", ".mov", ".m4v"):
                tail += ["-tag:v", "hvc1"]
            if out.suffix.lower() in (".mp4", ".mov", ".m4v"):
                tail += ["-movflags", "+faststart"]

            def prog(f):
                self.progress(base + (1 - base) * f)
                self.where(f * dur)

            if not plan.python:
                self.stage("Enhancing the picture (filters)" + (" + sound" if info.audio else ""))
                vf = ",".join(pre + post_filters(s, plan.out_w, plan.out_h, plan.fps, self.have) + burn) or "null"
                inputs = [*hw_args(vf), *(["-hwaccel", "auto"] if s.hwaccel else []), "-i", str(info.path)]
                if separate_audio and aargs:
                    inputs += ["-i", audio_src]
                self.ff.run([*inputs, "-map", "0:v:0", "-vf", vf, *aargs, *tail, str(tmp)],
                            dur, prog, None, self.cancel)
                how = "filters"
            else:
                how = self._render_python(info, s, plan, pre, aargs, audio_src, tail, tmp, dur, prog, burn)
            self.stage("Checking the result")
            o = self.ff.probe(tmp)
            if o.error or not o.video:
                raise RuntimeError("the result can't be read: " + (o.error or "no video"))
            want = dur * plan.length_factor
            got = o.video.duration or o.duration
            if abs(got - want) > max(0.5, 0.03 * want):
                raise RuntimeError(f"length check failed ({got:.1f} s instead of {want:.1f} s)")
            if srt and s.sub_embed:
                self.stage("Adding the subtitle track")
                speech.embed(self.ff, tmp, srt, getattr(self, "_sub_lang", ""))
            finish(tmp, out)
            import shutil as _shs
            _shs.rmtree(tmp.parent / (tmp.stem + ".stab"), ignore_errors=True)    # kept only while unfinished
            if srt and s.sub_save_srt:
                import shutil as _sh
                srt_tmp = working_path(out.with_suffix(".srt"))
                _sh.copyfile(srt, srt_tmp)
                finish(srt_tmp, out.with_suffix(".srt"))
            if s.compare != "off":
                self.make_compare(info, s, ana, plan, out)
        except BaseException:
            if tmp.exists():
                try:
                    tmp.unlink()
                except OSError:
                    pass
            raise
        finally:
            import shutil
            shutil.rmtree(work, ignore_errors=True)
        self.progress(1.0)
        bits = [f"{plan.in_w}x{plan.in_h} → {plan.out_w}x{plan.out_h}", how, venc[1]]
        if plan.out_fps:
            bits.append(f"{plan.out_fps:g} fps")
        if plan.slowmo > 1:
            bits.append(f"{plan.slowmo}× slow motion")
        if plan.separate:
            bits.append({"voices": "music removed", "quieter": "music turned down",
                         "music": "voices removed"}.get(s.separate, "sound separated"))
        if plan.sound_ai:
            bits.append("sound rebuilt to 48 kHz")
        if plan.shape:
            bits.append(f"shape fixed ({plan.pic_w}x{plan.pic_h} → {plan.shape[0]}x{plan.shape[1]}"
                        + (" with bars" if plan.shape[:2] != plan.shape[2:] else "") + ")")
        if ratio:
            bits.append(f"sound re-synced ({info.drift:+.2f} s)")
        if s.hdr == "to_hdr":
            bits.append("HDR10")
        if target:
            bits.append(f"{out.stat().st_size / 1048576:.1f} MB (target {s.target_mb:g} MB)")
        if srt:
            bits.append("subtitles" + (" burned in" if burn else "") + (" + track" if s.sub_embed else ""))
        return ", ".join(bits)

    def make_compare(self, info: MediaInfo, s: EnhanceSettings, ana: dict, plan: Plan, out: Path):
        """A before/after video next to the result: side by side, or a split screen."""
        if plan.slowmo > 1:
            self.log("Before/after video skipped: it can't line up with slow motion.")
            return
        if s.hdr == "to_hdr":
            self.log("Before/after video skipped: an HDR result can't be shown next to the normal original.")
            return
        from breezy.core.outputs import unique_path
        cmp_path = unique_path(out.with_name(out.stem + "_compare" + out.suffix))
        cmp_tmp = working_path(cmp_path)
        crop = ana.get("crop") if s.crop == "auto" else None
        fps = plan.enc_fps
        w, h = plan.out_w, plan.out_h
        if s.compare == "side":
            sc = min(1.0, 1920 / w)
            cw, chh = int(w * sc) // 2 * 2, int(h * sc) // 2 * 2
            a = f"scale={cw}:{chh}:flags=lanczos,setsar=1"
            fc = (f"[0:v]{'crop={}:{}:{}:{},'.format(*crop) if crop else ''}{a},fps={fps:.6g}[b];"
                  f"[1:v]{a}[a];[b][a]hstack=inputs=2,drawbox=x={cw - 1}:y=0:w=2:h=ih:color=white@0.9:t=fill[v]")
        else:
            half = (w // 2) // 2 * 2
            fc = (f"[0:v]{'crop={}:{}:{}:{},'.format(*crop) if crop else ''}scale={w}:{h}:flags=lanczos,setsar=1,"
                  f"fps={fps:.6g},crop={half}:{h}:0:0[b];[1:v]setsar=1,crop={w - half}:{h}:{half}:0[a];"
                  f"[b][a]hstack=inputs=2,drawbox=x={half - 1}:y=0:w=2:h=ih:color=white@0.9:t=fill[v]")
        s2 = dataclasses.replace(s, size_mode="quality", hdr="off")
        codec, venc = encoder_args(info, s2)
        self.log(f"Making the before/after video ({'side by side' if s.compare == 'side' else 'split screen'})…")
        self.stage("Making the before/after video")
        self.ff.run(["-i", str(info.path), "-i", str(out), "-filter_complex", fc, "-map", "[v]", "-map", "1:a?",
                     *venc, "-c:a", "copy", *(["-movflags", "+faststart"] if out.suffix.lower() == ".mp4" else []),
                     str(cmp_tmp)], 0, None, None, self.cancel)
        finish(cmp_tmp, cmp_path)
        self.compare_path = cmp_path

    # ============================================================ python steps
    def _steps(self, s: EnhanceSettings, plan: Plan) -> dict:
        st = {
            "up": ai.Upscaler(s.upscaler, plan.factor, s.ai_gpu, s.tile, reuse=s.ai_reuse) if plan.factor else None,
            "faces": ai.FaceRestorer(s.ai_gpu, s.face_strength, s.face_min) if plan.faces else None,
            "colour": ai.Colouriser(s.ai_gpu, s.colour_strength) if plan.colour else None,
            "stamps": extras.StampRemover(s.stamps, s.stamp_method, s.ai_gpu) if plan.stamps else None,
            "dehaze": extras.Dehazer(s.dehaze) if s.dehaze else None,
            "low": extras.LowLight(s.low_light, s.ai_gpu) if plan.low_light else None,
            "horizon": extras.Horizon(s.horizon) if s.horizon else None,
            "privacy": extras.PrivacyBlur(s.privacy_faces, s.privacy_plates, s.privacy_style, s.ai_gpu)
            if plan.privacy else None,
            "vdn": extras.VideoDenoiser(s.denoise_ai, s.denoise_ai_temporal, s.ai_gpu, s.tile, reuse=s.ai_reuse)
            if plan.denoise_ai else None,
            "remove": extras.ObjectRemover(s.remove_objects, s.remove_method, s.remove_grow, s.ai_gpu)
            if plan.remove else None,
            "deblur": extras.Deblurrer(s.deblur, s.ai_gpu, s.tile, reuse=s.ai_reuse) if plan.deblur else None,
            "rs": None, "scene": None,
        }
        sc = getattr(self, "_scan", None)
        if plan.rs:
            pw, ph = (plan.shape[0], plan.shape[1]) if plan.shape else (plan.in_w, plan.in_h)
            if sc and sc.get("motion") is not None:
                sw, sh = sc["size"]
                st["rs"] = extras.RollingShutterFix(s.rolling_shutter, sc["motion"], (pw / sw, ph / sh))
            else:
                st["rs"] = extras.RollingShutterFix(s.rolling_shutter)
        if plan.scene:
            st["scene"] = extras.SceneLight(s.per_scene, sc["scenes"] if sc else None)
        return st

    def _step_list(self, st: dict, plan: Plan, s: EnhanceSettings) -> list:
        """The per-frame steps in order: [(key, function)]."""
        steps = []
        for key in ("rs", "scene", "vdn", "deblur", "remove", "stamps", "dehaze", "low"):
            if st.get(key) is not None:
                steps.append((key, st[key].apply))
        if s.fringes:
            steps.append(("fringes", lambda f: extras.fix_fringes(f, s.fringes)))
        if st.get("colour") is not None:
            steps.append(("colour", st["colour"].colourise))
        if st.get("horizon") is not None:
            steps.append(("horizon", st["horizon"].apply))
        up = st.get("up")
        steps.append(("up", lambda f: ai.enhance_frame(up, f, plan.out_w, plan.out_h, s.ai_strength, self._check)))
        if st.get("faces") is not None:
            steps.append(("faces", lambda f: st["faces"].restore(f, self._check)))
        if st.get("privacy") is not None:
            steps.append(("privacy", st["privacy"].apply))
        return steps

    def _process(self, st: dict, rgb: np.ndarray, plan: Plan, s: EnhanceSettings) -> np.ndarray:
        for _key, fn in self._step_list(st, plan, s):
            rgb = fn(rgb)
        return rgb

    def _log_step_times(self, busy: dict, wall: float, frames: int, names: dict):
        """Which step limits the speed: each step runs in its own thread, so the slowest one sets the pace
        and the others work alongside it."""
        if not busy or not frames or wall <= 0:
            return
        label = dict(names, up="upscale / resize", fringes="fringes")
        rows = sorted(busy.items(), key=lambda kv: -kv[1])
        parts = [f"{label.get(k, k)} {v / frames:.2f} s ({min(100, v / wall * 100):.0f}% busy)" for k, v in rows[:5]]
        self.log("Time per frame: " + ", ".join(parts))
        k, v = rows[0]
        self.log(f"Slowest step: {label.get(k, k)} - it sets the speed; the other steps run at the same time.")

    @staticmethod
    def _stage(upstream, fn, busy: dict, key: str, stop: threading.Event, depth: int = 3):
        """Run one step in its own thread: while the graphics card works on one frame, the processor
        already prepares the next one in the step before (frames stay in order)."""
        q: queue.Queue = queue.Queue(maxsize=depth)
        end = object()
        err: list = []

        def put(x):
            while not stop.is_set():
                try:
                    q.put(x, timeout=0.2)
                    return True
                except queue.Full:
                    pass
            return False

        def run():
            try:
                for f in upstream:
                    t = time.perf_counter()
                    out = fn(f)
                    busy[key] = busy.get(key, 0.0) + time.perf_counter() - t
                    if not put(out):
                        return
            except BaseException as e:  # noqa - handed to the consumer
                err.append(e)
            put(end)

        threading.Thread(target=run, daemon=True, name=f"enh-{key}").start()
        while True:
            try:
                x = q.get(timeout=0.2)
            except queue.Empty:
                if stop.is_set():
                    return
                continue
            if x is end:
                if err:
                    raise err[0]
                return
            yield x

    def _render_python(self, info, s, plan: Plan, pre, aargs, audio_src, tail, tmp: Path, dur, prog,
                       burn: list | None = None) -> str:
        st = self._steps(s, plan)
        names = {"up": f"upscale {ai.MODELS.get((s.upscaler, plan.factor), '')}", "faces": "faces",
                 "colour": "colourise", "stamps": f"hide areas ({s.stamp_method})", "dehaze": "dehaze",
                 "low": "low-light AI", "horizon": "horizon", "privacy": "privacy blur", "vdn": "AI denoise",
                 "remove": f"remove {s.remove_objects.replace('_', ' & ')}", "deblur": "AI deblur",
                 "rs": "rolling-shutter fix", "scene": "light & colour per scene"}
        used = [names[k] for k, v in st.items() if v is not None]
        if plan.dust:
            used.insert(0, "dust")
        if s.fringes:
            used.append("fringes")
        need_between = plan.retime or plan.stutter
        use_rife = need_between and ai.rife_available() and (
            (plan.retime and frame_method(s) == "rife") or (s.stutter == "ai")
            or (plan.slowmo > 1 and frame_method(s) == "rife"))
        rife = ai.Interpolator(s.ai_gpu) if use_rife else None
        between = rife.between if rife else extras.blend_between
        if plan.stutter:
            used.append(f"stutter repair ({'AI' if rife and s.stutter == 'ai' else 'blend'})")
        if plan.retime:
            used.append(f"{'RIFE' if rife else 'blended'} frames → {plan.enc_fps * plan.slowmo:g} fps"
                        + (f" played at {plan.enc_fps:g} fps ({plan.slowmo}× slow)" if plan.slowmo > 1 else ""))
        devs = [x.session.get_providers()[0] for x in list(st.values()) + [rife]
                if x is not None and getattr(x, "session", None) is not None]
        dev = "graphics card" if any(d != "CPUExecutionProvider" for d in devs) else "processor"
        from breezy.core import ai_engine
        if ai_engine.trt_active and any(getattr(x, "session", None) is not None and
                                        getattr(x.session, "_max_batch", None) for x in st.values() if x is not None):
            dev += ", TensorRT"
            self.log("TensorRT: a model used for the first time with this tile size is prepared for the graphics "
                     "card first (a few minutes, once).")
        self.log(f"Steps: {', '.join(used) or 'resize only'} (AI on the {dev})")
        friendly = {"up": f"AI upscaling to {plan.out_w}x{plan.out_h}" if plan.factor else "", "faces": "restoring faces",
                    "colour": "colourising", "vdn": "AI denoise", "deblur": "AI deblur", "low": "low-light AI",
                    "remove": "removing objects", "privacy": "privacy blur", "stamps": "hiding areas",
                    "rs": "wobble fix", "scene": "light & colour per scene", "dehaze": "dehaze",
                    "horizon": "levelling"}
        short = [friendly[k] for k, v in st.items() if v is not None and friendly.get(k)]
        if plan.stutter:
            short.append("stutter repair")
        if plan.retime:
            short.append("slow motion" if plan.slowmo > 1 else "new frame rate")
        short = short or ["resize"]
        steps_text = ", ".join(short[:4]) + (f" +{len(short) - 4} more" if len(short) > 4 else "")

        n_est = max(1, int(round(dur * plan.fps)))
        dec_vf = ",".join(pre + ["format=rgb24"])
        post = post_filters(s, plan.out_w, plan.out_h, plan.fps, self.have, resize=False,
                            python_retime=plan.retime) + list(burn or [])
        seg = self._segments(info, s, plan, dur, burn, tmp)
        start_frame, n_total = 0, n_est
        if seg:
            start_frame = seg["done"] * seg["per"]
            if seg["done"]:
                self.log(f"Resuming: {seg['done']} part(s) ({start_frame / plan.fps / 60:.1f} min) were already made.")
            for k in ("rs", "scene"):                   # these steps count frames: continue the count
                if st.get(k) is not None:
                    st[k].i = start_frame
            n_est = max(1, n_total - start_frame)
        # stabilising (vidstabtransform) counts frames from the start of the video: don't jump, drop instead
        skip = start_frame if (start_frame and s.stabilize) else 0
        seek = ["-ss", f"{start_frame / plan.fps:.6f}"] if (start_frame and not skip) else []
        dec = proc.popen([self.ff.ffmpeg, "-v", "error", "-nostdin", *hw_args(dec_vf),
                          *(["-hwaccel", "auto"] if s.hwaccel else []), *seek,
                          "-i", str(info.path), "-map", "0:v:0", "-an", "-sn", "-dn", "-vf", dec_vf,
                          "-fps_mode", "passthrough", "-f", "rawvideo", "-"],
                         stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        raw_in = [self.ff.ffmpeg, "-v", "error", "-nostdin", "-y", "-f", "rawvideo", "-pix_fmt", "rgb24",
                  "-s", f"{plan.out_w}x{plan.out_h}",
                  # frames leave Python at the new rate only when Python made the new frames (RIFE / slow
                  # motion); otherwise they are still at the source rate and FFmpeg's filters convert them
                  "-r", f"{(plan.enc_fps if plan.retime else plan.fps):.6g}", "-i", "-"]
        errf = tempfile.TemporaryFile()
        if seg:
            enc = _SegmentEncoder(raw_in, ["-map", "0:v:0", *(["-vf", ",".join(post)] if post else []),
                                           *self._venc, "-an"], seg, self._save_segments)
        else:
            enc_cmd = list(raw_in)
            if aargs:
                enc_cmd += ["-i", audio_src]
            enc_cmd += ["-map", "0:v:0", *(["-vf", ",".join(post)] if post else []), *aargs, *tail, str(tmp)]
            enc = proc.popen(enc_cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=errf)
        frame_bytes = plan.in_w * plan.in_h * 3
        qin: queue.Queue = queue.Queue(maxsize=4)
        qout: queue.Queue = queue.Queue(maxsize=4)
        failed: list = []

        def reader():
            try:
                dropped = 0
                while True:
                    buf = dec.stdout.read(frame_bytes)
                    if len(buf) < frame_bytes:
                        break
                    if dropped < skip:              # already made in an earlier run
                        dropped += 1
                        continue
                    qin.put(buf)
            finally:
                qin.put(None)

        def writer():
            try:
                while True:
                    b = qout.get()
                    if b is None:
                        break
                    enc.stdin.write(b)
            except Exception as e:  # noqa - encoder died; reported below
                failed.append(e)
                while qout.get() is not None:
                    pass

        tr, tw = threading.Thread(target=reader, daemon=True), threading.Thread(target=writer, daemon=True)
        tr.start()
        tw.start()
        count = [0]
        n_parts = -(-n_total // seg["per"]) if seg else 0
        shown = [-1]

        def show_stage(frame_no: int):
            part = frame_no // seg["per"] + 1 if seg else 0
            if part != shown[0]:
                shown[0] = part
                self.stage(f"Enhancing ({steps_text})" + (f" - part {min(part, n_parts)} of {n_parts}" if seg else ""))

        show_stage(start_frame)

        def source() -> Iterator[np.ndarray]:
            while True:
                self._check()
                buf = qin.get()
                if buf is None:
                    return
                count[0] += 1
                n = count[0]
                if seg and n % 25 == 0:
                    show_stage(start_frame + n)
                yield np.frombuffer(buf, np.uint8).reshape(plan.in_h, plan.in_w, 3)

        g: Iterator[np.ndarray] = source()
        if plan.dust:
            g = extras.dust_stream(g, s.dust)
        busy: dict = {}
        stop = threading.Event()
        for key, fn in self._step_list(st, plan, s):
            g = self._stage(g, fn, busy, key, stop)
        if plan.stutter:
            g = extras.stutter_stream(g, between if s.stutter == "ai" else extras.blend_between,
                                      max_run=max(1, int(s.stutter_max)))
        if plan.retime:
            g = extras.retime_stream(g, plan.retime_ratio, between)
        try:
            t_loop = time.monotonic()
            n_out_est = n_est * (plan.enc_fps * plan.slowmo / plan.fps if plan.retime else 1.0)
            k_out, t_first = 0, None
            ratio_out = n_out_est / max(1, n_est)            # output frames per input frame
            done_out, all_out = start_frame * ratio_out, max(1.0, n_total * ratio_out)
            for f in g:
                qout.put(f.tobytes())
                k_out += 1
                if k_out % 2 == 0:       # count finished frames, not frames read (many wait in the queues)
                    prog(min(0.99, (done_out + k_out) / all_out))
                if k_out == 1:
                    t_first = time.monotonic()
                elif k_out == 13 and t_first:      # measured once the pipeline is full
                    per = (time.monotonic() - t_first) / 12
                    self.log(f"Speed: {1 / per:.2f} frames/s - about {per * n_out_est / 60:.0f} min for this video")
            qout.put(None)
            self._log_step_times(busy, time.monotonic() - t_loop, count[0], names)
            tw.join()
            enc.stdin.close()
            rc = enc.wait()
            if seg and rc == 0 and not failed:
                seg["complete"] = True
                self._save_segments(seg)
                self.stage(f"Joining the {n_parts} parts and adding the sound")
                self._join_segments(seg, aargs, audio_src, tail, tmp)
            if rc != 0 or failed:
                errf.seek(0)
                msg = errf.read().decode("utf-8", "replace").strip().splitlines()
                raise RuntimeError("encoder failed: " + (msg[-1] if msg else str(failed[0]) if failed else f"exit {rc}"))
        except BaseException:
            stop.set()
            for p in (dec, enc):
                try:
                    p.kill()
                except Exception:
                    pass
            try:
                qout.put_nowait(None)
            except queue.Full:
                pass
            raise
        finally:
            stop.set()
            try:
                dec.kill()
            except Exception:
                pass
            dec.stdout.close()
            dec.wait()
            errf.close()
        if seg:
            import shutil as _sh
            _sh.rmtree(seg["dir"], ignore_errors=True)
        return f"{', '.join(used) or 'resize'} ({start_frame + count[0]} frames)"

    # ============================================================ resume inside a file
    SEGMENT_SECONDS = 60

    def _stab_cache(self, info, s: EnhanceSettings, ana: dict, tmp: Path, dur: float) -> Optional[Path]:
        """Where a long video's measured camera shake is kept until the video is finished (so a resumed run
        doesn't measure it again)."""
        if not s.resume_parts or dur < 2 * self.SEGMENT_SECONDS:
            return None
        import hashlib
        import json
        st = info.path.stat()
        key = hashlib.sha1(json.dumps([str(info.path), st.st_size, int(st.st_mtime), s.stabilize, s.stab_mode, s.deinterlace,
                                       s.crop, ana.get("crop"), ana.get("interlaced")], default=str)
                           .encode()).hexdigest()[:16]
        d = tmp.parent / (tmp.stem + ".stab")
        d.mkdir(parents=True, exist_ok=True)
        for old in d.glob("*.trf"):
            if old.stem != key:
                old.unlink(missing_ok=True)
        return d / f"{key}.trf"

    def _segments(self, info, s: EnhanceSettings, plan: Plan, dur: float, burn, tmp: Path) -> Optional[dict]:
        """Long videos are made in 1-minute parts kept in the hidden working folder: if the app stops
        (cancel, crash, power cut), the next run continues after the last finished part."""
        if not s.resume_parts or dur < 2 * self.SEGMENT_SECONDS or burn or not plan.fps:
            return None
        per = max(1, int(round(self.SEGMENT_SECONDS * plan.fps)))
        per_out = per
        if plan.retime:
            # new frames: a part must hold a whole number of output frames that start exactly on a source
            # frame, so a resumed run makes the same frames as an unbroken one
            from fractions import Fraction
            r = Fraction(plan.retime_ratio).limit_denominator(100000)
            if r.numerator > 4 * per:
                return None
            per = max(r.numerator, int(round(per / r.numerator)) * r.numerator)
            per_out = per * r.denominator // r.numerator
        import hashlib
        import json
        spec = {k: v for k, v in s.to_spec().items() if k not in ("tile", "videos_at_once", "hwaccel")}
        st = info.path.stat()
        # [2, ...]: parts made before 0.15.2 could have the wrong frame timing - never reuse them
        key = hashlib.sha1(json.dumps([2, str(info.path), st.st_size, int(st.st_mtime), spec, plan.in_w, plan.in_h,
                                       plan.out_w, plan.out_h, plan.fps, per_out], sort_keys=True, default=str)
                           .encode()).hexdigest()[:16]
        d = tmp.parent / (tmp.stem + ".parts")
        seg = {"dir": d, "key": key, "per": per, "per_out": per_out, "done": 0, "complete": False}
        try:
            old = json.loads((d / "parts.json").read_text("utf-8"))
            if old.get("key") == key and old.get("per") == seg["per"]:
                seg["done"] = int(old.get("done", 0))
                seg["complete"] = bool(old.get("complete"))
        except (OSError, ValueError):
            pass
        if not seg["done"]:
            import shutil as _sh
            _sh.rmtree(d, ignore_errors=True)
        d.mkdir(parents=True, exist_ok=True)
        # parts that were started but not finished are made again
        for f in d.glob("*.mkv"):
            try:
                if int(f.stem) >= seg["done"]:
                    f.unlink()
            except (ValueError, OSError):
                pass
        return seg

    @staticmethod
    def _save_segments(seg: dict):
        import json
        tmpf = seg["dir"] / "parts.json.new"
        tmpf.write_text(json.dumps({k: v for k, v in seg.items() if k != "dir"}), "utf-8")
        tmpf.replace(seg["dir"] / "parts.json")

    def _join_segments(self, seg: dict, aargs, audio_src, tail, tmp: Path):
        """Put the parts together (no re-encoding) and add the sound."""
        parts = sorted(seg["dir"].glob("*.mkv"), key=lambda f: int(f.stem))
        lst = seg["dir"] / "list.txt"
        lst.write_text("".join("file '" + str(p).replace("\\", "/").replace("'", "'\\''") + "'\n" for p in parts),
                       "utf-8")
        cmd = [self.ff.ffmpeg, "-v", "error", "-nostdin", "-y", "-f", "concat", "-safe", "0", "-i", str(lst)]
        if aargs:
            cmd += ["-i", audio_src]
        cmd += ["-map", "0:v:0", *aargs, "-c:v", "copy", *tail[len(self._venc):], str(tmp)]
        r = proc.run(cmd, timeout=None, text=True)
        if r.returncode != 0:
            raise RuntimeError("joining the parts failed: " + (r.stderr or "").strip()[-200:])

    # ============================================================== preview
    def preview(self, info: MediaInfo, s: EnhanceSettings, ana: dict, t: float, max_w: int = 0, use_ai: bool = True):
        """Returns (before_rgb, after_rgb, (ai seconds per frame, device) or None) at the output size
        (or scaled down to max_w wide). 'Before' is the source, cropped like the result and resized plainly.
        Without use_ai the AI steps (upscale, faces, colour, low light, AI fill) are left out."""
        import cv2
        ai.set_half(s.ai_half)
        if not use_ai:
            s = dataclasses.replace(s, upscaler="lanczos", faces=False, colourise="off", low_light=0, denoise_ai=0,
                                    remove_objects="off", deblur=0,
                                    stamp_method="blur" if s.stamp_method == "ai" else s.stamp_method)
        plan = make_plan(info, s, ana)
        v = info.video
        t = max(0.0, min(t, (v.duration or info.duration or 1) - 0.1))
        crop = ana.get("crop") if s.crop == "auto" else None
        raw = self._frame(info.path, t, ["crop={}:{}:{}:{}".format(*crop)] if crop else [], plan.pic_w, plan.pic_h,
                          hwaccel=s.hwaccel)
        start = max(0.0, t - 0.5)
        pre = pre_filters(s, ana, self.have, single_frame=True, shape=plan.shape)
        frames = self._frame(info.path, start, pre, plan.in_w, plan.in_h, last_of=t - start + 0.04, all_frames=True,
                             hwaccel=s.hwaccel)
        pre_img = frames[-1]
        ai_sec = None
        frame_steps = plan.factor or plan.faces or plan.colour or plan.low_light or plan.privacy or plan.stamps \
            or plan.per_frame_other or plan.denoise_ai or plan.remove or plan.deblur or plan.rs or plan.scene
        if frame_steps:
            self._scan = None
            st = self._steps(s, plan)
            if st.get("rs") is not None and len(frames) >= 2:
                st["rs"].motion_for(frames[-2])       # the frame before, so the motion can be measured
            t1 = time.monotonic()
            mid = self._process(st, pre_img, plan, s)
            sec = time.monotonic() - t1
            ai_used = [x for x in st.values() if x is not None and getattr(x, "session", None) is not None]
            if ai_used:
                gpu = any(x.session.get_providers()[0] != "CPUExecutionProvider" for x in ai_used)
                ai_sec = (sec, "graphics card" if gpu else "processor")
            post = post_filters(s, plan.out_w, plan.out_h, plan.fps, self.have, resize=False, single_frame=True)
            after = self._filter_image(mid, post) if post else mid
        else:
            post = post_filters(s, plan.out_w, plan.out_h, plan.fps, self.have, single_frame=True)
            after = self._filter_image(pre_img, post)
        before = cv2.resize(raw, (after.shape[1], after.shape[0]), interpolation=cv2.INTER_LANCZOS4)
        if max_w and after.shape[1] > max_w:
            h = int(round(after.shape[0] * max_w / after.shape[1]))
            before = cv2.resize(before, (max_w, h), interpolation=cv2.INTER_AREA)
            after = cv2.resize(after, (max_w, h), interpolation=cv2.INTER_AREA)
        return before, after, ai_sec

    def _frame(self, path: Path, t: float, vf: list[str], w: int, h: int, last_of: float = 0.0,
               all_frames: bool = False, hwaccel: bool = True):
        """Decoded (and filtered) picture(s) at time t. Kept in a small cache, so changing a setting that
        doesn't affect these filters doesn't decode again."""
        chain = ",".join(vf + ["format=rgb24"])
        try:
            mt = Path(path).stat().st_mtime
        except OSError:
            mt = 0
        key = (str(path), mt, round(t, 3), chain, w, h, round(last_of, 3), all_frames)
        hit = _FRAMES.get(key)
        if hit is not None:
            _FRAMES.move_to_end(key)
            return [f.copy() for f in hit] if all_frames else hit.copy()
        data = b""
        for hw in ((True, False) if hwaccel else (False,)):       # graphics-card decoding, else the processor
            cmd = [self.ff.ffmpeg, "-v", "error", "-nostdin", *hw_args(chain), *(["-hwaccel", "auto"] if hw else []),
                   "-ss", f"{t:.3f}", "-i", str(path)]
            if last_of:
                cmd += ["-t", f"{last_of:.3f}"]
            else:
                cmd += ["-frames:v", "1"]
            cmd += ["-map", "0:v:0", "-an", "-sn", "-vf", chain, "-f", "rawvideo", "-"]
            data = proc.run(cmd, timeout=300).stdout
            if len(data) >= w * h * 3:
                break
        fb = w * h * 3
        if len(data) < fb:
            raise RuntimeError("couldn't read a frame at this time")
        k = len(data) // fb - 1
        if all_frames:
            out = [np.frombuffer(data[i * fb:(i + 1) * fb], np.uint8).reshape(h, w, 3).copy()
                   for i in range(max(0, k - 1), k + 1)]
        else:
            out = np.frombuffer(data[k * fb:(k + 1) * fb], np.uint8).reshape(h, w, 3).copy()
        _FRAMES[key] = out
        while len(_FRAMES) > 16:
            _FRAMES.popitem(last=False)
        return [f.copy() for f in out] if all_frames else out.copy()

    def _filter_image(self, rgb: np.ndarray, vf: list[str]) -> np.ndarray:
        h, w = rgb.shape[:2]
        cmd = [self.ff.ffmpeg, "-v", "error", "-nostdin", "-f", "rawvideo", "-pix_fmt", "rgb24", "-s", f"{w}x{h}",
               "-i", "-", "-vf", ",".join(vf + ["format=rgb24"]), "-f", "rawvideo", "-"]
        p = proc.popen(cmd, stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        data, err = p.communicate(rgb.tobytes(), timeout=300)
        if p.returncode != 0 or not data:
            raise RuntimeError("preview filter failed: " + err.decode("utf-8", "replace").strip()[-200:])
        out_w, out_h = w, h
        for f in vf:
            if f.startswith("scale="):
                a = f[6:].split(":")
                out_w, out_h = int(a[0]), int(a[1])
        return np.frombuffer(data[:out_w * out_h * 3], np.uint8).reshape(out_h, out_w, 3).copy()
