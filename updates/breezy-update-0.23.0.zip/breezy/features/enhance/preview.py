"""Before/after preview: one frame rendered with the current settings, compared with a
draggable divider; zoom to 100%/200% and drag to look around."""
from __future__ import annotations

import threading
import time
from typing import Optional

import numpy as np
from PySide6.QtCore import QObject, QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPen
from PySide6.QtWidgets import QComboBox, QHBoxLayout, QLabel, QSizePolicy, QSlider, QVBoxLayout, QWidget

from breezy.core import theme


def _qimg(rgb: np.ndarray) -> QImage:
    h, w = rgb.shape[:2]
    return QImage(np.ascontiguousarray(rgb).data, w, h, w * 3, QImage.Format_RGB888).copy()


def _t(sec: float) -> str:
    m, s = divmod(max(0.0, sec), 60)
    h, m = divmod(int(m), 60)
    return f"{h}:{m:02d}:{s:04.1f}" if h else f"{m}:{s:04.1f}"


class _Compare(QWidget):
    area_drawn = Signal(list)

    def __init__(self):
        super().__init__()
        self.areas: list = []          # [x, y, w, h] fractions of the picture, drawn on top
        self.mark_mode = False
        self._new_area = None
        self.before: Optional[QImage] = None
        self.after: Optional[QImage] = None
        self.split = 0.5
        self.zoom = 0.0                # 0 = fit
        self.center = QPointF(0.5, 0.5)
        self.message = "Select a video, then pick a moment to compare."
        self._drag = None
        self.setMinimumSize(320, 220)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMouseTracking(True)

    def _geom(self):
        iw, ih = self.after.width(), self.after.height()
        W, H = self.width(), self.height()
        if self.zoom <= 0:
            sc = min(W / iw, H / ih)
        else:
            sc = self.zoom / max(1.0, self.devicePixelRatioF())
        dw, dh = iw * sc, ih * sc
        if self.zoom <= 0:
            x0, y0 = (W - dw) / 2, (H - dh) / 2
        else:
            x0 = W / 2 - self.center.x() * dw
            y0 = H / 2 - self.center.y() * dh
            x0 = min(0, max(W - dw, x0)) if dw > W else (W - dw) / 2
            y0 = min(0, max(H - dh, y0)) if dh > H else (H - dh) / 2
        return QRectF(x0, y0, dw, dh)

    def paintEvent(self, _e):
        c = theme.colors()
        p = QPainter(self)
        p.setRenderHint(QPainter.SmoothPixmapTransform, self.zoom <= 0)
        p.fillRect(self.rect(), QColor("#0b0d11"))
        if self.after is None or self.before is None:
            p.setPen(QColor(c["muted"]))
            p.drawText(self.rect().adjusted(20, 20, -20, -20), Qt.AlignCenter | Qt.TextWordWrap, self.message)
            p.end()
            return
        r = self._geom()
        sx = max(r.left(), min(r.right(), self.width() * self.split))
        p.save()
        p.setClipRect(QRectF(0, 0, sx, self.height()))
        p.drawImage(r, self.before)
        p.restore()
        p.save()
        p.setClipRect(QRectF(sx, 0, self.width() - sx, self.height()))
        p.drawImage(r, self.after)
        p.restore()
        p.setPen(QPen(QColor("#ffffff"), 2))
        p.drawLine(QPointF(sx, 0), QPointF(sx, self.height()))
        p.setBrush(QColor(c["accent"]))
        p.drawEllipse(QPointF(sx, self.height() / 2), 9, 9)
        f = QFont()
        f.setPixelSize(12)
        f.setBold(True)
        p.setFont(f)
        for text, x, align in (("BEFORE", sx - 8, Qt.AlignRight), ("AFTER", sx + 8, Qt.AlignLeft)):
            box = QRectF(x - 80 if align == Qt.AlignRight else x, 8, 80, 20)
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(0, 0, 0, 150))
            tw = p.fontMetrics().horizontalAdvance(text) + 12
            bx = box.right() - tw if align == Qt.AlignRight else box.left()
            p.drawRoundedRect(QRectF(bx, 8, tw, 20), 4, 4)
            p.setPen(Qt.white)
            p.drawText(QRectF(bx, 8, tw, 20), Qt.AlignCenter, text)
        if self.areas or self._new_area:
            p.setBrush(Qt.NoBrush)
            p.setPen(QPen(QColor("#facc15"), 2, Qt.DashLine))
            for a in self.areas + ([self._new_area] if self._new_area else []):
                p.drawRect(QRectF(r.x() + a[0] * r.width(), r.y() + a[1] * r.height(), a[2] * r.width(),
                                  a[3] * r.height()))
        if self.mark_mode:
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(0, 0, 0, 160))
            p.drawRoundedRect(QRectF(10, self.height() - 34, 330, 24), 6, 6)
            p.setPen(Qt.white)
            p.drawText(QRectF(10, self.height() - 34, 330, 24), Qt.AlignCenter,
                       "Drag a box around each stamp or logo to hide")
        if self.message and self.message.startswith("Rendering"):
            p.setPen(Qt.NoPen)
            p.setBrush(QColor(0, 0, 0, 150))
            p.drawRoundedRect(QRectF(self.width() / 2 - 90, self.height() - 34, 180, 24), 6, 6)
            p.setPen(Qt.white)
            p.drawText(QRectF(self.width() / 2 - 90, self.height() - 34, 180, 24), Qt.AlignCenter, "Updating…")
        p.end()

    def _img_pos(self, pt):
        r = self._geom()
        return (min(1, max(0, (pt.x() - r.x()) / r.width())), min(1, max(0, (pt.y() - r.y()) / r.height())))

    def mousePressEvent(self, e):
        if self.after is None:
            return
        if self.mark_mode:
            self._drag = ("mark", self._img_pos(e.position()), None)
            return
        x = e.position().x()
        near = abs(x - self.width() * self.split) < 14
        self._drag = ("split" if near or self.zoom <= 0 else "pan", e.position(), QPointF(self.center))
        self.mouseMoveEvent(e)

    def mouseMoveEvent(self, e):
        if self.after is None:
            return
        if self.mark_mode:
            self.setCursor(Qt.CrossCursor)
            if self._drag and self._drag[0] == "mark" and (e.buttons() & Qt.LeftButton):
                (x0, y0), (x1, y1) = self._drag[1], self._img_pos(e.position())
                self._new_area = [min(x0, x1), min(y0, y1), abs(x1 - x0), abs(y1 - y0)]
                self.update()
            return
        near = abs(e.position().x() - self.width() * self.split) < 14
        self.setCursor(Qt.SplitHCursor if near or self.zoom <= 0 else Qt.OpenHandCursor)
        if not self._drag or not (e.buttons() & Qt.LeftButton):
            return
        kind, start, c0 = self._drag
        if kind == "split":
            self.split = max(0.0, min(1.0, e.position().x() / max(1, self.width())))
        else:
            r = self._geom()
            d = e.position() - start
            self.center = QPointF(min(1, max(0, c0.x() - d.x() / r.width())), min(1, max(0, c0.y() - d.y() / r.height())))
        self.update()

    def mouseReleaseEvent(self, _e):
        if self._drag and self._drag[0] == "mark" and self._new_area:
            a = self._new_area
            self._new_area = None
            if a[2] > 0.005 and a[3] > 0.005:
                self.area_drawn.emit([round(v, 4) for v in a])
            self.update()
        self._drag = None


class _Worker(QObject):
    done = Signal(int, object, object, object, str)

    def __init__(self):
        super().__init__()
        self._want = None
        self._busy = False
        self._lock = threading.Lock()

    def request(self, token, fn):
        with self._lock:
            self._want = (token, fn)
            if self._busy:
                return
            self._busy = True
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        while True:
            with self._lock:
                job, self._want = self._want, None
                if job is None:
                    self._busy = False
                    return
            token, fn = job
            try:
                b, a, sec = fn()
                self.done.emit(token, b, a, sec, "")
            except Exception as e:  # noqa
                self.done.emit(token, None, None, None, str(e).splitlines()[0] if str(e) else type(e).__name__)


class BeforeAfter(QWidget):
    """make_fn(t, use_ai) is called on the UI thread and returns a job; job() runs in the background
    and returns (before_rgb, after_rgb, ai_seconds). Setting changes re-render without AI (quick);
    the 'Preview with AI' button renders the full result."""
    rendered = Signal(object)      # ai seconds per frame (or None)
    area_drawn = Signal(list)      # a box drawn in "mark areas" mode

    def __init__(self, parent=None):
        super().__init__(parent)
        self.make_fn = None
        self.dur = 0.0
        self._token = 0
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(6)
        top = QHBoxLayout()
        self.title = QLabel("Before / after", objectName="muted")
        self.zoom = QComboBox()
        for text, z in (("Fit", 0.0), ("100%", 1.0), ("200%", 2.0), ("400%", 4.0)):
            self.zoom.addItem(text, z)
        self.zoom.setToolTip("Zoom in to judge detail; drag the picture to look around")
        self.zoom.currentIndexChanged.connect(self._zoom)
        from PySide6.QtWidgets import QPushButton
        self.ai_btn = QPushButton("Preview with AI")
        self.ai_btn.setToolTip("Setting changes update the preview quickly without the AI steps.\n"
                               "Press this to see this moment with AI upscaling, faces and colour.")
        self.ai_btn.clicked.connect(lambda: self._render(use_ai=True))
        top.addWidget(self.title, 1)
        top.addWidget(self.ai_btn)
        top.addWidget(QLabel("Zoom:"))
        top.addWidget(self.zoom)
        v.addLayout(top)
        self.view = _Compare()
        self.view.area_drawn.connect(self.area_drawn)
        v.addWidget(self.view, 1)
        row = QHBoxLayout()
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(0, 0)
        self.slider.valueChanged.connect(self._moved)
        self.time_label = QLabel("0:00.0")
        self.time_label.setMinimumWidth(110)
        row.addWidget(QLabel("Moment:"))
        row.addWidget(self.slider, 1)
        row.addWidget(self.time_label)
        v.addLayout(row)
        self.status = QLabel("", objectName="muted")
        self.status.setWordWrap(True)
        v.addWidget(self.status)
        self.worker = _Worker()
        self.worker.done.connect(self._done)
        self._timer = QTimer(self, singleShot=True, interval=500)
        self._timer.timeout.connect(self._render)
        self._t0 = 0.0
        self._ai = False
        self.setEnabled(False)

    def set_video(self, name: str, duration: float, make_fn, t: Optional[float] = None):
        self.make_fn = make_fn
        self.dur = max(0.1, duration)
        self.title.setText(f"<b>{name}</b> - drag the divider to compare")
        self.slider.blockSignals(True)
        self.slider.setRange(0, int(self.dur * 10))
        self.slider.setValue(int((t if t is not None else self.dur * 0.3) * 10))
        self.slider.blockSignals(False)
        self.view.before = self.view.after = None
        self.view.message = "Rendering preview…"
        self.view.update()
        self.setEnabled(True)
        self.refresh(now=True)

    def set_areas(self, areas: list):
        self.view.areas = [list(a) for a in areas]
        self.view.update()

    def set_mark_mode(self, on: bool):
        self.view.mark_mode = on
        self.view.unsetCursor()
        self.view.update()

    def clear(self, message="Select a video, then pick a moment to compare."):
        self._token += 1
        self.make_fn = None
        self.view.before = self.view.after = None
        self.view.message = message
        self.view.update()
        self.status.setText("")
        self.title.setText("Before / after")
        self.setEnabled(False)

    def refresh(self, now: bool = False):
        if not self.make_fn:
            return
        self.time_label.setText(f"{_t(self.slider.value() / 10)} / {_t(self.dur)}")
        if now:
            self._render()
        else:
            self._timer.start()

    def _moved(self, _v):
        self.refresh()

    def _zoom(self):
        self.view.zoom = self.zoom.currentData()
        self.view.center = QPointF(0.5, 0.5)
        self.view.update()

    def _render(self, use_ai: bool = False):
        if not self.make_fn:
            return
        self._token += 1
        t = self.slider.value() / 10
        fn = self.make_fn
        self._ai = use_ai
        self.view.message = "Rendering preview…"
        self.view.update()
        self.status.setText("Rendering the preview frame with AI (this can take a while)…" if use_ai
                            else "Rendering the preview frame…")
        self._t0 = time.monotonic()
        self.worker.request(self._token, fn(t, use_ai))

    def _done(self, token, b, a, sec, err):
        if token != self._token:
            return
        self.view.message = ""
        if err:
            self.view.before = self.view.after = None
            self.view.message = f"Preview failed: {err}"
            self.status.setText("")
        else:
            self.view.before, self.view.after = _qimg(b), _qimg(a)
            took = time.monotonic() - self._t0
            self.status.setText(f"{a.shape[1]}x{a.shape[0]} · {'with AI' if self._ai else 'without AI'} · "
                                f"took {took:.1f} s")
            self.rendered.emit(sec)
        self.view.update()
