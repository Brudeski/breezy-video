"""AI upscaling with Real-ESRGAN models on ONNX Runtime (DirectML graphics card when possible).

Models (in breezy/models):
    esrgan_general_x4v3.onnx  'AI fast'  - compact Real-ESRGAN general model, 4x, made for video
    real_esrgan_x2plus.onnx   'AI best'  - full Real-ESRGAN RRDB, 2x
    real_esrgan_x4plus.onnx   'AI best'  - full Real-ESRGAN RRDB, 4x
Frames are processed in overlapping tiles so any size fits in memory; the AI result can be
blended with a plain Lanczos upscale ("AI strength") to tone down the painted look.
"""
from __future__ import annotations

import threading
from pathlib import Path

import numpy as np

from breezy.features.tracker.detector import models_dir

MODELS = {("ai_fast", 4): "esrgan_general_x4v3.onnx",
          ("ai_best", 2): "real_esrgan_x2plus.onnx",
          ("ai_best", 4): "real_esrgan_x4plus.onnx"}

_sessions: dict = {}
_lock = threading.Lock()


def model_file(kind: str, factor: int) -> Path:
    return models_dir() / MODELS[(kind, factor)]


def available(kind: str) -> bool:
    return all(model_file(k, f).is_file() for (k, f) in MODELS if k == kind)


# ---------------------------------------------------------------- half precision (fp16)
# The big picture models run about twice as fast in half precision on NVIDIA cards with tensor cores
# (RTX 20xx and newer, GTX 16xx). A half-precision copy is made once and checked against the original;
# if it differs visibly (or fails) the original is used.
HALF_MODELS = {"esrgan_general_x4v3.onnx", "real_esrgan_x2plus.onnx", "real_esrgan_x4plus.onnx",
               "NAFNet-GoPro-width64.onnx", "scunet_color_real_psnr.onnx"}
_half = {"on": True}


def set_half(on: bool) -> None:
    _half["on"] = bool(on)


def _half_dir() -> Path:
    from breezy.core.settings import app_data_dir
    d = app_data_dir() / "fp16_models"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _half_copy(path: Path) -> Path | None:
    """The half-precision copy of a model (made once), or None if it can't be made or failed its check."""
    d = _half_dir()
    out, bad = d / path.name, d / (path.name + ".bad")
    if bad.exists():
        return None
    if out.is_file() and out.stat().st_mtime >= path.stat().st_mtime:
        return out
    try:
        import onnx
        from onnxruntime.transformers.float16 import convert_float_to_float16
        m = onnx.load(str(path))
        m16 = convert_float_to_float16(m, keep_io_types=True)
        tmp = out.with_suffix(".tmp")
        onnx.save(m16, str(tmp))
        tmp.replace(out)
        return out
    except Exception as e:  # noqa - no 'onnx' package, an unsupported model...: stay in full precision
        import logging
        logging.info("half precision not available for %s: %s", path.name, e)
        return None


def _test_picture(shape) -> np.ndarray:
    """A picture-like test input (smooth gradients, edges, a little noise) of the model's input shape."""
    n, c, h, w = shape
    yy, xx = np.mgrid[0:h, 0:w].astype(np.float32)
    base = 0.5 + 0.3 * np.sin(xx / 7.0) * np.cos(yy / 11.0)
    edges = ((xx // 16 + yy // 16) % 2) * 0.2
    rng = np.random.default_rng(1)
    chans = [np.clip(base * (0.8 + 0.2 * k) + edges + rng.normal(0, 0.02, (h, w)), 0, 1) for k in range(c)]
    return np.stack(chans)[None].astype(np.float32).repeat(n, 0)


def _half_ok(full, half, path: Path) -> bool:
    """The half-precision copy must give the same picture (PSNR 40 dB or better on a test picture);
    when it doesn't, the original is used from now on."""
    try:
        if len(full.get_inputs()) != 1:
            return False
        inp = full.get_inputs()[0]
        shape = [d if isinstance(d, int) and d > 0 else 128 for d in inp.shape]
        shape[0] = 1
        feeds = {inp.name: _test_picture(shape)}
        a = np.clip(full.run(None, feeds)[0], 0, 1)
        b = half.run(None, feeds)[0]
        mse = float(np.mean((a - np.clip(b, 0, 1)) ** 2))
        ok = bool(np.all(np.isfinite(b))) and 10 * np.log10(1.0 / max(mse, 1e-12)) >= 40.0
    except Exception:
        ok = False
    if not ok:
        try:
            (_half_dir() / (path.name + ".bad")).write_text("differs from full precision")
        except OSError:
            pass
    return ok


def _psnr_vs(ref, test, shape: list, batch: int) -> float:
    """How alike two sessions' outputs are on a picture-like test input (dB; inf = identical)."""
    inp = ref.get_inputs()[0].name
    x = np.concatenate([_test_picture(shape)] * batch)
    a = np.clip(ref.run(None, {inp: x[:1]})[0], 0, 1)
    b = test.run(None, {test.get_inputs()[0].name: x})[0]
    if not np.all(np.isfinite(b)):
        return 0.0
    b = np.clip(b, 0, 1)
    worst = max(float(np.mean((a[0] - b[i]) ** 2)) for i in range(batch))
    return 10 * np.log10(1.0 / max(worst, 1e-12))


def _trt_session(ort, path: Path, tile: int):
    """The model compiled by TensorRT for this graphics card (engine kept on disk; built on first use).
    Before it's used, its result is compared with the processor's on a test picture (also with several
    pictures per call): if it differs, half precision is switched off for it, and if it still differs the
    model doesn't use TensorRT (remembered)."""
    from breezy.core import ai_engine
    from breezy.core.encoders import provider_args
    cache = ai_engine.trt_cache_dir()
    bad = cache / (path.name + ".bad")
    if bad.exists():
        raise RuntimeError("TensorRT failed its check for this model earlier")
    ref = ort.InferenceSession(str(path), providers=["CPUExecutionProvider"])
    name = ref.get_inputs()[0].name
    size = -(-max(64, tile) // 64) * 64
    batch = 1 if path.name.startswith("real_esrgan") else 4
    # a model whose half-precision copy already failed its check doesn't get half precision here either
    half_ok = bool(_half["on"]) and not (_half_dir() / (path.name + ".bad")).exists()
    for fp16 in ([True, False] if half_ok else [False]):
        opts = {"device_id": 0, "trt_fp16_enable": fp16, "trt_engine_cache_enable": True,
                "trt_engine_cache_path": str(cache), "trt_timing_cache_enable": True,
                "trt_timing_cache_path": str(cache), "trt_max_workspace_size": 2 << 30,
                "trt_profile_min_shapes": f"{name}:1x3x16x16",
                "trt_profile_opt_shapes": f"{name}:{batch}x3x{size}x{size}",
                "trt_profile_max_shapes": f"{name}:{batch}x3x{size}x{size}"}
        so = ort.SessionOptions()
        so.log_severity_level = 3
        sess = ort.InferenceSession(str(path), so, providers=[("TensorrtExecutionProvider", opts),
                                                              *provider_args(["CUDAExecutionProvider"], True),
                                                              "CPUExecutionProvider"])
        if sess.get_providers()[0] != "TensorrtExecutionProvider":
            raise RuntimeError("TensorRT not used")
        if _psnr_vs(ref, sess, [1, 3, 128, 128], min(2, batch)) >= 38.0:
            sess._model_path = path.name
            sess._max_batch = batch
            sess._max_size = size
            return sess
        import logging
        logging.warning("TensorRT result for %s differs from the processor's (half precision %s)", path.name, fp16)
    try:
        bad.write_text("differs from the processor's result")
    except OSError:
        pass
    raise RuntimeError("TensorRT result differs")


def _session(path: Path, use_gpu: bool, tile: int = 0):
    import onnxruntime as ort
    from breezy.core.encoders import onnx_providers, provider_args
    from breezy.core import ai_engine
    if use_gpu and tile and path.name in HALF_MODELS and ai_engine.trt_active:
        key = (str(path), "trt", -(-max(64, tile) // 64) * 64, _half["on"])
        with _lock:
            if key not in _sessions:
                try:
                    _sessions[key] = _trt_session(ort, path, tile)
                except Exception as e:  # noqa - fall back to CUDA
                    import logging
                    logging.warning("TensorRT unavailable for %s (%s) - using CUDA", path.name, e)
                    _sessions[key] = None
            if _sessions[key] is not None:
                return _sessions[key]
    want_half = (use_gpu and _half["on"] and path.name in HALF_MODELS
                 and "CUDAExecutionProvider" in onnx_providers(use_gpu))
    key = (str(path), use_gpu, want_half)
    with _lock:
        if key not in _sessions and want_half:
            full = _session_unlocked(ort, path, use_gpu, onnx_providers, provider_args, tile)
            hp = _half_copy(path)
            if hp is not None:
                half = _session_unlocked(ort, hp, use_gpu, onnx_providers, provider_args, tile)
                if _half_ok(full, half, path):
                    _sessions[key] = half
                    _sessions.pop((str(path), use_gpu, "raw"), None)     # free the full-precision copy
                else:
                    _sessions[key] = full
                    _sessions.pop((str(hp), use_gpu, "raw"), None)
            else:
                _sessions[key] = full
        if key not in _sessions:
            _sessions[key] = _session_unlocked(ort, path, use_gpu, onnx_providers, provider_args, tile)
        return _sessions[key]


def _session_unlocked(ort, path: Path, use_gpu: bool, onnx_providers, provider_args, tile: int = 0):
    cache = (str(path), use_gpu, "raw")
    if cache not in _sessions:
        opts = ort.SessionOptions()
        opts.log_severity_level = 3
        opts.add_session_config_entry("session.set_denormal_as_zero", "1")   # tiny numbers can be 40x slower
        provs = onnx_providers(use_gpu)
        if "DmlExecutionProvider" in provs:
            opts.enable_mem_pattern = False
            opts.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
        try:
            _sessions[cache] = ort.InferenceSession(str(path), opts, providers=provider_args(provs, bool(tile)))
        except Exception:
            if provs == ["CPUExecutionProvider"]:
                raise
            _sessions[cache] = ort.InferenceSession(str(path), opts, providers=["CPUExecutionProvider"])
        try:
            _sessions[cache]._model_path = path.name.replace(".fp16", "")
        except Exception:
            pass
    return _sessions[cache]


# ---------------------------------------------------------------- tiles
_batch_ok: dict = {}          # model -> whether it takes several tiles per call


class TileRunner:
    """Runs an image model over a frame in equal-size, overlapping tiles.

    - every tile has the same shape (the frame is padded at its edges), so the graphics card can keep the
      fastest settings for it and several tiles go through the model in one call (batch);
    - reuse=True (fixed cameras): a tile whose picture hasn't changed since its AI result was made keeps
      that result instead of running the model again (refreshed at least every `max_age` frames).
    """

    def __init__(self, session, factor: int = 1, tile: int = 512, pad: int = 16, multiple: int = 1,
                 reuse: bool = False, budget: int = 0, max_age: int = 60):
        self.session, self.f, self.pad, self.m = session, factor, pad, max(1, multiple)
        self.inp = session.get_inputs()[0].name
        self.reuse = reuse
        # smaller tiles when reusing (finer areas can be kept), several per call so the card stays as busy
        self.core = max(64, min(tile, 384) if reuse else tile)
        self.budget = budget or (tile + 2 * pad) ** 2           # pixels per call the memory allows
        self.max_age = max_age
        self._key = str(getattr(session, "_model_path", id(session)))
        self.reset()
        self.reused = self.ran = 0

    def reset(self):
        self.ref = self.out = self.age = None
        self.shape = None

    def _call(self, batch: np.ndarray) -> np.ndarray:
        ok = _batch_ok.get(self._key, True)
        if len(batch) > 1 and ok:
            try:
                return self.session.run(None, {self.inp: batch})[0]
            except Exception:
                _batch_ok[self._key] = False          # the model only takes one tile per call
        return np.concatenate([self.session.run(None, {self.inp: batch[i:i + 1]})[0] for i in range(len(batch))])

    K = 8                     # change detection on 8x8-pixel averages: sensor noise averages out, real changes don't

    def run(self, rgb: np.ndarray, cancel=None) -> np.ndarray:
        """rgb (H, W, 3) uint8 -> (H*f, W*f, 3) float32 0..1"""
        import cv2
        h, w = rgb.shape[:2]
        f, p, m, k = self.f, self.pad, self.m, self.K
        ch, cw = min(self.core, h), min(self.core, w)
        sh, sw = -(-(ch + 2 * p) // m) * m, -(-(cw + 2 * p) // m) * m       # tile shape the model sees
        x = rgb.astype(np.float32) / 255.0
        xp = np.pad(x, ((p, sh - ch - p), (p, sw - cw - p), (0, 0)), mode="reflect" if min(h, w) > p else "edge")
        ys = sorted(set(list(range(0, h - ch + 1, ch)) + [h - ch]))
        xs = sorted(set(list(range(0, w - cw + 1, cw)) + [w - cw]))
        tiles = [(y0, x0) for y0 in ys for x0 in xs]
        if self.shape != (h, w, len(tiles)):
            self.reset()
            self.shape = (h, w, len(tiles))
            self.out = np.zeros((h * f, w * f, 3), np.float32)
            self.age = {t: 10 ** 9 for t in tiles}
        todo = tiles
        if self.reuse and self.ref is not None:
            kd = 2 * k                                       # 16x16 averages: noise is 2x weaker than at 8x8
            bw, bh = max(1, w // kd), max(1, h // kd)
            cur_b = cv2.resize(x, (bw, bh), interpolation=cv2.INTER_AREA)
            ref_b = cv2.resize(self.ref, (bw, bh), interpolation=cv2.INTER_AREA)
            d = np.abs(cur_b - ref_b) * 255                  # per colour channel
            todo = []
            for (y0, x0) in tiles:
                reg = d[y0 // kd:max(y0 // kd + 1, (y0 + ch) // kd), x0 // kd:max(x0 // kd + 1, (x0 + cw) // kd)]
                # something moved or appeared (a local change), or the tile is due for a refresh
                if reg.size == 0 or float(reg.max()) > 6.0 or self.age[(y0, x0)] >= self.max_age:
                    todo.append((y0, x0))
                else:
                    self.age[(y0, x0)] += 1
        per_call = max(1, min(self.budget // (sh * sw), getattr(self.session, "_max_batch", 64)))
        for i in range(0, len(todo), per_call):
            if cancel is not None:
                cancel()
            group = todo[i:i + per_call]
            batch = np.stack([xp[y0:y0 + sh, x0:x0 + sw].transpose(2, 0, 1) for (y0, x0) in group])
            out = self._call(np.ascontiguousarray(batch))
            for (y0, x0), o in zip(group, out):
                o = o.transpose(1, 2, 0)
                self.out[y0 * f:(y0 + ch) * f, x0 * f:(x0 + cw) * f] = o[p * f:(p + ch) * f, p * f:(p + cw) * f]
                self.age[(y0, x0)] = 0
                if self.reuse:
                    if self.ref is None:
                        self.ref = x.copy()
                    self.ref[y0:y0 + ch, x0:x0 + cw] = x[y0:y0 + ch, x0:x0 + cw]
        self.ran += len(todo)
        self.reused += len(tiles) - len(todo)
        if not self.reuse:
            return self.out
        if len(todo) == len(tiles):
            return self.out.copy()
        # kept tiles: carry over the smooth changes since their AI result was made (brightness, colour,
        # white balance, low light...), so they match the frame; fine detail and noise stay the AI's
        diff = x - self.ref
        bw, bh = max(1, w // k), max(1, h // k)
        low = cv2.resize(cv2.resize(diff, (bw, bh), interpolation=cv2.INTER_AREA), (w * f, h * f),
                         interpolation=cv2.INTER_LINEAR)
        return self.out + low


class Upscaler:
    def __init__(self, kind: str, factor: int, use_gpu: bool = True, tile: int = 384, pad: int = 16,
                 reuse: bool = False):
        path = model_file(kind, factor)
        if not path.is_file():
            raise RuntimeError(f"AI model missing: {path.name}")
        self.factor = factor
        self.tile, self.pad = max(64, tile), pad
        self.session = _session(path, use_gpu, tile=self.tile + 2 * pad)
        self.inp = self.session.get_inputs()[0].name
        self.provider = self.session.get_providers()[0]
        shape = self.session.get_inputs()[0].shape
        # a model with a fixed input size (e.g. a re-downloaded original) is fed exact-size tiles
        self.fixed = shape[2] if isinstance(shape[2], int) and isinstance(shape[3], int) else 0
        # the full model needs much more memory per pixel: one tile per call
        budget = (self.tile + 2 * pad) ** 2 * (1 if kind == "ai_best" else 2)
        self.runner = TileRunner(self.session, factor, self.tile, pad, reuse=reuse, budget=budget)

    def _run(self, x: np.ndarray) -> np.ndarray:
        """x: (h, w, 3) float32 0..1 RGB -> (h*f, w*f, 3)."""
        y = self.session.run(None, {self.inp: x.transpose(2, 0, 1)[None]})[0][0]
        return y.transpose(1, 2, 0)

    def upscale(self, rgb: np.ndarray, cancel=None) -> np.ndarray:
        """rgb: (H, W, 3) uint8 -> (H*f, W*f, 3) uint8."""
        h, w = rgb.shape[:2]
        f, p = self.factor, self.pad
        x = rgb.astype(np.float32) / 255.0
        if self.fixed:
            F = self.fixed
            p = min(p, F // 4)
            step = F - 2 * p
            xp = np.pad(x, ((p, p + (-h) % step), (p, p + (-w) % step), (0, 0)), mode="edge")
            y = np.zeros((h * f, w * f, 3), np.float32)
            for y0 in range(0, h, step):
                for x0 in range(0, w, step):
                    if cancel is not None:
                        cancel()
                    out = self._run(np.ascontiguousarray(xp[y0:y0 + F, x0:x0 + F]))
                    hh, ww = min(step, h - y0), min(step, w - x0)
                    y[y0 * f:(y0 + hh) * f, x0 * f:(x0 + ww) * f] = out[p * f:(p + hh) * f, p * f:(p + ww) * f]
        else:
            y = self.runner.run(rgb, cancel)
        return (np.clip(y, 0, 1) * 255 + 0.5).astype(np.uint8)


def enhance_frame(up: "Upscaler | None", rgb: np.ndarray, out_w: int, out_h: int, strength: int = 100,
                  cancel=None) -> np.ndarray:
    """AI-upscale a frame (or just resize it when up is None), resize to the output size,
    blend with a plain upscale."""
    import cv2
    if up is None:
        if (rgb.shape[1], rgb.shape[0]) == (out_w, out_h):
            return rgb
        interp = cv2.INTER_AREA if rgb.shape[1] > out_w else cv2.INTER_LANCZOS4
        return cv2.resize(rgb, (out_w, out_h), interpolation=interp)
    big = up.upscale(rgb, cancel)
    if (big.shape[1], big.shape[0]) != (out_w, out_h):
        interp = cv2.INTER_AREA if big.shape[1] > out_w else cv2.INTER_LANCZOS4
        big = cv2.resize(big, (out_w, out_h), interpolation=interp)
    if strength < 100:
        plain = cv2.resize(rgb, (out_w, out_h), interpolation=cv2.INTER_LANCZOS4)
        a = strength / 100
        big = cv2.addWeighted(big, a, plain, 1 - a, 0)
    return big


# ------------------------------------------------------------- face restoration
FACE_MODEL, FACE_DET = "gfpgan_v1.4_fp16.onnx", "face_detection_yunet_2023mar.onnx"
_FFHQ = np.array([[192.98138, 239.94708], [318.90277, 240.1936], [256.63416, 314.01935],
                  [201.26117, 371.41043], [313.08905, 371.15118]], np.float32)


def faces_available() -> bool:
    return (models_dir() / FACE_MODEL).is_file() and (models_dir() / FACE_DET).is_file()


class FaceFinder:
    """YuNet face finder: rows of x, y, w, h, 5 landmark points (10 values), score."""

    def __init__(self, confidence: float = 0.7, min_size: int = 32):
        self.det_path = str(models_dir() / FACE_DET)
        self.det = None
        self.det_size = None
        self.conf, self.min_size = confidence, min_size

    def _detector(self, w: int, h: int):
        import cv2
        if self.det is None:
            self.det = cv2.FaceDetectorYN.create(self.det_path, "", (w, h), self.conf, 0.3, 200)
        if self.det_size != (w, h):
            self.det.setInputSize((w, h))
            self.det_size = (w, h)
        return self.det

    def find(self, rgb: np.ndarray) -> np.ndarray:
        import cv2
        h, w = rgb.shape[:2]
        sc = min(1.0, 1280 / max(w, h))            # detect on at most 1280 px, map back
        small = cv2.resize(rgb, (int(w * sc), int(h * sc)), interpolation=cv2.INTER_AREA) if sc < 1 else rgb
        _, faces = self._detector(small.shape[1], small.shape[0]).detect(np.ascontiguousarray(small[:, :, ::-1]))
        if faces is None:
            return np.zeros((0, 15), np.float32)
        faces = faces.copy()
        faces[:, :14] /= sc
        return faces[(faces[:, 2] >= self.min_size) & (faces[:, 3] >= self.min_size)]


class FaceRestorer:
    """YuNet finds faces (with eye/nose/mouth points); GFPGAN v1.4 rebuilds each one; the result is
    feathered back into the frame and mixed with the original by `strength`."""

    def __init__(self, use_gpu: bool = True, strength: int = 80, min_size: int = 32, confidence: float = 0.7):
        import cv2
        self.session = _session(models_dir() / FACE_MODEL, use_gpu)
        self.finder = FaceFinder(confidence, min_size)
        self.strength = strength / 100
        m = np.zeros((512, 512), np.float32)
        m[28:-28, 28:-28] = 1
        self.mask = cv2.GaussianBlur(m, (0, 0), 14)

    def find(self, rgb: np.ndarray) -> np.ndarray:
        return self.finder.find(rgb)

    def restore(self, rgb: np.ndarray, cancel=None) -> np.ndarray:
        import cv2
        faces = self.find(rgb)
        if not len(faces):
            return rgb
        h, w = rgb.shape[:2]
        out = rgb.astype(np.float32)
        for f in faces:
            if cancel is not None:
                cancel()
            lm = f[4:14].reshape(5, 2).astype(np.float32)
            M, _ = cv2.estimateAffinePartial2D(lm, _FFHQ, method=cv2.LMEDS)
            if M is None:
                continue
            crop = cv2.warpAffine(rgb, M, (512, 512), flags=cv2.INTER_LINEAR, borderMode=cv2.BORDER_REFLECT)
            x = (crop.astype(np.float32) / 127.5 - 1.0).transpose(2, 0, 1)[None]
            y = self.session.run(None, {self.session.get_inputs()[0].name: x})[0][0]
            fixed = (np.clip(y.transpose(1, 2, 0), -1, 1) + 1) * 127.5
            IM = cv2.invertAffineTransform(M)
            back = cv2.warpAffine(fixed, IM, (w, h), flags=cv2.INTER_LINEAR)
            m = cv2.warpAffine(self.mask, IM, (w, h), flags=cv2.INTER_LINEAR)[:, :, None] * self.strength
            out = out * (1 - m) + back * m
        return np.clip(out + 0.5, 0, 255).astype(np.uint8)


# ------------------------------------------------------------------ colourising
COLOR_MODEL = "ddcolor.onnx"


def colour_available() -> bool:
    return (models_dir() / COLOR_MODEL).is_file() and (models_dir() / "ddcolor.data").is_file()


class Colouriser:
    """DDColor predicts colour (Lab a/b) from the black & white picture at 256x256; the colour is
    scaled up and laid over the original brightness, so detail stays sharp. Colours are smoothed
    over time (reset at scene cuts) to avoid flicker."""

    def __init__(self, use_gpu: bool = True, strength: int = 100, smooth: float = 0.6):
        self.session = _session(models_dir() / COLOR_MODEL, use_gpu)
        self.strength, self.smooth = strength / 100, smooth
        self.prev_ab = None
        self.prev_l = None

    def reset(self):
        self.prev_ab = self.prev_l = None

    def colourise(self, rgb: np.ndarray) -> np.ndarray:
        import cv2
        h, w = rgb.shape[:2]
        gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
        g3 = cv2.cvtColor(gray, cv2.COLOR_GRAY2RGB)
        x = cv2.resize(g3, (256, 256), interpolation=cv2.INTER_AREA).astype(np.float32) / 255
        ab = self.session.run(None, {self.session.get_inputs()[0].name: x.transpose(2, 0, 1)[None]})[0][0]
        ab = ab.transpose(1, 2, 0)
        small_l = x[:, :, 0]
        if self.prev_ab is not None and self.smooth > 0:
            cut = float(np.abs(small_l - self.prev_l).mean()) > 0.12
            if not cut:
                ab = self.smooth * self.prev_ab + (1 - self.smooth) * ab
        self.prev_ab, self.prev_l = ab, small_l
        lab = cv2.cvtColor(g3.astype(np.float32) / 255, cv2.COLOR_RGB2LAB)
        lab[:, :, 1:] = cv2.resize(ab, (w, h), interpolation=cv2.INTER_CUBIC) * self.strength
        return (np.clip(cv2.cvtColor(lab, cv2.COLOR_LAB2RGB), 0, 1) * 255 + 0.5).astype(np.uint8)


# -------------------------------------------------------- frame interpolation
RIFE_MODEL = "rife_v4.9.onnx"


def rife_available() -> bool:
    return (models_dir() / RIFE_MODEL).is_file()


class Interpolator:
    """RIFE v4.9: makes the frame at time t (0..1) between two frames."""

    def __init__(self, use_gpu: bool = True, max_side: int = 1920):
        self.session = _session(models_dir() / RIFE_MODEL, use_gpu)
        self.max_side = max_side

    def between(self, a: np.ndarray, b: np.ndarray, t: float) -> np.ndarray:
        import cv2
        h, w = a.shape[:2]
        sc = min(1.0, self.max_side / max(w, h))     # very large frames: estimate at a lower size
        if sc < 1:
            sw, sh = int(w * sc) // 2 * 2, int(h * sc) // 2 * 2
            a_, b_ = (cv2.resize(x, (sw, sh), interpolation=cv2.INTER_AREA) for x in (a, b))
        else:
            a_, b_ = a, b
        hh, ww = a_.shape[:2]
        ph, pw = (32 - hh % 32) % 32, (32 - ww % 32) % 32

        def prep(x):
            x = x.astype(np.float32) / 255
            if ph or pw:
                x = np.pad(x, ((0, ph), (0, pw), (0, 0)), mode="edge")
            return x.transpose(2, 0, 1)[None]
        y = self.session.run(None, {"img0": prep(a_), "img1": prep(b_), "timestep": np.array([t], np.float32)})[0][0]
        y = (np.clip(y.transpose(1, 2, 0)[:hh, :ww], 0, 1) * 255 + 0.5).astype(np.uint8)
        if sc < 1:
            y = cv2.resize(y, (w, h), interpolation=cv2.INTER_CUBIC)
        return y


def voice_model(kind: str) -> Path:
    return models_dir() / "voice" / f"{kind}.rnnn"
