"""Subtitles from speech with Whisper (faster-whisper / CTranslate2, runs well on the processor).

The speech model is downloaded the first time it's used (tiny 75 MB ... medium 1.5 GB) into
breezy/models/whisper. The sound is decoded by FFmpeg to 16 kHz mono and handed over as numbers,
so faster-whisper never has to open files itself.
"""
from __future__ import annotations

from pathlib import Path
from typing import Callable

import numpy as np

from breezy.core import proc
from breezy.features.tracker.detector import models_dir

SIZES = [("Fast (base)", "base"), ("Good (small)", "small"), ("Best (medium, slow)", "medium")]
LANGS = [("Detect automatically", ""), ("English", "en"), ("French", "fr"), ("Spanish", "es"), ("German", "de"),
         ("Italian", "it"), ("Portuguese", "pt"), ("Dutch", "nl"), ("Russian", "ru"), ("Chinese", "zh"),
         ("Japanese", "ja"), ("Korean", "ko"), ("Arabic", "ar"), ("Hindi", "hi"), ("Ukrainian", "uk"),
         ("Polish", "pl"), ("Turkish", "tr"), ("Vietnamese", "vi"), ("Tagalog", "tl")]


def available() -> bool:
    try:
        import faster_whisper  # noqa: F401
        return True
    except Exception:
        return False


def model_root() -> Path:
    return models_dir() / "whisper"


_models: dict = {}


def _cuda_devices() -> int:
    try:
        import ctranslate2
        return ctranslate2.get_cuda_device_count()
    except Exception:
        return 0


def load(size: str, use_gpu: bool, log: Callable[[str], None] = print):
    from faster_whisper import WhisperModel
    key = (size, use_gpu)
    if key in _models:
        return _models[key]
    root = model_root()
    root.mkdir(parents=True, exist_ok=True)
    have = any(root.glob(f"models--Systran--faster-whisper-{size}/snapshots/*/model.bin"))
    if not have:
        log(f"Downloading the speech model '{size}' (first time only)…")
    m = None
    if use_gpu and _cuda_devices() > 0:
        try:
            m = WhisperModel(size, device="cuda", compute_type="int8_float16", download_root=str(root))
        except Exception:
            m = None
    if m is None:
        m = WhisperModel(size, device="cpu", compute_type="int8", download_root=str(root))
    _models[key] = m
    return m


def decode_16k(ffmpeg, src: Path, af: list[str]) -> np.ndarray:
    chain = ",".join(af + ["aresample=16000"]) if af else "aresample=16000"
    r = proc.run([ffmpeg.ffmpeg, "-v", "error", "-nostdin", "-i", str(src), "-map", "0:a:0", "-af", chain,
                  "-ac", "1", "-f", "f32le", "-"], timeout=None)
    if r.returncode != 0:
        raise RuntimeError("couldn't read the sound for subtitles")
    return np.frombuffer(r.stdout, np.float32)


def transcribe(ffmpeg, src: Path, size: str = "small", language: str = "", translate: bool = False,
               use_gpu: bool = True, time_scale: float = 1.0, af: list[str] | None = None,
               progress: Callable[[float], None] = lambda f: None, cancel: Callable[[], None] = lambda: None,
               log: Callable[[str], None] = print) -> tuple[list[tuple[float, float, str]], str]:
    """[(start, end, text)] in output-video time (source time x time_scale) and the language found."""
    audio = decode_16k(ffmpeg, src, af or [])
    total = len(audio) / 16000 or 1.0

    def run(model):
        segs, info = model.transcribe(audio, language=language or None,
                                      task="translate" if translate else "transcribe",
                                      vad_filter=True, beam_size=5, condition_on_previous_text=False,
                                      word_timestamps=True)
        out = []
        for s in segs:
            cancel()
            words = list(s.words or [])
            if not words:
                if s.text.strip():
                    out.append((s.start * time_scale, s.end * time_scale, s.text.strip()))
            else:
                # split into readable captions: at most ~2 lines (84 characters) or 6 seconds each
                cue, start = [], None
                for w in words:
                    if start is None:
                        start = w.start
                    text = "".join(x.word for x in cue + [w]).strip()
                    if cue and (len(text) > 84 or w.end - start > 6.0):
                        out.append((start * time_scale, cue[-1].end * time_scale,
                                    "".join(x.word for x in cue).strip()))
                        cue, start = [w], w.start
                    else:
                        cue.append(w)
                if cue:
                    out.append((start * time_scale, cue[-1].end * time_scale, "".join(x.word for x in cue).strip()))
            progress(min(1.0, s.end / total))
        progress(1.0)
        return out, info.language

    model = load(size, use_gpu, log)
    try:
        return run(model)
    except Exception as e:
        # the graphics card libraries (cuBLAS/cuDNN) can be missing and only fail on first use
        msg = str(e).lower()
        if not use_gpu or not any(k in msg for k in ("cuda", "cublas", "cudnn", ".dll", "gpu")):
            raise
        log("Speech: the graphics card couldn't be used, using the processor instead.")
        _models.pop((size, True), None)
        _models[(size, True)] = load(size, False, log)
        return run(_models[(size, True)])


def _ts(t: float) -> str:
    ms = int(round(t * 1000))
    h, ms = divmod(ms, 3600000)
    m, ms = divmod(ms, 60000)
    s, ms = divmod(ms, 1000)
    return f"{h:02d}:{m:02d}:{s:02d},{ms:03d}"


def write_srt(segments, path: Path, max_chars: int = 42) -> None:
    lines = []
    for i, (a, b, text) in enumerate(segments, 1):
        words, rows, cur = text.split(), [], ""
        for w in words:                                # wrap to two readable lines
            if cur and len(cur) + 1 + len(w) > max_chars:
                rows.append(cur)
                cur = w
            else:
                cur = f"{cur} {w}".strip()
        if cur:
            rows.append(cur)
        lines += [str(i), f"{_ts(a)} --> {_ts(b)}", "\n".join(rows), ""]
    Path(path).write_text("\n".join(lines), "utf-8")


def embed(ffmpeg, video: Path, srt: Path, language: str) -> None:
    """Add the subtitles as a selectable track (no re-encoding)."""
    tmp = video.with_name(video.stem + ".subs" + video.suffix)
    codec = "mov_text" if video.suffix.lower() in (".mp4", ".mov", ".m4v") else "srt"
    lang = {"en": "eng", "fr": "fra", "es": "spa", "de": "deu", "it": "ita", "pt": "por", "nl": "nld", "ru": "rus",
            "zh": "zho", "ja": "jpn", "ko": "kor", "ar": "ara", "hi": "hin", "uk": "ukr", "pl": "pol", "tr": "tur",
            "vi": "vie", "tl": "tgl"}.get(language, "und")
    r = proc.run([ffmpeg.ffmpeg, "-v", "error", "-nostdin", "-y", "-i", str(video), "-i", str(srt), "-map", "0",
                  "-map", "1:0", "-c", "copy", "-c:s", codec, "-metadata:s:s:0", f"language={lang}", str(tmp)],
                 timeout=None, text=True)
    if r.returncode != 0:
        raise RuntimeError("couldn't add the subtitle track: " + (r.stderr or "").strip()[-200:])
    tmp.replace(video)
