"""Speed test of the AI steps on this PC, and time estimates from it.

measure() runs each AI model on a small test picture (twice - the first run warms the graphics card up)
and records milliseconds per megapixel of input. estimate_minutes() turns that into "minutes of work per
minute of video" for given settings and a given source.
"""
from __future__ import annotations

import time
from typing import Callable

import numpy as np

TEST_W, TEST_H = 384, 256


def _test_image() -> np.ndarray:
    import cv2
    rng = np.random.default_rng(7)
    img = (rng.random((TEST_H // 8, TEST_W // 8, 3)) * 255).astype(np.uint8)
    img = cv2.resize(img, (TEST_W, TEST_H), interpolation=cv2.INTER_CUBIC)
    return np.clip(img.astype(np.int16) + rng.integers(-12, 12, img.shape), 0, 255).astype(np.uint8)


def _time(fn, runs: int = 2) -> float:
    best = None
    for i in range(runs + 1):
        t = time.perf_counter()
        fn()
        dt = time.perf_counter() - t
        if i and (best is None or dt < best):      # the first run includes warming up
            best = dt
    return best


def measure(use_gpu: bool = True, log: Callable[[str], None] = print,
            progress: Callable[[float], None] = lambda f: None, cancel: Callable[[], None] = lambda: None) -> dict:
    """{step: ms per input megapixel}, plus "device"."""
    from . import ai, extras
    img = _test_image()
    mp = TEST_W * TEST_H / 1e6
    steps = []
    if ai.available("ai_fast"):
        steps.append(("fast", lambda: ai.Upscaler("ai_fast", 4, use_gpu, 384),
                      lambda m: ai.enhance_frame(m, img, TEST_W * 2, TEST_H * 2, 100)))
    if ai.available("ai_best"):
        steps.append(("best2", lambda: ai.Upscaler("ai_best", 2, use_gpu, 384),
                      lambda m: ai.enhance_frame(m, img, TEST_W * 2, TEST_H * 2, 100)))
    if extras.have(extras.DENOISE_MODEL):
        steps.append(("denoise", lambda: extras.VideoDenoiser(100, 0, use_gpu), lambda m: m._denoise(img)))
    if extras.have(extras.DEBLUR_MODEL):
        steps.append(("deblur", lambda: extras.Deblurrer(100, use_gpu), lambda m: m.apply(img)))
    if ai.rife_available():
        steps.append(("rife", lambda: ai.Interpolator(use_gpu), lambda m: m.between(img, img[:, ::-1].copy(), 0.5)))
    out: dict = {}
    devices = set()
    # the speed test uses the plain engine (TensorRT would first prepare every model - minutes); the time
    # estimates then learn the real speed from finished tasks
    from breezy.core import ai_engine
    trt, ai_engine.trt_active = ai_engine.trt_active, False
    try:
        return _measure_steps(steps, out, devices, mp, log, progress, cancel)
    finally:
        ai_engine.trt_active = trt


def _measure_steps(steps, out, devices, mp, log, progress, cancel) -> dict:
    for k, (name, make, run) in enumerate(steps):
        cancel()
        log(f"Speed test: {name}…")
        model = make()
        sess = getattr(model, "session", None) or getattr(getattr(model, "up", None), "session", None)
        if sess is not None:
            devices.add(sess.get_providers()[0])
        out[name] = round(_time(lambda: run(model)) / mp * 1000, 1)
        progress((k + 1) / max(1, len(steps)))
    out["device"] = "graphics card" if any(d != "CPUExecutionProvider" for d in devices) else "processor"
    return out


# a middling graphics card (ms per megapixel); only used to weigh files and steps against each other
# when this PC hasn't been measured
DEFAULT_BENCH = {"fast": 60.0, "best2": 900.0, "denoise": 700.0, "deblur": 900.0, "rife": 40.0}


def level_minutes(tier: str, settings, width: int = 1280, height: int = 720, fps: float = 30.0) -> float | None:
    """Estimated minutes of work per minute of video (720p by default) for a global Quality level on this PC
    (its measured speed, corrected by how fast earlier Enhance tasks went). None until the PC is measured."""
    from types import SimpleNamespace
    from breezy.core.quality import hardware_values
    from .filters import EnhanceSettings, tier_settings
    from .render import make_plan
    hw = (settings.get("app", "hardware") if settings else None) or {}
    bench = hw.get("bench")
    if not bench:
        return None
    s = tier_settings(tier, (settings.get("enhance", "content", "general") if settings else "general"))
    vals = s.to_spec()
    vals.update(hardware_values(settings).get("enhance", {}))
    fr = settings.get("enhance", "frame_rate", "same") if settings else "same"
    vals["frame_rate"] = fr or "same"
    vals["fr_choice"] = (settings.get("enhance", "fr_choice", "auto") if settings else "auto") or "auto"
    s = EnhanceSettings.from_spec(vals)
    info = SimpleNamespace(video=SimpleNamespace(width=width, height=height, fps=fps, duration=60, codec="h264",
                                                 sar=1.0), duration=60, audio=None)
    plan = make_plan(info, s, {"brightness": 100})
    m = work_units(s, plan, 60.0, bench)
    from breezy.core.quality import speed_class
    return m * (learned_factor(settings, speed_class(s.to_spec())) or 1.0)


def learned_factor(settings, cls: str = "heavy") -> float | None:
    """How much longer (>1) or shorter (<1) Enhance really took on this PC than estimated, learned from
    finished Enhance tasks (None until one has finished)."""
    if settings is None:
        return None
    table = settings.get("app", "learned_speed") or {}
    rates = {}
    for k, v in table.items():
        kind, _, w = k.partition("|")
        name, _, c = kind.partition("/")
        if name in ("enhance.run", "enhance.auto") and (c or "heavy") == cls and v:
            rates[int(w or 1)] = float(v)
    if not rates:
        return None
    w = min(rates)                        # fewest videos at once = closest to one video's own time
    per_unit = w / rates[w]               # seconds per estimated work minute, for one video
    return max(0.05, min(20.0, per_unit / 60.0))


def work_units(s, plan, duration: float, bench: dict | None = None) -> float:
    """Relative amount of work for one video (minutes of work, estimated) - for progress and time left."""
    m = estimate_minutes(s, plan, bench or DEFAULT_BENCH) or 0.0
    passes = 0.0
    if s.stabilize:
        passes += 1.5
    if plan.rs or plan.scene:
        passes += 1.0
    per_pass = plan.fps * 3.0 * plan.in_w * plan.in_h / 1e6 / 1000      # minutes per minute of video
    return max(1e-3, (m + passes * per_pass) * max(duration, 1.0) / 60)


def estimate_minutes(s, plan, bench: dict) -> float | None:
    """Minutes of work for one minute of this video with these settings (AI steps + ~a base cost)."""
    if not bench:
        return None
    in_mp = plan.in_w * plan.in_h / 1e6
    out_mp = plan.out_w * plan.out_h / 1e6
    # decoding, filters, piping, encoding (rough; measured relative costs of the classic filters)
    filt = 1.0
    if s.deblock or s.deband or s.white_balance or s.sharpen:
        filt += 0.5
    if s.denoise and s.denoise_method == "nlmeans":
        filt += 1.0 if s.gpu_filters else 6.0            # on the graphics card (OpenCL) / on the processor
    if plan.python:
        filt += 0.3                                       # frames pass through the app's own steps
    ms = 2.5 * (in_mp + out_mp) * filt
    if plan.factor:
        if s.upscaler == "ai_fast":
            ms += bench.get("fast", 0) * in_mp
        else:
            b2 = bench.get("best2", 0)
            ms += (b2 if plan.factor == 2 else b2 * 2.2) * in_mp     # the x4 model costs roughly twice as much
    if plan.denoise_ai:
        ms += bench.get("denoise", 0) * in_mp
    if plan.deblur:
        ms += bench.get("deblur", 0) * in_mp
    frames = 60 * plan.fps
    rife_frames = 0.0
    if plan.retime:
        rife_frames += 60 * plan.enc_fps * plan.slowmo
    if plan.stutter and s.stutter == "ai":
        rife_frames += frames * 0.02                   # only frozen frames are rebuilt
    seconds = frames * ms / 1000 + rife_frames * bench.get("rife", 0) * min(in_mp, 2.07) / 1000
    if plan.remove or plan.colour or plan.faces or plan.low_light:
        seconds *= 1.3                                 # smaller AI steps not measured separately
    return seconds / 60
