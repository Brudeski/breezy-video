"""One quick pass over the whole video (small pictures) before rendering, for the steps that need to
know the video as a whole:

- scenes (cuts) and each scene's light & colour levels, for "Fix lighting & colour per scene"
- camera motion per band of lines, measured on the ORIGINAL (unstabilised) picture, for the
  rolling-shutter fix

Results are cached in memory per file.
"""
from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Callable

import numpy as np

from breezy.core import proc

SCAN_W = 320
_cache: dict = {}


def _key(path: Path, chain: list[str], scenes: bool, motion: bool) -> tuple:
    p = Path(path)
    try:
        st = p.stat()
        return (str(p), st.st_size, int(st.st_mtime), tuple(chain), scenes, motion)
    except OSError:
        return (str(p), 0, 0, tuple(chain), scenes, motion)


def prepass(ffmpeg, path: Path, width: int, height: int, chain: list[str], scenes: bool, motion: bool,
            n_est: int = 0, hwaccel: bool = True, progress: Callable[[float], None] = lambda f: None,
            cancel: Callable[[], None] = lambda: None) -> dict:
    """chain: filters to apply first (deinterlace, crop, colour...) so the frames match the render's.
    width/height: the picture size after those filters. Returns {"scenes": [(first_frame, lo, hi, grey)],
    "motion": array (frames, bands, 2) or None, "size": (w, h) of the scan pictures}."""
    key = _key(path, chain, scenes, motion)
    if key in _cache:
        return _cache[key]
    import cv2
    from .extras import band_motion, frame_levels
    sw = SCAN_W
    sh = max(16, int(round(sw * height / max(1, width) / 2)) * 2)
    vf = ",".join(chain + [f"scale={sw}:{sh}:flags=area", "format=rgb24"])
    p = proc.popen([ffmpeg.ffmpeg, "-v", "error", "-nostdin", *(["-hwaccel", "auto"] if hwaccel else []),
                    "-i", str(path), "-map", "0:v:0", "-an", "-sn", "-dn", "-vf", vf, "-fps_mode", "passthrough",
                    "-f", "rawvideo", "-"], stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    fb = sw * sh * 3
    motions, cuts, levels = [], [0], []
    prev_gray = prev_tiny = None
    diffs: list[float] = []
    i = 0
    try:
        while True:
            buf = p.stdout.read(fb)
            if len(buf) < fb:
                break
            if i % 16 == 0:
                cancel()
                if n_est:
                    progress(min(0.99, i / n_est))
            rgb = np.frombuffer(buf, np.uint8).reshape(sh, sw, 3)
            gray = cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)
            if motion:
                motions.append(band_motion(prev_gray, gray) if prev_gray is not None
                               else np.zeros((16, 2), np.float32))
            if scenes:
                tiny = cv2.resize(rgb, (64, 36), interpolation=cv2.INTER_AREA).astype(np.int16)
                if prev_tiny is not None:
                    d = float(np.abs(tiny - prev_tiny).mean())
                    recent = diffs[-15:]
                    base = float(np.median(recent)) if recent else 0.0
                    if d > max(22.0, 4 * base) and i - cuts[-1] >= 8:
                        cuts.append(i)
                    diffs.append(d)
                prev_tiny = tiny
                if i % 2 == 0:
                    levels.append((i, *frame_levels(rgb)))
            prev_gray = gray
            i += 1
    finally:
        try:
            p.kill()
        except Exception:
            pass
        p.stdout.close()
        p.wait()
    out = {"frames": i, "size": (sw, sh), "motion": np.stack(motions) if motions else None, "scenes": []}
    if scenes:
        bounds = cuts + [i]
        for a, b in zip(bounds[:-1], bounds[1:]):
            ls = [x[1:] for x in levels if a <= x[0] < b]
            if not ls:
                continue
            lo = np.median(np.stack([x[0] for x in ls]), axis=0)
            hi = np.median(np.stack([x[1] for x in ls]), axis=0)
            greys = np.stack([x[2] for x in ls])
            ok = np.isfinite(greys).all(axis=1)
            grey = np.median(greys[ok], axis=0) if ok.sum() >= max(1, len(ls) // 4) else None
            out["scenes"].append((a, [float(v) for v in lo], [float(v) for v in hi],
                                  None if grey is None else [float(v) for v in grey]))
    if len(_cache) > 20:
        _cache.clear()
    _cache[key] = out
    progress(1.0)
    return out
