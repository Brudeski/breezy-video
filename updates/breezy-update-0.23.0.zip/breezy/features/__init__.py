"""Built-in features. Each sub-package exposes FEATURE = <Feature subclass>.

BUILTIN is a fallback list used if automatic discovery isn't possible
(e.g. inside some packaged .exe builds). Add new built-in features here too.
"""
BUILTIN = ["pipelines", "stitcher", "convert", "duplicates", "motion", "ends", "stabilize", "transform", "subtitles", "tracker", "enhance", "organise", "tasks", "settings"]
