"""Duplicates page: find identical videos and the same footage in other files (re-encoded, resized)."""
from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (QFileDialog, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPlainTextEdit,
                               QPushButton, QSplitter, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

from breezy.core import theme
from breezy.core.tasks import Task
from breezy.core.ui import Card, SettingsColumn, check, combo, spin
from breezy.features.organise import logic

ROLE = Qt.UserRole
MODULE = "duplicates"


def _size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


class DuplicatesWidget(QWidget):
    def __init__(self, feature):
        super().__init__()
        self.feature = feature
        self.ctx = feature.context
        self.tm = self.ctx.tasks
        self.extra_files: list[Path] = []
        self.infos = []
        self.groups: list[logic.DupGroup] = []
        self.keep: dict[Path, bool] = {}
        self._scan_id = None
        st = feature.setting

        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)

        src = Card()
        top = QHBoxLayout()
        self.folder_edit = QLineEdit(st("last_folder", ""))
        self.folder_edit.setPlaceholderText("Folder of videos…")
        self.folder_edit.setToolTip("The folder to look for duplicates in")
        browse = QPushButton("Browse…")
        browse.setToolTip("Choose the folder to look in")
        browse.clicked.connect(self._browse)
        add = QPushButton("Add files…")
        add.setToolTip("Add one or more video files to compare")
        add.clicked.connect(self._add_files)
        clear = QPushButton("Clear")
        clear.setToolTip("Empty the list (nothing is deleted)")
        clear.clicked.connect(self._clear)
        self.recursive = check("Include subfolders", st("recursive", True),
                               "Also look in every folder inside the chosen folder")
        self.find_btn = QPushButton("Find duplicates", objectName="primary")
        self.find_btn.setToolTip("Compare every video and group the copies")
        self.find_btn.clicked.connect(self.scan)
        for wdg in (QLabel("Folder:"), self.folder_edit, browse, add, clear, self.recursive, self.find_btn):
            top.addWidget(wdg, 1 if wdg is self.folder_edit else 0)
        src.v.addLayout(top)
        self.extra_label = QLabel("", objectName="muted")
        src.v.addWidget(self.extra_label)
        lv.addWidget(src)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Keep", "Size", "Picture", "Length", "Folder"])
        self.tree.header().resizeSection(0, 330)
        self.tree.setToolTip("Ticked = keep. The best copy of each set is ticked for you")
        self.tree.itemChanged.connect(self._keep_changed)
        split = QSplitter(Qt.Vertical)
        split.addWidget(self.tree)
        self.log = QPlainTextEdit(readOnly=True)
        self.log.setMaximumBlockCount(2000)
        split.addWidget(self.log)
        split.setSizes([600, 120])
        lv.addWidget(split, 1)
        bar = QHBoxLayout()
        self.label = QLabel("Choose a folder and press 'Find duplicates'", objectName="muted")
        self.deal_btn = QPushButton("Move the unticked copies", objectName="primary")
        self.deal_btn.setToolTip("Move every unticked copy away (to the place chosen on the right)")
        self.deal_btn.clicked.connect(self._deal)
        bar.addWidget(self.label, 1)
        bar.addWidget(self.deal_btn)
        lv.addLayout(bar)
        root.addWidget(left, 1)

        col = SettingsColumn(360)
        d = col.add(Card("Finding duplicates"))
        self.footage = d.full(check("Also find the same footage in other files", st("footage", True),
                                    "Re-encoded, resized or re-exported copies: same length and the same pictures.\n"
                                    "Off = only files that are exactly identical"))
        self.threshold = d.row("Count as the same from:", spin(70, 100, int(st("threshold", 98)), " %", step=1),
                               "How alike the pictures must be to count as the same footage.\n"
                               "Higher = stricter (fewer, surer matches)")
        self.action = d.row("Unticked copies go:", combo(
            [("To a 'Duplicates' folder (beside each)", "folder")] +
            ([("To the Recycle Bin", "recycle")] if sys.platform == "win32" else []),
            st("dup_action", "folder"),
            "'Duplicates' folder: moved into a folder called Duplicates next to each copy - easy to check.\n"
            "Recycle Bin: frees the space; can still be restored from the Recycle Bin"))
        d.note("The best copy (most pixels, then highest quality) is ticked to keep. Nothing is deleted outright.")
        root.addWidget(col)
        for w in (self.footage, self.recursive):
            w.toggled.connect(self._save)
        self.threshold.valueChanged.connect(self._save)
        self.action.currentIndexChanged.connect(self._save)
        self.tm.finished.connect(self._task_finished)
        from breezy.core.ui import install_drop, install_list_tools
        install_drop(self, lambda d: (self.folder_edit.setText(str(d)), self.scan()), self._add_paths)
        install_list_tools(self.tree, lambda it: Path(it.data(0, ROLE)) if it and isinstance(it.data(0, ROLE), str)
                           else None)
        self._update()

    # ---------------------------------------------------------------- files
    def _say(self, m: str):
        self.log.appendPlainText(m)

    def _save(self, *_):
        f = self.feature
        f.set_setting("footage", self.footage.isChecked())
        f.set_setting("threshold", self.threshold.value())
        f.set_setting("dup_action", self.action.currentData())
        f.set_setting("recursive", self.recursive.isChecked())
        f.set_setting("last_folder", self.folder_edit.text().strip())

    def _browse(self):
        d = QFileDialog.getExistingDirectory(self, "Folder to look in", self.folder_edit.text())
        if d:
            self.folder_edit.setText(d)
            self.scan()

    def _add_files(self):
        from breezy.core.ui import pick_videos
        files = pick_videos(self, self.folder_edit.text().strip())
        if files:
            self._add_paths(files)

    def _add_paths(self, files):
        self.extra_files += [f for f in files if f not in self.extra_files]
        self.scan()

    def _clear(self):
        self.folder_edit.setText("")
        self.extra_files, self.infos, self.groups, self.keep = [], [], [], {}
        self.tree.clear()
        self._update()

    # ----------------------------------------------------------------- scan
    def scan(self):
        folder = self.folder_edit.text().strip()
        if not folder and not self.extra_files:
            QMessageBox.information(self, "Duplicates", "Choose a folder, or add files.")
            return
        self._save()
        spec = {"folder": folder, "recursive": self.recursive.isChecked(),
                "files": [str(f) for f in self.extra_files], "dups": True,
                "footage": self.footage.isChecked(), "threshold": self.threshold.value() / 100}
        name = Path(folder).name if folder else f"{len(self.extra_files)} file(s)"
        t = Task("organise.scan", MODULE, "Find duplicates in " + name, spec=spec, resumable=False, media=False)
        self._scan_id = t.id
        self.tm.submit(t)
        self._say("Looking for duplicates…")
        self._update()

    def _task_finished(self, task_id: str):
        t = self.tm.get(task_id)
        if not t or t.module != MODULE:
            return
        res = self.tm.results.pop(task_id, None)
        if t.kind == "organise.scan" and res is not None and task_id == self._scan_id:
            self.infos, self.groups = res["infos"], res["groups"]
            self.keep = {i.path: i.path == g.keep for g in self.groups for i in g.files}
            self._fill()
            self._say(f"{len(self.infos)} video(s) compared; {len(self.groups)} set(s) of duplicates.")
        elif t.kind == "organise.apply":
            self._say(t.message or ("Done." if t.status == "done" else t.status))
            if t.status == "done":
                QTimer.singleShot(200, self.scan)
        self._update()

    def _fill(self):
        self.tree.blockSignals(True)
        self.tree.clear()
        c = theme.colors()
        for g in self.groups:
            top = QTreeWidgetItem(self.tree)
            top.setText(0, f"{'Identical files' if g.kind == 'identical' else 'Same footage'} ({len(g.files)})"
                        + ("" if g.kind == "identical" else f" - {g.score:.0%} alike"))
            top.setForeground(0, QBrush(QColor(c["muted"])))
            top.setFlags(Qt.ItemIsEnabled)
            for i in g.files:
                ch = QTreeWidgetItem(top)
                ch.setData(0, ROLE, str(i.path))
                ch.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable | Qt.ItemIsUserCheckable)
                ch.setCheckState(0, Qt.Checked if self.keep.get(i.path) else Qt.Unchecked)
                ch.setText(0, i.path.name + ("   ★ best" if i.path == g.keep else ""))
                ch.setToolTip(0, str(i.path))
                ch.setText(1, _size(i.size))
                v = i.video
                ch.setText(2, f"{v.width}x{v.height}" if v else "")
                ch.setText(3, f"{int(i.duration // 60)}:{int(i.duration % 60):02d}")
                ch.setText(4, str(i.path.parent))
            top.setExpanded(True)
        self.tree.blockSignals(False)
        self._update()

    def _keep_changed(self, item, _col):
        d = item.data(0, ROLE)
        if isinstance(d, str):
            self.keep[Path(d)] = item.checkState(0) == Qt.Checked
            self._update()

    def _deal(self):
        drop = [p for p, k in self.keep.items() if not k]
        if not drop:
            return
        for g in self.groups:
            if not any(self.keep.get(i.path) for i in g.files):
                QMessageBox.warning(self, "Duplicates", "Every set needs at least one ticked copy to keep.")
                return
        action = self.action.currentData()
        where = "the Recycle Bin" if action == "recycle" else "a 'Duplicates' folder beside each"
        if QMessageBox.question(self, "Duplicates", f"Move {len(drop)} copy/copies to {where}?") != QMessageBox.Yes:
            return
        if action == "recycle":
            n, errors = logic.to_recycle_bin(drop)
            self._say(f"✔ {n} file(s) moved to the Recycle Bin." + (" Problems: " + "; ".join(errors) if errors else ""))
            self.groups, self.keep = [], {}
            self.tree.clear()
            QTimer.singleShot(100, self.scan)
            return
        moves = [[str(p), str(p.parent / "Duplicates" / p.name)] for p in drop]
        self.tm.submit(Task("organise.apply", MODULE, f"Move {len(moves)} duplicate(s)",
                            spec={"moves": moves, "copy": False, "what": "Moving duplicates"},
                            resumable=False, media=False))

    def _update(self):
        busy = any(t.module == MODULE and t.status in ("queued", "running") for t in self.tm.tasks)
        n = len(self.extra_files)
        self.extra_label.setText(f"+ {n} added file(s)" if n else "")
        self.extra_label.setVisible(bool(n))
        drop = [p for p, k in self.keep.items() if not k]
        if self.groups:
            size = sum(i.size for g in self.groups for i in g.files if i.path in drop)
            self.label.setText(f"{len(self.groups)} set(s); {len(drop)} unticked copy/copies ({_size(size)})")
        elif self.infos:
            self.label.setText("No duplicates found.")
        self.deal_btn.setEnabled(not busy and bool(drop))
        self.find_btn.setEnabled(not busy)
