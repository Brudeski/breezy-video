"""Duplicates: find identical videos and the same footage in other files."""
from breezy.core.plugin import Feature
from breezy.features.organise import tasks  # noqa: F401  (the scan / move runners)


class DuplicatesFeature(Feature):
    id = "duplicates"
    name = "Duplicates"
    description = ("Find duplicate videos - identical copies and re-encoded or resized versions of the same "
                   "footage - and move the extra copies to a 'Duplicates' folder or the Recycle Bin.")
    order = 15
    icon = "copies"

    def create_widget(self):
        from .widget import DuplicatesWidget
        self.widget = DuplicatesWidget(self)
        return self.widget

    def theme_changed(self):
        self.widget._fill()


FEATURE = DuplicatesFeature
