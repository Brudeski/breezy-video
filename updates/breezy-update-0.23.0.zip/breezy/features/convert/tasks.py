"""Convert & Compress: change format, shrink to a file size, lower the resolution or frame rate."""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

from breezy.core import encoders
from breezy.core.ffmpeg import FFmpeg, MediaInfo
from breezy.core.filepage import video_task_items
from breezy.core.outputs import apply_pattern, finish, output_dir, unique_path, working_path
from breezy.core.proc import Cancelled
from breezy.core.tasks import Task, TaskContext, register_runner

# key -> (label, extension, video codec, audio codec when re-encoded)
FORMATS = {
    "mp4_h264": ("MP4 · H.264 (plays everywhere)", ".mp4", "h264", "aac"),
    "mp4_hevc": ("MP4 · H.265 (about half the size)", ".mp4", "hevc", "aac"),
    "mkv_hevc": ("MKV · H.265", ".mkv", "hevc", "aac"),
    "mov_h264": ("MOV · H.264 (Apple)", ".mov", "h264", "aac"),
    "webm_vp9": ("WebM · VP9 (for websites, slow)", ".webm", "vp9", "opus"),
    "mp4_copy": ("MP4 · keep the video as it is (fast, lossless)", ".mp4", "copy", "aac"),
    "mp3": ("Sound only · MP3", ".mp3", "", "mp3"),
    "m4a": ("Sound only · M4A (AAC)", ".m4a", "", "aac"),
}
RESOLUTIONS = [("Same as source", 0), ("2160p (4K)", 2160), ("1440p", 1440), ("1080p (Full HD)", 1080),
               ("720p", 720), ("480p", 480), ("360p", 360)]
FRAME_RATES = [("Same as source", 0), ("60 fps", 60), ("50 fps", 50), ("30 fps", 30), ("25 fps", 25),
               ("24 fps", 24), ("15 fps", 15)]
SIZE_MODES = [("Set by quality", "quality"), ("Target file size", "target"), ("Percent of the original size", "percent")]
QUICK_SIZES = [("Quick sizes…", 0), ("8 MB", 8), ("10 MB (Discord)", 10), ("25 MB (email)", 25), ("50 MB", 50),
               ("100 MB", 100), ("500 MB", 500), ("2 GB", 2048)]
AUDIO = [("Keep as it is (when possible)", "keep"), ("Re-encode", "encode"), ("Remove the sound", "off")]
# containers and the sound formats they can hold without re-encoding
_COPY_OK = {".mp4": {"aac", "mp3", "ac3", "eac3", "alac", "opus"}, ".mov": {"aac", "mp3", "ac3", "alac", "pcm_s16le"},
            ".mkv": None, ".webm": {"opus", "vorbis"}, ".m4a": {"aac", "alac"}, ".mp3": {"mp3"}}


@dataclass
class Plan:
    ext: str
    vcodec: str          # h264 | hevc | vp9 | copy | "" (sound only)
    acodec: str          # aac | opus | mp3 | copy | "" (no sound)
    width: int
    height: int
    fps: float
    scale: bool
    new_fps: float       # 0 = unchanged
    target_kbps: int     # video bitrate for a target size (0 = by quality)
    audio_kbps: int
    note: str = ""


def plan_for(info: MediaInfo, s: dict) -> Plan:
    label, ext, vcodec, aenc = FORMATS.get(s.get("format", "mp4_h264"), FORMATS["mp4_h264"])
    v, a = info.video, info.audio
    if vcodec and not v:
        vcodec = ""                                   # a sound file: nothing to encode
    w, h = (v.width, v.height) if v else (0, 0)
    fps = float(v.fps) if v and v.fps else 30.0
    scale = False
    res = int(s.get("resolution", 0) or 0)
    if vcodec not in ("", "copy") and res and min(w, h) > res:      # only ever smaller (short side, so portrait too)
        f = res / min(w, h)
        w, h = int(round(w * f / 2)) * 2, int(round(h * f / 2)) * 2
        scale = True
    new_fps = 0.0
    want = float(s.get("frame_rate", 0) or 0)
    if vcodec not in ("", "copy") and want and want < fps - 0.5:
        new_fps = want
    out_fps = new_fps or fps
    # sound
    audio_mode = s.get("audio", "keep")
    if not a or audio_mode == "off":
        acodec, akbps = "", 0
    else:
        ok = _COPY_OK.get(ext, set())
        if audio_mode == "keep" and (ok is None or a.codec in ok):
            acodec = "copy"
            akbps = int((getattr(a, "bit_rate", 0) or 0) / 1000) or 160
        else:
            acodec = aenc
            akbps = int(s.get("audio_kbps", 160) or 160)
    # size
    dur = (v.duration if v and v.duration else 0) or info.duration or 1.0
    mode = s.get("size_mode", "quality")
    target_kbps = 0
    note = ""
    if vcodec not in ("", "copy") and mode in ("target", "percent"):
        mb = float(s.get("target_mb", 25.0)) if mode == "target" else \
            (info.size or 0) / 1048576 * float(s.get("percent", 50)) / 100
        total_kbit = mb * 8 * 1024 * 0.97
        target_kbps = max(50, int(total_kbit / dur - akbps))
        src_mb = (info.size or 0) / 1048576
        if mode == "target" and src_mb and mb >= src_mb * 0.95:
            # already under the target: don't blow it up to that size - normal quality instead
            return Plan(ext, vcodec, acodec, w, h, fps, scale, new_fps, 0, akbps,
                        "already smaller than the target - made at the normal quality")
        bpp = target_kbps * 1000 / max(1, w * h * out_fps)
        if bpp < 0.02:
            note = "very low quality at this size - choose a smaller resolution"
        if mode == "target" and total_kbit / dur - akbps < 50:
            note = "the sound alone is about this big - the target can't be reached"
    return Plan(ext, vcodec, acodec, w, h, fps, scale, new_fps, target_kbps, akbps, note)


def estimate_mb(info: MediaInfo, s: dict, settings=None) -> float | None:
    """Rough size of the result in MB."""
    p = plan_for(info, s)
    dur = info.duration or 0
    if not dur:
        return None
    if p.vcodec == "":
        return (p.audio_kbps * dur) / 8 / 1024
    if p.vcodec == "copy":
        return (info.size or 0) / 1048576
    if p.target_kbps:
        return (p.target_kbps + p.audio_kbps) * dur / 8 / 1024 / 0.97
    try:
        from breezy.features.enhance.filters import EnhanceSettings
        from breezy.features.enhance.render import estimate_size_mb
        es = EnhanceSettings(size="same", upscaler="lanczos", same_size_ai=False,
                             codec=p.vcodec if p.vcodec in ("h264", "hevc") else "hevc", crf=int(s.get("crf", 20)),
                             audio_bitrate=f"{p.audio_kbps}k" if p.acodec not in ("copy", "") else "")
        mb = estimate_size_mb(info, es, {}, settings)
        if mb is None:
            return None
        if p.scale and info.video:          # a smaller picture needs less than proportionally fewer bits
            mb *= ((p.width * p.height) / (info.video.width * info.video.height)) ** 0.8
        if p.new_fps:
            mb *= (p.new_fps / p.fps) ** 0.8
        if p.vcodec == "vp9":
            mb *= 0.6
        return mb
    except Exception:
        return None


def _video_args(p: Plan, s: dict, kbps: int) -> list[str]:
    speed = s.get("enc_speed", "balanced")
    if p.vcodec == "copy":
        return ["-c:v", "copy"]
    if p.vcodec == "vp9":
        cpu = {"quality": "1", "balanced": "2", "fast": "4"}.get(speed, "2")
        rate = ["-b:v", f"{kbps}k"] if kbps else ["-crf", str(min(63, int(s.get("crf", 20)) + 12)), "-b:v", "0"]
        return ["-c:v", "libvpx-vp9", *rate, "-row-mt", "1", "-deadline", "good", "-cpu-used", cpu,
                "-pix_fmt", "yuv420p"]
    args = encoders.video_args(p.vcodec, int(s.get("crf", 20)), bool(s.get("enc_gpu", True)),
                               ["-pix_fmt", "yuv420p"], speed=speed)
    if kbps:
        from breezy.features.enhance.render import _bitrate_args
        args = _bitrate_args(args, kbps)
    if p.vcodec == "hevc" and p.ext in (".mp4", ".mov"):
        args += ["-tag:v", "hvc1"]
    return args


def _audio_args(p: Plan) -> list[str]:
    if not p.acodec:
        return ["-an"]
    if p.acodec == "copy":
        return ["-c:a", "copy"]
    enc = {"aac": "aac", "opus": "libopus", "mp3": "libmp3lame"}[p.acodec]
    return ["-c:a", enc, "-b:a", f"{p.audio_kbps}k"]


def convert(ff: FFmpeg, info: MediaInfo, s: dict, out: Path, ctx: TaskContext, log=print) -> str:
    p = plan_for(info, s)
    dur = info.duration or 1.0
    vf = []
    if p.scale:
        vf.append(f"scale={p.width}:{p.height}:flags=lanczos")
    if p.new_fps:
        vf.append(f"fps={p.new_fps:g}")
    kbps = p.target_kbps
    limit_mb = None
    if kbps and s.get("size_mode") in ("target", "percent") and p.vcodec not in ("", "copy"):
        limit_mb = float(s.get("target_mb", 25.0)) if s.get("size_mode") == "target" else \
            (info.size or 0) / 1048576 * float(s.get("percent", 50)) / 100
    for attempt in range(3):
        tmp = working_path(out)
        args = ["-i", str(info.path)]
        if p.vcodec:
            args += ["-map", "0:v:0"]
        if p.acodec:
            args += ["-map", "0:a:0"]
        args += ["-map_metadata", "0"]
        if p.vcodec:
            args += (["-vf", ",".join(vf)] if vf else []) + _video_args(p, s, kbps)
        else:
            args += ["-vn"]
        args += _audio_args(p)
        if p.ext in (".mp4", ".mov", ".m4a"):
            args += ["-movflags", "+faststart"]
        label = "Converting" if attempt == 0 else "Making it a little smaller"
        try:
            ff.run(args + [str(tmp)], dur, lambda f, lb=label: ctx.item_progress(f, lb), None, ctx.cancel_event)
        except Cancelled:
            tmp.unlink(missing_ok=True)
            raise
        except Exception:
            tmp.unlink(missing_ok=True)
            if p.acodec == "copy" and attempt == 0:
                log("The sound can't go into this format as it is; re-encoding just the sound.")
                p.acodec, p.audio_kbps = ("opus" if p.ext == ".webm" else "aac"), int(s.get("audio_kbps", 160) or 160)
                continue
            raise
        size_mb = tmp.stat().st_size / 1048576
        if limit_mb and size_mb > limit_mb * 1.005 and attempt < 2:
            over = size_mb / limit_mb
            kbps = max(40, int(kbps / over * 0.96))
            log(f"Result {size_mb:.1f} MB is over {limit_mb:.1f} MB - making it again at a lower bitrate.")
            tmp.unlink(missing_ok=True)
            continue
        finish(tmp, out)
        break
    if s.get("keep_date", True):
        try:
            st = info.path.stat()
            os.utime(out, (st.st_atime, st.st_mtime))
        except OSError:
            pass
    size = out.stat().st_size / 1048576
    orig = (info.size or 0) / 1048576
    bits = [f"{size:.1f} MB" + (f" ({size / orig:.0%} of the original)" if orig else "")]
    if p.scale:
        bits.append(f"{p.width}×{p.height}")
    if p.new_fps:
        bits.append(f"{p.new_fps:g} fps")
    if p.vcodec == "copy":
        bits.append("video copied without re-encoding")
    return ", ".join(bits)


def _run(task: Task, ctx: TaskContext, files: list[str]):
    s = task.spec
    pattern = s.get("name_pattern", "{name}_converted")
    video_task_items(ctx, files, task)
    for _i, f in ctx.items():
        src = Path(f)
        try:
            info = ctx.ffmpeg.probe(src)
            if info.error:
                raise RuntimeError(info.error)
            p = plan_for(info, s)
            if not p.vcodec and not p.acodec:
                raise RuntimeError("no sound to save")
            out = unique_path(output_dir(s, src) / (apply_pattern(pattern, src.stem) + p.ext))
            ctx.log(f"=== {src.name} → {out}")
            if p.note:
                ctx.log(f"Note: {p.note}")
            msg = convert(ctx.ffmpeg, info, s, out, ctx, ctx.log)
            ctx.add_output(out)
            ctx.log(f"✔ {out.name}: {msg}")
        except Cancelled:
            raise
        except Exception as e:  # noqa - keep going with the next video
            ctx.error(f"{src.name}: {str(e).splitlines()[0] if str(e) else type(e).__name__}")


def run_convert(task: Task, ctx: TaskContext):
    _run(task, ctx, task.spec["files"])


def run_auto(task: Task, ctx: TaskContext):
    files = task.spec.get("input_files", [])
    if not files:
        ctx.log("No input files.")
        return
    _run(task, ctx, files)


register_runner("convert.run", run_convert)
register_runner("convert.auto", run_auto)
