"""Convert & Compress page."""
from __future__ import annotations

from pathlib import Path

from breezy.core.filepage import VideoListPage
from breezy.core.ui import Card, check, combo, spin
from breezy.features.ends.editor import fmt
from breezy.features.stitcher.joiner import _fmt_size
from .tasks import AUDIO, FORMATS, FRAME_RATES, QUICK_SIZES, RESOLUTIONS, SIZE_MODES, estimate_mb, plan_for

ABITRATES = [("96 kbps", 96), ("128 kbps", 128), ("160 kbps", 160), ("192 kbps", 192), ("256 kbps", 256),
             ("320 kbps", 320)]


class ConvertWidget(VideoListPage):
    MODULE = "convert"
    TITLE = "Convert & Compress"
    DEFAULT_FOLDER = "Converted"
    DEFAULT_PATTERN = "{name}_converted"
    COLUMNS = [("Length", 70), ("Picture", 130), ("Size", 80), ("New size", 95), ("Details", 200)]
    RUN_TEXT = "Convert ticked videos"
    RUN_TIP = "Make converted copies of the ticked videos. The originals are never changed."
    task_kind, auto_kind, task_verb = "convert.run", "convert.auto", "Convert"
    needs_video = False

    def build_settings(self, col):
        st = self.st
        F = col.add(Card("Format"))
        self.format = F.row("Save as:", combo([(v[0], k) for k, v in FORMATS.items()], st("format", "mp4_h264")),
                            "H.264 plays on every phone, TV and website.\n"
                            "H.265 makes files about half the size at the same quality (newer devices).\n"
                            "WebM/VP9 is for websites (slow to make).\n"
                            "'Keep the video as it is' only changes the container (e.g. MKV or MTS to MP4):\n"
                            "instant and lossless, but the size stays about the same.\n"
                            "'Sound only' saves just the sound as MP3 or M4A.")
        S = col.add(Card("Size", "How big the new file is"))
        self.size_mode = S.row("File size:", combo(SIZE_MODES, st("size_mode", "quality")),
                               "Set by quality: the same quality for every video; the size follows.\n"
                               "Target file size: every video comes out at about this size (e.g. to\n"
                               "fit an upload limit) - the quality follows. If it comes out too big it's\n"
                               "made again a little smaller.\n"
                               "Percent: each video becomes this share of its original size.")
        self.crf = S.row("Quality:", spin(0, 40, int(st("crf", 20)), " CRF"),
                         "Lower = better and bigger. 18 looks practically identical; 23-28 for small files.\n"
                         "Set by the Quality level (top left).")
        self.target = S.row("Target size:", spin(1, 100000, float(st("target_mb", 25.0)), " MB", 1, 1.0),
                            "The size every video should come out at")
        self.quick = S.row("", combo(QUICK_SIZES, 0, "Common upload limits"))
        self.quick.currentIndexChanged.connect(self._quick)
        self.percent = S.row("Percent of original:", spin(5, 100, int(st("percent", 50)), " %", step=5))
        self.resolution = S.row("Resolution:", combo(RESOLUTIONS, int(st("resolution", 0))),
                                "Only ever makes the picture smaller (never bigger). Measured on the short\n"
                                "side, so 1080p also fits upright phone video.\n\n"
                                "When to use: a smaller resolution keeps a small file looking clean.")
        self.frame_rate = S.row("Frame rate:", combo(FRAME_RATES, int(st("frame_rate", 0))),
                                "Only ever lowers it (frames are dropped). 30 fps saves space on 60 fps video")
        A = col.add(Card("Sound"))
        self.audio = A.row("Sound:", combo(AUDIO, st("audio", "keep")),
                           "Keep: copied unchanged when the new format can hold it, otherwise re-encoded.")
        self.audio_kbps = A.row("Re-encoded bitrate:", combo(ABITRATES, int(st("audio_kbps", 160))))
        V = col.add(Card("Encoding"))
        self.enc_gpu = V.row("Encoder:", combo([("Graphics card (faster)", True), ("Processor (smaller files)", False)],
                                               bool(st("enc_gpu", True))),
                             "The processor makes slightly smaller files at the same quality, but is slower")
        self.keep_date = V.full(check("Give the new file the original's date", bool(st("keep_date", True)),
                                      "Keeps 'date modified' (and the recording date inside the file), so\n"
                                      "photo apps and folders sort the new file where the original was."))
        self.connect_all(self.format, self.size_mode, self.crf, self.target, self.percent, self.resolution,
                         self.frame_rate, self.audio, self.audio_kbps, self.enc_gpu, self.keep_date)
        self._enable()

    def _quick(self, *_):
        mb = self.quick.currentData()
        if mb:
            self.target.setValue(float(mb))
            if self.size_mode.currentData() != "target":
                self.size_mode.setCurrentIndex(self.size_mode.findData("target"))
        self.quick.blockSignals(True)
        self.quick.setCurrentIndex(0)
        self.quick.blockSignals(False)

    def _enable(self):
        fmt_key = self.format.currentData()
        vcodec = FORMATS[fmt_key][2]
        enc = vcodec not in ("", "copy")
        mode = self.size_mode.currentData()
        self.size_mode.setEnabled(enc)
        self.crf.setEnabled(enc and mode == "quality")
        self.target.setEnabled(enc and mode == "target")
        self.quick.setEnabled(enc)
        self.percent.setEnabled(enc and mode == "percent")
        self.resolution.setEnabled(enc)
        self.frame_rate.setEnabled(enc)
        self.enc_gpu.setEnabled(vcodec in ("h264", "hevc"))
        self.audio_kbps.setEnabled(self.audio.currentData() != "off")
        self.audio.setEnabled(True)

    def settings_changed(self):
        self._enable()

    def settings(self) -> dict:
        return {"format": self.format.currentData(), "size_mode": self.size_mode.currentData(),
                "crf": self.crf.value(), "target_mb": self.target.value(), "percent": self.percent.value(),
                "resolution": self.resolution.currentData(), "frame_rate": self.frame_rate.currentData(),
                "audio": self.audio.currentData(), "audio_kbps": self.audio_kbps.currentData(),
                "enc_gpu": self.enc_gpu.currentData(), "keep_date": self.keep_date.isChecked()}

    def spec_for(self, files):
        return dict(super().spec_for(files), enc_speed=self.st("enc_speed", "balanced"))

    def reload_settings(self):
        from breezy.core.ui import reload_from
        reload_from(self.feature, {"crf": self.crf, "enc_gpu": self.enc_gpu})

    def can_run(self) -> str:
        return ""

    def fill_row(self, it, p: Path, info):
        s = self.settings() if hasattr(self, "keep_date") else {}
        v = info.video
        it.setText(1, fmt(info.duration, False))
        if v:
            fps = f" {float(v.fps):.3g} fps" if v.fps else ""
            it.setText(2, f"{v.width}×{v.height}{fps}")
        else:
            it.setText(2, "sound only")
        it.setText(3, _fmt_size(info.size))
        if not s:
            return
        p_ = plan_for(info, s)
        mb = estimate_mb(info, s, self.ctx.settings)
        if mb is not None:
            it.setText(4, ("≈ " if not p_.target_kbps and p_.vcodec not in ("", "copy") else "") +
                       _fmt_size(int(mb * 1048576)))
        bits = []
        if not p_.vcodec and not p_.acodec:
            self.warn(it, 5, "No sound to save - skipped")
            return
        if p_.vcodec and not v:
            bits.append("sound only")
        if p_.scale:
            bits.append(f"→ {p_.width}×{p_.height}")
        if p_.new_fps:
            bits.append(f"→ {p_.new_fps:g} fps")
        if p_.vcodec == "copy":
            bits.append("video copied")
        if p_.acodec == "copy":
            bits.append("sound copied")
        elif not p_.acodec and info.audio:
            bits.append("no sound")
        if p_.note and p_.target_kbps:
            self.warn(it, 5, p_.note)
        elif p_.note:
            it.setText(5, p_.note)
        else:
            it.setText(5, ", ".join(bits))
