"""Convert & Compress: change format, shrink to a file size, lower the resolution or frame rate."""
from breezy.core.plugin import Feature
from . import tasks as _tasks  # noqa: F401  (registers the task runners)


class ConvertFeature(Feature):
    id = "convert"
    name = "Convert & Compress"
    description = ("Change format (MP4, MKV, MOV, WebM, or sound only), shrink videos to a file size or a "
                   "share of their size, lower the resolution or frame rate. Originals are never changed.")
    order = 12
    icon = "compress"

    def create_widget(self):
        from .widget import ConvertWidget
        self.widget = ConvertWidget(self)
        return self.widget

    def theme_changed(self):
        self.widget.theme_changed()

    def shutdown(self):
        w = getattr(self, "widget", None)
        if w is not None:
            w.shutdown()


FEATURE = ConvertFeature
