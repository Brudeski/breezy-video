"""Settings card: watch folders, start with Windows, keep running in the tray."""
from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QCheckBox, QDialog, QDialogButtonBox, QFileDialog, QFormLayout, QHBoxLayout, QLineEdit,
                               QMessageBox, QPushButton, QTreeWidget, QTreeWidgetItem, QWidget)

from breezy.core import watch as watchmod
from breezy.core.ui import Card, combo


class WatchDialog(QDialog):
    def __init__(self, pipes: list[str], parent=None, folder: str = "", pipe: str = "", sub: bool = False):
        super().__init__(parent)
        self.setWindowTitle("Watch a folder")
        f = QFormLayout(self)
        row = QWidget()
        h = QHBoxLayout(row)
        h.setContentsMargins(0, 0, 0, 0)
        self.folder = QLineEdit(folder)
        self.folder.setMinimumWidth(320)
        b = QPushButton("Browse…")
        b.clicked.connect(self._browse)
        h.addWidget(self.folder, 1)
        h.addWidget(b)
        f.addRow("Folder:", row)
        self.pipe = combo([(p, p) for p in pipes], pipe or None,
                          "What is done with each new video (make pipelines on the Pipelines page)")
        f.addRow("Run pipeline:", self.pipe)
        self.sub = QCheckBox("Include subfolders")
        self.sub.setChecked(sub)
        f.addRow("", self.sub)
        self.existing = QCheckBox("Also run it on the videos already in the folder")
        self.existing.setToolTip("Off: only videos that arrive from now on")
        f.addRow("", self.existing)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self._ok)
        bb.rejected.connect(self.reject)
        f.addRow(bb)

    def _browse(self):
        d = QFileDialog.getExistingDirectory(self, "Folder to watch", self.folder.text())
        if d:
            self.folder.setText(d)

    def _ok(self):
        if not Path(self.folder.text().strip()).is_dir():
            QMessageBox.information(self, "Watch a folder", "Please choose a folder that exists.")
            return
        if not self.pipe.currentData():
            QMessageBox.information(self, "Watch a folder", "Make a pipeline first on the Pipelines page.")
            return
        self.accept()


class WatchCard(Card):
    def __init__(self, context):
        super().__init__("Watch folders", "New videos in these folders are run through a pipeline automatically")
        self.ctx = context
        self.svc = getattr(context.window, "watch", None)
        self.tree = QTreeWidget()
        self.tree.setRootIsDecorated(False)
        self.tree.setHeaderLabels(["Folder", "Pipeline", "Subfolders"])
        self.tree.setColumnWidth(0, 240)
        self.tree.setMinimumHeight(110)
        self.tree.setToolTip("Untick a folder to stop watching it for a while")
        self.tree.itemChanged.connect(self._ticked)
        self.full(self.tree)
        row = QWidget()
        h = QHBoxLayout(row)
        h.setContentsMargins(0, 0, 0, 0)
        for text, tip, fn in (("Add…", "Watch another folder", self._add),
                              ("Change…", "Change the selected watch folder", self._edit),
                              ("Remove", "Stop watching the selected folder (nothing is deleted)", self._remove)):
            b = QPushButton(text)
            b.setToolTip(tip)
            b.clicked.connect(fn)
            h.addWidget(b)
        h.addStretch(1)
        self.full(row)
        st = context.settings
        self.autostart = QCheckBox("Start Breezy with Windows (in the tray)")
        self.autostart.setChecked(watchmod.autostart_enabled())
        self.autostart.setEnabled(sys.platform == "win32")
        self.autostart.setToolTip("Breezy starts quietly in the tray when you sign in to Windows, so watch\n"
                                  "folders work without opening it.")
        self.autostart.toggled.connect(self._autostart)
        self.full(self.autostart)
        self.to_tray = QCheckBox("Keep running in the tray when the window is closed")
        self.to_tray.setChecked(bool(st.get("app", "close_to_tray", True)))
        self.to_tray.setToolTip("While folders are watched, closing the window leaves Breezy running in the\n"
                                "tray (right-click its icon to quit).")
        self.to_tray.toggled.connect(lambda on: st.set("app", "close_to_tray", on))
        self.full(self.to_tray)
        if self.svc is not None:
            self.svc.changed.connect(self._fill)
        self._fill()

    def _pipes(self) -> list[str]:
        return sorted((self.ctx.settings.get("app", "pipelines") or {}).keys(), key=str.lower)

    def _fill(self):
        if self.svc is None:
            return
        self.tree.blockSignals(True)
        self.tree.clear()
        pipes = set(self._pipes())
        for w in self.svc.watches():
            it = QTreeWidgetItem(self.tree)
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(0, Qt.Checked if w.get("on", True) else Qt.Unchecked)
            it.setText(0, w["folder"])
            it.setToolTip(0, w["folder"])
            name = w.get("pipeline", "")
            it.setText(1, name if name in pipes else f"{name} (missing!)")
            it.setText(2, "yes" if w.get("subfolders") else "")
        self.tree.blockSignals(False)

    def _ticked(self, it, _col):
        ws = self.svc.watches()
        i = self.tree.indexOfTopLevelItem(it)
        if 0 <= i < len(ws):
            ws[i]["on"] = it.checkState(0) == Qt.Checked
            self.svc.save_watches(ws)

    def _add(self):
        pipes = self._pipes()
        if not pipes:
            QMessageBox.information(self, "Watch folders", "Make a pipeline first on the Pipelines page - it says "
                                    "what happens to each new video.")
            return
        d = WatchDialog(pipes, self)
        if d.exec():
            self.svc.add(d.folder.text().strip(), d.pipe.currentData(), d.sub.isChecked(), d.existing.isChecked())
            self._offer_autostart()

    def _edit(self):
        i = self.tree.indexOfTopLevelItem(self.tree.currentItem()) if self.tree.currentItem() else -1
        ws = self.svc.watches()
        if not (0 <= i < len(ws)):
            return
        w = ws[i]
        d = WatchDialog(self._pipes(), self, w["folder"], w.get("pipeline", ""), bool(w.get("subfolders")))
        d.existing.hide()
        if d.exec():
            w.update(folder=d.folder.text().strip(), pipeline=d.pipe.currentData(), subfolders=d.sub.isChecked())
            self.svc.save_watches(ws)

    def _remove(self):
        i = self.tree.indexOfTopLevelItem(self.tree.currentItem()) if self.tree.currentItem() else -1
        ws = self.svc.watches()
        if 0 <= i < len(ws):
            del ws[i]
            self.svc.save_watches(ws)

    def _autostart(self, on: bool):
        if not watchmod.set_autostart(on):
            QMessageBox.warning(self, "Start with Windows", "Windows didn't allow the change.")

    def _offer_autostart(self):
        if sys.platform != "win32" or self.autostart.isChecked():
            return
        if QMessageBox.question(self, "Watch folders", "Start Breezy with Windows, so the folder is watched even "
                                "when you haven't opened Breezy?") == QMessageBox.Yes:
            self.autostart.setChecked(True)
