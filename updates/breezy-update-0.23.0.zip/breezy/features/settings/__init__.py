"""App-wide settings: theme, Breezy Output folder, FFmpeg, GPU, history, what's new."""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from PySide6.QtWidgets import (QCheckBox, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPushButton,
                               QTextBrowser, QVBoxLayout, QWidget)

from breezy import __version__
from breezy.changelog import CHANGES
from breezy.core import encoders
from breezy.core.ffmpeg import FFmpeg, _app_root
from breezy.core.plugin import Feature
from breezy.core.settings import app_data_dir
from breezy.core.ui import Card, SettingsColumn, combo


def _open_folder(path: Path):
    path.mkdir(parents=True, exist_ok=True)
    if sys.platform == "win32":
        os.startfile(str(path))  # noqa
    else:
        subprocess.Popen(["xdg-open", str(path)])


class SettingsFeature(Feature):
    id = "app"
    name = "Settings"
    description = "Look, where files are saved, FFmpeg and graphics card, output history and what's new."
    order = 1000
    icon = "gear"

    def create_widget(self):
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        col = SettingsColumn(520)
        h.addWidget(col)

        look = col.add(Card("Look"))
        self.theme = look.row("Theme:", combo([("Follow Windows", "auto"), ("Light", "light"), ("Dark", "dark")],
                                              self.context.settings.get("app", "theme", "auto")))
        self.theme.currentIndexChanged.connect(lambda: self.context.window.set_theme(self.theme.currentData()))
        self.tips = QCheckBox("Show explanatory tooltips when hovering over controls")
        self.tips.setChecked(bool(self.context.settings.get("app", "tooltips", True)))
        self.tips.setToolTip("Show a short explanation when you hold the mouse over a setting or button "
                             "(like this one). Turn off once you know your way around.")
        self.tips.toggled.connect(self._tips_toggled)
        look.full(self.tips)

        out = col.add(Card("Breezy Output folder", "Where every module saves its files by default"))
        row = QWidget()
        rh = QHBoxLayout(row)
        rh.setContentsMargins(0, 0, 0, 0)
        self.root = QLineEdit(self.context.settings.get("app", "output_root", ""))
        self.root.setPlaceholderText("Not chosen yet - you'll be asked the first time")
        self.root.editingFinished.connect(lambda: self.context.settings.set("app", "output_root", self.root.text().strip()))
        b = QPushButton("Browse…")
        b.clicked.connect(self._pick_root)
        o = QPushButton("Open")
        o.clicked.connect(lambda: self.root.text() and _open_folder(Path(self.root.text())))
        rh.addWidget(self.root, 1)
        rh.addWidget(b)
        rh.addWidget(o)
        out.full(row)
        out.note("Each module saves into its own subfolder here (folder names are editable on each page).")

        ff = col.add(Card("FFmpeg"))
        frow = QWidget()
        fh = QHBoxLayout(frow)
        fh.setContentsMargins(0, 0, 0, 0)
        self.dir_edit = QLineEdit(self.setting("ffmpeg_dir", "") or "")
        self.dir_edit.setPlaceholderText("Auto-detect (bin folder, PATH, winget)")
        fb = QPushButton("Browse…")
        fb.clicked.connect(self._browse)
        fa = QPushButton("Apply")
        fa.clicked.connect(self._apply)
        fh.addWidget(self.dir_edit, 1)
        fh.addWidget(fb)
        fh.addWidget(fa)
        ff.full(frow)
        self.found = ff.note("")

        gpu = col.add(Card("Graphics card"))
        self.gpu_label = gpu.note("Checking…")
        recheck = QPushButton("Check again")
        recheck.clicked.connect(self._recheck_gpu)
        gpu.full(recheck)

        tk = col.add(Card("Tasks", "Whether a second task may start while one is running"))
        from breezy.core.ui import combo as _combo, spin as _spin
        st_ = self.context.settings
        self.par_mode = tk.row("Run side by side:", _combo(
            [("One at a time", "off"), ("When they don't compete (graphics card + processor)", "smart"),
             ("Any tasks", "any")], st_.get("app", "parallel_mode", "smart")),
            "When they don't compete: e.g. Enhance (graphics card) can run while Motion Trimmer\n"
            "(processor) works; two graphics-card jobs still wait for each other")
        self.par_max = tk.row("At most:", _spin(2, 6, int(st_.get("app", "parallel_max", 2) or 2), " tasks"))
        self.par_mode.currentIndexChanged.connect(self._par_changed)
        self.par_max.valueChanged.connect(self._par_changed)
        self.par_max.setEnabled(self.par_mode.currentData() == "any")

        from .watchcard import WatchCard
        self.watch_card = col.add(WatchCard(self.context))
        from .updatecard import UpdateCard
        self.update_card = col.add(UpdateCard(self.context))

        cu = col.add(Card("Computer use", "How much of the PC the app may use while it works"))
        from breezy.core import power
        self.power_mode = cu.row("Use the PC's power:", _combo(power.MODES, st_.get("app", "power_mode", "full")),
            "Full speed: tasks finish as fast as possible, the PC may feel slow meanwhile.\n"
            "Spare power only: the app and its tools (FFmpeg, AI) get the lowest processor and graphics-card "
            "priority, so whatever you do comes first and tasks use what's left.\n\n"
            "When to use: full speed when you're away or not using the PC; spare power while you work or game.")
        self.power_mode.currentIndexChanged.connect(self._power_changed)
        power.listeners.append(self._power_shown)
        self.idle_pause = QCheckBox("Pause tasks while I'm using the PC")
        self.idle_pause.setChecked(bool(st_.get("app", "pause_when_busy", False)))
        self.idle_pause.setToolTip("Tasks pause as soon as you use the keyboard or mouse and continue by themselves "
                                   "when the PC has been idle for the time below.\n\nWhen to use: for a PC you "
                                   "use for games or heavy work during the day and leave running overnight.")
        self.idle_pause.toggled.connect(self._power_changed)
        cu.full(self.idle_pause)
        self.idle_min = cu.row("Continue after idle for:", _spin(1, 120, int(st_.get("app", "idle_minutes", 5) or 5), " min"),
                               "How long the PC must be left alone before paused tasks continue.\n\n"
                               "When to use: shorter to make the most of breaks, longer if tasks keep "
                               "stopping and starting.")
        self.idle_min.valueChanged.connect(self._power_changed)
        self.idle_min.setEnabled(self.idle_pause.isChecked())

        ae = col.add(Card("AI engine", "What runs the AI models"))
        from breezy.core import ai_engine
        self.engine = ae.row("Engine:", _combo(ai_engine.ENGINES, st_.get("app", "ai_engine", "auto")),
                             "NVIDIA CUDA is usually much faster on NVIDIA cards. A change applies at the next start")
        self.engine.currentIndexChanged.connect(self._engine_changed)
        self.engine_label = ae.note(ai_engine.status_text(st_))
        self.engine_label.setWordWrap(True)
        eb = QPushButton("Install NVIDIA engine")
        eb.clicked.connect(lambda: self.context.window.install_cuda())
        tb = QPushButton("Install NVIDIA TensorRT")
        tb.setToolTip("Downloads NVIDIA TensorRT (about 1.2 GB, once) and tests it. TensorRT compiles each big AI model\n"
                      "for your exact graphics card: usually 2-3x faster than CUDA. The first time a model is used\n"
                      "with a new tile size it takes a few minutes to prepare.\n\n"
                      "When to use: on RTX 20xx / GTX 16xx and newer cards with the NVIDIA engine installed.")
        tb.clicked.connect(lambda: self.context.window.install_trt())
        brow = QWidget()
        bh = QHBoxLayout(brow)
        bh.setContentsMargins(0, 0, 0, 0)
        bh.addWidget(eb)
        bh.addWidget(tb)
        ae.full(brow)

        pc = col.add(Card("Your PC", "Measured once on first start: used to suggest settings and time estimates"))
        from breezy.core import hardware
        self.hw_label = pc.note(hardware.summary(self.context.settings.get("app", "hardware") or {}))
        self.hw_label.setWordWrap(True)
        scan = QPushButton("Scan my PC again")
        scan.clicked.connect(self._scan_pc)
        pc.full(scan)

        rp = col.add(Card("Repair", "Missing or damaged parts are downloaded automatically"))
        from breezy.core.ui import check
        self.auto_repair = rp.full(check("Download missing or damaged parts automatically",
                                         self.context.settings.get("app", "auto_repair", True),
                                         "Checks the AI models at every start, and FFmpeg's filters.\n"
                                         "If FFmpeg lacks a filter the modules need, a complete FFmpeg\n"
                                         "is downloaded into the app's bin folder."))
        self.auto_repair.toggled.connect(lambda on: self.context.settings.set("app", "auto_repair", on))
        self.repair_label = rp.note("Checking…")
        rb = QPushButton("Check && repair now")
        rb.clicked.connect(self._repair_now)
        rp.full(rb)

        hist = col.add(Card("Output history", "Used by 'Use output from…' on every page"))
        self.hist_label = hist.note("")
        hb = QWidget()
        hbh = QHBoxLayout(hb)
        hbh.setContentsMargins(0, 0, 0, 0)
        clear = QPushButton("Clear history")
        clear.clicked.connect(self._clear_history)
        logs = QPushButton("Open log/settings folder")
        logs.clicked.connect(lambda: _open_folder(app_data_dir()))
        plugins = QPushButton("Open plugins folder")
        plugins.clicked.connect(lambda: _open_folder(_app_root() / "plugins"))
        for x in (clear, logs, plugins):
            hbh.addWidget(x)
        hist.full(hb)
        self.context.history.changed.connect(self._refresh)

        news = Card(f"What's new - version {__version__}")
        tb = QTextBrowser()
        html = ""
        for v, items in CHANGES:
            html += f"<h4>Version {v}</h4><ul>" + "".join(f"<li>{i}</li>" for i in items) + "</ul>"
        tb.setHtml(html)
        news.v.addWidget(tb, 1)
        h.addWidget(news, 1)
        self._refresh()
        from PySide6.QtCore import QTimer
        QTimer.singleShot(5000, self._refresh)     # GPU detection finishes in the background
        return w

    def engine_changed(self):
        if hasattr(self, "engine_label"):
            from breezy.core import ai_engine
            self.engine_label.setText(ai_engine.status_text(self.context.settings))

    def _engine_changed(self, *_):
        from breezy.core import ai_engine
        st_ = self.context.settings
        st_.set("app", "ai_engine", self.engine.currentData())
        self.engine_label.setText(ai_engine.status_text(st_) + "\n(The change applies when the app starts again.)")
        if self.engine.currentData() in ("auto", "cuda"):
            self.context.window._maybe_install_cuda()

    def _power_shown(self, mode: str):
        self.power_mode.blockSignals(True)
        self.power_mode.setCurrentIndex(max(0, self.power_mode.findData(mode)))
        self.power_mode.blockSignals(False)

    def _power_changed(self, *_):
        st_ = self.context.settings
        st_.set("app", "pause_when_busy", self.idle_pause.isChecked())
        st_.set("app", "idle_minutes", self.idle_min.value())
        self.idle_min.setEnabled(self.idle_pause.isChecked())
        from breezy.core import power
        power.switch(st_, self.power_mode.currentData())

    def _par_changed(self, *_):
        st_ = self.context.settings
        st_.set("app", "parallel_mode", self.par_mode.currentData())
        st_.set("app", "parallel_max", self.par_max.value())
        self.par_max.setEnabled(self.par_mode.currentData() == "any")
        from PySide6.QtCore import QTimer
        QTimer.singleShot(0, self.context.window.tasks._schedule)

    def _scan_pc(self):
        self.hw_label.setText("Scanning… (see Tasks)")
        self.context.window.scan_hardware()

    def hardware_scanned(self, result: dict):
        if hasattr(self, "hw_label"):
            from breezy.core import hardware
            self.hw_label.setText(hardware.summary(result))

    def _repair_now(self):
        self.repair_label.setText("Checking…")
        self.context.window.check_repairs(force=True)

    def repair_checked(self, found: dict):
        if not hasattr(self, "repair_label"):
            return
        models, filters = found.get("models", []), found.get("ffmpeg_missing", [])
        if found.get("error"):
            text = f"Couldn't check: {found['error']}"
        elif not models and not filters and not found.get("unfixable"):
            text = "✔ All AI models are present and intact; FFmpeg has every filter the modules need."
        else:
            bits = []
            if models:
                bits.append(f"{len(models)} AI model file(s) missing or damaged ({', '.join(models[:4])}"
                            f"{'…' if len(models) > 4 else ''})")
            if filters:
                bits.append(f"FFmpeg is missing: {', '.join(filters[:6])}{'…' if len(filters) > 6 else ''}")
            if found.get("unfixable"):
                bits.append(f"{', '.join(found['unfixable'])} can't be downloaded - reinstall the app to restore it")
            auto = self.context.settings.get("app", "auto_repair", True)
            fixing = (auto or found.get("force")) and not found.get("after") and (models or found.get("ffmpeg"))
            text = "; ".join(bits) + (" - downloading now (see the task bar)." if fixing else ".")
        self.repair_label.setText(text)

    def _tips_toggled(self, on):
        self.context.settings.set("app", "tooltips", bool(on))
        win = self.context.window
        if win is not None and getattr(win, "tip_gate", None) is not None:
            win.tip_gate.enabled = bool(on)

    def _pick_root(self):
        d = QFileDialog.getExistingDirectory(None, "Where should the 'Breezy Output' folder go?", self.root.text())
        if d:
            p = Path(d) if Path(d).name.lower() == "breezy output" else Path(d) / "Breezy Output"
            self.root.setText(str(p))
            self.context.settings.set("app", "output_root", str(p))

    def _browse(self):
        d = QFileDialog.getExistingDirectory(None, "Folder containing ffmpeg.exe and ffprobe.exe")
        if d:
            self.dir_edit.setText(d)

    def _apply(self):
        self.set_setting("ffmpeg_dir", self.dir_edit.text().strip())
        new = FFmpeg(self.dir_edit.text().strip() or None)
        ff = self.context.ffmpeg
        ff.ffmpeg, ff.ffprobe = new.ffmpeg, new.ffprobe
        self._refresh()

    def _recheck_gpu(self):
        encoders._found.clear()
        self.context.settings.set("app", "gpu_encoders", {})
        encoders.detect(self.context.ffmpeg, self.context.settings)
        self._refresh()

    def _clear_history(self):
        if QMessageBox.question(None, "Clear history", "Forget the list of files made so far? "
                                "(The files themselves are not deleted.)") == QMessageBox.Yes:
            self.context.history.clear()

    def _refresh(self):
        ff = self.context.ffmpeg
        self.found.setText(f"{ff.version()}\n{ff.ffmpeg}" if ff.available else
                           "Not found. Run install_ffmpeg.bat or choose the folder with ffmpeg.exe and ffprobe.exe.")
        enc = encoders._found
        prov = encoders.onnx_providers(True)
        if enc:
            names = [e for e in (enc.get("hevc"), enc.get("h264")) if e]
            self.gpu_label.setText(("Video encoding: " + (f"{encoders.gpu_name()} GPU ({', '.join(names)})" if names
                                                         else "no GPU encoder found - using the CPU")) +
                                   "\nAI detection: " + ("GPU (DirectML)" if "DmlExecutionProvider" in prov else
                                                         "GPU (CUDA)" if "CUDAExecutionProvider" in prov else "CPU"))
        runs = self.context.history.runs
        self.hist_label.setText(f"{len(runs)} run(s), {sum(len(r.get('outputs', [])) for r in runs)} file(s) remembered.")

    def theme_changed(self):
        self._refresh()


FEATURE = SettingsFeature
