"""Settings card: updates."""
from __future__ import annotations

import time

from PySide6.QtWidgets import QCheckBox, QHBoxLayout, QLabel, QMessageBox, QPushButton, QWidget

from breezy import __version__
from breezy.core.ui import Card


class UpdateCard(Card):
    def __init__(self, context):
        super().__init__("Updates", "New versions come from Breezy's page on GitHub")
        self.ctx = context
        st = context.settings
        self.status = QLabel("")
        self.status.setWordWrap(True)
        self.full(self.status)
        self.auto = QCheckBox("Look for updates automatically (once a day)")
        self.auto.setChecked(bool(st.get("app", "update_auto", True)))
        self.auto.setToolTip("Breezy looks for a new version when it starts and once a day, and asks before\n"
                             "installing anything.")
        self.auto.toggled.connect(lambda on: st.set("app", "update_auto", on))
        self.full(self.auto)
        row = QWidget()
        h = QHBoxLayout(row)
        h.setContentsMargins(0, 0, 0, 0)
        self.check_btn = QPushButton("Check now")
        self.check_btn.setToolTip("Look for a new version right now")
        self.check_btn.clicked.connect(self._check)
        h.addWidget(self.check_btn)
        h.addStretch(1)
        self.full(row)
        up = getattr(context.window, "updates", None)
        if up is not None:
            up.nothing.connect(lambda: self._done("You have the newest version."))
            up.failed.connect(lambda e: self._done(f"Couldn't check: {e}"))
            up.found.connect(lambda info: self._done(f"Version {info.get('version')} is available."))
        self._show()

    def _show(self, extra: str = ""):
        t = float(self.ctx.settings.get("app", "update_checked", 0) or 0)
        when = time.strftime("%Y-%m-%d %H:%M", time.localtime(t)) if t else "never"
        self.status.setText(f"This is version {__version__}. Last looked: {when}." + (f"\n{extra}" if extra else ""))

    def _check(self):
        up = getattr(self.ctx.window, "updates", None)
        if up is None:
            return
        self.check_btn.setEnabled(False)
        self._show("Looking…")
        up.check_soon(manual=True)

    def _done(self, text: str):
        self.check_btn.setEnabled(True)
        self._show(text)
