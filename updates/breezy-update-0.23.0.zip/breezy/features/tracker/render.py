"""Render the reframed video: FFmpeg decodes -> numpy/OpenCV crops & scales -> FFmpeg encodes.

(FFmpeg's own animated crop can't change the crop size per frame without crashing, so the
virtual camera is applied here.) Frames travel as 8-bit YUV 4:2:0, half the size of RGB.
Optionally only the frames inside `keep` stretches are written (reframed + subjects-only in
one file); the sound is then cut to exactly the same frames.
"""
from __future__ import annotations

import queue
import subprocess
import tempfile
import threading
from pathlib import Path
from typing import Callable, Optional

import numpy as np

from breezy.core import encoders, proc
from breezy.core.ffmpeg import Cancelled, FFmpeg, MediaInfo
from breezy.core.outputs import finish, working_path
from breezy.core.sync import audio_bitrate, needs_fix, tempo
from .detector import TrackData
from .framing import FrameSettings, camera_path, out_geometry


def _even(x: float) -> int:
    return int(round(x / 2)) * 2


class Renderer:
    def __init__(self, ffmpeg: FFmpeg, log: Callable[[str], None] = print,
                 progress: Callable[[float], None] = lambda f: None, cancel: Optional[threading.Event] = None):
        self.ff, self.log, self.progress = ffmpeg, log, progress
        self.cancel = cancel or threading.Event()

    def render(self, td: TrackData, fs: FrameSettings, out: Path, keep: list[tuple[float, float]] | None = None,
               codec: str = "same", crf: int = 16, use_gpu: bool = True, hwaccel: bool = True,
               fix_drift: bool = True, drift_threshold: float = 0.1, abr: str = "") -> str:
        import cv2
        info: MediaInfo = td.info
        v = info.video
        W, H = v.width, v.height
        fps = v.fps or 30
        rate = float(fps)
        vlen = v.duration if v.duration else info.duration
        n_est = max(1, int(round(vlen * rate)))
        aspect, ow, oh = out_geometry(W, H, fs)
        times = np.arange(n_est + int(rate * 5) + 2) / rate
        cx, cy, cw, ch = camera_path(td, fs, W, H, times)
        kept = np.ones(len(times), bool)
        if keep is not None:
            kept[:] = False
            for s, e in keep:
                kept |= (times >= s - 1e-6) & (times < e - 1e-6)
        vc = codec if codec in ("hevc", "h264") else ("hevc" if v.codec == "hevc" else "h264")
        venc = encoders.video_args(vc, crf, use_gpu, ["-pix_fmt", "yuv420p"])
        out.parent.mkdir(parents=True, exist_ok=True)
        tmp = working_path(out)

        # ---- sound
        ratio = tempo(info) if (fix_drift and info.audio and needs_fix(info, drift_threshold)) else None
        aargs: list[str] = []
        fcomplex = None
        if info.audio:
            bitrate = abr or audio_bitrate(info)
            if keep is not None:
                r = ratio or 1.0
                parts, labels = [], []
                # sound per kept stretch, exactly as long as its frames
                runs = _runs(kept[:n_est + int(rate * 5)])
                for k, (a, b) in enumerate(runs):
                    s, d = a / rate, (b - a) / rate
                    tf = f",atempo={r:.6f}" if r != 1.0 else ""
                    parts.append(f"[1:a:0]atrim=start={s * r:.6f}:duration={d * r + 0.05:.6f},asetpts=PTS-STARTPTS"
                                 f"{tf},apad,atrim=end={d:.6f}[a{k}]")
                    labels.append(f"[a{k}]")
                if runs:
                    fcomplex = ";".join(parts) + ";" + "".join(labels) + f"concat=n={len(runs)}:v=0:a=1[aout]"
                    aargs = ["-map", "[aout]", "-c:a", "aac", "-b:a", bitrate]
            elif ratio:
                aargs = ["-map", "1:a:0", "-af", f"atempo={ratio:.6f}", "-c:a", "aac", "-b:a", bitrate]
            else:
                aargs = ["-map", "1:a:0", "-c:a", "copy"]
        enc_cmd = [self.ff.ffmpeg, "-v", "error", "-nostdin", "-y", "-f", "rawvideo", "-pix_fmt", "yuv420p",
                   "-s", f"{ow}x{oh}", "-r", str(fps), "-i", "-"]
        if info.audio:
            enc_cmd += ["-i", str(info.path)]
        if fcomplex:
            enc_cmd += ["-filter_complex", fcomplex]
        enc_cmd += ["-map", "0:v:0", *venc, *aargs]
        if vc == "hevc" and out.suffix.lower() in (".mp4", ".mov", ".m4v"):
            enc_cmd += ["-tag:v", "hvc1"]
        if out.suffix.lower() in (".mp4", ".mov", ".m4v"):
            enc_cmd += ["-movflags", "+faststart"]
        enc_cmd.append(str(tmp))

        errf = tempfile.TemporaryFile()
        enc = proc.popen(enc_cmd, stdin=subprocess.PIPE, stdout=subprocess.DEVNULL, stderr=errf)
        frame_bytes = W * H * 3 // 2
        written = 0
        try:
            for attempt in ((True, False) if hwaccel else (False,)):
                dec = proc.popen([self.ff.ffmpeg, "-v", "error", "-nostdin"] + (["-hwaccel", "auto"] if attempt else []) +
                                 ["-i", str(info.path), "-map", "0:v:0", "-an", "-sn", "-dn", "-fps_mode", "passthrough",
                                  "-pix_fmt", "yuv420p", "-f", "rawvideo", "-"],
                                 stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
                q: queue.Queue = queue.Queue(maxsize=6)

                def reader(dec=dec):
                    try:
                        while True:
                            buf = dec.stdout.read(frame_bytes)
                            if len(buf) < frame_bytes:
                                break
                            q.put(buf)
                    finally:
                        q.put(None)
                th = threading.Thread(target=reader, daemon=True)
                th.start()
                i = 0
                try:
                    while True:
                        if self.cancel.is_set():
                            raise Cancelled("Cancelled by user")
                        proc.checkpoint()
                        buf = q.get()
                        if buf is None:
                            break
                        k = min(i, len(times) - 1)
                        i += 1
                        if not kept[k]:
                            continue
                        enc.stdin.write(self._crop(cv2, buf, W, H, cx[k], cy[k], cw[k], ch[k], ow, oh))
                        written += 1
                        if i % 10 == 0:
                            self.progress(min(0.99, i / n_est))
                finally:
                    dec.kill() if self.cancel.is_set() else None
                    try:
                        while q.get_nowait() is not None:
                            pass
                    except queue.Empty:
                        pass
                    dec.stdout.close()
                    dec.wait()
                if i > 0:
                    break
                self.log("Graphics-card decoding failed; decoding on the processor instead.")
            enc.stdin.close()
            rc = enc.wait()
            if rc != 0:
                errf.seek(0)
                msg = errf.read().decode("utf-8", "replace").strip().splitlines()
                raise RuntimeError("encoder failed: " + (msg[-1] if msg else f"exit {rc}"))
            if written == 0:
                raise RuntimeError("no frames were written")
            finish(tmp, out)
        except BaseException:
            try:
                enc.kill()
            except Exception:
                pass
            enc.wait()
            if tmp.exists():
                try:
                    tmp.unlink()
                except OSError:
                    pass
            raise
        finally:
            errf.close()
        self.progress(1.0)
        enc_name = venc[1]
        return (f"{ow}x{oh}, {written} frames ({written / rate:.1f} s), {enc_name}"
                + (f", sound re-synced ({info.drift:+.2f} s drift fixed)" if ratio else ""))

    @staticmethod
    def _crop(cv2, buf: bytes, W: int, H: int, cx, cy, cw, ch, ow: int, oh: int) -> bytes:
        a = np.frombuffer(buf, np.uint8)
        y = a[:W * H].reshape(H, W)
        u = a[W * H:W * H + W * H // 4].reshape(H // 2, W // 2)
        vv = a[W * H + W * H // 4:].reshape(H // 2, W // 2)
        w2, h2 = max(2, _even(cw)), max(2, _even(ch))
        w2, h2 = min(w2, W), min(h2, H)
        x0 = min(max(0, _even(cx - w2 / 2)), W - w2)
        y0 = min(max(0, _even(cy - h2 / 2)), H - h2)
        interp = cv2.INTER_AREA if w2 > ow else cv2.INTER_CUBIC
        Y = cv2.resize(y[y0:y0 + h2, x0:x0 + w2], (ow, oh), interpolation=interp)
        U = cv2.resize(u[y0 // 2:(y0 + h2) // 2, x0 // 2:(x0 + w2) // 2], (ow // 2, oh // 2), interpolation=interp)
        V = cv2.resize(vv[y0 // 2:(y0 + h2) // 2, x0 // 2:(x0 + w2) // 2], (ow // 2, oh // 2), interpolation=interp)
        return Y.tobytes() + U.tobytes() + V.tobytes()


def _runs(mask: np.ndarray) -> list[tuple[int, int]]:
    """[(first index, end index)] of True runs."""
    out, start = [], None
    for i, m in enumerate(mask):
        if m and start is None:
            start = i
        elif not m and start is not None:
            out.append((start, i))
            start = None
    if start is not None:
        out.append((start, len(mask)))
    return out
