"""Subject Tracker task runners: find subjects, make the outputs, and auto-run on another task's output."""
from __future__ import annotations

import csv
from pathlib import Path

import numpy as np

from breezy.core.outputs import apply_pattern, output_dir, unique_path
from breezy.core.proc import Cancelled
from breezy.core.settings import app_data_dir
from breezy.core.tasks import Task, TaskContext, register_runner
from breezy.features.motion.cutter import CutOptions, Cutter
from .detector import DEFAULT_MODEL, TrackData, analyze, load_cached
from .framing import FrameSettings, segments
from .render import Renderer

PATTERNS = {"name_tracked": "{name}_tracked", "name_subjects": "{name}_subjects"}


def cache_dir() -> Path:
    return app_data_dir() / "tracker_cache"


def _fmt(t: float) -> str:
    m, s = divmod(t, 60)
    h, m = divmod(int(m), 60)
    return f"{h}:{m:02d}:{s:06.3f}"


def _analyze(ctx: TaskContext, spec: dict, info, prog) -> TrackData:
    return analyze(ctx.ffmpeg, info, fps=spec.get("det_fps", 5.0), model=spec.get("model", DEFAULT_MODEL),
                   use_gpu=spec.get("det_gpu", True), hwaccel=spec.get("hwaccel", True),
                   cancel=ctx.cancel_event, on_progress=prog, cache_dir=cache_dir())


def _probe_all(ctx: TaskContext, files: list[str]):
    infos = {}
    for f in files:
        ctx.checkpoint()
        infos[f] = ctx.ffmpeg.probe(Path(f))
    ctx.set_items(files, [max(infos[f].duration or 1.0, 1.0) for f in files], [Path(f).name for f in files])
    return infos


def _analyze_one(ctx: TaskContext, spec: dict, info, prog) -> TrackData:
    name = info.path.name
    if info.error:
        ctx.log(f"✖ Can't read {name}: {info.error}")
        return TrackData(info, np.zeros(0), [], error=info.error)
    td = _analyze(ctx, spec, info, prog)
    if td.error:
        ctx.log(f"✖ {name}: {td.error}")
    return td


def run_analyze(task: Task, ctx: TaskContext):
    files = task.spec["files"]
    infos = _probe_all(ctx, files)
    def find(_i, f, prog):
        prog(None, "Finding subjects")
        return _analyze_one(ctx, task.spec, infos[f], prog)

    res = ctx.parallel(find,
                       task.spec.get("det_workers", 1))
    out = {files[i]: td for i, td in res.items()}
    if ctx.cancel_event.is_set():
        raise Cancelled("Cancelled by user")
    ctx.log(f"Looked for subjects in {len(out)} video(s).")
    return out


def write_csv(td: TrackData, fs: FrameSettings, segs, path: Path):
    filt = td.filtered(fs.classes, fs.conf, fs.min_height)
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["start_seconds", "end_seconds", "duration_seconds", "start", "end", "most_subjects_at_once"])
        for s, e in segs:
            n = max((len(d) for t, d in zip(td.times, filt) if s <= t < e), default=0)
            w.writerow([f"{s:.3f}", f"{e:.3f}", f"{e - s:.3f}", _fmt(s), _fmt(e), n])


def _make(task: Task, ctx: TaskContext, files: list[str]):
    s = task.spec
    fs = FrameSettings.from_spec(s)
    want_reframe, want_cut, want_csv = s.get("out_reframe", True), s.get("out_cut", False), s.get("out_csv", False)
    combine = s.get("combine", True)
    if not (want_reframe or want_cut or want_csv):
        raise RuntimeError("Nothing to make - tick at least one output")
    infos = {}
    for f in files:
        ctx.checkpoint()
        infos[f] = ctx.ffmpeg.probe(Path(f))
    fps, model = s.get("det_fps", 5.0), s.get("model", DEFAULT_MODEL)
    # items: first "find subjects" for videos not analysed yet (several at once), then "make" for each video
    if not task.items:
        todo = [f for f in files if not infos[f].error and load_cached(infos[f], fps, model, cache_dir()) is None]
        items = [["find", f] for f in todo] + [["make", f] for f in files]
        weights = [0.4 * max(infos[f].duration or 1.0, 1.0) for f in todo] + \
                  [max(infos[f].duration or 1.0, 1.0) for f in files]
        names = [f"Finding subjects: {Path(f).name}" for f in todo] + [Path(f).name for f in files]
        ctx.set_items(items, weights, names)
    find_idx = [i for i, it in enumerate(task.items) if it[0] == "find"]
    if find_idx:
        def find(_i, it, prog):
            prog(None, "Finding subjects")
            return _analyze_one(ctx, s, infos[it[1]], prog)
        ctx.parallel(find, s.get("det_workers", 1), find_idx)
        if ctx.cancel_event.is_set():
            raise Cancelled("Cancelled by user")
    pat_t = s.get("name_tracked", PATTERNS["name_tracked"])
    pat_s = s.get("name_subjects", PATTERNS["name_subjects"])
    for _i, (_kind, f) in ctx.items():
        src = Path(f)
        info = infos[f]
        try:
            if info.error:
                raise RuntimeError(info.error)
            td = load_cached(info, fps, model, cache_dir())
            a_share = 0.0 if td else 0.4
            td = td or _analyze(ctx, s, info, lambda x: ctx.item_progress(a_share * x, "Finding subjects"))
            if td.error:
                raise RuntimeError(td.error)
            folder = output_dir(s, src)
            segs = segments(td, fs)
            jobs = []
            if not segs and s.get("no_subjects", "skip") == "copy" and (want_reframe or want_cut):
                import shutil
                folder.mkdir(parents=True, exist_ok=True)
                out = unique_path(folder / (apply_pattern(pat_t, src.stem) + src.suffix))
                shutil.copy2(src, out)
                ctx.add_output(out)
                ctx.log(f"✔ {out.name}: nobody found - copied unchanged")
            elif not segs:
                ctx.log(f"– {src.name}: no subjects found at these settings - skipped.")
            if not segs:
                if want_csv:
                    folder.mkdir(parents=True, exist_ok=True)
                    out = unique_path(folder / (apply_pattern(pat_s, src.stem) + ".csv"))
                    write_csv(td, fs, segs, out)
                    ctx.add_output(out)
                continue
            if want_reframe and want_cut and combine:
                jobs.append(("render", segs))
            else:
                if want_reframe:
                    jobs.append(("render", None))
                if want_cut:
                    jobs.append(("cut", segs))
            share = (1 - a_share) / max(1, len(jobs))
            for k, (kind, keep) in enumerate(jobs):
                base = a_share + k * share

                step = f" (step {k + 1} of {len(jobs)})" if len(jobs) > 1 else ""
                job = ("Reframing - the camera follows the subjects" if kind == "render"
                       else "Cutting out the parts with subjects") + step

                def prog(x, label=None, base=base, job=job):
                    ctx.item_progress(None if x is None else base + share * x, f"{job}: {label}" if label else job)
                ext = src.suffix if src.suffix.lower() in (".mp4", ".mov", ".mkv", ".m4v") else ".mp4"
                if kind == "render":
                    out = unique_path(folder / (apply_pattern(pat_t, src.stem) + ext))
                    ctx.log(f"=== {src.name} → {out}")
                    msg = Renderer(ctx.ffmpeg, ctx.log, prog, ctx.cancel_event).render(
                        td, fs, out, keep=keep, codec=s.get("codec", "same"), crf=s.get("crf", 16),
                        use_gpu=s.get("enc_gpu", True), hwaccel=s.get("hwaccel", True),
                        fix_drift=s.get("fix_drift", True), drift_threshold=s.get("drift_threshold", 0.1),
                        abr=s.get("audio_bitrate", ""))
                    ctx.add_output(out)
                    ctx.log(f"✔ {out.name}: reframed{' + only the parts with subjects' if keep else ''}; {msg}")
                else:
                    out = unique_path(folder / (apply_pattern(pat_s, src.stem) + src.suffix))
                    ctx.log(f"=== {src.name} → {out}")
                    opts = CutOptions(edge_gpu=s.get("edge_gpu", False), edge_crf=s.get("crf", 16),
                                      full_gpu=s.get("enc_gpu", True), full_crf=s.get("crf", 16),
                                      drift_threshold=s.get("drift_threshold", 0.1),
                                      audio_bitrate=s.get("audio_bitrate", "") or "auto")
                    r = Cutter(ctx.ffmpeg, log=ctx.log, progress=prog, cancel_event=ctx.cancel_event,
                               options=opts).cut(info, keep, out, fix_drift=s.get("fix_drift", True),
                                                 exact_audio=s.get("exact_audio", True))
                    ctx.add_output(r.output)
                    ctx.log(f"✔ {r.output.name}: {r.message}")
            if want_csv:
                out = unique_path(folder / (apply_pattern(pat_s, src.stem) + ".csv"))
                folder.mkdir(parents=True, exist_ok=True)
                write_csv(td, fs, segs, out)
                ctx.log(f"✔ {out.name}: {len(segs)} stretch(es) with subjects")
                ctx.add_output(out)
        except Cancelled:
            raise
        except Exception as e:  # noqa - keep going with the next video
            ctx.error(f"{src.name}: {str(e).splitlines()[0] if str(e) else type(e).__name__}")


def run_make(task: Task, ctx: TaskContext):
    _make(task, ctx, task.spec["files"])


def run_auto(task: Task, ctx: TaskContext):
    files = task.spec.get("input_files", [])
    if not files:
        ctx.log("No input files.")
        return
    _make(task, ctx, files)


register_runner("tracker.analyze", run_analyze)
register_runner("tracker.make", run_make)
register_runner("tracker.auto", run_auto)
