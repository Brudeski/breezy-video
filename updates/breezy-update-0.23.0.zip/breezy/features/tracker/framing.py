"""Turn detections into (a) the stretches with subjects and (b) a smooth virtual-camera path.

The camera path is a crop window (centre x/y + width; height follows the output aspect)
for every output frame. Per detection sample the window is fitted around the chosen
subject(s) plus a border, kept within the max zoom, and held for a while when nobody is
visible before easing back to the full picture. The path is then smoothed with a
zero-phase Gaussian, so the camera glides (and starts moving slightly before a subject
does - like a camera operator who knows what's coming).
"""
from __future__ import annotations

from dataclasses import dataclass, field

import numpy as np

from .detector import TrackData

ASPECTS = {"source": None, "16:9": 16 / 9, "9:16": 9 / 16, "1:1": 1.0, "4:3": 4 / 3, "4:5": 4 / 5,
           "21:9": 21 / 9}
RESOLUTIONS = {"source": None, "2160": 2160, "1440": 1440, "1080": 1080, "720": 720}


@dataclass
class FrameSettings:
    classes: set = field(default_factory=lambda: {0})
    conf: float = 0.40
    min_height: float = 0.0        # ignore subjects shorter than this share of the frame height
    mode: str = "all"              # all | largest | central
    border_mode: str = "frame"     # frame | subject
    border: float = 0.10
    smooth: float = 10.0           # 0 = snappy .. 10 = very slow and cinematic (default 10, user's choice)
    anticipate: bool = True        # True: zero-phase (moves slightly ahead); False: reacts after, like a live operator
    max_zoom: float = 0.0          # 0 = unlimited
    hold: float = 3.0              # seconds to hold the framing when nobody is visible
    aspect: str = "source"
    resolution: str = "source"
    pad_before: float = 1.0
    pad_after: float = 2.0
    merge_gap: float = 0.5

    @classmethod
    def from_spec(cls, s: dict) -> "FrameSettings":
        known = cls.__dataclass_fields__
        kw = {k: v for k, v in s.items() if k in known}
        if "classes" in kw:
            kw["classes"] = set(kw["classes"])
        return cls(**kw)


def smooth_sigma(smooth: float) -> float:
    """Slider 0..10 -> Gaussian sigma in seconds (7 ~ 0.7 s, 10 ~ 2.3 s)."""
    return 0.0 if smooth <= 0 else 0.04 * 1.5 ** smooth


def out_geometry(width: int, height: int, fs: FrameSettings) -> tuple[float, int, int]:
    """(aspect w/h, output width, output height) - even sizes."""
    a = ASPECTS.get(fs.aspect) or width / height
    res = RESOLUTIONS.get(fs.resolution)
    if res is None:                           # same as source: keep the source's long side
        if a >= width / height:
            ow = width
            oh = width / a
        else:
            oh = height
            ow = height * a
    else:
        if a >= 1:
            oh, ow = res, res * a
        else:
            ow, oh = res, res / a
    return a, max(2, int(round(ow / 2)) * 2), max(2, int(round(oh / 2)) * 2)


def full_view(width: int, height: int, aspect: float) -> tuple[float, float, float]:
    """Largest window of this aspect inside the frame: (cx, cy, w)."""
    w = width if width / height <= aspect else height * aspect
    w = min(w, width)
    return width / 2, height / 2, w


# ---------------------------------------------------------------- presence
def presence(td: TrackData, fs: FrameSettings) -> np.ndarray:
    return np.array([len(d) > 0 for d in td.filtered(fs.classes, fs.conf, fs.min_height)], bool)


def segments(td: TrackData, fs: FrameSettings) -> list[tuple[float, float]]:
    """Stretches (s) with subjects, padded and merged, within the picture."""
    info = td.info
    vlen = info.video.duration if info.video and info.video.duration else info.duration
    if not len(td.times):
        return []
    dt = 1.0 / td.fps if td.fps > 0 else (td.times[1] - td.times[0] if len(td.times) > 1 else 0.1)
    pres = presence(td, fs)
    raw = []
    for t, p in zip(td.times, pres):
        if not p:
            continue
        s, e = t - fs.pad_before, t + dt + fs.pad_after
        if raw and s <= raw[-1][1] + fs.merge_gap:
            raw[-1][1] = max(raw[-1][1], e)
        else:
            raw.append([s, e])
    out = []
    for s, e in raw:
        s, e = max(0.0, s), min(vlen, e)
        if e - s > 0.05:
            out.append((round(s, 3), round(e, 3)))
    return out


# ------------------------------------------------------------- camera path
def _targets(td: TrackData, fs: FrameSettings, width: int, height: int, aspect: float) -> np.ndarray:
    """Per sample: (cx, cy, w) in source pixels, NaN where nobody is visible."""
    fcx, fcy, fw = full_view(width, height, aspect)
    min_w = max(32.0, fw / fs.max_zoom) if fs.max_zoom and fs.max_zoom > 0 else 32.0
    out = np.full((len(td.times), 3), np.nan)
    for i, d in enumerate(td.filtered(fs.classes, fs.conf, fs.min_height)):
        if not len(d):
            continue
        b = d[:, :4] * np.array([width, height, width, height])
        if fs.mode == "largest":
            k = int(np.argmax((b[:, 2] - b[:, 0]) * (b[:, 3] - b[:, 1])))
            box = b[k]
        elif fs.mode == "central":
            c = np.stack([(b[:, 0] + b[:, 2]) / 2 - width / 2, (b[:, 1] + b[:, 3]) / 2 - height / 2], 1)
            box = b[int(np.argmin((c ** 2).sum(1)))]
        else:
            box = np.array([b[:, 0].min(), b[:, 1].min(), b[:, 2].max(), b[:, 3].max()])
        bw, bh = box[2] - box[0], box[3] - box[1]
        if fs.border_mode == "subject":
            mx, my = fs.border * bw, fs.border * bh
        else:
            mx, my = fs.border * width, fs.border * height
        w = max(bw + 2 * mx, (bh + 2 * my) * aspect, min_w)
        w = min(w, fw)
        h = w / aspect
        cx = min(max((box[0] + box[2]) / 2, w / 2), width - w / 2)
        cy = min(max((box[1] + box[3]) / 2, h / 2), height - h / 2)
        out[i] = (cx, cy, w)
    return out


def _gauss(x: np.ndarray, sigma: float) -> np.ndarray:
    if sigma <= 0.5 or len(x) < 2:
        return x
    r = int(3 * sigma)
    k = np.exp(-0.5 * (np.arange(-r, r + 1) / sigma) ** 2)
    k /= k.sum()
    return np.convolve(np.pad(x, r, mode="edge"), k, mode="valid")


def _causal(x: np.ndarray, sigma: float) -> np.ndarray:
    """Forward-only smoothing (two cascaded exponential filters): reacts after the fact."""
    if sigma <= 0.5 or len(x) < 2:
        return x
    a = 1.0 - np.exp(-1.0 / (0.7 * sigma))
    out = np.asarray(x, float).copy()
    for _ in range(2):
        y = np.empty_like(out)
        acc = out[0]
        for i, v in enumerate(out):
            acc += a * (v - acc)
            y[i] = acc
        out = y
    return out


def camera_path(td: TrackData, fs: FrameSettings, width: int, height: int, frame_times: np.ndarray):
    """Crop windows for these times: arrays (cx, cy, w, h) in source pixels."""
    aspect = ASPECTS.get(fs.aspect) or width / height
    fcx, fcy, fw = full_view(width, height, aspect)
    n = len(frame_times)
    if not len(td.times):
        return np.full(n, fcx), np.full(n, fcy), np.full(n, fw), np.full(n, fw / aspect)
    tg = _targets(td, fs, width, height, aspect)
    # hold the last framing for a while when nobody is visible, then go back to the full view
    last, last_t = None, -1e9
    filled = np.empty_like(tg)
    for i, t in enumerate(td.times):
        if not np.isnan(tg[i, 0]):
            last, last_t = tg[i], t
            filled[i] = tg[i]
        elif last is not None and t - last_t <= fs.hold:
            filled[i] = last
        else:
            filled[i] = (fcx, fcy, fw)
    cx = np.interp(frame_times, td.times, filled[:, 0])
    cy = np.interp(frame_times, td.times, filled[:, 1])
    lw = np.interp(frame_times, td.times, np.log(filled[:, 2]))
    if n > 1:
        step = float(np.median(np.diff(frame_times)))
        sig = smooth_sigma(fs.smooth) / step if step > 0 else 0
        f = _gauss if fs.anticipate else _causal
        cx, cy, lw = f(cx, sig), f(cy, sig), f(lw, sig)
    w = np.minimum(np.exp(lw), fw)
    h = w / aspect
    cx = np.clip(cx, w / 2, width - w / 2)
    cy = np.clip(cy, h / 2, height - h / 2)
    return cx, cy, w, h
