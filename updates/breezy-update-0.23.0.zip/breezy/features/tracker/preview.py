"""Scrub preview: any moment of a video with the detected subjects boxed and the virtual
camera's crop window drawn on top - or the reframed result itself."""
from __future__ import annotations

import subprocess
import sys
import threading
from pathlib import Path
from typing import Optional

import numpy as np
from PySide6.QtCore import QObject, QPointF, QRectF, Qt, QTimer, Signal
from PySide6.QtGui import QColor, QFont, QImage, QPainter, QPen
from PySide6.QtWidgets import (QCheckBox, QHBoxLayout, QLabel, QPushButton, QSizePolicy, QSlider,
                               QVBoxLayout, QWidget)

from breezy.core import theme
from .detector import COCO, TrackData
from .framing import FrameSettings, camera_path, presence

_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
GRAB_W = 1280


def _t(sec: float) -> str:
    m, s = divmod(max(0.0, sec), 60)
    h, m = divmod(int(m), 60)
    return f"{h}:{m:02d}:{s:04.1f}" if h else f"{m}:{s:04.1f}"


class _Grabber(QObject):
    """Grabs one frame at a time in the background; the newest request wins."""
    ready = Signal(int, QImage)

    def __init__(self, ffmpeg_exe: str):
        super().__init__()
        self.exe = ffmpeg_exe
        self._want: Optional[tuple] = None
        self._busy = False
        self._lock = threading.Lock()

    def request(self, token: int, path: Path, t: float, w: int, h: int):
        with self._lock:
            self._want = (token, path, t, w, h)
            if self._busy:
                return
            self._busy = True
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        while True:
            with self._lock:
                job, self._want = self._want, None
                if job is None:
                    self._busy = False
                    return
            token, path, t, w, h = job
            cmd = [self.exe, "-v", "error", "-nostdin", "-ss", f"{max(0.0, t):.3f}", "-i", str(path),
                   "-frames:v", "1", "-an", "-sn", "-vf", f"scale={w}:{h}", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]
            try:
                data = subprocess.run(cmd, capture_output=True, timeout=60, creationflags=_NO_WINDOW).stdout
            except (subprocess.TimeoutExpired, OSError):
                data = b""
            if len(data) >= w * h * 3:
                self.ready.emit(token, QImage(data[:w * h * 3], w, h, w * 3, QImage.Format_RGB888).copy())


class _Player(QObject):
    """Plays from a time at real-time speed (silent, reduced size) and emits each frame."""
    frame = Signal(int, float, QImage)
    ended = Signal(int)
    FPS = 30

    def __init__(self, ffmpeg_exe: str):
        super().__init__()
        self.exe = ffmpeg_exe
        self._stop = threading.Event()
        self._proc = None

    def start(self, token: int, path: Path, t0: float, w: int, h: int, src_fps: float):
        self.stop()
        self._stop = threading.Event()
        fps = min(self.FPS, src_fps or self.FPS)
        threading.Thread(target=self._run, args=(token, path, t0, w, h, fps, self._stop), daemon=True).start()

    def stop(self):
        self._stop.set()
        p = self._proc
        if p is not None:
            try:
                p.kill()
            except Exception:
                pass

    def _run(self, token, path, t0, w, h, fps, stop):
        import time
        cmd = [self.exe, "-v", "error", "-nostdin", "-hwaccel", "auto", "-ss", f"{max(0.0, t0):.3f}", "-i", str(path),
               "-an", "-sn", "-vf", f"fps={fps},scale={w}:{h}", "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]
        try:
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=_NO_WINDOW)
        except OSError:
            self.ended.emit(token)
            return
        self._proc = p
        size, k, start = w * h * 3, 0, None
        try:
            while not stop.is_set():
                buf = p.stdout.read(size)
                if len(buf) < size:
                    break
                if start is None:
                    start = time.monotonic()
                due = start + k / fps
                now = time.monotonic()
                if now < due:
                    time.sleep(due - now)
                if time.monotonic() - due < 1.5 / fps:     # skip frames we're too late for
                    self.frame.emit(token, t0 + k / fps, QImage(buf, w, h, w * 3, QImage.Format_RGB888).copy())
                k += 1
        finally:
            try:
                p.kill()
            except Exception:
                pass
            p.wait()
            if not stop.is_set():
                self.ended.emit(token)


class _Timeline(QWidget):
    """Strip showing where subjects are (filled) and the current position; click/drag to seek."""
    seek = Signal(float)

    def __init__(self):
        super().__init__()
        self.setFixedHeight(16)
        self.duration = 1.0
        self.pos_t = 0.0
        self.times = np.zeros(0)
        self.pres = np.zeros(0, bool)
        self.segs: list = []
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip("Where subjects are found (dark) and what the subjects-only cut keeps (light).\n"
                        "Click or drag to jump.")

    def set_data(self, duration, times, pres, segs):
        self.duration, self.times, self.pres, self.segs = max(duration, 0.01), times, pres, segs
        self.update()

    def set_pos(self, t):
        self.pos_t = t
        self.update()

    def paintEvent(self, _e):
        c = theme.colors()
        p = QPainter(self)
        w, h = self.width(), self.height()
        p.fillRect(0, 0, w, h, QColor(c["panel2"]))
        acc = QColor(c["accent"])
        light = QColor(acc)
        light.setAlpha(70)
        for s, e in self.segs:
            p.fillRect(QRectF(s / self.duration * w, 0, max(1.0, (e - s) / self.duration * w), h), light)
        if len(self.times) > 1:
            dt = self.times[1] - self.times[0]
            for t, on in zip(self.times, self.pres):
                if on:
                    p.fillRect(QRectF(t / self.duration * w, 3, max(1.0, dt / self.duration * w), h - 6), acc)
        x = self.pos_t / self.duration * w
        p.setPen(QPen(QColor(c["text"]), 2))
        p.drawLine(QPointF(x, 0), QPointF(x, h))
        p.end()

    def _emit(self, e):
        self.seek.emit(max(0.0, min(1.0, e.position().x() / max(1, self.width()))) * self.duration)

    def mousePressEvent(self, e):
        self._emit(e)

    def mouseMoveEvent(self, e):
        self._emit(e)


class _View(QWidget):
    def __init__(self):
        super().__init__()
        self.img: Optional[QImage] = None
        self.boxes: list = []       # (x1, y1, x2, y2, label, chosen)  in 0..1
        self.crop = None            # (x, y, w, h) in 0..1
        self.reframed = False
        self.message = "Select a video to preview it."
        self.setMinimumSize(320, 200)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)

    def paintEvent(self, _e):
        c = theme.colors()
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.fillRect(self.rect(), QColor("#0b0d11"))
        if self.img is None:
            p.setPen(QColor(c["muted"]))
            p.drawText(self.rect(), Qt.AlignCenter | Qt.TextWordWrap, self.message)
            p.end()
            return
        iw, ih = self.img.width(), self.img.height()
        if self.reframed and self.crop:
            cx, cy, cw, ch = self.crop
            src = QRectF(cx * iw, cy * ih, cw * iw, ch * ih)
            ar = src.width() / max(1.0, src.height())
        else:
            src = QRectF(0, 0, iw, ih)
            ar = iw / ih
        W, H = self.width(), self.height()
        dw, dh = (W, W / ar) if W / H < ar else (H * ar, H)
        dst = QRectF((W - dw) / 2, (H - dh) / 2, dw, dh)
        p.drawImage(dst, self.img, src)
        if not self.reframed:
            def m(x, y):
                return QPointF(dst.x() + x * dst.width(), dst.y() + y * dst.height())
            if self.crop:   # darken what the camera leaves out
                cx, cy, cw, ch = self.crop
                r = QRectF(m(cx, cy), m(cx + cw, cy + ch))
                shade = QColor(0, 0, 0, 120)
                p.fillRect(QRectF(dst.left(), dst.top(), dst.width(), r.top() - dst.top()), shade)
                p.fillRect(QRectF(dst.left(), r.bottom(), dst.width(), dst.bottom() - r.bottom()), shade)
                p.fillRect(QRectF(dst.left(), r.top(), r.left() - dst.left(), r.height()), shade)
                p.fillRect(QRectF(r.right(), r.top(), dst.right() - r.right(), r.height()), shade)
                p.setPen(QPen(QColor("#facc15"), 2))
                p.drawRect(r)
            f = QFont()
            f.setPixelSize(12)
            f.setBold(True)
            p.setFont(f)
            for x1, y1, x2, y2, label, chosen in self.boxes:
                r = QRectF(m(x1, y1), m(x2, y2))
                col = QColor(c["accent"]) if chosen else QColor(160, 160, 160, 170)
                p.setPen(QPen(col, 2 if chosen else 1, Qt.SolidLine if chosen else Qt.DashLine))
                p.drawRect(r)
                if chosen:
                    tw = p.fontMetrics().horizontalAdvance(label) + 8
                    p.fillRect(QRectF(r.left(), r.top() - 17, tw, 17), col)
                    p.setPen(Qt.white)
                    p.drawText(QRectF(r.left() + 4, r.top() - 17, tw, 17), Qt.AlignVCenter, label)
        p.end()


class ScrubPreview(QWidget):
    def __init__(self, ffmpeg_exe: str, parent=None):
        super().__init__(parent)
        self.td: Optional[TrackData] = None
        self.fs: Optional[FrameSettings] = None
        self._token = 0
        self._img_t = -1.0
        self.path_times = np.zeros(0)
        self.path = None
        self.grabber = _Grabber(ffmpeg_exe)
        self.grabber.ready.connect(self._got)
        self.player = _Player(ffmpeg_exe)
        self.player.frame.connect(self._play_frame)
        self.player.ended.connect(self._play_ended)
        self.playing = False
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        v.setSpacing(6)
        top = QHBoxLayout()
        self.title = QLabel("Preview", objectName="muted")
        self.reframed = QCheckBox("Show the reframed result")
        self.reframed.toggled.connect(self._reframed_toggled)
        self.all_boxes = QCheckBox("Show other detections")
        self.all_boxes.setToolTip("Also outline things that aren't chosen subjects (or are below the confidence)")
        self.all_boxes.toggled.connect(self._update_overlay)
        top.addWidget(self.title, 1)
        top.addWidget(self.all_boxes)
        top.addWidget(self.reframed)
        v.addLayout(top)
        self.view = _View()
        v.addWidget(self.view, 1)
        self.timeline = _Timeline()
        self.timeline.seek.connect(self.set_time)
        v.addWidget(self.timeline)
        row = QHBoxLayout()
        self.play_btn = QPushButton("▶ Play")
        self.play_btn.setToolTip("Play the reframed result (silent, reduced size)")
        self.play_btn.clicked.connect(self.toggle_play)
        self.back = QPushButton("◀ 1 s")
        self.fwd = QPushButton("1 s ▶")
        self.slider = QSlider(Qt.Horizontal)
        self.slider.setRange(0, 0)
        self.slider.valueChanged.connect(lambda v: self.set_time(v / 10, from_slider=True))
        self.time_label = QLabel("0:00.0")
        self.time_label.setMinimumWidth(110)
        self.back.clicked.connect(lambda: self.set_time(self.cur - 1))
        self.fwd.clicked.connect(lambda: self.set_time(self.cur + 1))
        row.addWidget(self.play_btn)
        row.addWidget(self.back)
        row.addWidget(self.slider, 1)
        row.addWidget(self.fwd)
        row.addWidget(self.time_label)
        v.addLayout(row)
        self.cur = 0.0
        self._grab_timer = QTimer(self, singleShot=True, interval=90)
        self._grab_timer.timeout.connect(self._grab)
        self._set_enabled(False)

    def _set_enabled(self, on: bool):
        for w in (self.play_btn, self.back, self.fwd, self.slider, self.reframed, self.all_boxes, self.timeline):
            w.setEnabled(on)

    # ------------------------------------------------------------ api
    def clear(self, message: str = "Select a video to preview it."):
        self.stop()
        self.td = None
        self.view.img, self.view.boxes, self.view.crop = None, [], None
        self.view.message = message
        self.title.setText("Preview")
        self.slider.setRange(0, 0)
        self.timeline.set_data(1, np.zeros(0), np.zeros(0, bool), [])
        self._set_enabled(False)
        self.view.update()

    def show_video(self, td: TrackData, fs: FrameSettings, segs, t: Optional[float] = None):
        same = self.td is not None and self.td.info.path == td.info.path
        if not same:
            self.stop()
        self.td = td
        info = td.info
        self.title.setText(f"<b>{info.path.name}</b>")
        dur = info.video.duration if info.video and info.video.duration else info.duration
        self.dur = dur
        self.slider.blockSignals(True)
        self.slider.setRange(0, int(dur * 10))
        self.slider.blockSignals(False)
        self._set_enabled(True)
        if not same:
            self.view.img = None
            self.view.message = "Loading frame…"
            self._img_t = -1.0
        self.update_settings(fs, segs)
        if t is None:
            t = self.cur if same else self._first_subject(fs)
        self.set_time(t, force=True)

    def update_settings(self, fs: FrameSettings, segs):
        if not self.td:
            return
        self.fs = fs
        v = self.td.info.video
        self.path_times = np.arange(0, max(self.dur, 0.1) + 0.1, 1 / 15)
        self.path = camera_path(self.td, fs, v.width, v.height, self.path_times)
        self.timeline.set_data(self.dur, self.td.times, presence(self.td, fs), segs)
        self._update_overlay()

    def _first_subject(self, fs) -> float:
        pres = presence(self.td, fs)
        idx = np.flatnonzero(pres)
        return float(self.td.times[idx[len(idx) // 2]]) if len(idx) else 0.0

    def set_time(self, t: float, from_slider: bool = False, force: bool = False):
        if not self.td:
            return
        t = max(0.0, min(self.dur, t))
        if abs(t - self.cur) < 1e-4 and not force:
            return
        self.cur = t
        if not from_slider:
            self.slider.blockSignals(True)
            self.slider.setValue(int(round(t * 10)))
            self.slider.blockSignals(False)
        self.time_label.setText(f"{_t(t)} / {_t(self.dur)}")
        self.timeline.set_pos(t)
        self._update_overlay()
        if self.playing:
            self._start_player()         # jump while playing: continue from the new spot
        else:
            self._grab_timer.start()

    def hideEvent(self, e):          # leaving the page stops playback
        self.stop()
        super().hideEvent(e)

    # ------------------------------------------------------- playback
    def _size(self):
        v = self.td.info.video
        w = min(960, v.width) // 2 * 2
        return w, max(2, int(round(w * v.height / v.width / 2)) * 2)

    def _start_player(self):
        self._token += 1
        w, h = self._size()
        self.player.start(self._token, self.td.info.path, self.cur, w, h, float(self.td.info.video.fps or 30))

    def toggle_play(self):
        if self.playing:
            self.stop()
            return
        if not self.td:
            return
        if self.cur >= self.dur - 0.2:
            self.cur = 0.0
        if not self.reframed.isChecked():
            self.reframed.setChecked(True)     # Play shows the reframed result (untick to see the boxes)
        self.playing = True
        self.play_btn.setText("⏸ Pause")
        self._start_player()

    def stop(self):
        if self.playing:
            self.playing = False
            self.player.stop()
            self._token += 1
            self.play_btn.setText("▶ Play")

    def _play_frame(self, token: int, t: float, img: QImage):
        if token != self._token or not self.td:
            return
        self.cur = min(t, self.dur)
        self.slider.blockSignals(True)
        self.slider.setValue(int(round(self.cur * 10)))
        self.slider.blockSignals(False)
        self.time_label.setText(f"{_t(self.cur)} / {_t(self.dur)}")
        self.timeline.set_pos(self.cur)
        self.view.img = img
        self._update_overlay()

    def _play_ended(self, token: int):
        if token == self._token:
            self.stop()

    # ------------------------------------------------------- internals
    def _grab(self):
        if not self.td:
            return
        v = self.td.info.video
        w = min(GRAB_W, v.width) // 2 * 2
        h = max(2, int(round(w * v.height / v.width / 2)) * 2)
        self._token += 1
        self.grabber.request(self._token, self.td.info.path, self.cur, w, h)

    def _got(self, token: int, img: QImage):
        if token != self._token:
            return
        self.view.img = img
        self.view.update()

    def _reframed_toggled(self, on: bool):
        self.view.reframed = on
        self.view.update()

    def _update_overlay(self):
        if not self.td or self.fs is None:
            return
        v = self.td.info.video
        fs = self.fs
        boxes = []
        if len(self.td.times):
            k = int(np.argmin(np.abs(self.td.times - self.cur)))
            d = self.td.dets[k]
            chosen_ids = set()
            for j, row in enumerate(d):
                x1, y1, x2, y2, sc, cl = row
                ok = int(cl) in fs.classes and sc >= fs.conf and (y2 - y1) >= fs.min_height
                if ok:
                    chosen_ids.add(j)
                if ok or self.all_boxes.isChecked():
                    name = COCO[int(cl)] if int(cl) < len(COCO) else str(int(cl))
                    boxes.append((x1, y1, x2, y2, f"{name} {sc:.0%}", ok))
        self.view.boxes = boxes
        if self.path is not None and len(self.path_times):
            i = min(len(self.path_times) - 1, int(round(self.cur * 15)))
            cx, cy, cw, ch = (a[i] for a in self.path)
            self.view.crop = ((cx - cw / 2) / v.width, (cy - ch / 2) / v.height, cw / v.width, ch / v.height)
        self.view.update()
