"""Subject Tracker page: find people (or other subjects), preview the virtual camera, make the outputs."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (QAbstractItemView, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QListWidget,
                               QListWidgetItem, QMessageBox, QPlainTextEdit, QPushButton, QSlider, QSplitter,
                               QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

from breezy.core import theme
from breezy.core.outputs import output_spec
from breezy.core.sync import drift_text, needs_fix
from breezy.core.tasks import Task
from breezy.core.ui import (Card, OutputCard, OutputPicker, SettingsColumn, TaskBar, check, combo,
                            open_in_explorer, spin)
from breezy.features.stitcher.detector import VIDEO_EXTS
from .detector import COCO, COMMON, DEFAULT_MODEL, MODELS, TrackData, available_models
from .framing import FrameSettings, presence, segments
from .preview import ScrubPreview

ROLE = Qt.UserRole
DEFAULT_FOLDER = "Subject Tracker"
ZOOM_UNLIMITED = 11          # slider positions 2..10 = 1.0x..5.0x, 11 = unlimited
BITRATES = [("Automatic", ""), ("64 kbps", "64k"), ("96 kbps", "96k"), ("128 kbps", "128k"),
            ("192 kbps", "192k"), ("320 kbps", "320k")]


def _dur(sec: float) -> str:
    sec = int(round(sec))
    return f"{sec // 3600}:{sec % 3600 // 60:02d}:{sec % 60:02d}"


def _labeled_slider(lo, hi, val, left, right, fmt):
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(0, 0, 0, 0)
    s = QSlider(Qt.Horizontal)
    s.setRange(lo, hi)
    s.setValue(val)
    lab = QLabel(fmt(val))
    lab.setMinimumWidth(64)
    s.valueChanged.connect(lambda v: lab.setText(fmt(v)))
    h.addWidget(QLabel(left, objectName="muted"))
    h.addWidget(s, 1)
    h.addWidget(QLabel(right, objectName="muted"))
    h.addWidget(lab)
    return w, s


class TrackerWidget(QWidget):
    def __init__(self, feature):
        super().__init__()
        self.feature = feature
        self.ctx = feature.context
        self.ff = self.ctx.ffmpeg
        self.tm = self.ctx.tasks
        self.files: list[Path] = []
        self.extra_files: list[Path] = []
        self.tracks: dict[Path, TrackData] = {}
        self.unchecked: set[Path] = set()
        self.analyze_task_id = None
        self._ticked_anyway: set[Path] = set()
        self._build()
        self._akey_now = self._akey()
        self.tm.finished.connect(self._task_finished)
        self._update_buttons()
        self._install_tools()

    # ================================================================ layout

    def _build(self):
        st = self.feature.setting
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(14)

        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.setSpacing(8)
        src = Card()
        top = QHBoxLayout()
        self.folder_edit = QLineEdit(st("last_folder", ""))
        self.folder_edit.setPlaceholderText("Folder of videos…")
        self.folder_edit.editingFinished.connect(self._gather_and_list)
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse_folder)
        self.recursive = check("Include subfolders", st("recursive", False))
        self.use_out = QPushButton("Use output from…")
        self.use_out.setToolTip("Add files made by any module - or queue tracking of a task's output "
                                "that hasn't finished yet")
        self.use_out.clicked.connect(self._use_output)
        self.find_btn = QPushButton("Find subjects", objectName="primary")
        self.find_btn.setToolTip("Look for subjects so you can check the framing in the preview.\n"
                                 "(Optional - 'Make' finds them by itself.)")
        self.find_btn.clicked.connect(self.find_all)
        top.addWidget(QLabel("Folder:"))
        top.addWidget(self.folder_edit, 1)
        top.addWidget(browse)
        add_files = QPushButton("Add files…")
        add_files.setToolTip("Choose one or more video files (they're added to the list)")
        add_files.clicked.connect(self._add_files)
        top.addWidget(add_files)
        clear_files = QPushButton("Clear")
        clear_files.setToolTip("Empty the list (folder and added files)")
        clear_files.clicked.connect(self._clear_files)
        top.addWidget(clear_files)
        top.addWidget(self.recursive)
        top.addWidget(self.use_out)
        top.addWidget(self.find_btn)
        src.v.addLayout(top)
        self.extra_label = QLabel("", objectName="muted")
        src.v.addWidget(self.extra_label)
        lv.addWidget(src)

        self.tree = QTreeWidget()
        self.tree.setColumnCount(5)
        self.tree.setHeaderLabels(["Video", "Length", "With subjects", "Most at once", "Details"])
        self.tree.setSelectionMode(QAbstractItemView.SingleSelection)
        self.tree.setAlternatingRowColors(True)
        h = self.tree.header()
        h.resizeSection(0, 300)
        for c, w in ((1, 70), (2, 110), (3, 95)):
            h.resizeSection(c, w)
        h.setStretchLastSection(True)
        self.tree.itemChanged.connect(self._item_changed)
        self.tree.currentItemChanged.connect(self._current_changed)
        self.preview = ScrubPreview(self.ff.ffmpeg if self.ff else "ffmpeg")
        hsplit = QSplitter(Qt.Horizontal)
        hsplit.addWidget(self.tree)
        hsplit.addWidget(self.preview)
        hsplit.setStretchFactor(0, 2)
        hsplit.setStretchFactor(1, 3)
        hsplit.setSizes([440, 620])
        self.log = QPlainTextEdit(readOnly=True)
        self.log.setMaximumBlockCount(2000)
        self.log.setPlaceholderText("Messages")
        split = QSplitter(Qt.Vertical)
        split.addWidget(hsplit)
        split.addWidget(self.log)
        split.setSizes([560, 90])
        lv.addWidget(split, 1)

        run = Card()
        rh = QHBoxLayout()
        self.taskbar = TaskBar(self.tm, "tracker")
        self.taskbar.hide()                 # progress is shown in the bar at the bottom and on the Tasks page
        rh.addStretch(1)
        self.open_btn = QPushButton("Open output folder")
        self.open_btn.clicked.connect(self._open_output)
        self.make_btn = QPushButton("Make selected", objectName="primary")
        self.make_btn.clicked.connect(self.make)
        rh.addWidget(self.open_btn)
        rh.addWidget(self.make_btn)
        run.v.addLayout(rh)
        lv.addWidget(run)
        root.addWidget(left, 1)

        # ---------- right: every setting visible
        col = SettingsColumn(400)
        d = col.add(Card("Detection"))
        models = available_models() or list(MODELS)
        self.model = d.row("Detector:", combo([(MODELS[m], m) for m in models],
                                              st("model", DEFAULT_MODEL if DEFAULT_MODEL in models else models[0])),
                           "Accurate finds more (small, far, partly hidden subjects) but is slower")
        self.det_fps = d.row("Look for subjects:", combo([("2 times per second", 2.0), ("5 times per second", 5.0),
                                                          ("10 times per second", 10.0), ("15 times per second", 15.0),
                                                          ("Every frame (slowest)", 0.0)], float(st("det_fps", 5.0))),
                             "More often follows fast movement better; the smooth camera fills in between")
        self.det_gpu = d.full(check("Use the graphics card for detection", st("det_gpu", True)))
        self.hwaccel = d.full(check("Use the graphics card to decode video", st("hwaccel", True)))
        self.det_workers = d.row("Videos analyzed at once:", spin(1, 8, int(st("det_workers", 1))),
                                 "More than 1 helps mainly when detection runs on the processor")
        d.note("Changing the detector or how often it looks means looking again. Everything below "
               "updates instantly.")
        self.classes = QListWidget()
        self.classes.setFixedHeight(150)
        chosen = set(st("classes", [0]))
        order = [COCO.index(n) for n in COMMON] + [i for i in range(len(COCO)) if COCO[i] not in COMMON]
        for i in order:
            it = QListWidgetItem(COCO[i].capitalize() if i else "People")
            it.setData(ROLE, i)
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(Qt.Checked if i in chosen else Qt.Unchecked)
            self.classes.addItem(it)
        self.classes.itemChanged.connect(self._settings_changed)
        d.row("Subjects:", self.classes, "What to follow. Common ones are at the top")
        self.conf = d.row("Confidence at least:", spin(5, 95, int(st("conf", 40)), " %", step=5),
                          "How sure the detector must be. Lower catches more, but with more false hits")
        self.min_h = d.row("Ignore subjects smaller than:", spin(0, 90, int(st("min_height", 0)), " % of height", step=1),
                           "Skip tiny, far-away subjects. 0 = keep all")

        f = col.add(Card("Framing", "How the virtual camera follows the subjects"))
        self.mode = f.row("With several subjects:", combo([("Fit them all", "all"), ("Follow the largest", "largest"),
                                                           ("Follow the most central", "central")], st("mode", "all")))
        self.border_mode = f.row("Border measured as:", combo([("% of the frame", "frame"),
                                                               ("% of the subject's size", "subject")],
                                                              st("border_mode", "frame")))
        self.border = f.row("Border around subjects:", spin(0, 100, int(st("border", 10)), " %", step=1))
        sw, self.smooth = _labeled_slider(0, 10, int(st("smooth", 10)), "snappy", "cinematic", lambda v: str(v))
        f.row("Smoothness:", sw, "How gently the camera moves and zooms")
        self.anticipate = f.row("Camera timing:", combo([("Anticipate (smoothest)", True),
                                                         ("React after they move (like a live operator)", False)],
                                                        st("anticipate", True)),
                                "Anticipate: the camera has seen the whole video, so it starts moving a moment\n"
                                "before the subject does. React: it follows only after they move")
        zw, self.zoom = _labeled_slider(2, ZOOM_UNLIMITED, int(st("zoom_pos", ZOOM_UNLIMITED)), "1×", "∞",
                                        lambda v: "Unlimited" if v >= ZOOM_UNLIMITED else f"{v / 2:.1f}×")
        f.row("Max zoom:", zw, "How far the camera may zoom in")
        self.hold = f.row("When nobody is visible:", spin(0, 60, float(st("hold", 3.0)), " s hold", 1, 0.5),
                          "Keep the last framing this long, then ease back out to the full picture")
        self.aspect = f.row("Shape:", combo([("Same as source", "source"), ("16:9 wide", "16:9"),
                                             ("9:16 vertical (phone)", "9:16"), ("1:1 square", "1:1"),
                                             ("4:3", "4:3"), ("4:5 portrait", "4:5"), ("21:9 cinema", "21:9")],
                                            st("aspect", "source")))
        self.resolution = f.row("Resolution:", combo([("Same as source", "source"), ("2160p (4K)", "2160"),
                                                      ("1440p", "1440"), ("1080p", "1080"), ("720p", "720")],
                                                     st("resolution", "source")),
                                "Height of the reframed video (width for vertical shapes)")

        o = col.add(Card("Make", "What 'Make selected' produces for each video"))
        self.out_reframe = o.full(check("Reframed video (camera follows the subjects)", st("out_reframe", True)))
        self.out_cut = o.full(check("Only the parts with subjects", st("out_cut_v2", True)))
        self.out_csv = o.full(check("List of times with subjects (.csv)", st("out_csv", False)))
        self.combine = o.row("When both videos are ticked:", combo([("One combined file", True),
                                                                    ("Two separate files", False)], st("combine", True)),
                             "Combined = reframed AND cut to the parts with subjects.\n"
                             "Separate = a reframed full-length video + a losslessly cut original")
        self.no_subjects = o.row("Videos with nobody in them:", combo([("Skip them", "skip"),
                                                                        ("Copy them unchanged", "copy")],
                                                                       st("no_subjects", "skip")))
        self.pad_before = o.row("Keep before subjects appear:", spin(0, 60, float(st("pad_before", 1.0)), " s", 1, 0.5))
        self.pad_after = o.row("Keep after they leave:", spin(0, 60, float(st("pad_after", 2.0)), " s", 1, 0.5))
        self.merge = o.row("Merge gaps shorter than:", spin(0, 600, float(st("merge_gap", 0.5)), " s", 1, 0.5))

        e = col.add(Card("Encoding"))
        self.codec = e.row("Video format:", combo([("Same as source", "same"), ("H.264 - plays everywhere", "h264"),
                                                   ("H.265 - smaller files", "hevc")], st("codec", "same")))
        self.crf = e.row("Quality:", spin(0, 40, int(st("crf", 16)), " CRF"),
                         "Lower = better quality, bigger file. 16 looks identical to the original")
        self.enc_gpu = e.row("Encoder:", combo([("Graphics card (faster)", True), ("Processor", False)],
                                               st("enc_gpu", True)))
        self.edge_gpu = e.row("Lossless cut edges:", combo([("Processor (most compatible)", False),
                                                            ("Graphics card (faster)", True)], st("edge_gpu", False)),
                              "For 'Only the parts with subjects' as a separate file: only the frames\n"
                              "at each cut are re-encoded")

        a = col.add(Card("Sound"))
        self.fix_drift = a.full(check("Fix audio drift (match the sound to the picture)", st("fix_drift", True)))
        self.drift_thr = a.row("Count as drifting from:", spin(0.01, 5.0, float(st("drift_threshold", 0.1)), " s",
                                                               decimals=2, step=0.05))
        self.exact_audio = a.full(check("Exact sound cuts in the lossless cut", st("exact_audio", True)))
        self.abr = a.row("Re-encoded sound bitrate:", combo(BITRATES, st("audio_bitrate", "")))
        self.fix_drift.toggled.connect(self._rebuild_tree)
        self.drift_thr.valueChanged.connect(self._rebuild_tree)

        self.out = col.add(OutputCard(self.feature, DEFAULT_FOLDER,
                                      [("name_tracked", "Reframed file name:", "{name}_tracked"),
                                       ("name_subjects", "Cut / list file name:", "{name}_subjects")]))
        root.addWidget(col)

        for w in (self.conf, self.min_h, self.border, self.smooth, self.zoom, self.hold, self.pad_before,
                  self.pad_after, self.merge):
            w.valueChanged.connect(self._settings_changed)
        for w in (self.mode, self.border_mode, self.aspect, self.resolution, self.anticipate):
            w.currentIndexChanged.connect(self._settings_changed)
        for w in (self.out_reframe, self.out_cut, self.out_csv):
            w.toggled.connect(self._outputs_changed)
        self.model.currentIndexChanged.connect(self._analysis_changed)
        self.det_fps.currentIndexChanged.connect(self._analysis_changed)
        self._recalc_timer = QTimer(self, singleShot=True, interval=200)
        self._recalc_timer.timeout.connect(self._recalc)
        self._outputs_changed()

    # ============================================================== helpers
    def _say(self, msg: str):
        self.log.appendPlainText(msg)

    def _classes(self) -> list[int]:
        return [self.classes.item(i).data(ROLE) for i in range(self.classes.count())
                if self.classes.item(i).checkState() == Qt.Checked]

    def _settings(self) -> dict:
        z = self.zoom.value()
        return {"classes": self._classes(), "conf": self.conf.value() / 100, "min_height": self.min_h.value() / 100,
                "mode": self.mode.currentData(), "anticipate": self.anticipate.currentData(),
                "no_subjects": self.no_subjects.currentData(), "det_workers": self.det_workers.value(), "border_mode": self.border_mode.currentData(),
                "border": self.border.value() / 100, "smooth": float(self.smooth.value()),
                "max_zoom": 0.0 if z >= ZOOM_UNLIMITED else z / 2, "hold": self.hold.value(),
                "aspect": self.aspect.currentData(), "resolution": self.resolution.currentData(),
                "pad_before": self.pad_before.value(), "pad_after": self.pad_after.value(),
                "merge_gap": self.merge.value(), "model": self.model.currentData(),
                "det_fps": self.det_fps.currentData(), "det_gpu": self.det_gpu.isChecked(),
                "hwaccel": self.hwaccel.isChecked(), "out_reframe": self.out_reframe.isChecked(),
                "out_cut": self.out_cut.isChecked(), "out_csv": self.out_csv.isChecked(),
                "combine": self.combine.currentData(), "codec": self.codec.currentData(), "crf": self.crf.value(),
                "enc_gpu": self.enc_gpu.currentData(), "edge_gpu": self.edge_gpu.currentData(),
                "fix_drift": self.fix_drift.isChecked(), "drift_threshold": self.drift_thr.value(),
                "exact_audio": self.exact_audio.isChecked(), "audio_bitrate": self.abr.currentData(),
                "name_tracked": self.out.pattern("name_tracked"), "name_subjects": self.out.pattern("name_subjects")}

    def _save_settings(self):
        f = self.feature
        f.set_setting("last_folder", self.folder_edit.text().strip())
        f.set_setting("recursive", self.recursive.isChecked())
        s = self._settings()
        for k, v in s.items():
            if k in ("name_tracked", "name_subjects", "max_zoom"):
                continue
            if k in ("conf", "min_height", "border"):
                v = round(v * 100)
            f.set_setting("out_cut_v2" if k == "out_cut" else k, v)
        f.set_setting("zoom_pos", self.zoom.value())

    def _fs(self) -> FrameSettings:
        return FrameSettings.from_spec(self._settings())

    def _akey(self):
        return (self.model.currentData(), self.det_fps.currentData())

    def _busy(self) -> bool:
        t = self.tm.get(self.analyze_task_id) if self.analyze_task_id else None
        return bool(t and t.status in ("queued", "running", "paused"))

    def _update_buttons(self):
        self.find_btn.setEnabled(not self._busy())
        anything = self.out_reframe.isChecked() or self.out_cut.isChecked() or self.out_csv.isChecked()
        self.make_btn.setEnabled(anything and bool(self._selected()) and bool(self._classes()))
        self.open_btn.setEnabled(True)
        n = len(self.extra_files)
        self.extra_label.setText(f"+ {n} added file(s)" if n else "")
        self.extra_label.setVisible(bool(n))

    def _outputs_changed(self, *_):
        both = self.out_reframe.isChecked() and self.out_cut.isChecked()
        self.combine.setEnabled(both)
        cut = self.out_cut.isChecked() or self.out_csv.isChecked()
        for w in (self.pad_before, self.pad_after, self.merge):
            w.setEnabled(cut)
        self._save_settings()
        self._update_buttons()

    def _browse_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Folder of videos", self.folder_edit.text())
        if d:
            self.folder_edit.setText(d)
            self._gather_and_list()

    def _open_output(self):
        from breezy.core.ui import open_module_output
        open_module_output(self, self.tm, "tracker", self.out, self.files[0] if self.files else None)

    def _selected(self) -> list[Path]:
        return [p for p in self.files if p not in self.unchecked]

    # ======================================================= output linking
    def _add_files(self):
        from breezy.core.ui import pick_videos
        files = pick_videos(self, self.folder_edit.text().strip())
        if files:
            self._add_paths(files)

    def _clear_files(self):
        self.folder_edit.setText("")
        self.extra_files = []
        self.removed = set()
        self._gather_and_list()
        self._update_buttons()

    # ------------------------------------------------------------ drag & drop, list menu
    def _install_tools(self):
        from breezy.core.ui import install_drop, install_list_tools
        install_drop(self, self._drop_folder, self._add_paths)
        install_list_tools(self.tree, self._path_of_item, self._remove_paths, self._gather_and_list)

    def _path_of_item(self, it):
        d = it.data(0, ROLE) if it else None
        return Path(d) if isinstance(d, str) else None

    def _drop_folder(self, d):
        self.folder_edit.setText(str(d))
        self._gather_and_list()

    def _add_paths(self, files):
        self.extra_files += [f for f in files if f not in self.extra_files]
        self.removed = getattr(self, "removed", set()) - set(files)
        self._gather_and_list()
        self._say(f"Added {len(files)} file(s).")
        self._update_buttons()

    def _remove_paths(self, paths):
        self.removed = getattr(self, "removed", set()) | set(paths)
        self.extra_files = [f for f in self.extra_files if f not in paths]
        self._gather_and_list()
        self._say(f"Removed {len(paths)} file(s) from the list (nothing is deleted).")
        self._update_buttons()

    def reload_settings(self):
        from breezy.core.ui import reload_from
        reload_from(self.feature, {"model": self.model, "det_fps": self.det_fps, "smooth": self.smooth,
                                   "crf": self.crf, "det_gpu": self.det_gpu, "enc_gpu": self.enc_gpu,
                                   "hwaccel": self.hwaccel})

    def _use_output(self):
        dlg = OutputPicker(self.tm, self, "tracker")
        if not dlg.exec():
            return
        files, future = dlg.selection()
        if files:
            self.extra_files += [Path(f) for f in files if Path(f) not in self.extra_files]
            self._gather_and_list()
            self._say(f"Added {len(files)} file(s).")
        for tid in future:
            self._queue_auto(tid)
        self._update_buttons()

    def _queue_auto(self, task_id: str):
        out = output_spec(self.ctx.settings, "tracker", DEFAULT_FOLDER, self, self.out.values())
        if out is None:
            return
        src = self.tm.get(task_id)
        name = src.title if src else task_id
        t = Task("tracker.auto", "tracker", f"Track subjects in output of '{name}'",
                 spec=dict(self._settings(), output=out), input_from=task_id)
        self.tm.submit(t)
        self._say(f"Queued: track subjects in the files from '{name}' when it finishes (current settings).")

    # ============================================================ files
    def _gather_files(self) -> list[Path]:
        text = self.folder_edit.text().strip()
        folder = Path(text) if text else None
        files = []
        if folder and folder.is_dir():
            it = folder.rglob("*") if self.recursive.isChecked() else folder.glob("*")
            skip = {self.out.values()["folder"].lower(), "breezy output"}
            tails = []
            for key in ("name_tracked", "name_subjects"):
                pat = self.out.pattern(key)
                if pat.startswith("{name}") and pat != "{name}":
                    tails.append(pat.split("{name}", 1)[1])
            files = sorted(p for p in it if p.is_file() and p.suffix.lower() in VIDEO_EXTS
                           and not (set(x.lower() for x in p.relative_to(folder).parts[:-1]) & skip)
                           and not any(p.stem.endswith(t) for t in tails))
        removed = getattr(self, "removed", set())
        return [p for p in files if p not in removed] + \
            [p for p in self.extra_files if p not in files and p.is_file() and p not in removed]

    def _gather_and_list(self):
        self.files = self._gather_files()
        self._rebuild_tree()

    def find_all(self):
        if not self.ff.available:
            QMessageBox.warning(self, "Subject Tracker", "FFmpeg was not found. See the Settings page.")
            return
        if not available_models():
            QMessageBox.warning(self, "Subject Tracker", "The detection models are missing from this install.")
            return
        text = self.folder_edit.text().strip()
        if text and not Path(text).is_dir():
            QMessageBox.warning(self, "Subject Tracker", "That folder doesn't exist.")
            return
        self.files = self._gather_files()
        if not self.files:
            QMessageBox.information(self, "Subject Tracker",
                                    "No videos found. Choose a folder, or add files with 'Use output from…'.")
            return
        self._save_settings()
        if self._akey() != self._akey_now:
            self.tracks.clear()
            self._akey_now = self._akey()
        todo = [p for p in self.files if p not in self.tracks]
        if not todo:
            self._rebuild_tree()
            self._say("All videos are already checked.")
            return
        name = Path(text).name if text else f"{len(todo)} file(s)"
        t = self.tm.submit(Task("tracker.analyze", "tracker", f"Find subjects in {name}",
                                spec=dict(self._settings(), files=[str(p) for p in todo]), resumable=False))
        self.analyze_task_id = t.id
        self.taskbar.follow(t.id)
        self._say(f"Looking for subjects in {len(todo)} video(s)…")
        self._rebuild_tree()

    def _task_finished(self, task_id: str):
        t = self.tm.get(task_id)
        if not t or t.module != "tracker":
            return
        if task_id == self.analyze_task_id:
            res = self.tm.results.pop(task_id, None)
            if res:
                self.tracks.update({Path(k): v for k, v in res.items()})
                found = sum(1 for p, td in self.tracks.items() if not td.error and presence(td, self._fs()).any())
                self._say(f"Done: subjects found in {found} of {len(res)} video(s).")
            elif t.status != "done":
                self._say(f"Finding subjects {t.status}: {t.message}")
            self._rebuild_tree()
        elif t.kind in ("tracker.make", "tracker.auto"):
            msg = f"{t.title}: {len(t.outputs)} file(s) made"
            if t.errors:
                msg += f"; {len(t.errors)} failed: " + "; ".join(t.errors[:5])
            if t.status == "cancelled":
                msg += " - cancelled"
            self._say(msg)
            self.feature.set_setting("last_outputs", list(t.outputs))
        self._update_buttons()

    def _settings_changed(self, *_):
        self._recalc_timer.start()

    def _analysis_changed(self):
        self._save_settings()
        if self.tracks and self._akey() != self._akey_now:
            self._say("Detector settings changed - press 'Find subjects' to look again with them.")

    def _recalc(self):
        self._save_settings()
        self._rebuild_tree(keep_preview=True)
        cur = self._current_path()
        if cur and cur in self.tracks and not self.tracks[cur].error:
            fs = self._fs()
            self.preview.update_settings(fs, segments(self.tracks[cur], fs))
        self._update_buttons()

    # ================================================================= tree
    def _current_path(self):
        it = self.tree.currentItem()
        d = it.data(0, ROLE) if it else None
        return Path(d) if isinstance(d, str) else None

    def _rebuild_tree(self, *_, keep_preview: bool = False):
        c = theme.colors()
        fs = self._fs()
        cur = self._current_path()
        thr, fix = self.drift_thr.value(), self.fix_drift.isChecked()
        self.tree.blockSignals(True)
        self.tree.clear()
        found, none, failed, pending = [], [], [], []
        for p in self.files:
            td = self.tracks.get(p)
            if td is None:
                pending.append(p)
            elif td.error:
                failed.append(p)
            elif presence(td, fs).any():
                found.append(p)
            else:
                none.append(p)
        select = None
        for p in found:
            td = self.tracks[p]
            info = td.info
            pres = presence(td, fs)
            filt = td.filtered(fs.classes, fs.conf, fs.min_height)
            segs = segments(td, fs)
            it = QTreeWidgetItem(self.tree)
            it.setData(0, ROLE, str(p))
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(0, Qt.Unchecked if p in self.unchecked else Qt.Checked)
            it.setText(0, p.name)
            it.setToolTip(0, str(p))
            it.setText(1, _dur(info.duration))
            it.setText(2, f"{pres.mean():.0%} of the time")
            it.setText(3, str(max(len(d) for d in filt)))
            kept = sum(e - s for s, e in segs)
            note = f"{len(segs)} stretch(es), {_dur(kept)} with padding"
            if needs_fix(info, thr):
                note = f"{drift_text(info) or 'sound drifts'} ({'will be fixed' if fix else 'NOT fixed'}); " + note
                it.setForeground(4, QBrush(QColor(c["warn"])))
            it.setText(4, note)
            fnt = it.font(0)
            fnt.setBold(True)
            it.setFont(0, fnt)
            if p == cur:
                select = it
        groups = (("No subjects found at these settings", none, c["muted"], True),
                  ("Could not read", failed, c["warn"], False),
                  ("Looking…" if self._busy() else "Not checked yet - 'Find subjects' to preview",
                   pending, c["muted"], True))
        for title, items, color, tickable in groups:
            if not items:
                continue
            top = QTreeWidgetItem(self.tree)
            top.setText(0, f"{title} ({len(items)})")
            top.setForeground(0, QBrush(QColor(color)))
            top.setFlags(Qt.ItemIsEnabled)
            for p in items:
                ch = QTreeWidgetItem(top)
                ch.setData(0, ROLE, str(p))
                ch.setText(0, p.name)
                ch.setToolTip(0, str(p))
                if tickable:
                    ch.setFlags(ch.flags() | Qt.ItemIsUserCheckable)
                    default_off = items is none
                    off = p in self.unchecked or (default_off and p not in self._ticked_anyway)
                    ch.setCheckState(0, Qt.Unchecked if off else Qt.Checked)
                    if default_off and p not in self._ticked_anyway:
                        self.unchecked.add(p)
                else:
                    ch.setFlags(Qt.ItemIsEnabled)
                    self.unchecked.add(p)
                td = self.tracks.get(p)
                if td:
                    ch.setText(1, _dur(td.info.duration))
                    if td.error:
                        ch.setText(4, td.error)
                if p == cur:
                    select = ch
            top.setExpanded(len(items) <= 30)
        self.tree.blockSignals(False)
        if select is not None:
            self.tree.blockSignals(True)
            self.tree.setCurrentItem(select)
            self.tree.blockSignals(False)
        elif not keep_preview:
            self.preview.clear()
        self._update_buttons()

    def theme_changed(self):
        self._rebuild_tree(keep_preview=True)
        self.preview.update()

    def _current_changed(self, item, _prev=None):
        p = self._current_path()
        if not p:
            return
        td = self.tracks.get(p)
        if td is None:
            self.preview.clear("Press 'Find subjects' to preview this video.")
        elif td.error:
            self.preview.clear(f"Can't preview: {td.error}")
        else:
            fs = self._fs()
            self.preview.show_video(td, fs, segments(td, fs))

    def _item_changed(self, item: QTreeWidgetItem, _col: int):
        key = item.data(0, ROLE)
        if not isinstance(key, str):
            return
        p = Path(key)
        if item.checkState(0) == Qt.Checked:
            self.unchecked.discard(p)
            self._ticked_anyway.add(p)
        else:
            self.unchecked.add(p)
            self._ticked_anyway.discard(p)
        self._update_buttons()

    # ================================================================= make
    def make(self):
        self.files = self._gather_files()
        self._rebuild_tree(keep_preview=True)
        sel = self._selected()
        if not sel:
            return
        if not available_models():
            QMessageBox.warning(self, "Subject Tracker", "The detection models are missing from this install.")
            return
        out = output_spec(self.ctx.settings, "tracker", DEFAULT_FOLDER, self, self.out.values())
        if out is None:
            return
        self._save_settings()
        self.preview.stop()
        title = f"Track subjects in {len(sel)} video(s)" if len(sel) > 1 else f"Track subjects in {sel[0].name}"
        t = self.tm.submit(Task("tracker.make", "tracker", title,
                                spec=dict(self._settings(), files=[str(p) for p in sel], output=out)))
        self.taskbar.follow(t.id)
        self._say(f"Queued: {title}.")
        self._update_buttons()
