"""Find people (or other chosen subjects) in a video with YOLOv10 running on ONNX Runtime.

Detection runs a few times per second on a downscaled copy of the picture. Every detection
above a low floor is kept (with its class and score) and cached on disk, so changing the
subjects, the confidence or the framing afterwards is instant - no re-analysis.
"""
from __future__ import annotations

import hashlib
import subprocess
import sys
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import numpy as np

from breezy.core import proc
from breezy.core.ffmpeg import Cancelled, FFmpeg, MediaInfo

COCO = ["person", "bicycle", "car", "motorcycle", "airplane", "bus", "train", "truck", "boat",
        "traffic light", "fire hydrant", "stop sign", "parking meter", "bench", "bird", "cat", "dog",
        "horse", "sheep", "cow", "elephant", "bear", "zebra", "giraffe", "backpack", "umbrella",
        "handbag", "tie", "suitcase", "frisbee", "skis", "snowboard", "sports ball", "kite",
        "baseball bat", "baseball glove", "skateboard", "surfboard", "tennis racket", "bottle",
        "wine glass", "cup", "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange",
        "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "couch", "potted plant",
        "bed", "dining table", "toilet", "tv", "laptop", "mouse", "remote", "keyboard", "cell phone",
        "microwave", "oven", "toaster", "sink", "refrigerator", "book", "clock", "vase", "scissors",
        "teddy bear", "hair drier", "toothbrush"]
# shown first in the subject list
COMMON = ["person", "dog", "cat", "bird", "horse", "car", "bicycle", "motorcycle", "truck", "bus",
          "boat", "sports ball", "cow", "sheep", "bear"]

MODELS = {"n": "Fast (YOLOv10-N)", "s": "Balanced (YOLOv10-S)", "m": "Accurate (YOLOv10-M)"}
DEFAULT_MODEL = "m"
INPUT = 640
FLOOR = 0.10            # detections below this score are not stored
CACHE_VERSION = 1


def models_dir() -> Path:
    base = Path(getattr(sys, "_MEIPASS", Path(__file__).resolve().parents[2]))
    return base / "breezy" / "models" if (base / "breezy" / "models").is_dir() else base / "models"


def model_path(size: str) -> Path:
    return models_dir() / f"yolov10{size}.onnx"


def available_models() -> list[str]:
    return [m for m in MODELS if model_path(m).is_file()]


# ------------------------------------------------------------------ detector
_sessions: dict = {}
_lock = threading.Lock()


def provider_used(size: str, use_gpu: bool) -> str:
    s = _session(size, use_gpu)
    return s.get_providers()[0] if s else "none"


def _session(size: str, use_gpu: bool):
    import onnxruntime as ort
    from breezy.core.encoders import onnx_providers, provider_args
    key = (size, use_gpu)
    with _lock:
        if key not in _sessions:
            opts = ort.SessionOptions()
            opts.log_severity_level = 3
            opts.add_session_config_entry("session.set_denormal_as_zero", "1")   # tiny numbers can be 40x slower
            provs = onnx_providers(use_gpu)
            if "DmlExecutionProvider" in provs:          # DirectML requirements
                opts.enable_mem_pattern = False
                opts.execution_mode = ort.ExecutionMode.ORT_SEQUENTIAL
            try:
                _sessions[key] = ort.InferenceSession(str(model_path(size)), opts, providers=provider_args(provs))
            except Exception:
                if provs == ["CPUExecutionProvider"]:
                    raise
                _sessions[key] = ort.InferenceSession(str(model_path(size)), opts,
                                                      providers=["CPUExecutionProvider"])
        return _sessions[key]


class Detector:
    def __init__(self, size: str = DEFAULT_MODEL, use_gpu: bool = True):
        if not model_path(size).is_file():
            raise RuntimeError(f"Detection model {MODELS.get(size, size)} is missing ({model_path(size).name})")
        self.session = _session(size, use_gpu)
        self.inp = self.session.get_inputs()[0].name

    def detect(self, rgb: np.ndarray) -> np.ndarray:
        """rgb: HxWx3 uint8. Returns (k, 6) float32: x1, y1, x2, y2 (0..1 of the frame), score, class."""
        h, w = rgb.shape[:2]
        s = INPUT / max(h, w)
        nh, nw = int(round(h * s)), int(round(w * s))
        if (nh, nw) != (h, w):
            import cv2
            rgb = cv2.resize(rgb, (nw, nh), interpolation=cv2.INTER_AREA)
        top, left = (INPUT - nh) // 2, (INPUT - nw) // 2
        canvas = np.full((INPUT, INPUT, 3), 114, np.uint8)
        canvas[top:top + nh, left:left + nw] = rgb
        x = canvas.transpose(2, 0, 1)[None].astype(np.float32) / 255.0
        out = self.session.run(None, {self.inp: x})[0][0]          # (300, 6)
        out = out[out[:, 4] >= FLOOR]
        if not len(out):
            return np.zeros((0, 6), np.float32)
        d = out.astype(np.float32).copy()
        d[:, [0, 2]] = np.clip((d[:, [0, 2]] - left) / nw, 0, 1)
        d[:, [1, 3]] = np.clip((d[:, [1, 3]] - top) / nh, 0, 1)
        return d


# ------------------------------------------------------------------ results
@dataclass
class TrackData:
    info: MediaInfo
    times: np.ndarray                         # sample times (s)
    dets: list = field(default_factory=list)  # per sample: (k, 6) array
    fps: float = 5.0
    model: str = DEFAULT_MODEL
    error: str = ""

    def filtered(self, classes: set[int], conf: float, min_height: float = 0.0) -> list[np.ndarray]:
        cl = np.array(sorted(classes)) if classes else np.zeros(0)
        out = []
        for d in self.dets:
            if len(d):
                keep = (d[:, 4] >= conf) & np.isin(d[:, 5].astype(int), cl)
                if min_height > 0:
                    keep &= (d[:, 3] - d[:, 1]) >= min_height
                d = d[keep]
            out.append(d)
        return out


def _cache_file(cache_dir: Path, info: MediaInfo, fps: float, model: str) -> Path:
    key = f"{info.path}|{info.size}|{int(info.mtime)}|{fps}|{model}|v{CACHE_VERSION}"
    return Path(cache_dir) / (hashlib.sha1(key.encode()).hexdigest() + ".npz")


def load_cached(info: MediaInfo, fps: float, model: str, cache_dir) -> Optional[TrackData]:
    cf = _cache_file(cache_dir, info, fps, model) if cache_dir else None
    if not (cf and cf.is_file()):
        return None
    try:
        z = np.load(cf)
        counts = z["counts"]
        flat = z["dets"]
        idx = np.concatenate([[0], np.cumsum(counts)])
        dets = [flat[idx[i]:idx[i + 1]] for i in range(len(counts))]
        return TrackData(info, z["times"], dets, fps, model)
    except Exception:
        return None


def _save_cache(td: TrackData, cache_dir):
    cf = _cache_file(cache_dir, td.info, td.fps, td.model)
    try:
        cf.parent.mkdir(parents=True, exist_ok=True)
        counts = np.array([len(d) for d in td.dets], np.int32)
        flat = np.concatenate(td.dets) if td.dets else np.zeros((0, 6), np.float32)
        np.savez(cf, times=td.times, counts=counts, dets=flat.astype(np.float32))
    except OSError:
        pass


def analyze(ffmpeg: FFmpeg, info: MediaInfo, fps: float = 5.0, model: str = DEFAULT_MODEL,
            use_gpu: bool = True, hwaccel: bool = True, cancel: threading.Event | None = None,
            on_progress: Callable[[float], None] | None = None, cache_dir=None) -> TrackData:
    """fps <= 0 means every frame."""
    cached = load_cached(info, fps, model, cache_dir)
    if cached is not None:
        return cached
    v = info.video
    if not v or not v.width:
        return TrackData(info, np.zeros(0), [], fps, model, error="no video stream")
    det = Detector(model, use_gpu)
    s = INPUT / max(v.width, v.height)
    w, h = max(2, int(round(v.width * s / 2)) * 2), max(2, int(round(v.height * s / 2)) * 2)
    src_fps = float(v.fps) if v.fps else 30.0
    rate = src_fps if fps <= 0 else min(fps, src_fps)
    vlen = v.duration if v.duration else info.duration
    expected = max(1, int(vlen * rate) + 1)
    vf = (f"fps={rate}," if fps > 0 else "") + f"scale={w}:{h}:flags=area,format=rgb24"
    times, dets = [], []
    for attempt in ((True, False) if hwaccel else (False,)):
        cmd = [ffmpeg.ffmpeg, "-v", "error", "-nostdin"] + (["-hwaccel", "auto"] if attempt else []) + \
              ["-i", str(info.path), "-an", "-sn", "-dn", "-vf", vf, "-f", "rawvideo", "-"]
        p = proc.popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
        frame = w * h * 3
        times, dets = [], []
        try:
            while True:
                if cancel is not None and cancel.is_set():
                    p.kill()
                    raise Cancelled("Cancelled by user")
                proc.checkpoint()
                buf = p.stdout.read(frame)
                if len(buf) < frame:
                    break
                img = np.frombuffer(buf, np.uint8).reshape(h, w, 3)
                times.append(len(times) / rate)
                dets.append(det.detect(img))
                if on_progress:
                    on_progress(min(1.0, len(times) / expected))
        finally:
            p.stdout.close()
            p.wait()
        if times:
            break
    if not times:
        return TrackData(info, np.zeros(0), [], fps, model, error="could not decode the video")
    td = TrackData(info, np.array(times, np.float64), dets, fps, model)
    if cache_dir:
        _save_cache(td, cache_dir)
    return td
