"""Subject Tracker: find people (or other subjects) and reframe the video around them."""
from breezy.core.plugin import Feature
from . import tasks  # noqa: F401  (registers the task runners)


class TrackerFeature(Feature):
    id = "tracker"
    name = "Subject Tracker"
    description = ("Find people (or animals, cars…) in videos. Make a reframed video where a smooth virtual "
                   "camera zooms and follows them, a copy with only the parts where they appear, and/or a "
                   "list of the times. Originals are never changed.")
    order = 40
    icon = "target"

    def create_widget(self):
        from .widget import TrackerWidget
        self.widget = TrackerWidget(self)
        return self.widget

    def theme_changed(self):
        self.widget.theme_changed()


FEATURE = TrackerFeature
