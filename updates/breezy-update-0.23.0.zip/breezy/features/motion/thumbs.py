"""Background loader for 'strip of 3' thumbnails (start / middle / end of a motion part)."""
from __future__ import annotations

import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from PySide6.QtCore import QObject, QRect, Qt, Signal
from PySide6.QtGui import QColor, QFont, QImage, QPainter

TW, TH = 192, 108          # one frame of the strip
_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


def _fmt(t: float) -> str:
    m, s = divmod(t, 60)
    return f"{int(m)}:{s:04.1f}"


def grab_frame(ffmpeg_exe: str, path: Path, t: float) -> QImage:
    cmd = [ffmpeg_exe, "-v", "error", "-nostdin", "-ss", f"{max(0.0, t):.3f}", "-i", str(path),
           "-frames:v", "1", "-an", "-sn",
           "-vf", f"scale={TW}:{TH}:force_original_aspect_ratio=decrease,"
                  f"pad={TW}:{TH}:(ow-iw)/2:(oh-ih)/2",
           "-f", "rawvideo", "-pix_fmt", "rgb24", "-"]
    try:
        data = subprocess.run(cmd, capture_output=True, timeout=60, creationflags=_NO_WINDOW).stdout
    except (subprocess.TimeoutExpired, OSError):
        data = b""
    if len(data) < TW * TH * 3:
        img = QImage(TW, TH, QImage.Format_RGB888)
        img.fill(QColor("#333"))
        return img
    return QImage(data[:TW * TH * 3], TW, TH, TW * 3, QImage.Format_RGB888).copy()


def make_strip(ffmpeg_exe: str, path: Path, times: tuple[float, float, float]) -> QImage:
    strip = QImage(TW * 3 + 8, TH, QImage.Format_RGB888)
    strip.fill(QColor("#1f2430"))
    p = QPainter(strip)
    f = QFont()
    f.setPixelSize(13)
    f.setBold(True)
    p.setFont(f)
    for i, t in enumerate(times):
        x = i * (TW + 4)
        p.drawImage(x, 0, grab_frame(ffmpeg_exe, path, t))
        label = ("start ", "middle ", "end ")[i] + _fmt(t)
        r = QRect(x + 4, TH - 20, TW - 8, 18)
        p.fillRect(QRect(x, TH - 22, TW, 22), QColor(0, 0, 0, 150))
        p.setPen(Qt.white)
        p.drawText(r, Qt.AlignLeft | Qt.AlignVCenter, label)
    p.end()
    return strip


class ThumbLoader(QObject):
    """request(key, path, times) -> later emits ready(key, QImage) on the UI thread."""
    ready = Signal(str, QImage)
    progress = Signal(int, int)       # done, total (for the current batch)

    def __init__(self, ffmpeg, parent=None):
        super().__init__(parent)
        self.ff = ffmpeg
        self.cache: dict[str, QImage] = {}
        self._pending: set[str] = set()
        self._pool = ThreadPoolExecutor(max_workers=2)
        self._batch_total = 0
        self._batch_done = 0

    @staticmethod
    def key(path: Path, times) -> str:
        return f"{path}|" + "|".join(f"{t:.1f}" for t in times)

    def request(self, path: Path, times: tuple[float, float, float]) -> str:
        k = self.key(path, times)
        if k in self.cache:
            self.ready.emit(k, self.cache[k])
        elif k not in self._pending:
            if not self._pending:
                self._batch_total = self._batch_done = 0
            self._pending.add(k)
            self._batch_total += 1
            self._pool.submit(self._work, k, path, times)
        return k

    def _work(self, k, path, times):
        img = make_strip(self.ff.ffmpeg, path, times)
        self.cache[k] = img
        self._pending.discard(k)
        self._batch_done += 1
        self.ready.emit(k, img)
        self.progress.emit(self._batch_done, self._batch_total)

    def shutdown(self):
        self._pool.shutdown(wait=False, cancel_futures=True)
