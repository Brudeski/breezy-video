"""Motion Trimmer: cut videos down to just the parts with motion."""
from breezy.core.plugin import Feature
from . import tasks as _tasks  # noqa: F401  (registers the task runners)


class MotionFeature(Feature):
    id = "motion"
    name = "Motion Trimmer"
    description = ("Scan videos for motion and make trimmed copies that keep only the moving parts. "
                   "Small areas that change all the time (clocks, date stamps) are ignored automatically. "
                   "Cuts are smart: the video is copied losslessly and only the frames at each cut are "
                   "re-encoded. Originals are never changed.")
    order = 20
    icon = "scissors"

    def create_widget(self):
        from .widget import MotionWidget
        self.widget = MotionWidget(self)
        return self.widget

    def theme_changed(self):
        self.widget.theme_changed()


FEATURE = MotionFeature
