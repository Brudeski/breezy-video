"""Preview panel: big thumbnail strip on single click, plays a motion part on double click.

Also offers 'Open in VLC' (starting at the part's start time) when VLC is installed.
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Optional

from PySide6.QtCore import Qt, QUrl
from PySide6.QtGui import QImage, QPixmap
from PySide6.QtWidgets import (QHBoxLayout, QLabel, QPushButton, QSizePolicy, QSlider,
                               QStackedWidget, QVBoxLayout, QWidget)

try:
    from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
    from PySide6.QtMultimediaWidgets import QVideoWidget
    HAVE_PLAYER = True
except Exception:  # pragma: no cover - multimedia module missing
    HAVE_PLAYER = False


def find_vlc() -> Optional[str]:
    exe = shutil.which("vlc")
    if exe:
        return exe
    if sys.platform == "win32":
        for base in (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)")):
            if base:
                p = Path(base) / "VideoLAN" / "VLC" / "vlc.exe"
                if p.is_file():
                    return str(p)
    return None


def _t(ms: int) -> str:
    s = ms / 1000
    m, s = divmod(s, 60)
    return f"{int(m)}:{s:04.1f}"


class PreviewPanel(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.path: Optional[Path] = None
        self.start = self.end = 0.0
        self._strip: Optional[QImage] = None
        self._seek_pending = False
        self.vlc = find_vlc()

        v = QVBoxLayout(self)
        v.setContentsMargins(6, 0, 0, 0)
        self.title = QLabel("Click a motion part to preview it.\nDouble-click to play it.")
        self.title.setWordWrap(True)
        v.addWidget(self.title)

        self.stack = QStackedWidget()
        self.stack.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.strip_label = QLabel(alignment=Qt.AlignCenter)
        self.strip_label.setMinimumSize(320, 120)
        self.strip_label.setStyleSheet("background:#11141a; color:#9ca3af;")
        self.stack.addWidget(self.strip_label)
        self.player = None   # created on first play (keeps start-up light)
        if HAVE_PLAYER:
            self.video = QVideoWidget()
            self.stack.addWidget(self.video)
        v.addWidget(self.stack, 1)

        ctl = QHBoxLayout()
        self.play_btn = QPushButton("▶ Play part")
        self.play_btn.clicked.connect(self.toggle)
        self.replay_btn = QPushButton("⟲ Replay")
        self.replay_btn.clicked.connect(self.replay)
        self.pos = QSlider(Qt.Horizontal)
        self.pos.sliderMoved.connect(lambda ms: self.player is not None and self.player.setPosition(ms))
        self.time = QLabel("0:00.0")
        self.vlc_btn = QPushButton("Open in VLC")
        self.vlc_btn.clicked.connect(self.open_vlc)
        self.vlc_btn.setToolTip("Opens VLC at the start of this part" if self.vlc else "VLC is not installed")
        ctl.addWidget(self.play_btn)
        ctl.addWidget(self.replay_btn)
        ctl.addWidget(self.pos, 1)
        ctl.addWidget(self.time)
        v.addLayout(ctl)
        v.addWidget(self.vlc_btn, alignment=Qt.AlignRight)
        if not HAVE_PLAYER:
            self.strip_label.setText("Video playback isn't available on this system.\nUse 'Open in VLC'.")
        self._update_buttons()

    # ----------------------------------------------------------------- api
    def show_part(self, path: Path, start: float, end: float, strip: Optional[QImage], label: str):
        self._stop()
        self.path, self.start, self.end = path, start, end
        self.title.setText(label)
        self.set_strip(strip)
        self.stack.setCurrentIndex(0)
        self._update_buttons()

    def set_strip(self, strip: Optional[QImage]):
        self._strip = strip
        if strip is None:
            self.strip_label.setPixmap(QPixmap())
            self.strip_label.setText("Loading thumbnails…" if self.path else "")
        else:
            self._render_strip()

    def play_part(self, path: Path, start: float, end: float, label: str, strip: Optional[QImage] = None):
        self.show_part(path, start, end, strip, label)
        self.replay()

    def clear(self):
        self._stop()
        self.path = None
        self.title.setText("Click a motion part to preview it.\nDouble-click to play it.")
        self.set_strip(None)
        self._update_buttons()

    # ------------------------------------------------------------ playback
    def _ensure_player(self) -> bool:
        if self.player is None and HAVE_PLAYER:
            self.player = QMediaPlayer(self)
            if QAudioOutput is not None:
                self.audio = QAudioOutput(self)
                self.player.setAudioOutput(self.audio)
            self.player.setVideoOutput(self.video)
            self.player.positionChanged.connect(self._on_position)
            self.player.durationChanged.connect(self._on_duration)
            self.player.mediaStatusChanged.connect(self._on_status)
            self.player.playbackStateChanged.connect(self._on_state)
        return self.player is not None

    def replay(self):
        if not (self.path and self._ensure_player()):
            return
        self.stack.setCurrentIndex(1)
        url = QUrl.fromLocalFile(str(self.path))
        if self.player.source() != url:
            self._seek_pending = True
            self.player.setSource(url)
        else:
            self.player.setPosition(int(self.start * 1000))
        self.player.play()

    def toggle(self):
        if not (self.path and self._ensure_player()):
            return
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()
        elif self.stack.currentIndex() == 0 or self.player.position() >= int(self.end * 1000) - 50:
            self.replay()
        else:
            self.player.play()

    def _stop(self):
        if self.player is not None:
            self.player.stop()

    def _on_status(self, status):
        if self._seek_pending and status in (QMediaPlayer.LoadedMedia, QMediaPlayer.BufferedMedia):
            self._seek_pending = False
            self.player.setPosition(int(self.start * 1000))

    def _on_position(self, ms: int):
        if not self.pos.isSliderDown():
            self.pos.setValue(ms)
        self.time.setText(_t(ms))
        if self.end and ms >= int(self.end * 1000) and self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()  # stop at the end of the motion part

    def _on_duration(self, ms: int):
        self.pos.setRange(0, ms)

    def _on_state(self, state):
        playing = state == QMediaPlayer.PlayingState
        self.play_btn.setText("❚❚ Pause" if playing else "▶ Play part")

    # ----------------------------------------------------------------- vlc
    def open_vlc(self):
        if not (self.vlc and self.path):
            return
        subprocess.Popen([self.vlc, f"--start-time={self.start:.2f}", f"--stop-time={self.end:.2f}",
                          "--play-and-pause", str(self.path)])

    # -------------------------------------------------------------- layout
    def _update_buttons(self):
        has = self.path is not None
        self.play_btn.setEnabled(has and HAVE_PLAYER)
        self.replay_btn.setEnabled(has and HAVE_PLAYER)
        self.vlc_btn.setEnabled(has and bool(self.vlc))

    def _render_strip(self):
        if self._strip is None:
            return
        w = max(100, self.strip_label.width() - 8)
        self.strip_label.setPixmap(QPixmap.fromImage(self._strip).scaledToWidth(w, Qt.SmoothTransformation))

    def resizeEvent(self, e):
        super().resizeEvent(e)
        self._render_strip()
