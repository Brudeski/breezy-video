"""Cut a video down to a list of segments, at the highest possible quality.

Smart cut (H.264 / H.265 sources)
---------------------------------
A video can only be stream-copied starting at a keyframe. For every segment:

    s ........ k ...................... e
    |- head -->|------- body ---------->|
     re-encode       copied as-is

* head: from the exact cut point `s` to the next keyframe `k` is re-encoded
  with the same codec at very high quality (usually well under a second);
* body: from `k` to the segment end `e` is copied untouched (lossless).

Audio is copied untouched: each segment's sound is trimmed by packet and placed
at the segment's exact length, so it stays in sync. The joins are then checked by decoding the frames around
every cut. If anything fails (or the codec isn't H.264/H.265), the trimmed video
is re-encoded exactly instead (same pipeline, every piece re-encoded at high
quality), and the log says so.
"""
from __future__ import annotations

import shutil
import subprocess
import sys
import tempfile
import threading
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from breezy.core.ffmpeg import Cancelled, FFmpeg, MediaInfo
from breezy.core.outputs import finish, working_dir, working_path
from breezy.core.sync import audio_bitrate, needs_fix, tempo

_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
_ENCODERS = {
    "hevc": ["-c:v", "libx265", "-preset", "medium", "-crf", "16",
             "-x265-params", "repeat-headers=1:open-gop=0:bframes=0:log-level=error"],
    "h264": ["-c:v", "libx264", "-preset", "medium", "-crf", "14", "-bf", "0"],
}
_TAG = {"hevc": "hev1", "h264": "avc1"}


@dataclass
class CutOptions:
    edge_gpu: bool = False        # encoder for the few frames at each cut (smart cut)
    edge_crf: int = 16
    full_gpu: bool = True         # encoder when the whole video has to be re-encoded
    full_crf: int = 16
    drift_threshold: float = 0.1
    audio_bitrate: str = "auto"   # "auto" or e.g. "192k"


def _edge_args(codec: str, opts: "CutOptions", pix: list[str]) -> list[str]:
    """Encoder for smart-cut edge pieces: no B-frames, headers on every keyframe."""
    from breezy.core import encoders
    if opts.edge_gpu and encoders.found(codec):
        args = encoders.video_args(codec, opts.edge_crf, True, pix)
        enc = args[1]
        args += ["-bf", "0"]
        if enc.endswith("_amf"):
            args += ["-header_insertion_mode", "idr"]
        elif enc.endswith("_nvenc") or enc.endswith("_qsv"):
            args += ["-forced-idr", "1"] if enc.endswith("_nvenc") else []
        return args
    base = list(_ENCODERS[codec])
    base[base.index("-crf") + 1] = str(opts.edge_crf)
    return base + pix


@dataclass
class CutResult:
    output: Path
    method: str          # "smart" or "re-encoded"
    message: str
    ok: bool = True


def _q(path: Path | str) -> str:
    return "file '" + str(Path(path).resolve()).replace("\\", "/").replace("'", "'\\''") + "'"


class Cutter:
    def __init__(self, ffmpeg: FFmpeg, log: Callable[[str], None] = print,
                 progress: Callable[[float], None] = lambda f: None,
                 cancel_event: Optional[threading.Event] = None, options: CutOptions | None = None):
        self.ff, self.log, self.progress = ffmpeg, log, progress
        self.cancel = cancel_event or threading.Event()
        self.opts = options or CutOptions()

    def _abr(self, info: MediaInfo) -> str:
        return audio_bitrate(info) if self.opts.audio_bitrate in ("", "auto") else self.opts.audio_bitrate

    # ------------------------------------------------------------- helpers
    def _run(self, args: list[str], total: float = 0.0, prog: Callable[[float], None] | None = None):
        self.ff.run(args, total, prog, None, self.cancel)

    def keyframes(self, info: MediaInfo) -> list[float]:
        return self.packets(info)[1]

    def packets(self, info: MediaInfo) -> tuple[list[float], list[float]]:
        """(all video frame times, keyframe times), relative to the start of the file."""
        def probe(entries: str) -> str:
            return subprocess.run([self.ff.ffprobe, "-v", "error", "-select_streams", "v:0",
                                   "-show_entries", entries, "-of", "csv=p=0", str(info.path)],
                                  capture_output=True, text=True, creationflags=_NO_WINDOW).stdout
        start = 0.0
        for line in probe("stream=start_time").split():
            try:
                start = float(line.strip(","))
                break
            except ValueError:
                pass
        allp, keys = [], []
        for line in probe("packet=pts_time,flags").splitlines():
            parts = line.strip().split(",")
            if len(parts) < 2:
                continue
            try:
                t = float(parts[0]) - start
            except ValueError:
                continue
            allp.append(t)
            if "K" in parts[1]:
                keys.append(t)
        return sorted(allp), sorted(keys)

    @staticmethod
    def _pix_args(info: MediaInfo) -> list[str]:
        pf = info.video.pix_fmt if info.video else ""
        if pf.startswith("yuvj"):
            return ["-pix_fmt", pf.replace("yuvj", "yuv"), "-color_range", "pc"]
        return ["-pix_fmt", pf] if pf else []

    # ----------------------------------------------------------------- api
    def cut(self, info: MediaInfo, segments: list[tuple[float, float]], out: Path,
            fix_drift: bool = True, exact_audio: bool = True) -> CutResult:
        out.parent.mkdir(parents=True, exist_ok=True)
        if out.resolve() == info.path.resolve():
            raise RuntimeError("Output would overwrite the original")
        vlen = info.video.duration if info.video and info.video.duration > 0 else info.duration
        segments = [(s, min(e, vlen)) for s, e in segments if s < vlen - 0.05]   # stay on the picture
        total = sum(e - s for s, e in segments)
        codec = info.video.codec if info.video else ""
        tmp_out = working_path(out)
        # sound longer/shorter than picture? map cut times onto the sound and speed it to match
        self._ratio = tempo(info) if (fix_drift and info.audio and
                                      needs_fix(info, self.opts.drift_threshold)) else None
        # re-encode the sound from PCM (sample-exact cuts) when fixing drift or when asked to
        self._pcm = bool(info.audio) and (self._ratio is not None or exact_audio)
        note = f"; sound re-synced ({info.drift:+.2f} s drift fixed)" if self._ratio else \
            ("; exact sound cuts" if self._pcm else "")
        if codec in _ENCODERS:
            work = Path(tempfile.mkdtemp(prefix="breezy_cut_", dir=working_dir(out)))
            try:
                self._smart(info, segments, tmp_out, work, codec)
                self._stage("Checking the result")
                problem = self._verify(info, segments, tmp_out)
                if not problem:
                    finish(tmp_out, out)
                    return CutResult(out, "smart", f"Smart cut: kept {_fmt(total)} in {len(segments)} "
                                                   f"part(s); only the frames at each cut were re-encoded" + note)
                self.log(f"Smart cut check failed ({problem}); re-encoding exactly instead.")
            except Cancelled:
                _unlink(tmp_out)
                raise
            except Exception as e:  # noqa - fall back to exact re-encode
                self.log(f"Smart cut failed ({str(e).splitlines()[0]}); re-encoding exactly instead.")
            finally:
                shutil.rmtree(work, ignore_errors=True)
            _unlink(tmp_out)
        else:
            self.log(f"{codec or 'This'} video can't be smart-cut; re-encoding exactly at high quality.")
        enc_codec = codec if codec in _ENCODERS else "h264"
        work = Path(tempfile.mkdtemp(prefix="breezy_cut_", dir=working_dir(out)))
        try:
            self._smart(info, segments, tmp_out, work, enc_codec, encode_all=True)
            self._stage("Checking the result")
            problem = self._verify(info, segments, tmp_out, check_frames=False)
            if problem:
                raise RuntimeError(f"re-encoded file failed its check: {problem}")
            finish(tmp_out, out)
        except BaseException:
            _unlink(tmp_out)
            raise
        finally:
            shutil.rmtree(work, ignore_errors=True)
        return CutResult(out, "re-encoded", f"Re-encoded at high quality: kept {_fmt(total)} "
                                            f"in {len(segments)} part(s)" + note)

    # --------------------------------------------------------- smart cut
    def _enc_args(self, codec: str, info: MediaInfo) -> list[str]:
        pix = self._pix_args(info)
        if self._encode_all:
            from breezy.core import encoders
            if self.opts.full_gpu and encoders.found(codec):
                return encoders.video_args(codec, self.opts.full_crf, True, pix) + ["-bf", "0"]
            base = list(_ENCODERS[codec])
            base[base.index("-crf") + 1] = str(self.opts.full_crf)
            return base + pix
        return _edge_args(codec, self.opts, pix)

    def _smart(self, info: MediaInfo, segments, out: Path, work: Path, codec: str,
               encode_all: bool = False):
        """encode_all=True: same pipeline, but every piece is re-encoded (exact fallback)."""
        self._encode_all = encode_all
        self._stage("Finding the keyframes")
        self._src_frames, keys = self.packets(info)
        if not keys and not encode_all:
            raise RuntimeError("no keyframes found")
        total = sum(e - s for s, e in segments) or 1.0
        done = 0.0
        vlist, alist = [], []
        audio_src = None
        if info.audio:
            self._stage("Preparing the sound")
        if self._pcm:
            # decode the sound once to plain PCM: sample-exact positions for the re-synced cuts
            audio_src = work / "audio.wav"
            self._run(["-i", str(info.path), "-map", "0:a:0", "-vn", "-sn", "-dn",
                       "-c:a", "pcm_s16le", str(audio_src)])
        elif info.audio:
            # copy the soundtrack on its own so cuts in it aren't pulled back to video keyframes
            audio_src = work / "audio.mka"
            self._run(["-i", str(info.path), "-map", "0:a:0", "-vn", "-sn", "-dn", "-c", "copy",
                       str(audio_src)])
        for n, (s, e) in enumerate(segments):
            self._stage(f"{'Re-encoding' if encode_all else 'Cutting'} part {n + 1} of {len(segments)}")
            k = next((t for t in keys if t >= s - 0.002), None)
            pieces = []
            if encode_all or k is None or k >= e - 0.05:
                pieces.append(("enc", s, e))
            elif k - s <= 0.002:
                pieces.append(("copy", k, e))
            else:
                pieces += [("enc", s, k), ("copy", k, e)]
            for m, (kind, a, b) in enumerate(pieces):
                if self.cancel.is_set():
                    raise Cancelled("Cancelled by user")
                p = work / f"v{n:04d}_{m}.ts"
                if kind == "enc":
                    # exact frame count (cutting by time can round one frame either way)
                    nfr = sum(1 for t in self._src_frames if a - 0.001 <= t < b - 0.001)
                    limit = ["-frames:v", str(nfr)] if nfr else ["-t", f"{b - a:.3f}"]
                    self._run(["-ss", f"{a:.3f}", "-i", str(info.path), *limit,
                               "-map", "0:v:0", "-an", "-sn", "-dn", *self._enc_args(codec, info),
                               "-f", "mpegts", str(p)])
                else:
                    # +1 ms lands on the keyframe itself; -2 ms keeps the frame AT the end point out
                    self._run(["-ss", f"{a + 0.001:.3f}", "-i", str(info.path), "-t", f"{b - a - 0.002:.3f}",
                               "-map", "0:v:0", "-an", "-sn", "-dn", "-c", "copy",
                               "-f", "mpegts", str(p)])
                vlist.append(_q(p))
            if audio_src and self._pcm:
                # sample-exact: the sound for picture time s..e lives at s*r..e*r (r = 1 without drift);
                # speed it to exactly e-s
                r = self._ratio or 1.0
                a_piece = work / f"a{n:04d}.wav"
                tempo_f = f"atempo={r:.6f}," if r != 1.0 else ""
                self._run(["-ss", f"{s * r:.4f}", "-i", str(audio_src), "-t", f"{(e - s) * r + 0.05:.4f}",
                           "-af", f"{tempo_f}apad,atrim=end={e - s:.6f},asetpts=PTS-STARTPTS",
                           "-c:a", "pcm_s16le", str(a_piece)])
                alist += [_q(a_piece), f"duration {e - s:.6f}"]
            elif audio_src:
                # audio packets are all keyframes: trim by packet, then place it at its exact length
                a_piece = work / f"a{n:04d}.mka"
                self._run(["-i", str(audio_src), "-ss", f"{s:.3f}", "-to", f"{e:.3f}", "-c", "copy",
                           str(a_piece)])
                alist += [_q(a_piece), f"duration {e - s:.3f}"]
            done += e - s
            self.progress(0.9 * done / total)

        self._stage(f"Joining the {len(segments)} part(s)")
        vtxt, atxt = work / "video.txt", work / "audio.txt"
        vtxt.write_text("\n".join(vlist) + "\n", "utf-8")
        args = ["-f", "concat", "-safe", "0", "-i", str(vtxt)]
        maps = ["-map", "0:v:0"]
        if info.audio:
            atxt.write_text("\n".join(alist) + "\n", "utf-8")
            args += ["-f", "concat", "-safe", "0", "-i", str(atxt)]
            maps += ["-map", "1:a:0"]
        args += maps + ["-c", "copy", "-tag:v", _TAG[codec]]
        if self._pcm:
            args += ["-c:a", "aac", "-b:a", self._abr(info)]   # exact/re-synced sound is encoded once
        else:
            args += ["-avoid_negative_ts", "make_zero"]
        if out.suffix.lower() in (".mp4", ".mov", ".m4v"):
            args += ["-movflags", "+faststart"]
        args.append(str(out))
        self._run(args)
        self.progress(0.95)

    def _stage(self, text: str):
        from breezy.core.tasks import say_stage
        say_stage(self.progress, text)

    def _verify(self, info: MediaInfo, segments, out: Path, check_frames: bool = True) -> str:
        """Empty string if fine, else a short description of the problem."""
        o = self.ff.probe(out)
        if o.error:
            return o.error
        expected = sum(e - s for s, e in segments)
        if abs(o.duration - expected) > 0.5 + 0.1 * len(segments):
            return f"length {o.duration:.1f}s, expected {expected:.1f}s"
        if self._pcm and o.drift is not None and abs(o.drift) > 0.1:
            return f"sound and picture differ by {o.drift:+.2f}s"
        # the video track must hold exactly the source frames inside the segments
        want = sum(1 for t in getattr(self, "_src_frames", []) for s, e in segments if s - 0.001 <= t < e - 0.001)
        got = len(self.packets(o)[0]) if check_frames else want
        if want and abs(got - want) > len(segments):
            return f"video has {got} frames, expected {want}"
        # decode the frames around every join
        t, joins = 0.0, []
        for s, e in segments[:-1]:
            t += e - s
            joins.append(t)
        joins = [0.0] + joins
        for j in joins:
            res = subprocess.run([self.ff.ffmpeg, "-v", "error", "-nostdin", "-ss", f"{max(0.0, j - 1.0):.3f}",
                                  "-i", str(out), "-t", "2.5", "-map", "0:v:0", "-f", "null", "-"],
                                 capture_output=True, text=True, creationflags=_NO_WINDOW)
            err = (res.stderr or "").strip()
            if res.returncode != 0 or err:
                return f"decode problem near {j:.1f}s: {err.splitlines()[0] if err else res.returncode}"
        return ""


def _unlink(p: Path):
    try:
        p.unlink()
    except OSError:
        pass


def _fmt(sec: float) -> str:
    sec = int(round(sec))
    return f"{sec // 60}:{sec % 60:02d}" if sec < 3600 else f"{sec // 3600}:{sec % 3600 // 60:02d}:{sec % 60:02d}"
