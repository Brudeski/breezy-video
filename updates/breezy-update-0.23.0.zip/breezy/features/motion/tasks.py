"""Motion Trimmer task runners: find motion, trim, and automatic trimming of another task's output."""
from __future__ import annotations

from pathlib import Path

import numpy as np

from breezy.core.outputs import apply_pattern, output_dir, unique_path
from breezy.core.proc import Cancelled
from breezy.core.settings import app_data_dir
from breezy.core.tasks import Task, TaskContext, register_runner
from .analyzer import (DEFAULT_MERGE_GAP, DEFAULT_MIN_MOTION, DEFAULT_SENSITIVITY, SMALL_AREA,
                       MotionProfile, analyze, segments_for)
from .cutter import CutOptions, Cutter


def cache_dir() -> Path:
    return app_data_dir() / "motion_cache"


def _analyze_files(task: Task, ctx: TaskContext, files: list[str]) -> dict[str, MotionProfile]:
    s = task.spec
    infos = {}
    for f in files:
        ctx.checkpoint()
        infos[f] = ctx.ffmpeg.probe(Path(f))
    ctx.set_items(files, [max(infos[f].duration or 1.0, 1.0) for f in files], [Path(f).name for f in files])

    def one(_i, f, prog):
        info = infos[f]
        if info.error:
            ctx.log(f"✖ Can't read {Path(f).name}: {info.error}")
            return MotionProfile(info, np.zeros(0), error=info.error)
        prog(None, f"Looking for motion ({s.get('fps', 10.0):g} pictures per second)")
        p = analyze(ctx.ffmpeg, info, ctx.cancel_event, fps=s.get("fps", 10.0),
                    small_area=s.get("small_area", SMALL_AREA), hwaccel=s.get("hwaccel", True),
                    cache_dir=cache_dir(), on_progress=prog)
        if p.error:
            ctx.log(f"✖ {Path(f).name}: {p.error}")
        return p

    res = ctx.parallel(one, s.get("workers", 4))
    if ctx.cancel_event.is_set():
        raise Cancelled("Cancelled by user")
    return {files[i]: p for i, p in res.items()}


def segment_params(spec: dict) -> dict:
    return {"sensitivity": spec.get("sensitivity", DEFAULT_SENSITIVITY), "pad_before": spec.get("pad_before", 1.0),
            "pad_after": spec.get("pad_after", 2.0), "merge_gap": spec.get("merge_gap", DEFAULT_MERGE_GAP),
            "min_motion": spec.get("min_motion", DEFAULT_MIN_MOTION)}


def cut_options(spec: dict) -> CutOptions:
    return CutOptions(edge_gpu=spec.get("edge_gpu", False), edge_crf=spec.get("edge_crf", 16),
                      full_gpu=spec.get("full_gpu", True), full_crf=spec.get("full_crf", 16),
                      drift_threshold=spec.get("drift_threshold", 0.1),
                      audio_bitrate=spec.get("audio_bitrate", "") or "auto")


def run_analyze(task: Task, ctx: TaskContext):
    profiles = _analyze_files(task, ctx, task.spec["files"])
    moving = 0
    prm = segment_params(task.spec)
    for p in profiles.values():
        if not p.error and segments_for(p, **prm).has_motion:
            moving += 1
    ctx.log(f"Analyzed {len(profiles)} video(s): {moving} with motion at the current settings.")
    return profiles


def _trim(task: Task, ctx: TaskContext):
    s = task.spec
    opts = cut_options(s)
    pattern = s.get("name_pattern", "{name}_motion")
    for _i, it in ctx.items():
        src = Path(it["path"])
        try:
            info = ctx.ffmpeg.probe(src)
            if info.error:
                raise RuntimeError(info.error)
            segs = [tuple(x) for x in it["segments"]]
            if not segs:
                ctx.log(f"– {src.name}: no parts ticked - skipped.")
                continue
            base = apply_pattern(pattern, src.stem)
            if s.get("separate_parts") and len(segs) > 1:
                # every ticked part its own file: …_part01, …_part02 (progress shared out by length)
                total = sum(e - b for b, e in segs) or 1.0
                done = 0.0
                for n, seg in enumerate(segs, 1):
                    out = unique_path(output_dir(s, src) / f"{base}_part{n:02d}{src.suffix}")
                    ctx.log(f"=== {src.name} part {n} of {len(segs)} → {out}")
                    share = (seg[1] - seg[0]) / total

                    def prog(f=None, label=None, d=done, sh=share, n=n):
                        inner = label if label and not label.startswith(("Cutting part", "Re-encoding part")) else ""
                        ctx.item_progress(None if f is None else d + sh * f,
                                          f"Saving part {n} of {len(segs)}" + (f": {inner}" if inner else ""))
                    cutter = Cutter(ctx.ffmpeg, log=ctx.log, progress=prog, cancel_event=ctx.cancel_event,
                                    options=opts)
                    r = cutter.cut(info, [seg], out, fix_drift=s.get("fix_drift", True),
                                   exact_audio=s.get("exact_audio", True))
                    ctx.add_output(r.output)
                    ctx.log(f"✔ {r.output.name}: {r.message}")
                    done += share
                continue
            out = unique_path(output_dir(s, src) / (base + src.suffix))
            ctx.log(f"=== {src.name} → {out}")
            cutter = Cutter(ctx.ffmpeg, log=ctx.log, progress=ctx.item_progress,
                            cancel_event=ctx.cancel_event, options=opts)
            r = cutter.cut(info, segs, out,
                           fix_drift=s.get("fix_drift", True), exact_audio=s.get("exact_audio", True))
            ctx.add_output(r.output)
            ctx.log(f"✔ {r.output.name}: {r.message}")
        except Cancelled:
            raise
        except Exception as e:  # noqa - keep going with the next video
            ctx.error(f"{src.name}: {str(e).splitlines()[0] if str(e) else type(e).__name__}")


def trim_items(profiles: dict, spec: dict) -> tuple[list[dict], list[str]]:
    """(items to trim, names of videos with no motion)."""
    prm = segment_params(spec)
    items, still = [], []
    for f, p in profiles.items():
        if p.error:
            continue
        r = segments_for(p, **prm)
        if r.has_motion:
            items.append({"path": str(f), "segments": [list(x) for x in r.segments], "kept": r.kept})
        else:
            still.append(Path(f).name)
    return items, still


def run_trim(task: Task, ctx: TaskContext):
    items = task.spec["items"]
    ctx.set_items(items, [max(i.get("kept", 1.0), 1.0) for i in items], [Path(i["path"]).name for i in items])
    _trim(task, ctx)


def run_auto(task: Task, ctx: TaskContext):
    """Input = files from another task: find motion with the saved settings, then trim."""
    s = task.spec
    if "auto_items" not in s:
        profiles = _analyze_files(task, ctx, s.get("input_files", []))
        s["auto_items"], still = trim_items(profiles, s)
        if still:
            ctx.log(f"No motion (skipped): {', '.join(still)}")
        task.done_items = []
    items = s["auto_items"]
    if not items:
        ctx.log("No motion found in these files - nothing to trim.")
        return
    ctx.set_items(items, [max(i.get("kept", 1.0), 1.0) for i in items], [Path(i["path"]).name for i in items])
    _trim(task, ctx)


register_runner("motion.analyze", run_analyze)
register_runner("motion.trim", run_trim)
register_runner("motion.auto", run_auto)
