"""Find the parts of a video that contain motion.

How it works
------------
1. FFmpeg decodes the video at 5 frames per second, shrunk to 160x90
   (fast, and plenty for spotting movement). Brightness AND colour are used, so
   a red object on a grey background of the same brightness is still seen.
2. The picture is split into a 16x9 grid of blocks. A block "changed" when
   enough of its pixels clearly changed since the previous sample, compared with
   that block's own normal noise level.
3. Auto-ignore: blocks that keep changing steadily through the whole clip (a
   ticking clock, a date stamp, a flickering light) are ignored - but only when
   they are a *small* part of the picture. If most of the picture changes
   constantly (e.g. a moving dashcam) it is treated as real motion.
4. A frame "has motion" when the share of changed blocks reaches the
   sensitivity threshold. Runs of motion shorter than the "shortest motion"
   setting are ignored.
5. Motion runs become segments, padded before/after; segments separated by a
   still stretch shorter than the "merge" setting are joined into one.

Steps 1-3 are the slow part and are done once per file; steps 4-5 are instant,
so moving the sliders updates the result immediately.
"""
from __future__ import annotations

import subprocess
import sys
import threading
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Optional

import numpy as np

from breezy.core.ffmpeg import Cancelled, FFmpeg, MediaInfo

SAMPLE_FPS = 5
W, H = 160, 90
BLOCK = 10                     # 16 x 9 blocks
PIXEL_CHANGE = 18             # |dY|+|dU|+|dV| above this = pixel changed
STEADY_MIN = 0.10              # overlay: block changes in >=10% of samples...
STEADY_SPREAD = 0.8            # ...and in >=80% of 5-second windows (steady, not a burst)
SMALL_AREA = 0.15              # ...ignored only if all such blocks cover <15% of the picture
_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0

# Sensitivity 1..10 -> share of the (non-ignored) picture that must change
SENSITIVITY_SHARE = [0.20, 0.12, 0.08, 0.05, 0.03, 0.02, 0.012, 0.008, 0.005, 0.003]
DEFAULT_SENSITIVITY = 10      # user's choice (0.14.0: 10)
DEFAULT_MERGE_GAP = 30.0      # still stretches shorter than this stay in (user's choice, 0.19.0)
DEFAULT_MIN_MOTION = 0.4      # motion shorter than this is ignored (user's choice)


@dataclass
class MotionProfile:
    """Per-file analysis result (independent of the slider settings)."""
    info: MediaInfo
    share: np.ndarray                    # per sample: share of watched blocks that changed
    ignored_share: float = 0.0           # how much of the picture was auto-ignored
    error: str = ""
    fps: float = SAMPLE_FPS              # analysis samples per second

    @property
    def sample_dt(self) -> float:
        return 1.0 / self.fps


@dataclass
class MotionResult:
    profile: MotionProfile
    segments: list[tuple[float, float]] = field(default_factory=list)
    # for each segment: (start, middle, end) moments of actual motion - used for thumbnails
    marks: list[tuple[float, float, float]] = field(default_factory=list)

    @property
    def kept(self) -> float:
        return sum(e - s for s, e in self.segments)

    @property
    def has_motion(self) -> bool:
        return bool(self.segments)


def _decode_gray(ffmpeg: FFmpeg, path: Path, cancel: threading.Event | None,
                 hwaccel: bool, fps: float = SAMPLE_FPS, expected: int = 0,
                 on_progress=None) -> np.ndarray:
    cmd = [ffmpeg.ffmpeg, "-v", "error", "-nostdin"]
    if hwaccel:
        cmd += ["-hwaccel", "auto"]
    cmd += ["-i", str(path), "-an", "-sn", "-dn",
            "-vf", f"fps={fps},scale={W}:{H}:flags=area,format=yuv444p",
            "-f", "rawvideo", "-"]
    from breezy.core import proc as _proc
    proc = _proc.popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    chunks, frame, got = [], W * H * 3, 0
    try:
        while True:
            if cancel is not None and cancel.is_set():
                proc.kill()
                raise Cancelled("Cancelled by user")
            buf = proc.stdout.read(frame * 25)
            if not buf:
                break
            chunks.append(buf)
            got += len(buf)
            if on_progress and expected:
                on_progress(min(1.0, got / frame / expected))
    finally:
        proc.stdout.close()
        err = proc.stderr.read().decode("utf-8", "replace")
        proc.wait()
    data = b"".join(chunks)
    n = len(data) // frame
    if n == 0:
        raise RuntimeError(err.strip().splitlines()[-1] if err.strip() else "no frames decoded")
    return np.frombuffer(data[:n * frame], dtype=np.uint8).reshape(n, 3, H, W)  # planar Y,U,V


def _cache_file(cache_dir, info: MediaInfo, fps: float, small_area: float):
    import hashlib
    key = f"{info.path}|{info.size}|{int(info.mtime)}|{fps}|{small_area}|v1"
    return Path(cache_dir) / (hashlib.sha1(key.encode()).hexdigest() + ".npz")


def analyze(ffmpeg: FFmpeg, info: MediaInfo, cancel: threading.Event | None = None,
            fps: float = SAMPLE_FPS, small_area: float = SMALL_AREA, hwaccel: bool = True,
            cache_dir=None, on_progress=None) -> MotionProfile:
    cf = _cache_file(cache_dir, info, fps, small_area) if cache_dir else None
    if cf and cf.is_file():
        try:
            z = np.load(cf)
            return MotionProfile(info, z["share"], float(z["ignored"]), fps=fps)
        except Exception:
            pass
    expected = int((info.video.duration if info.video and info.video.duration else info.duration) * fps) + 1
    try:
        try:
            frames = _decode_gray(ffmpeg, info.path, cancel, hwaccel, fps, expected, on_progress)
        except RuntimeError:
            if not hwaccel:
                raise
            frames = _decode_gray(ffmpeg, info.path, cancel, False, fps, expected, on_progress)
    except Cancelled:
        raise
    except Exception as e:  # noqa
        return MotionProfile(info, np.zeros(0), error=str(e), fps=fps)
    prof = profile_from_frames(info, frames, fps, small_area)
    if cf:
        try:
            cf.parent.mkdir(parents=True, exist_ok=True)
            np.savez(cf, share=prof.share, ignored=prof.ignored_share)
        except OSError:
            pass
    return prof


def profile_from_frames(info: MediaInfo, frames: np.ndarray, fps: float = SAMPLE_FPS,
                        small_area: float = SMALL_AREA) -> MotionProfile:
    """frames: (n, 3, H, W) planar YUV, or (n, H, W) grayscale."""
    if len(frames) < 2:
        return MotionProfile(info, np.zeros(len(frames)), fps=fps)
    f = frames.astype(np.int16)
    diff = np.abs(f[1:] - f[:-1])
    if diff.ndim == 4:
        diff = diff.sum(axis=1)                                       # Y + U + V
    bh, bw = H // BLOCK, W // BLOCK
    px = (diff > PIXEL_CHANGE)[:, :bh * BLOCK, :bw * BLOCK]
    frac = px.reshape(len(px), bh, BLOCK, bw, BLOCK).mean(axis=(2, 4))  # share of block's pixels
    baseline = np.median(frac, axis=0)                                # each block's normal level
    changed = frac > np.maximum(0.04, baseline * 3)                    # (n-1, bh, bw)

    # steady changers (clock / date stamp / flicker): changing often AND throughout the clip
    win = max(2, int(round(5 * fps)))
    nwin = max(1, len(changed) // win)
    per_win = np.array([changed[i * win:(i + 1) * win].any(axis=0) for i in range(nwin)])
    steady = (changed.mean(axis=0) >= STEADY_MIN) & (per_win.mean(axis=0) >= STEADY_SPREAD)
    ignored_share = float(steady.mean())
    small = ignored_share < small_area
    watch = ~steady if small else np.ones_like(steady)
    if not watch.any():
        watch = np.ones_like(steady)
    share = (changed & watch).sum(axis=(1, 2)) / watch.sum()
    share = np.concatenate([[0.0], share])                           # align with frame index
    return MotionProfile(info, share.astype(np.float32), ignored_share if small else 0.0, fps=fps)


def segments_for(profile: MotionProfile, sensitivity: int = DEFAULT_SENSITIVITY,
                 pad_before: float = 1.0, pad_after: float = 2.0,
                 merge_gap: float = DEFAULT_MERGE_GAP,
                 min_motion: float = DEFAULT_MIN_MOTION) -> MotionResult:
    if profile.error or len(profile.share) == 0:
        return MotionResult(profile, [])
    thr = SENSITIVITY_SHARE[max(1, min(10, sensitivity)) - 1]
    hot = profile.share >= thr
    dt = profile.sample_dt
    v = profile.info.video
    # cut times live on the picture's timeline (the sound may be longer - see audio drift)
    dur = (v.duration if v and v.duration > 0 else profile.info.duration) or len(profile.share) * dt
    need = max(1, int(round(min_motion / dt)))          # samples of continuous motion required

    # runs of consecutive motion samples: (first index, last index)
    runs, i, n = [], 0, len(hot)
    while i < n:
        if hot[i]:
            j = i
            while j + 1 < n and hot[j + 1]:
                j += 1
            if j - i + 1 >= need:
                runs.append((i, j))
            i = j + 1
        else:
            i += 1

    segs: list[list[float]] = []
    for a, b in runs:
        core_s, core_e = max(0.0, a * dt - dt), min(dur, (b + 1) * dt)   # motion began after sample a-1
        s, e = max(0.0, core_s - pad_before), min(dur, core_e + pad_after)
        if segs and s <= segs[-1][1] + merge_gap:
            segs[-1][1] = max(segs[-1][1], e)
            segs[-1][2].append((a, b))
        else:
            segs.append([s, e, [(a, b)]])

    marks = []
    for _, _, rs in segs:
        idx = [k for a, b in rs for k in range(a, b + 1)]               # samples with real motion
        first, last = idx[0], idx[-1]
        mid = min(idx, key=lambda k: abs(k - (first + last) / 2))
        marks.append(tuple(round(float(min(dur, k * dt)), 3) for k in (first, mid, last)))
    return MotionResult(profile, [(round(float(x[0]), 3), round(float(x[1]), 3)) for x in segs], marks)
