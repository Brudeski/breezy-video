"""Motion Trimmer page: find motion, review and preview the parts, trim - long work runs as tasks."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import QSize, Qt, QTimer
from PySide6.QtGui import QBrush, QColor, QIcon, QImage, QPixmap
from PySide6.QtWidgets import (QAbstractItemView, QFileDialog, QHBoxLayout, QLabel, QLineEdit,
                               QMessageBox, QPlainTextEdit, QPushButton, QSlider, QSplitter, QTreeWidget,
                               QTreeWidgetItem, QVBoxLayout, QWidget)

from breezy.core import theme
from breezy.core.outputs import output_spec
from breezy.core.sync import drift_text, needs_fix
from breezy.core.tasks import Task
from breezy.core.ui import (Card, OutputCard, OutputPicker, SettingsColumn, TaskBar, check, combo,
                            open_in_explorer, spin)
from breezy.features.stitcher.detector import VIDEO_EXTS
from breezy.features.stitcher.joiner import _fmt_size
from .analyzer import (DEFAULT_MERGE_GAP, DEFAULT_MIN_MOTION, DEFAULT_SENSITIVITY, SMALL_AREA,
                       MotionProfile, MotionResult, segments_for)
from .preview import PreviewPanel
from .thumbs import ThumbLoader

ROLE = Qt.UserRole
DEFAULT_FOLDER = "Trimmed"
DEFAULT_PATTERN = "{name}_motion"
BITRATES = [("Automatic", ""), ("64 kbps", "64k"), ("96 kbps", "96k"), ("128 kbps", "128k"),
            ("192 kbps", "192k"), ("320 kbps", "320k")]


def _t(sec: float) -> str:
    m, s = divmod(sec, 60)
    h, m = divmod(int(m), 60)
    return f"{h}:{m:02d}:{s:04.1f}" if h else f"{m}:{s:04.1f}"


def _dur(sec: float) -> str:
    sec = int(round(sec))
    return f"{sec // 3600}:{sec % 3600 // 60:02d}:{sec % 60:02d}"


class MotionWidget(QWidget):
    def __init__(self, feature):
        super().__init__()
        self.feature = feature
        self.ctx = feature.context
        self.ff = self.ctx.ffmpeg
        self.tm = self.ctx.tasks
        self.files: list[Path] = []
        self.extra_files: list[Path] = []
        self.profiles: dict[Path, MotionProfile] = {}
        self.results: dict[Path, MotionResult] = {}
        self.unchecked: set[Path] = set()
        self.parts_off: set[tuple] = set()          # (path, start, end) of motion parts the user unticked
        self._migrate_defaults()
        if feature.setting("remember_parts", False):
            self.parts_off = {(str(a), float(b), float(c)) for a, b, c in feature.setting("parts_off", []) or []}
        self.analyze_task_id = None
        self._analysis_key = None
        self.thumbs = ThumbLoader(self.ff, self)
        self.thumbs.ready.connect(self._thumb_ready)
        self.thumbs.progress.connect(self._thumb_progress)
        self._thumb_items: dict[str, list[QTreeWidgetItem]] = {}
        self._build()
        self._analysis_key = self._akey()
        self.tm.finished.connect(self._task_finished)
        self._update_buttons()
        self._install_tools()

    # ================================================================ layout

    def _build(self):
        st = self.feature.setting
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(14)

        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.setSpacing(8)
        src = Card()
        top = QHBoxLayout()
        self.folder_edit = QLineEdit(st("last_folder", ""))
        self.folder_edit.setPlaceholderText("Folder of videos…")
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse_folder)
        self.recursive = check("Include subfolders", st("recursive", False))
        self.use_out = QPushButton("Use output from…")
        self.use_out.setToolTip("Add files made by any module - or queue automatic trimming of a task "
                                "that hasn't finished yet")
        self.use_out.clicked.connect(self._use_output)
        self.analyze_btn = QPushButton("Find motion", objectName="primary")
        self.analyze_btn.clicked.connect(self.analyze_all)
        top.addWidget(QLabel("Folder:"))
        top.addWidget(self.folder_edit, 1)
        top.addWidget(browse)
        add_files = QPushButton("Add files…")
        add_files.setToolTip("Choose one or more video files (they're added to the list)")
        add_files.clicked.connect(self._add_files)
        top.addWidget(add_files)
        clear_files = QPushButton("Clear")
        clear_files.setToolTip("Empty the list (folder and added files)")
        clear_files.clicked.connect(self._clear_files)
        top.addWidget(clear_files)
        top.addWidget(self.recursive)
        top.addWidget(self.use_out)
        top.addWidget(self.analyze_btn)
        src.v.addLayout(top)
        self.extra_label = QLabel("", objectName="muted")
        src.v.addWidget(self.extra_label)
        lv.addWidget(src)

        self.tree = QTreeWidget()
        self.tree.setColumnCount(5)
        self.tree.setHeaderLabels(["Video / motion parts", "Length", "Kept", "Size", "Details"])
        self.tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tree.setAlternatingRowColors(True)
        h = self.tree.header()
        h.resizeSection(0, 360)
        for c, w in ((1, 75), (2, 115), (3, 75)):
            h.resizeSection(c, w)
        h.setStretchLastSection(True)
        self.tree.setIconSize(QSize(240, 45))
        self.tree.itemChanged.connect(self._item_changed)
        self.tree.itemExpanded.connect(self._request_thumbs)
        self.tree.currentItemChanged.connect(self._current_changed)
        self.tree.itemDoubleClicked.connect(self._double_clicked)
        self.preview = PreviewPanel()
        hsplit = QSplitter(Qt.Horizontal)
        hsplit.addWidget(self.tree)
        hsplit.addWidget(self.preview)
        hsplit.setStretchFactor(0, 3)
        hsplit.setStretchFactor(1, 2)
        hsplit.setSizes([640, 420])
        self.log = QPlainTextEdit(readOnly=True)
        self.log.setMaximumBlockCount(2000)
        self.log.setPlaceholderText("Messages")
        split = QSplitter(Qt.Vertical)
        split.addWidget(hsplit)
        split.addWidget(self.log)
        split.setSizes([560, 90])
        lv.addWidget(split, 1)

        run = Card()
        rh = QHBoxLayout()
        self.taskbar = TaskBar(self.tm, "motion")
        self.taskbar.hide()                 # progress is shown in the bar at the bottom and on the Tasks page
        rh.addStretch(1)
        self.thumb_label = QLabel("", objectName="muted")
        rh.addWidget(self.thumb_label)
        self.open_btn = QPushButton("Open output folder")
        self.open_btn.clicked.connect(self._open_output)
        self.trim_btn = QPushButton("Trim selected", objectName="primary")
        self.trim_btn.clicked.connect(self.trim)
        rh.addWidget(self.open_btn)
        rh.addWidget(self.trim_btn)
        run.v.addLayout(rh)
        lv.addWidget(run)
        root.addWidget(left, 1)

        # ---------- right: every setting visible
        col = SettingsColumn(390)
        d = col.add(Card("Detection", "Changes here update the list instantly"))
        sw = QWidget()
        sh = QHBoxLayout(sw)
        sh.setContentsMargins(0, 0, 0, 0)
        self.sens = QSlider(Qt.Horizontal)
        self.sens.setRange(1, 10)
        self.sens.setValue(int(st("sensitivity", DEFAULT_SENSITIVITY)))
        self.sens_label = QLabel(str(self.sens.value()))
        self.sens_label.setMinimumWidth(18)
        sh.addWidget(QLabel("low", objectName="muted"))
        sh.addWidget(self.sens, 1)
        sh.addWidget(QLabel("high", objectName="muted"))
        sh.addWidget(self.sens_label)
        d.row("Sensitivity:", sw, "How much of the picture must change to count as motion.\n"
                                  "Higher = picks up smaller movements.")
        self.before = d.row("Keep before motion:", spin(0, 60, float(st("pad_before", 1.0)), " s", 1, 0.5),
                            "Still footage kept before each burst of motion")
        self.after = d.row("Keep after motion:", spin(0, 60, float(st("pad_after", 2.0)), " s", 1, 0.5),
                           "Still footage kept after each burst of motion")
        self.merge = d.row("Merge pauses shorter than:", spin(0, 600, float(st("merge_gap", DEFAULT_MERGE_GAP)),
                                                               " s", 1, 0.5),
                           "Still stretches shorter than this (after padding) stay in,\n"
                           "so nearby bursts of motion become one part")
        self.min_motion = d.row("Ignore motion shorter than:", spin(0.2, 60, float(st("min_motion", DEFAULT_MIN_MOTION)),
                                                                     " s", 1, 0.2),
                                "Flickers or a bird darting past")
        for w in (self.sens, self.before, self.after, self.merge, self.min_motion):
            w.valueChanged.connect(self._settings_changed)
        d.note("These two need the videos analyzed again:")
        self.small_area = d.row("Auto-ignore busy areas up to:",
                                spin(0, 50, int(round(100 * st("small_area", SMALL_AREA))), " % of picture", step=1),
                                "Small areas that change all the time (clocks, date stamps, flicker) are ignored\n"
                                "if together they cover less than this. 0 = never ignore anything")
        self.fps = d.row("Analysis rate:", combo([("2 frames/s (fastest)", 2.0), ("5 frames/s", 5.0),
                                                  ("10 frames/s (most precise)", 10.0)], float(st("analysis_fps", 10.0))),
                         "How many frames per second are compared")
        self.small_area.valueChanged.connect(self._analysis_changed)
        self.fps.currentIndexChanged.connect(self._analysis_changed)

        c = col.add(Card("Cuts", "Smart cut copies the video and re-encodes only the frames at each cut"))
        self.edge_gpu = c.row("Encoder at each cut:", combo([("Processor (most compatible)", False),
                                                             ("Graphics card (faster)", True)], st("edge_gpu", False)))
        self.edge_crf = c.row("Cut quality:", spin(0, 40, int(st("edge_crf", 16)), " CRF"),
                              "Lower = better. 16 looks identical to the original")
        self.full_gpu = c.row("If a video must be re-encoded:", combo([("Graphics card (faster)", True),
                                                                      ("Processor", False)], st("full_gpu", True)),
                              "Used when a smart cut isn't possible for a video")
        self.full_crf = c.row("Re-encode quality:", spin(0, 40, int(st("full_crf", 16)), " CRF"))

        a = col.add(Card("Sound"))
        self.fix_drift = a.full(check("Fix audio drift (match the sound to the picture)", st("fix_drift", True)))
        self.drift_thr = a.row("Count as drifting from:", spin(0.01, 5.0, float(st("drift_threshold", 0.1)), " s",
                                                               decimals=2, step=0.05))
        self.exact_audio = a.full(check("Exact sound cuts (re-encode the trimmed sound once)", st("exact_audio", True),
                                        "On: sound is cut sample-exactly and re-encoded once (tiny quality loss).\n"
                                        "Off: sound is copied losslessly but can lag up to ~0.13 s at each cut."))
        self.abr = a.row("Re-encoded sound bitrate:", combo(BITRATES, st("audio_bitrate", "")))
        self.fix_drift.toggled.connect(self._rebuild_tree)
        self.drift_thr.valueChanged.connect(self._rebuild_tree)

        p = col.add(Card("Performance"))
        self.workers = p.row("Videos analyzed at once:", spin(1, 16, int(st("analyze_workers", 4))))
        self.hwaccel = p.full(check("Use the graphics card to decode while analyzing", st("hwaccel", True)))

        self.out = col.add(OutputCard(self.feature, DEFAULT_FOLDER, [("name_pattern", "File name:", DEFAULT_PATTERN)]))
        self.separate = self.out.full(check("Save each motion part as its own file", st("separate_parts", False),
                                            "Off: the ticked parts of a video are joined into one new video.\n"
                                            "On: every ticked part becomes its own file (…_part01, …_part02…).\n\n"
                                            "When to use: on for separate events you want to share or keep one by "
                                            "one;\noff for one short summary video per recording."))
        self.separate.toggled.connect(lambda on: self.feature.set_setting("separate_parts", on))
        self.remember = self.out.full(check("Remember unticked motion parts after closing the program",
                                            st("remember_parts", False),
                                            "Off: every motion part starts ticked each time you open the program.\n"
                                            "On: parts you untick stay unticked next time (matched by video and "
                                            "time,\nso small setting changes keep your choice).\n\n"
                                            "When to use: on if you go through a big folder over several sessions."))
        self.remember.toggled.connect(self._remember_toggled)
        root.addWidget(col)

        self._recalc_timer = QTimer(self, singleShot=True, interval=250)
        self._recalc_timer.timeout.connect(self._recalc)

    # ============================================================== helpers
    def _say(self, msg: str):
        self.log.appendPlainText(msg)

    def _settings(self) -> dict:
        return {"sensitivity": self.sens.value(), "pad_before": self.before.value(), "pad_after": self.after.value(),
                "merge_gap": self.merge.value(), "min_motion": self.min_motion.value(),
                "small_area": self.small_area.value() / 100, "fps": self.fps.currentData(),
                "edge_gpu": self.edge_gpu.currentData(), "edge_crf": self.edge_crf.value(),
                "full_gpu": self.full_gpu.currentData(), "full_crf": self.full_crf.value(),
                "fix_drift": self.fix_drift.isChecked(), "drift_threshold": self.drift_thr.value(),
                "exact_audio": self.exact_audio.isChecked(), "audio_bitrate": self.abr.currentData(),
                "workers": self.workers.value(), "hwaccel": self.hwaccel.isChecked(),
                "name_pattern": self.out.pattern("name_pattern")}

    def _save_settings(self):
        f = self.feature
        f.set_setting("last_folder", self.folder_edit.text().strip())
        f.set_setting("recursive", self.recursive.isChecked())
        rename = {"fps": "analysis_fps", "workers": "analyze_workers"}
        for k, v in self._settings().items():
            if k != "name_pattern":
                f.set_setting(rename.get(k, k), v)

    def _akey(self):
        return (self.small_area.value(), self.fps.currentData())

    def _busy(self) -> bool:
        t = self.tm.get(self.analyze_task_id) if self.analyze_task_id else None
        return bool(t and t.status in ("queued", "running", "paused"))

    def _update_buttons(self):
        busy = self._busy()
        self.analyze_btn.setEnabled(not busy)
        self.trim_btn.setEnabled(any(self._selected()))
        self.open_btn.setEnabled(True)
        n = len(self.extra_files)
        self.extra_label.setText(f"+ {n} added file(s)" if n else "")
        self.extra_label.setVisible(bool(n))

    def _browse_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Folder of videos", self.folder_edit.text())
        if d:
            self.folder_edit.setText(d)

    def _open_output(self):
        from breezy.core.ui import open_module_output
        open_module_output(self, self.tm, "motion", self.out, self.files[0] if self.files else None)

    @staticmethod
    def _pkey(p: Path, s: float, e: float) -> tuple:
        return (str(p), round(s, 2), round(e, 2))

    def _migrate_defaults(self):
        """One-time: 'Merge pauses shorter than' went from 0.5 s to 30 s in 0.19.0."""
        f = self.feature
        if int(f.setting("defaults_v", 0) or 0) < 2:
            if abs(float(f.setting("merge_gap", DEFAULT_MERGE_GAP) or 0) - 0.5) < 1e-6:
                f.set_setting("merge_gap", DEFAULT_MERGE_GAP)
            f.set_setting("defaults_v", 2)

    def _is_off(self, p: Path, s: float, e: float) -> bool:
        """A part counts as unticked if at least half of it was inside a part the user unticked
        (so the choice survives small changes to the padding or other settings)."""
        if self._pkey(p, s, e) in self.parts_off:
            return True
        ps, length = str(p), max(e - s, 1e-6)
        return any(a == ps and min(e, c) - max(s, b) >= 0.5 * length for a, b, c in self.parts_off)

    def _set_part(self, p: Path, s: float, e: float, on: bool):
        ps = str(p)
        if on:
            self.parts_off = {k for k in self.parts_off if not (k[0] == ps and min(e, k[2]) > max(s, k[1]))}
        else:
            self.parts_off.add(self._pkey(p, s, e))
        self._save_parts()

    def _save_parts(self):
        if self.remember.isChecked():
            self.feature.set_setting("parts_off", [list(k) for k in sorted(self.parts_off)][-5000:])

    def _remember_toggled(self, on: bool):
        self.feature.set_setting("remember_parts", on)
        if on:
            self._save_parts()
        else:
            self.feature.set_setting("parts_off", [])

    def _chosen_parts(self, p: Path) -> list[tuple[float, float]]:
        r = self.results.get(p)
        if not r or p in self.unchecked:
            return []
        return [(s, e) for s, e in r.segments if not self._is_off(p, s, e)]

    def _selected(self) -> list[Path]:
        return [p for p, r in self.results.items() if r.has_motion and self._chosen_parts(p)]

    # ======================================================= output linking
    def _add_files(self):
        from breezy.core.ui import pick_videos
        files = pick_videos(self, self.folder_edit.text().strip())
        if files:
            self._add_paths(files)

    def _clear_files(self):
        self.folder_edit.setText("")
        self.extra_files = []
        self.removed = set()
        self.files = []
        self.results = {}
        self._rebuild_tree()
        self._update_buttons()

    # ------------------------------------------------------------ drag & drop, list menu
    def _install_tools(self):
        from breezy.core.ui import install_drop, install_list_tools
        install_drop(self, self._drop_folder, self._add_paths)
        install_list_tools(self.tree, self._path_of_item, self._remove_paths, self._reread)

    def _path_of_item(self, it):
        d = it.data(0, ROLE) if it else None
        if isinstance(d, str):
            return Path(d)
        if isinstance(d, tuple) and len(d) > 1 and isinstance(d[1], str):
            return Path(d[1])
        return None

    def _reread(self):
        self.files = self._gather_files()
        self._rebuild_tree()
        self._update_buttons()

    def _drop_folder(self, d):
        self.folder_edit.setText(str(d))
        self.feature.set_setting("last_folder", str(d))
        self._reread()
        self._say("Folder set. Press 'Find motion' to analyze the videos.")

    def _add_paths(self, files):
        self.extra_files += [f for f in files if f not in self.extra_files]
        self.removed = getattr(self, "removed", set()) - set(files)
        self.files += [f for f in files if f not in self.files]
        self._say(f"Added {len(files)} file(s). Press 'Find motion' to analyze them.")
        self._rebuild_tree()
        self._update_buttons()

    def _remove_paths(self, paths):
        self.removed = getattr(self, "removed", set()) | set(paths)
        self.extra_files = [f for f in self.extra_files if f not in paths]
        self.files = [f for f in self.files if f not in paths]
        for p in paths:
            self.results.pop(p, None)
        self._rebuild_tree()
        self._say(f"Removed {len(paths)} file(s) from the list (nothing is deleted).")
        self._update_buttons()

    def reload_settings(self):
        from breezy.core.ui import reload_from
        reload_from(self.feature, {"analysis_fps": self.fps, "sensitivity": self.sens, "edge_crf": self.edge_crf,
                                   "full_crf": self.full_crf, "exact_audio": self.exact_audio,
                                   "full_gpu": self.full_gpu, "hwaccel": self.hwaccel})

    def _use_output(self):
        dlg = OutputPicker(self.tm, self, "motion")
        if not dlg.exec():
            return
        files, future = dlg.selection()
        if files:
            self.extra_files += [Path(f) for f in files if Path(f) not in self.extra_files]
            self.files += [Path(f) for f in files if Path(f) not in self.files]
            self._say(f"Added {len(files)} file(s). Press 'Find motion' to analyze them.")
            self._rebuild_tree()
        for tid in future:
            self._queue_auto(tid)
        self._update_buttons()

    def _queue_auto(self, task_id: str):
        out = output_spec(self.ctx.settings, "motion", DEFAULT_FOLDER, self, self.out.values())
        if out is None:
            return
        src = self.tm.get(task_id)
        name = src.title if src else task_id
        t = Task("motion.auto", "motion", f"Auto-trim output of '{name}'",
                 spec=dict(self._settings(), output=out), input_from=task_id)
        self.tm.submit(t)
        self._say(f"Queued: trim the files from '{name}' when it finishes (current settings).")

    # ============================================================ analysis
    def _gather_files(self) -> list[Path]:
        text = self.folder_edit.text().strip()
        folder = Path(text) if text else None
        files = []
        if folder and folder.is_dir():
            it = folder.rglob("*") if self.recursive.isChecked() else folder.glob("*")
            skip = {self.out.values()["folder"].lower(), "breezy output"}
            pat = self.out.pattern("name_pattern")
            tail = pat.split("{name}", 1)[1] if pat.startswith("{name}") and pat != "{name}" else ""
            files = sorted(p for p in it if p.is_file() and p.suffix.lower() in VIDEO_EXTS
                           and not (set(x.lower() for x in p.relative_to(folder).parts[:-1]) & skip)
                           and not (tail and p.stem.endswith(tail)))
        removed = getattr(self, "removed", set())
        return [p for p in files if p not in removed] + \
            [p for p in self.extra_files if p not in files and p.is_file() and p not in removed]

    def analyze_all(self):
        if not self.ff.available:
            QMessageBox.warning(self, "Motion Trimmer", "FFmpeg was not found. See the Settings page.")
            return
        text = self.folder_edit.text().strip()
        if text and not Path(text).is_dir():
            QMessageBox.warning(self, "Motion Trimmer", "That folder doesn't exist.")
            return
        files = self._gather_files()
        if not files:
            QMessageBox.information(self, "Motion Trimmer",
                                    "No videos found. Choose a folder, or add files with 'Use output from…'.")
            return
        self._save_settings()
        if self._akey() != self._analysis_key:
            self.profiles.clear()
            self._analysis_key = self._akey()
        self.files = files
        todo = [p for p in files if p not in self.profiles]
        if not todo:
            self._recalc()
            self._say("All videos are already analyzed.")
            return
        name = Path(text).name if text else f"{len(todo)} file(s)"
        t = self.tm.submit(Task("motion.analyze", "motion", f"Find motion in {name}",
                                spec=dict(self._settings(), files=[str(p) for p in todo]), resumable=False))
        self.analyze_task_id = t.id
        self.taskbar.follow(t.id)
        self._say(f"Finding motion in {len(todo)} video(s) ({len(files) - len(todo)} already analyzed)…")
        self._rebuild_tree()

    def _task_finished(self, task_id: str):
        t = self.tm.get(task_id)
        if not t or t.module != "motion":
            return
        if task_id == self.analyze_task_id:
            res = self.tm.results.pop(task_id, None)
            if res:
                self.profiles.update({Path(k): v for k, v in res.items()})
                self._recalc()
                moving = sum(1 for r in self.results.values() if r.has_motion)
                still = sum(1 for r in self.results.values() if not r.has_motion and not r.profile.error)
                self._say(f"Done: {moving} video(s) with motion, {still} with no motion (will be skipped).")
            elif t.status != "done":
                self._say(f"Finding motion {t.status}: {t.message}")
                self._rebuild_tree()
        elif t.kind in ("motion.trim", "motion.auto"):
            smart = sum(1 for l in t.log_lines if "Smart cut:" in l)
            msg = f"{t.title}: {len(t.outputs)} trimmed copy(ies) made ({smart} smart-cut)"
            if t.errors:
                msg += f"; {len(t.errors)} failed: " + "; ".join(t.errors[:5])
            if t.status == "cancelled":
                msg += " - cancelled"
            self._say(msg)
            self.feature.set_setting("last_outputs", list(t.outputs))
        self._update_buttons()

    def _settings_changed(self):
        self.sens_label.setText(str(self.sens.value()))
        self._recalc_timer.start()

    def _analysis_changed(self):
        self._save_settings()
        if self.profiles and self._akey() != self._analysis_key:
            self._say("Analysis settings changed - press 'Find motion' to analyze again with them.")

    def _recalc(self):
        self._save_settings()
        prm = {k: self._settings()[k] for k in ("sensitivity", "pad_before", "pad_after", "merge_gap", "min_motion")}
        self.results = {p: segments_for(self.profiles[p], **prm) for p in self.files if p in self.profiles}
        self._rebuild_tree()

    # ================================================================= tree
    def _rebuild_tree(self, *_):
        c = theme.colors()
        thr = self.drift_thr.value()
        self.tree.blockSignals(True)
        self.tree.clear()
        self._thumb_items = {}
        self.preview.clear()
        moving = [p for p in self.files if p in self.results and self.results[p].has_motion]
        still = [p for p in self.files if p in self.results and not self.results[p].has_motion
                 and not self.results[p].profile.error]
        failed = [p for p in self.files if p in self.results and self.results[p].profile.error]
        pending = [p for p in self.files if p not in self.results]
        for p in moving:
            r = self.results[p]
            info = r.profile.info
            top = QTreeWidgetItem(self.tree)
            top.setData(0, ROLE, str(p))
            top.setFlags(top.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsAutoTristate)
            top.setText(0, p.name)
            top.setToolTip(0, str(p))
            top.setText(1, _dur(info.duration))
            kept = sum(e - s for s, e in self._chosen_parts(p))
            pct = kept / info.duration if info.duration else 0
            top.setText(2, f"{_dur(kept)}  ({pct:.0%})")
            top.setText(3, _fmt_size(info.size))
            if needs_fix(info, thr):
                top.setForeground(4, QBrush(QColor(c["warn"])))
            top.setText(4, self._video_note(p))
            f = top.font(0)
            f.setBold(True)
            top.setFont(0, f)
            for (s, e), marks in zip(r.segments, r.marks):
                ch = QTreeWidgetItem(top)
                ch.setData(0, ROLE, ("part", str(p), s, e, marks))
                ch.setFlags(ch.flags() | Qt.ItemIsUserCheckable)
                off = p in self.unchecked or self._is_off(p, s, e)
                ch.setCheckState(0, Qt.Unchecked if off else Qt.Checked)
                ch.setText(0, f"{_t(s)}–{_t(e)}")
                ch.setText(2, f"{e - s:.1f} s")
                ch.setToolTip(0, "Tick the parts to save. Click to preview, double-click to play")
            if not r.segments:
                top.setCheckState(0, Qt.Unchecked if p in self.unchecked else Qt.Checked)
            top.setExpanded(len(r.segments) <= 6 and len(moving) <= 20)
        waiting = "Analyzing…" if self._busy() else "Not analyzed yet - press 'Find motion'"
        for title, items, color in (("No motion found - will be skipped", still, c["muted"]),
                                    ("Could not read", failed, c["warn"]),
                                    (waiting, pending, c["muted"])):
            if not items:
                continue
            top = QTreeWidgetItem(self.tree)
            top.setText(0, f"{title} ({len(items)})")
            top.setForeground(0, QBrush(QColor(color)))
            top.setFlags(Qt.ItemIsEnabled)
            for p in items:
                ch = QTreeWidgetItem(top)
                ch.setFlags(Qt.ItemIsEnabled | Qt.ItemIsSelectable)
                ch.setData(0, ROLE, ("file", str(p)))
                ch.setText(0, p.name)
                ch.setToolTip(0, str(p))
                r = self.results.get(p)
                if r:
                    ch.setText(1, _dur(r.profile.info.duration))
                    if r.profile.error:
                        ch.setText(4, r.profile.error)
            top.setExpanded(len(items) <= 15)
        self.tree.blockSignals(False)
        for i in range(self.tree.topLevelItemCount()):   # all thumbnail strips right away (user's choice)
            self._request_thumbs(self.tree.topLevelItem(i))
        self._update_buttons()

    def theme_changed(self):
        self._rebuild_tree()

    # ------------------------------------------------------------- previews
    @staticmethod
    def _part(item):
        d = item.data(0, ROLE) if item else None
        return d if isinstance(d, tuple) and d and d[0] == "part" else None

    def _request_thumbs(self, top: QTreeWidgetItem):
        for i in range(top.childCount()):
            ch = top.child(i)
            d = self._part(ch)
            if d:
                _, path, s, e, marks = d
                key = ThumbLoader.key(Path(path), marks)
                if ch not in self._thumb_items.get(key, []):
                    self._thumb_items.setdefault(key, []).append(ch)
                self.thumbs.request(Path(path), marks)

    def _thumb_ready(self, key: str, img: QImage):
        ic = QIcon(QPixmap.fromImage(img).scaled(240, 45, Qt.KeepAspectRatio, Qt.SmoothTransformation))
        for it in self._thumb_items.get(key, []):
            try:
                it.setIcon(0, ic)
            except RuntimeError:  # item was deleted by a rebuild
                pass
        d = self._part(self.tree.currentItem())
        if d and ThumbLoader.key(Path(d[1]), d[4]) == key:
            self.preview.set_strip(img)

    def _thumb_progress(self, done: int, total: int):
        self.thumb_label.setText(f"Thumbnails {done}/{total}" if done < total else "")

    def _label(self, path: Path, s: float, e: float) -> str:
        return f"<b>{path.name}</b><br>{_t(s)} → {_t(e)}  ({e - s:.1f} s)"

    def _current_changed(self, item, _prev=None):
        d = self._part(item)
        if not d:
            return
        _, path, s, e, marks = d
        key = self.thumbs.request(Path(path), marks)
        self.preview.show_part(Path(path), s, e, self.thumbs.cache.get(key), self._label(Path(path), s, e))

    def _double_clicked(self, item, _col=0):
        d = self._part(item)
        if d:
            _, path, s, e, marks = d
            self.preview.play_part(Path(path), s, e, self._label(Path(path), s, e),
                                   self.thumbs.cache.get(ThumbLoader.key(Path(path), marks)))
            return
        key = item.data(0, ROLE)
        if isinstance(key, str) and Path(key) in self.results:   # file row: play the whole video
            dur = self.results[Path(key)].profile.info.duration
            self.preview.play_part(Path(key), 0.0, dur, self._label(Path(key), 0.0, dur))

    def _item_changed(self, item: QTreeWidgetItem, _col: int):
        d = self._part(item)
        if d:                                            # one motion part ticked / unticked
            _, path, s, e, _marks = d
            p = Path(path)
            on = item.checkState(0) == Qt.Checked
            if on == (p not in self.unchecked and not self._is_off(p, s, e)):
                return                                   # not a tick change (e.g. its thumbnail arrived)
            if on:
                self._set_part(p, s, e, True)
                self.unchecked.discard(p)
            else:
                self._set_part(p, s, e, False)
            self._refresh_top(item.parent())
            self._update_buttons()
            return
        key = item.data(0, ROLE)
        if not isinstance(key, str):
            return
        p = Path(key)
        if item.checkState(0) == Qt.Checked:            # (the parts follow the video's tick by themselves)
            self.unchecked.discard(p)
        elif item.checkState(0) == Qt.Unchecked:
            self.unchecked.add(p)
        self._update_buttons()

    def _video_note(self, p: Path) -> str:
        r = self.results[p]
        info = r.profile.info
        chosen = self._chosen_parts(p)
        note = (f"{len(r.segments)} motion part(s)" if len(chosen) == len(r.segments)
                else f"{len(chosen)} of {len(r.segments)} motion parts ticked")
        if needs_fix(info, self.drift_thr.value()):
            note = (f"{drift_text(info) or 'sound drifts'} "
                    f"({'will be fixed' if self.fix_drift.isChecked() else 'NOT fixed'}); " + note)
        if r.profile.ignored_share:
            note += f"; ignored {r.profile.ignored_share:.0%} of picture (clock/stamp/flicker)"
        return note

    def _refresh_top(self, top):
        """Update a video's 'kept' time and part count after its parts were ticked / unticked."""
        if top is None:
            return
        key = top.data(0, ROLE)
        p = Path(key) if isinstance(key, str) else None
        r = self.results.get(p) if p else None
        if not r:
            return
        chosen = self._chosen_parts(p)
        kept = sum(e - s for s, e in chosen)
        info = r.profile.info
        self.tree.blockSignals(True)
        top.setText(2, f"{_dur(kept)}  ({kept / info.duration if info.duration else 0:.0%})")
        top.setText(4, self._video_note(p))
        self.tree.blockSignals(False)

    # ================================================================= trim
    def trim(self):
        sel = self._selected()
        if not sel:
            return
        out = output_spec(self.ctx.settings, "motion", DEFAULT_FOLDER, self, self.out.values())
        if out is None:
            return
        self._save_settings()
        self.preview.clear()          # stop playback while trimming
        items = []
        for p in sel:
            parts = self._chosen_parts(p)
            items.append({"path": str(p), "segments": [list(x) for x in parts],
                          "kept": sum(e - s for s, e in parts)})
        title = f"Trim {len(items)} video(s)" if len(items) > 1 else f"Trim {sel[0].name}"
        t = self.tm.submit(Task("motion.trim", "motion", title,
                                spec=dict(self._settings(), items=items, output=out,
                                          separate_parts=self.separate.isChecked())))
        self.taskbar.follow(t.id)
        self._say(f"Queued: {title}.")
        self._update_buttons()
