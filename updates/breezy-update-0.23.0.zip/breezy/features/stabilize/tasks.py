"""Stabilizer task runners: stabilise videos, a short side-by-side preview, and another task's output.

The work is done by Enhance's renderer with every other fix switched off, so it shares its encoders,
1-minute resumable parts, progress and time estimates."""
from __future__ import annotations

import dataclasses
import shutil
import time
from pathlib import Path

from breezy.core.outputs import apply_pattern, output_dir, unique_path
from breezy.core.proc import Cancelled
from breezy.core.settings import app_data_dir
from breezy.core.tasks import Task, TaskContext, register_runner
from breezy.features.enhance.filters import EnhanceSettings
from breezy.features.enhance.tasks import cache_file

MODULE = "stabilize"
# what the user sets on the page (everything else stays off)
KEYS = ("stabilize", "stab_mode", "stab_edges", "rs_fix", "rolling_shutter", "horizon", "crf", "codec",
        "enc_gpu", "enc_speed", "hwaccel", "gpu_filters", "fix_drift", "resume_parts", "compare")


def stab_settings(spec: dict) -> EnhanceSettings:
    """Enhance settings that only stabilise (and fix wobble / level the horizon)."""
    neutral = dict(size="same", upscaler="lanczos", same_size_ai=False, denoise=0, denoise_ai=0, deblock=0,
                   deband=False, auto_levels=0, white_balance=False, per_scene=0, shadows=0, highlights=0,
                   vibrance=0, sharpen=0, grain=0, low_light=0, colourise="off", faces=False, crop="off",
                   deflicker=0, dehaze=0, dust=0, stutter="off", deblur=0, shape="off", lens=0, fringes=0,
                   vignette=0, sound_ai="off", audio_denoise=0, loudness=False, voice="off", separate="off",
                   declip=0, wind=0, hum="off", stereo=0, frame_rate="same", slowmo=1, size_mode="quality",
                   subtitles=False, hdr="off", lut="none", auto_suggest=False, ten_bit=False)
    vals = dict(neutral)
    vals.update({k: spec[k] for k in KEYS if k in spec})
    return EnhanceSettings(**vals)


def has_work(s: EnhanceSettings) -> bool:
    return bool(s.stabilize or (s.rs_fix and s.rolling_shutter) or s.horizon)


def _render(ctx: TaskContext, src: Path, s: EnhanceSettings, out: Path, prog, log):
    from breezy.features.enhance.analysis import check
    from breezy.features.enhance.render import Enhancer
    info = ctx.ffmpeg.probe(src)
    if info.error:
        raise RuntimeError(info.error)
    if not info.video:
        raise RuntimeError("no picture in this file")
    prog(None, "Checking the video")
    ana = check(ctx.ffmpeg, info, cache_file())
    bench = ((ctx.settings.get("app", "hardware") if ctx.settings else None) or {}).get("bench") or None
    enh = Enhancer(ctx.ffmpeg, log, prog, ctx.cancel_event, stage=lambda text: prog(None, text), bench=bench,
                   where=lambda sec: prog(None, None, sec))
    msg = enh.render(info, s, ana, out)
    return enh, msg


def _stabilise(task: Task, ctx: TaskContext, files: list[str]):
    spec = task.spec
    s = stab_settings(spec)
    if not has_work(s):
        ctx.log("Nothing to do: stabilising, the wobble fix and horizon levelling are all off.")
        return
    pattern = spec.get("name_pattern", "{name}_stabilised")
    if not task.items:
        durs = [max(ctx.ffmpeg.probe(Path(f)).duration or 1.0, 1.0) for f in files]
        ctx.set_items(files, durs, [Path(f).name for f in files])
    for _i, f in ctx.items():
        src = Path(f)
        try:
            ext = src.suffix if src.suffix.lower() in (".mp4", ".mov", ".mkv", ".m4v") else ".mp4"
            out = unique_path(output_dir(spec, src) / (apply_pattern(pattern, src.stem) + ext))
            ctx.log(f"=== {src.name} → {out}")
            enh, msg = _render(ctx, src, s, out, ctx.item_progress, ctx.log)
            if getattr(enh, "compare_path", None):
                ctx.add_output(enh.compare_path)
                ctx.log(f"✔ {enh.compare_path.name}: before/after video")
            ctx.add_output(out)
            ctx.log(f"✔ {out.name}: {msg}")
        except Cancelled:
            raise
        except Exception as e:  # noqa - keep going with the next video
            ctx.error(f"{src.name}: {str(e).splitlines()[0] if str(e) else type(e).__name__}")


def run_stabilise(task: Task, ctx: TaskContext):
    _stabilise(task, ctx, task.spec["files"])


def run_auto(task: Task, ctx: TaskContext):
    files = task.spec.get("input_files", [])
    if not files:
        ctx.log("No input files.")
        return
    _stabilise(task, ctx, files)


# ------------------------------------------------------------------ preview
def preview_dir() -> Path:
    d = app_data_dir() / "stab_preview"
    d.mkdir(parents=True, exist_ok=True)
    return d


def run_preview(task: Task, ctx: TaskContext):
    """A few seconds of the video stabilised, side by side with the original. Returns the file's path."""
    spec = task.spec
    src = Path(spec["path"])
    start, length = float(spec.get("start", 0.0)), float(spec.get("length", 8.0))
    ctx.set_items([str(src)], [length], [f"Preview of {src.name}"])
    result = None
    for _i, _f in ctx.items():
        result = _preview(ctx, src, start, length, spec)
    return result


def _preview(ctx: TaskContext, src: Path, start: float, length: float, spec: dict) -> str:
    s = dataclasses.replace(stab_settings(spec), compare="side", resume_parts=False, fix_drift=False)
    if not has_work(s):
        raise RuntimeError("stabilising, the wobble fix and horizon levelling are all off")
    d = preview_dir()
    for old in d.iterdir():                       # earlier previews (one may still be open in the player)
        if time.time() - old.stat().st_mtime > 60:
            try:
                shutil.rmtree(old) if old.is_dir() else old.unlink()
            except OSError:
                pass
    tag = f"{int(time.time() * 1000)}"
    clip = d / f"clip_{tag}.mp4"
    ctx.item_progress(None, "Cutting out the preview")
    ctx.ffmpeg.run(["-ss", f"{start:.3f}", "-i", str(src), "-t", f"{length:.3f}", "-map", "0:v:0", "-map", "0:a:0?",
                    "-c:v", "libx264", "-preset", "veryfast", "-crf", "12", "-pix_fmt", "yuv420p",
                    "-c:a", "aac", "-b:a", "160k", str(clip)], length, lambda f: ctx.item_progress(0.15 * f),
                   None, ctx.cancel_event)

    def prog(f=None, label=None, pos=None):
        ctx.item_progress(None if f is None else 0.15 + 0.85 * f, label, pos)
    s = dataclasses.replace(s, crf=min(s.crf, 18))
    enh, _msg = _render(ctx, clip, s, d / f"stab_{tag}.mp4", prog, ctx.log)
    result = getattr(enh, "compare_path", None)
    if not result or not Path(result).is_file():
        raise RuntimeError("the side-by-side preview wasn't made")
    ctx.log("Preview ready: original on the left, stabilised on the right.")
    return str(result)


register_runner("stabilize.run", run_stabilise)
register_runner("stabilize.auto", run_auto)
register_runner("stabilize.preview", run_preview)
