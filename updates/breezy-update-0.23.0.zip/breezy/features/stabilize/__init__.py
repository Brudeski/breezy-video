"""Stabilizer: steady shaky video, fix rolling-shutter wobble and level the horizon."""
from breezy.core.plugin import Feature
from . import tasks as _tasks  # noqa: F401  (registers the task runners)


class StabilizeFeature(Feature):
    id = "stabilize"
    name = "Stabilizer"
    description = ("Steady shaky video: smooth out camera shake or lock the view still, fix the 'jelly' wobble "
                   "of phones and action cameras, and level a tilted horizon. Preview a few seconds side by side "
                   "with the original before stabilising. Originals are never changed.")
    order = 28
    icon = "stab"

    def create_widget(self):
        from .widget import StabilizeWidget
        self.widget = StabilizeWidget(self)
        return self.widget

    def theme_changed(self):
        self.widget.theme_changed()

    def shutdown(self):
        w = getattr(self, "widget", None)
        if w is not None:
            w.shutdown()


FEATURE = StabilizeFeature
