"""Stabilizer page: list of videos, a side-by-side preview clip, and the camera-motion settings."""
from __future__ import annotations

import json
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from PySide6.QtCore import QObject, Qt, QUrl, Signal
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (QAbstractItemView, QFileDialog, QHBoxLayout, QLabel, QLineEdit,
                               QMessageBox, QPlainTextEdit, QPushButton, QSizePolicy, QSlider, QSplitter,
                               QStackedWidget, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

from breezy.core import theme
from breezy.core.outputs import output_spec
from breezy.core.tasks import Task
from breezy.core.ui import Card, OutputCard, OutputPicker, SettingsColumn, check, combo, spin
from breezy.features.ends.editor import fmt
from breezy.features.enhance.filters import LEVELS
from breezy.features.motion.preview import HAVE_PLAYER
from breezy.features.stitcher.detector import VIDEO_EXTS
from breezy.features.stitcher.joiner import _fmt_size
from .tasks import KEYS, has_work

if HAVE_PLAYER:
    from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
    from PySide6.QtMultimediaWidgets import QVideoWidget

ROLE = Qt.UserRole
DEFAULT_FOLDER = "Stabilised"
DEFAULT_PATTERN = "{name}_stabilised"
MODES = [("Smooth it (keep the camera's own moves)", "smooth"), ("Lock it still (like a tripod)", "lock")]
EDGES = [("Zoom in to hide the moving edges", "zoom"), ("Zoom only as much as needed", "adaptive"),
         ("Keep the whole picture (black edges)", "black")]
LENGTHS = [("5 seconds", 5.0), ("10 seconds", 10.0), ("20 seconds", 20.0)]


class Prober(QObject):
    done = Signal(str, object)

    def __init__(self, ffmpeg, parent=None):
        super().__init__(parent)
        self.ff = ffmpeg
        self._pool = ThreadPoolExecutor(max_workers=4)

    def request(self, path: Path):
        self._pool.submit(lambda: self.done.emit(str(path), self.ff.probe(path)))

    def shutdown(self):
        self._pool.shutdown(wait=False, cancel_futures=True)


class StabilizeWidget(QWidget):
    def __init__(self, feature):
        super().__init__()
        self.feature = feature
        self.ctx = feature.context
        self.ff = self.ctx.ffmpeg
        self.tm = self.ctx.tasks
        self.files: list[Path] = []
        self.extra_files: list[Path] = []
        self.removed: set[Path] = set()
        self.infos: dict[Path, object] = {}
        self.unchecked: set[Path] = set()
        self.current: Path | None = None
        self.preview_task: str | None = None
        self.preview_key = None
        self.previews: dict[str, str] = {}          # settings+clip key -> side-by-side file
        self.player = None
        self.prober = Prober(self.ff, self)
        self.prober.done.connect(self._probed)
        self._loading = True
        self._build()
        self._loading = False
        self._install_tools()
        self.tm.finished.connect(self._task_finished)
        if self.folder_edit.text().strip():
            self._reread()
        self._update_buttons()

    # ================================================================ settings helpers
    def _st(self, key: str, default=None):
        """Saved setting, else the current quality level's value, else the default."""
        v = self.feature.setting(key)
        if v is not None:
            return v
        q = getattr(self.ctx, "quality", None)
        try:
            exp = q.expected("stabilize") if q is not None else {}
        except Exception:
            exp = {}
        if key in exp:
            return exp[key]
        try:
            from breezy.core.quality import hardware_values
            hv = hardware_values(self.ctx.settings).get("stabilize", {})
            if key in hv:
                return hv[key]
        except Exception:
            pass
        return default

    # ================================================================ layout
    def _build(self):
        st = self._st
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(14)

        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.setSpacing(8)
        src = Card()
        top = QHBoxLayout()
        self.folder_edit = QLineEdit(st("last_folder", ""))
        self.folder_edit.setPlaceholderText("Folder of videos…")
        self.folder_edit.editingFinished.connect(self._reread)
        browse = QPushButton("Browse…")
        browse.setToolTip("Choose a folder: all its videos are listed")
        browse.clicked.connect(self._browse_folder)
        add_files = QPushButton("Add files…")
        add_files.setToolTip("Choose one or more video files (they're added to the list)")
        add_files.clicked.connect(self._add_files)
        clear_files = QPushButton("Clear")
        clear_files.setToolTip("Empty the list (folder and added files)")
        clear_files.clicked.connect(self._clear_files)
        self.recursive = check("Include subfolders", st("recursive", False))
        self.recursive.toggled.connect(self._reread)
        self.use_out = QPushButton("Use output from…")
        self.use_out.setToolTip("Add files made by any module - or queue stabilising the files of a task\n"
                                "that hasn't finished yet")
        self.use_out.clicked.connect(self._use_output)
        top.addWidget(QLabel("Folder:"))
        top.addWidget(self.folder_edit, 1)
        for w in (browse, add_files, clear_files, self.recursive, self.use_out):
            top.addWidget(w)
        src.v.addLayout(top)
        self.extra_label = QLabel("", objectName="muted")
        src.v.addWidget(self.extra_label)
        lv.addWidget(src)

        self.tree = QTreeWidget()
        self.tree.setRootIsDecorated(False)
        self.tree.setColumnCount(5)
        self.tree.setHeaderLabels(["Video", "Length", "Picture", "Size", "Details"])
        self.tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tree.setAlternatingRowColors(True)
        h = self.tree.header()
        h.resizeSection(0, 320)
        for c, w in ((1, 75), (2, 120), (3, 80)):
            h.resizeSection(c, w)
        h.setStretchLastSection(True)
        self.tree.setMinimumHeight(90)
        self.tree.itemChanged.connect(self._item_changed)
        self.tree.currentItemChanged.connect(self._current_changed)

        self.preview = self._build_preview()
        self.log = QPlainTextEdit(readOnly=True)
        self.log.setMaximumBlockCount(2000)
        self.log.setPlaceholderText("Messages")
        split = QSplitter(Qt.Vertical)
        split.setChildrenCollapsible(False)
        split.addWidget(self.tree)
        split.addWidget(self.preview)
        split.addWidget(self.log)
        split.setStretchFactor(0, 1)
        split.setStretchFactor(1, 4)
        split.setSizes([160, 560, 60])
        lv.addWidget(split, 1)

        run = Card()
        rh = QHBoxLayout()
        self.summary = QLabel("", objectName="muted")
        rh.addWidget(self.summary)
        rh.addStretch(1)
        self.open_btn = QPushButton("Open output folder")
        self.open_btn.setToolTip("Open where the stabilised videos are saved")
        self.open_btn.clicked.connect(self._open_output)
        self.run_btn = QPushButton("Stabilise ticked videos", objectName="primary")
        self.run_btn.setToolTip("Make stabilised copies of the ticked videos. The originals are never changed.")
        self.run_btn.clicked.connect(self.run)
        rh.addWidget(self.open_btn)
        rh.addWidget(self.run_btn)
        run.v.addLayout(rh)
        lv.addWidget(run)
        root.addWidget(left, 1)

        # ---------- right: settings
        col = SettingsColumn(400)
        S = col.add(Card("Stabilise", "Changes here need the preview made again"))
        self.level = S.row("Stabilise shaky video:", combo(LEVELS, int(st("stabilize", 2))),
                           "How strongly camera shake is smoothed out.\n"
                           "Light: small hand tremor. Medium: walking. Strong: running, vehicles, bumpy rides.\n\n"
                           "When to use: handheld, walking or vehicle video; Off for tripod or fixed cameras.")
        self.mode = S.row("Camera movement:", combo(MODES, st("stab_mode", "smooth")),
                          "Smooth it: the camera's intended moves (pans, walking forward) stay, only the\n"
                          "shake is removed.\n"
                          "Lock it still: the view is held where the video starts, as if on a tripod.\n\n"
                          "When to use: Lock for a camera meant to stand still (held by hand, on a windy\n"
                          "pole); Smooth for anything that moves on purpose.")
        self.edges = S.row("Edges:", combo(EDGES, st("stab_edges", "zoom")),
                           "Holding the picture steady moves its edges in and out of view.\n"
                           "Zoom in: the picture is zoomed once so no edge ever shows (a little is cut off).\n"
                           "Zoom only as needed: zooms in during shaky moments and back out when calm.\n"
                           "Keep the whole picture: nothing is cut off; moving black edges show instead.\n\n"
                           "When to use: Zoom in normally; Keep the whole picture when nothing at the\n"
                           "edges may be lost.")
        self.rs_fix = S.full(check("Fix rolling-shutter wobble", bool(st("rs_fix", False)),
                                   "Phones and action cameras record line by line: fast pans lean and\n"
                                   "vibration wobbles like jelly. This straightens it out.\n\n"
                                   "When to use: phone, action-camera and drone video with 'jelly' or leaning."))
        self.rs_strength = S.row("Wobble fix strength:", combo(LEVELS[1:], int(st("rolling_shutter", 3))),
                                 "Stronger = for cameras that read the picture out more slowly\n"
                                 "(cheap action and security cameras)")
        self.horizon = S.row("Level the horizon:", spin(0, 100, int(st("horizon", 0)), " %", step=10),
                             "Turns tilted footage level using long horizontal lines (zooms in slightly).\n\n"
                             "When to use: handheld and boat/vehicle video that leans. 0 = off.")

        V = col.add(Card("Video"))
        self.crf = V.row("Quality:", spin(0, 40, int(st("crf", 18)), " CRF"),
                         "Lower = better and bigger. 18 looks practically identical to the original.\n"
                         "Set by the Quality level (top left).")
        self.codec = V.row("Video format:", combo([("Same as source", "same"), ("H.264 - plays everywhere", "h264"),
                                                   ("H.265 - smaller files", "hevc")], st("codec", "same")))
        self.enc_gpu = V.row("Encoder:", combo([("Graphics card (faster)", True), ("Processor", False)],
                                               bool(st("enc_gpu", True))))
        self.compare = V.row("Before/after video:", combo([("Off", "off"), ("Side by side", "side"),
                                                           ("Split screen", "split")], st("compare", "off")),
                             "Also saves a video with the original next to the stabilised one")
        self.fix_drift = V.full(check("Fix audio drift (match the sound to the picture)", bool(st("fix_drift", True)),
                                      "If the sound track is longer or shorter than the picture, it's\n"
                                      "stretched slightly so it stays in sync."))
        self.resume = V.full(check("Long videos: keep the finished minutes if stopped",
                                   bool(st("resume_parts", True)),
                                   "Videos over 2 minutes are made in 1-minute parts. If the app is stopped\n"
                                   "(cancel, crash, power cut) it continues after the last finished part,\n"
                                   "and the camera shake isn't measured again."))

        self.out = col.add(OutputCard(self.feature, DEFAULT_FOLDER, [("name_pattern", "File name:", DEFAULT_PATTERN)]))
        root.addWidget(col)
        for w in (self.level, self.mode, self.edges, self.rs_strength, self.codec, self.enc_gpu, self.compare):
            w.currentIndexChanged.connect(self._changed)
        for w in (self.horizon, self.crf):
            w.valueChanged.connect(self._changed)
        for w in (self.rs_fix, self.fix_drift, self.resume):
            w.toggled.connect(self._changed)
        self._changed()

    def _build_preview(self) -> QWidget:
        box = QWidget()
        v = QVBoxLayout(box)
        v.setContentsMargins(0, 4, 0, 0)
        v.setSpacing(6)
        self.p_title = QLabel("Click a video, choose where to look, and press 'Make preview'.")
        self.p_title.setWordWrap(True)
        v.addWidget(self.p_title)
        self.p_stack = QStackedWidget()
        self.p_stack.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.p_note = QLabel(alignment=Qt.AlignCenter)
        self.p_note.setWordWrap(True)
        self.p_note.setMinimumSize(320, 160)
        self.p_note.setStyleSheet("background:#11141a; color:#9ca3af;")
        self.p_stack.addWidget(self.p_note)
        if HAVE_PLAYER:
            self.video = QVideoWidget()
            self.p_stack.addWidget(self.video)
        else:
            self.p_note.setText("Video playback isn't available on this system.")
        v.addWidget(self.p_stack, 1)

        r1 = QHBoxLayout()
        r1.addWidget(QLabel("Preview from:"))
        self.p_pos = QSlider(Qt.Horizontal)
        self.p_pos.setRange(0, 0)
        self.p_pos.setToolTip("Where in the video the preview starts")
        self.p_pos.valueChanged.connect(self._pos_changed)
        r1.addWidget(self.p_pos, 1)
        self.p_time = QLabel("0:00.00")
        self.p_time.setMinimumWidth(70)
        r1.addWidget(self.p_time)
        self.p_len = combo(LENGTHS, float(self._st("preview_length", 5.0)),
                           "How long the preview is. Longer = more to judge, but takes longer to make")
        self.p_len.currentIndexChanged.connect(lambda *_: (self._save_settings(), self._update_preview_state()))
        r1.addWidget(self.p_len)
        v.addLayout(r1)

        r2 = QHBoxLayout()
        self.p_make = QPushButton("Make preview", objectName="primary")
        self.p_make.setToolTip("Stabilises a few seconds from the chosen point and shows the original (left)\n"
                               "next to the stabilised version (right)")
        self.p_make.clicked.connect(self.make_preview)
        self.p_play = QPushButton("▶ Play")
        self.p_play.setToolTip("Play / pause the preview")
        self.p_play.clicked.connect(self._toggle)
        self.p_replay = QPushButton("⟲ Replay")
        self.p_replay.setToolTip("Play the preview from the start")
        self.p_replay.clicked.connect(self._replay)
        self.p_loop = check("Loop", True, "Play the preview over and over")
        self.p_status = QLabel("", objectName="muted")
        r2.addWidget(self.p_make)
        r2.addWidget(self.p_play)
        r2.addWidget(self.p_replay)
        r2.addWidget(self.p_loop)
        r2.addWidget(self.p_status, 1)
        v.addLayout(r2)
        return box

    # ================================================================ settings
    def _settings(self) -> dict:
        return {"stabilize": self.level.currentData(), "stab_mode": self.mode.currentData(),
                "stab_edges": self.edges.currentData(), "rs_fix": self.rs_fix.isChecked(),
                "rolling_shutter": self.rs_strength.currentData(), "horizon": self.horizon.value(),
                "crf": self.crf.value(), "codec": self.codec.currentData(), "enc_gpu": self.enc_gpu.currentData(),
                "compare": self.compare.currentData(), "fix_drift": self.fix_drift.isChecked(),
                "resume_parts": self.resume.isChecked(),
                "enc_speed": self._st("enc_speed", "balanced"), "hwaccel": bool(self._st("hwaccel", True)),
                "gpu_filters": bool(self._st("gpu_filters", True))}

    def _save_settings(self, *_):
        if self._loading:
            return
        f = self.feature
        f.set_setting("last_folder", self.folder_edit.text().strip())
        f.set_setting("recursive", self.recursive.isChecked())
        f.set_setting("preview_length", self.p_len.currentData())
        for k, v in self._settings().items():
            if k not in ("enc_speed", "hwaccel", "gpu_filters"):
                f.set_setting(k, v)

    def reload_settings(self):
        from breezy.core.ui import reload_from
        reload_from(self.feature, {"crf": self.crf, "enc_gpu": self.enc_gpu})

    def _changed(self, *_):
        self.rs_strength.setEnabled(self.rs_fix.isChecked())
        on = bool(self.level.currentData())
        self.mode.setEnabled(on)
        self.edges.setEnabled(on)
        self._save_settings()
        self._update_preview_state()
        self._update_buttons()

    # ================================================================= files
    def _say(self, msg: str):
        self.log.appendPlainText(msg)

    def _browse_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Folder of videos", self.folder_edit.text())
        if d:
            self.folder_edit.setText(d)
            self._reread()

    def _add_files(self):
        from breezy.core.ui import pick_videos
        files = pick_videos(self, self.folder_edit.text().strip())
        if files:
            self._add_paths(files)

    def _add_paths(self, files):
        files = [Path(f) for f in files]
        self.extra_files += [f for f in files if f not in self.extra_files]
        self.removed -= set(files)
        self._say(f"Added {len(files)} file(s).")
        self._reread()

    def _clear_files(self):
        self.folder_edit.setText("")
        self.extra_files, self.removed, self.files = [], set(), []
        self.unchecked.clear()
        self.current = None
        self._stop()
        self._rebuild()
        self._update_preview_state()

    def _drop_folder(self, d):
        self.folder_edit.setText(str(d))
        self._reread()

    def _remove_paths(self, paths):
        self.removed |= set(paths)
        self.extra_files = [f for f in self.extra_files if f not in paths]
        if self.current in paths:
            self.current = None
        self._say(f"Removed {len(paths)} file(s) from the list (nothing is deleted).")
        self._reread()

    def _install_tools(self):
        from breezy.core.ui import install_drop, install_list_tools
        install_drop(self, self._drop_folder, self._add_paths)
        install_list_tools(self.tree, self._path_of_item, self._remove_paths, self._reread)

    def _path_of_item(self, it):
        d = it.data(0, ROLE) if it else None
        return Path(d) if isinstance(d, str) else None

    def _gather_files(self) -> list[Path]:
        text = self.folder_edit.text().strip()
        folder = Path(text) if text else None
        files = []
        if folder and folder.is_dir():
            it = folder.rglob("*") if self.recursive.isChecked() else folder.glob("*")
            skip = {self.out.values()["folder"].lower(), "breezy output"}
            pat = self.out.pattern("name_pattern")
            tail = pat.split("{name}", 1)[1] if pat.startswith("{name}") and pat != "{name}" else ""
            files = sorted(p for p in it if p.is_file() and p.suffix.lower() in VIDEO_EXTS
                           and not (set(x.lower() for x in p.relative_to(folder).parts[:-1]) & skip)
                           and not (tail and p.stem.endswith(tail)))
        return [p for p in files if p not in self.removed] + \
            [p for p in self.extra_files if p not in files and p.is_file() and p not in self.removed]

    def _reread(self, *_):
        self.files = self._gather_files()
        self._save_settings()
        for p in self.files:
            if p not in self.infos:
                self.infos[p] = None
                self.prober.request(p)
        self._rebuild()

    def _probed(self, path: str, info):
        p = Path(path)
        self.infos[p] = info
        it = self._item_for(p)
        if it is not None:
            self._fill(it, p)
        if p == self.current:
            self._select(p)
        self._update_buttons()

    def _use_output(self):
        dlg = OutputPicker(self.tm, self, "stabilize")
        if not dlg.exec():
            return
        files, future = dlg.selection()
        if files:
            self._add_paths([Path(f) for f in files])
        for tid in future:
            self._queue_auto(tid)
        self._update_buttons()

    def _spec(self) -> dict:
        return dict(self._settings(), name_pattern=self.out.pattern("name_pattern"), learn_tag="stab")

    def _queue_auto(self, task_id: str):
        if not has_work(self._settings_obj()):
            QMessageBox.information(self, "Stabilizer", "Stabilising, the wobble fix and horizon levelling are all off.")
            return
        out = output_spec(self.ctx.settings, "stabilize", DEFAULT_FOLDER, self, self.out.values())
        if out is None:
            return
        src = self.tm.get(task_id)
        name = src.title if src else task_id
        self.tm.submit(Task("stabilize.auto", "stabilize", f"Stabilise output of '{name}'",
                            spec=dict(self._spec(), output=out), input_from=task_id))
        self._say(f"Queued: stabilise the files from '{name}' when it finishes (current settings).")

    def _settings_obj(self):
        from .tasks import stab_settings
        return stab_settings(self._settings())

    # ================================================================== list
    def _item_for(self, p: Path):
        for i in range(self.tree.topLevelItemCount()):
            it = self.tree.topLevelItem(i)
            if it.data(0, ROLE) == str(p):
                return it
        return None

    def _rebuild(self):
        was = self.tree.blockSignals(True)
        self.tree.clear()
        for p in self.files:
            it = QTreeWidgetItem(self.tree)
            it.setData(0, ROLE, str(p))
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(0, Qt.Unchecked if p in self.unchecked else Qt.Checked)
            it.setText(0, p.name)
            it.setToolTip(0, str(p))
            self._fill(it, p)
            if p == self.current:
                self.tree.setCurrentItem(it)
        self.tree.blockSignals(was)
        n = len(self.extra_files)
        self.extra_label.setText(f"+ {n} added file(s)" if n else "")
        self.extra_label.setVisible(bool(n))
        self._update_buttons()

    def _fill(self, it: QTreeWidgetItem, p: Path):
        c = theme.colors()
        was = self.tree.blockSignals(True)
        info = self.infos.get(p)
        for col in range(1, 5):
            it.setText(col, "")
        it.setForeground(4, QBrush(QColor(c["muted"])))
        if info is None:
            it.setText(4, "Reading…")
        elif info.error or not info.video:
            it.setText(4, "Could not read" if info.error else "No picture")
            it.setForeground(4, QBrush(QColor(c["warn"])))
        else:
            v = info.video
            it.setText(1, fmt(info.duration, False))
            fps = f" {float(v.fps):.3g} fps" if v.fps else ""
            it.setText(2, f"{v.width}×{v.height}{fps}")
            it.setText(3, _fmt_size(info.size))
            done = any(k[0] == str(p) for k in map(json.loads, self.previews))
            it.setText(4, "Previewed" if done else "")
        self.tree.blockSignals(was)

    def _item_changed(self, it: QTreeWidgetItem, _col: int):
        p = self._path_of_item(it)
        if p is None:
            return
        if it.checkState(0) == Qt.Checked:
            self.unchecked.discard(p)
        else:
            self.unchecked.add(p)
        self._update_buttons()

    def _current_changed(self, cur, _prev):
        p = self._path_of_item(cur)
        self.current = p
        self._select(p)

    def _select(self, p: Path | None):
        info = self.infos.get(p) if p else None
        ok = bool(info and not info.error and info.video and info.duration)
        self.p_pos.blockSignals(True)
        self.p_pos.setRange(0, int(max(0.0, info.duration - 1.0) * 10) if ok else 0)
        self.p_pos.setValue(min(self.p_pos.maximum(), int(info.duration * 10 * 0.3)) if ok else 0)
        self.p_pos.blockSignals(False)
        self._pos_changed()

    def _pos_changed(self, *_):
        self.p_time.setText(fmt(self.p_pos.value() / 10))
        self._update_preview_state()

    # ================================================================= preview
    def _preview_key(self) -> str | None:
        if not self.current:
            return None
        s = {k: v for k, v in self._settings().items() if k in KEYS and k not in ("compare", "resume_parts",
                                                                                  "fix_drift")}
        return json.dumps([str(self.current), self.p_pos.value(), self.p_len.currentData(), s], sort_keys=True)

    def _preview_busy(self) -> bool:
        t = self.tm.get(self.preview_task) if self.preview_task else None
        return bool(t and t.status in ("queued", "running", "paused"))

    def _update_preview_state(self):
        if not hasattr(self, "p_make"):
            return
        busy = self._preview_busy()
        info = self.infos.get(self.current) if self.current else None
        ok = bool(info and not info.error and info.video)
        self.p_make.setEnabled(ok and not busy and has_work(self._settings_obj()))
        self.p_make.setText("Making preview…" if busy else "Make preview")
        have = self.player is not None and self.p_stack.currentIndex() == 1
        self.p_play.setEnabled(have)
        self.p_replay.setEnabled(have)
        if not self.current:
            self.p_title.setText("Click a video, choose where to look, and press 'Make preview'.")
            return
        self.p_title.setText(f"<b>{self.current.name}</b>  ·  original on the left, stabilised on the right")
        key = self._preview_key()
        if busy:
            self.p_status.setText("Stabilising the preview…")
        elif key in self.previews and key == self.preview_key:
            self.p_status.setText("Showing the preview for these settings")
        elif key in self.previews:
            self._show_preview(key)
        elif self.preview_key is not None:
            self.p_status.setText("Settings or position changed - make the preview again")
        else:
            self.p_status.setText("")
            if self.p_stack.currentIndex() == 0 and ok:
                self.p_note.setText("Press 'Make preview' to see a few seconds stabilised next to the original.")

    def make_preview(self):
        if not self.current or self._preview_busy():
            return
        if not self.ff.available:
            QMessageBox.warning(self, "Stabilizer", "FFmpeg was not found. See the Settings page.")
            return
        spec = dict(self._settings(), path=str(self.current), start=self.p_pos.value() / 10,
                    length=self.p_len.currentData())
        t = self.tm.submit(Task("stabilize.preview", "stabilize", f"Preview stabilising {self.current.name}",
                                spec=spec, resumable=False))
        self.preview_task = t.id
        self._pending_key = self._preview_key()
        self._stop()
        self.p_stack.setCurrentIndex(0)
        self.p_note.setText("Making the preview… (it waits for other running tasks)")
        self._update_preview_state()

    def _task_finished(self, task_id: str):
        t = self.tm.get(task_id)
        if not t or t.module != "stabilize":
            return
        if task_id == self.preview_task:
            res = self.tm.results.pop(task_id, None)
            self.preview_task = None
            if t.status == "done" and res:
                self.previews[self._pending_key] = res
                self._show_preview(self._pending_key)
                it = self._item_for(self.current) if self.current else None
                if it is not None:
                    self._fill(it, self.current)
            else:
                self.p_note.setText("The preview couldn't be made" + (f": {t.message}" if t.message else "."))
                self._say(f"Preview: {t.message or t.status}")
            self._update_preview_state()
        else:
            self._update_buttons()

    def _show_preview(self, key: str):
        path = self.previews.get(key)
        if not path or not Path(path).is_file():
            self.previews.pop(key, None)
            return
        self.preview_key = key
        if not HAVE_PLAYER:
            self.p_note.setText(f"Preview saved: {path}")
            return
        if self.player is None:
            self.player = QMediaPlayer(self)
            if QAudioOutput is not None:
                self.audio = QAudioOutput(self)
                self.player.setAudioOutput(self.audio)
            self.player.setVideoOutput(self.video)
            self.player.mediaStatusChanged.connect(self._media_status)
            self.player.playbackStateChanged.connect(
                lambda st: self.p_play.setText("❚❚ Pause" if st == QMediaPlayer.PlayingState else "▶ Play"))
        self.p_stack.setCurrentIndex(1)
        self.player.setSource(QUrl.fromLocalFile(path))
        self.player.play()
        self.p_status.setText("Showing the preview for these settings")
        self.p_play.setEnabled(True)
        self.p_replay.setEnabled(True)

    def _media_status(self, status):
        if status == QMediaPlayer.EndOfMedia and self.p_loop.isChecked():
            self.player.setPosition(0)
            self.player.play()

    def _toggle(self):
        if self.player is None:
            return
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()
        else:
            self.player.play()

    def _replay(self):
        if self.player is not None:
            self.player.setPosition(0)
            self.player.play()

    def _stop(self):
        if self.player is not None:
            self.player.stop()
            self.player.setSource(QUrl())

    # ================================================================== run
    def _jobs(self) -> list[str]:
        out = []
        for p in self.files:
            info = self.infos.get(p)
            if p in self.unchecked or not info or info.error or not info.video:
                continue
            out.append(str(p))
        return out

    def _update_buttons(self):
        if not hasattr(self, "run_btn"):
            return
        jobs = self._jobs()
        work = has_work(self._settings_obj())
        self.run_btn.setEnabled(bool(jobs) and work)
        reading = sum(1 for p in self.files if self.infos.get(p) is None)
        txt = f"{len(jobs)} of {len(self.files)} video(s) ticked" if self.files else ""
        if reading:
            txt += f" · reading {reading}…"
        if not work:
            txt = "Turn on stabilising, the wobble fix or horizon levelling" + (f" · {txt}" if txt else "")
        self.summary.setText(txt)

    def _open_output(self):
        from breezy.core.ui import open_module_output
        open_module_output(self, self.tm, "stabilize", self.out, self.files[0] if self.files else None)

    def run(self):
        jobs = self._jobs()
        if not jobs or not has_work(self._settings_obj()):
            return
        if not self.ff.available:
            QMessageBox.warning(self, "Stabilizer", "FFmpeg was not found. See the Settings page.")
            return
        out = output_spec(self.ctx.settings, "stabilize", DEFAULT_FOLDER, self, self.out.values())
        if out is None:
            return
        self._save_settings()
        title = f"Stabilise {len(jobs)} video(s)" if len(jobs) > 1 else f"Stabilise {Path(jobs[0]).name}"
        t = self.tm.submit(Task("stabilize.run", "stabilize", title, spec=dict(self._spec(), files=jobs, output=out)))
        self._say(f"Queued: {title}.")
        return t

    def theme_changed(self):
        for i in range(self.tree.topLevelItemCount()):
            it = self.tree.topLevelItem(i)
            self._fill(it, Path(it.data(0, ROLE)))

    def shutdown(self):
        self._stop()
        self.prober.shutdown()
