"""Scene comparison: does the end of clip A look like the start of clip B?

For each clip we grab 3 small grayscale frames from its first ~1.5 s and 3 from
its last ~1.5 s, and keep the per-pixel median of each set (the median removes
things passing through, leaving the background). Two clips are compared with
the end-median of one vs the start-median of the next, using

* pixel layout correlation (where light and dark areas are),
* edge correlation (outlines of the background: horizon, buildings, furniture…),
* overall brightness.

Frames won't be identical (clips can be seconds or minutes apart), so the score
is deliberately loose. Sound is NOT compared. Results are cached per file so
re-scanning a folder is fast.
"""
from __future__ import annotations

import base64
import json
import math
import subprocess
import sys
import threading
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable, Iterable, Optional

from breezy.core.ffmpeg import FFmpeg, MediaInfo

W, H = 64, 36
_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
_CACHE_VERSION = 1


def _grab(ffmpeg_exe: str, path: Path, at_end: bool) -> Optional[list[int]]:
    seek = ["-sseof", "-1.6"] if at_end else ["-ss", "0"]
    cmd = [ffmpeg_exe, "-v", "error", "-nostdin", *seek, "-i", str(path), "-an", "-sn",
           "-vf", f"fps=2,scale={W}:{H}:flags=area,format=gray", "-frames:v", "3",
           "-f", "rawvideo", "-"]
    from breezy.core import proc
    try:
        out = proc.run(cmd, timeout=120).stdout
    except (subprocess.TimeoutExpired, OSError):
        return None
    n = len(out) // (W * H)
    if n == 0:
        return None
    frames = [out[i * W * H:(i + 1) * W * H] for i in range(n)]
    return [sorted(px)[len(px) // 2] for px in zip(*frames)]  # per-pixel median


def _ncc(x: list[float], y: list[float]) -> Optional[float]:
    n = len(x)
    mx, my = sum(x) / n, sum(y) / n
    sx = math.sqrt(sum((v - mx) ** 2 for v in x))
    sy = math.sqrt(sum((v - my) ** 2 for v in y))
    if sx < 1e-6 or sy < 1e-6:
        return None  # flat image (e.g. black frame) - no structure to compare
    return sum((a - mx) * (b - my) for a, b in zip(x, y)) / (sx * sy)


def _edges(img: list[int]) -> list[float]:
    out = []
    for yy in range(H - 1):
        row = yy * W
        for xx in range(W - 1):
            p = img[row + xx]
            out.append(abs(img[row + xx + 1] - p) + abs(img[row + W + xx] - p))
    return out


def similarity(a: list[int], b: list[int]) -> float:
    """0 = completely different scene, 1 = same scene/background."""
    ma, mb = sum(a) / len(a), sum(b) / len(b)
    bright = 1 - min(1.0, abs(ma - mb) / 80)
    layout = _ncc(a, b)
    edges = _ncc(_edges(a), _edges(b))
    if layout is None or edges is None:  # flat frames: brightness is all we have
        return bright * 0.6
    return max(0.0, min(1.0, 0.45 * layout + 0.40 * edges + 0.15 * bright))


class SceneStore:
    """Start/end background thumbnails for clips, cached on disk."""

    def __init__(self, cache_file: Path | None = None):
        self.cache_file = cache_file
        self._data: dict[str, list[Optional[str]]] = {}
        self._lock = threading.Lock()
        if cache_file and cache_file.is_file():
            try:
                raw = json.loads(cache_file.read_text("utf-8"))
                if raw.get("v") == _CACHE_VERSION:
                    self._data = raw.get("items", {})
            except (OSError, ValueError):
                pass

    @staticmethod
    def _key(info: MediaInfo) -> str:
        return f"{info.path}|{info.size}|{int(info.mtime)}"

    def has(self, info: MediaInfo) -> bool:
        return self._key(info) in self._data

    def _get(self, info: MediaInfo, idx: int) -> Optional[list[int]]:
        item = self._data.get(self._key(info))
        if not item or not item[idx]:
            return None
        return list(base64.b64decode(item[idx]))

    def link(self, a: MediaInfo, b: MediaInfo) -> Optional[float]:
        """Similarity of the end of a to the start of b (None if unknown)."""
        end_a, start_b = self._get(a, 1), self._get(b, 0)
        if end_a is None or start_b is None:
            return None
        return similarity(end_a, start_b)

    def self_match(self, a: MediaInfo) -> Optional[float]:
        """Similarity of the start of a to its own end: high for a camera that doesn't move."""
        s, e = self._get(a, 0), self._get(a, 1)
        if s is None or e is None:
            return None
        return similarity(s, e)

    def start_match(self, a: MediaInfo, b: MediaInfo) -> Optional[float]:
        """Similarity of the START of a to the START of b (same footage, other version?)."""
        sa, sb = self._get(a, 0), self._get(b, 0)
        if sa is None or sb is None:
            return None
        return similarity(sa, sb)

    def ensure(self, ffmpeg: FFmpeg, infos: Iterable[MediaInfo],
               on_progress: Callable[[int, int, str], None] | None = None,
               is_cancelled: Callable[[], bool] = lambda: False, workers: int = 6) -> None:
        todo = [i for i in infos if not i.error and i.video and not self.has(i)]
        total = len(todo)
        if not total:
            return

        def work(info: MediaInfo):
            if is_cancelled():
                return info, None
            s = _grab(ffmpeg.ffmpeg, info.path, at_end=False)
            e = _grab(ffmpeg.ffmpeg, info.path, at_end=True)
            enc = lambda f: base64.b64encode(bytes(f)).decode() if f else None
            return info, [enc(s), enc(e)]

        from breezy.core import proc
        with proc.pool(workers) as pool:
            for n, (info, item) in enumerate(pool.map(work, todo), 1):
                if item is not None:
                    with self._lock:
                        self._data[self._key(info)] = item
                if on_progress:
                    on_progress(n, total, info.path.name)
                if n % 50 == 0:
                    self.save()
        self.save()

    def save(self) -> None:
        if not self.cache_file:
            return
        try:
            with self._lock:
                payload = json.dumps({"v": _CACHE_VERSION, "items": self._data})
            self.cache_file.write_text(payload, "utf-8")
        except OSError:
            pass
