"""Join a detected group into one file at the highest possible quality.

* copy     - FFmpeg stream copy: the video/audio data is copied bit-for-bit,
             so there is zero quality loss and it is very fast.
* bytes    - byte-split pieces are concatenated back into the original file.
* reencode - only when pieces have different formats. Each piece is scaled /
             padded to a common size and frame rate and encoded at very high
             quality (or truly lossless with FFV1 if chosen).
"""
from __future__ import annotations

import os
import shutil
import tempfile
import threading
from collections import Counter
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Optional

from breezy.core.ffmpeg import Cancelled, FFmpeg, MediaInfo
from breezy.core.outputs import finish, working_dir, working_path
from breezy.core.sync import audio_bitrate, needs_fix, tempo
from .detector import METHOD_BYTES, METHOD_COPY, Group

# Containers where pieces are plain byte streams -> concat protocol is most reliable
_STREAM_CONTAINERS = {".ts", ".mts", ".m2ts", ".vob", ".mpg", ".mpeg"}

QUALITY_PRESETS = {
    "h264": ("H.264 - plays everywhere", ".mp4",
             ["-c:v", "libx264", "-preset", "slow", "-crf", "16", "-pix_fmt", "yuv420p",
              "-c:a", "aac", "-b:a", "320k"]),
    "h265": ("H.265 - smaller files", ".mp4",
             ["-c:v", "libx265", "-preset", "slow", "-crf", "16", "-pix_fmt", "yuv420p10le",
              "-tag:v", "hvc1", "-c:a", "aac", "-b:a", "320k"]),
    "lossless": ("Mathematically lossless FFV1 + FLAC (very large files)", ".mkv",
                 ["-c:v", "ffv1", "-level", "3", "-g", "1", "-slicecrc", "1",
                  "-c:a", "flac"]),
}

_LAYOUTS = {1: "mono", 2: "stereo", 6: "5.1", 8: "7.1"}


@dataclass
class JoinOptions:
    output_dir: Path
    container: str = "same"         # "same", ".mp4", ".mkv", ".mov"
    reencode_preset: str = "h264"
    verify: bool = True
    fix_drift: bool = True            # speed each clip's sound to match its picture (user's choice: on)
    crf: int = 16                     # re-encode quality (lower = better)
    use_gpu: bool = True              # GPU encoder for re-encodes when available (user's choice: on)
    audio_bitrate: str = ""           # "" = automatic (96k per channel)
    drift_threshold: float = 0.1      # seconds
    name_pattern: str = "{name}"


@dataclass
class JoinResult:
    output: Path
    method: str
    message: str
    ok: bool = True


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    n = 2
    while True:
        cand = path.with_name(f"{path.stem} ({n}){path.suffix}")
        if not cand.exists():
            return cand
        n += 1


def _safe_name(name: str) -> str:
    bad = '<>:"/\\|?*'
    out = "".join("_" if c in bad or ord(c) < 32 else c for c in name).strip(" .")
    return out or "joined"


def output_path_for(group: Group, opts: JoinOptions) -> Path:
    if group.method == METHOD_BYTES:
        ext = group.output_ext
    elif group.method == METHOD_COPY:
        ext = group.output_ext if opts.container == "same" else opts.container
    else:
        ext = QUALITY_PRESETS[opts.reencode_preset][1]
        if opts.container in (".mkv",) or opts.reencode_preset == "lossless":
            ext = ".mkv"
    from breezy.core.outputs import apply_pattern
    return unique_path(Path(opts.output_dir) / (_safe_name(apply_pattern(opts.name_pattern, group.output_name)) + ext))


class Joiner:
    def __init__(self, ffmpeg: FFmpeg, log: Callable[[str], None] = print,
                 progress: Callable[[float], None] = lambda f: None,
                 cancel_event: Optional[threading.Event] = None):
        self.ff, self.log, self.progress = ffmpeg, log, progress
        self.cancel = cancel_event or threading.Event()

    # ------------------------------------------------------------------ api
    def join(self, group: Group, opts: JoinOptions) -> JoinResult:
        Path(opts.output_dir).mkdir(parents=True, exist_ok=True)
        out = output_path_for(group, opts)
        inputs = {p.path.resolve() for p in group.parts}
        if out.resolve() in inputs:
            raise RuntimeError("Output would overwrite an input file")
        tmp = working_path(out)
        try:
            n = len(group.parts)
            if group.method == METHOD_BYTES:
                self._stage(f"Rebuilding the original file from {n} pieces")
                self._join_bytes(group, tmp)
                finish(tmp, out)
                return JoinResult(out, group.method, f"Rebuilt original file ({_fmt_size(out.stat().st_size)})")
            self._thr = opts.drift_threshold
            self._abr = opts.audio_bitrate
            self._opts = opts
            fix = opts.fix_drift and any(needs_fix(p, self._thr) for p in group.parts)
            if group.method == METHOD_COPY and fix:
                self._stage(f"Re-syncing the sound and joining {n} clips (video lossless)")
                self._join_copy_fixed(group, tmp)
            elif group.method == METHOD_COPY:
                self._stage(f"Joining {n} clips losslessly")
                try:
                    self._join_copy(group, tmp)
                except RuntimeError as e:
                    if tmp.suffix.lower() == ".mkv" or self.cancel.is_set():
                        raise
                    self.log(f"Stream copy into {tmp.suffix} failed ({e.args[0].splitlines()[0]}); "
                             "retrying with MKV container (still lossless).")
                    _unlink(tmp)
                    out = unique_path(out.with_suffix(".mkv"))
                    tmp = working_path(out)
                    self._join_copy(group, tmp)
            else:
                self._stage(f"Re-encoding {n} clips into one video")
                self._join_reencode(group, tmp, opts.reencode_preset, fix)
            finish(tmp, out)
        except BaseException:
            _unlink(tmp)
            raise

        msg = "Lossless stream copy" if group.method == METHOD_COPY else \
            "Re-encoded: " + QUALITY_PRESETS[opts.reencode_preset][0]
        if fix and group.method != METHOD_BYTES:
            n = sum(needs_fix(p, self._thr) for p in group.parts)
            msg += f"; sound re-synced to the picture ({n} drifting clip(s) fixed)"
            if group.method == METHOD_COPY:
                msg = msg.replace("Lossless stream copy", "Lossless video")
        if opts.verify:
            self._stage("Checking the result's length")
            ok, vmsg = self._verify(group, out, fix)
            return JoinResult(out, group.method, f"{msg}. {vmsg}", ok)
        return JoinResult(out, group.method, msg)

    def _stage(self, text: str):
        from breezy.core.tasks import say_stage
        say_stage(self.progress, text)

    # ------------------------------------------------------------ methods
    def _join_bytes(self, group: Group, out: Path):
        total = group.total_size or 1
        done = 0
        with open(out, "wb") as dst:
            for p in group.parts:
                self.log(f"Appending {p.path.name}")
                with open(p.path, "rb") as src:
                    while chunk := src.read(8 * 1024 * 1024):
                        if self.cancel.is_set():
                            raise Cancelled("Cancelled by user")
                        dst.write(chunk)
                        done += len(chunk)
                        self.progress(done / total)

    def _join_copy(self, group: Group, out: Path):
        src_ext = group.parts[0].path.suffix.lower()
        list_file = None
        if src_ext in _STREAM_CONTAINERS:
            args = ["-fflags", "+genpts", "-i", "concat:" + "|".join(str(p.path) for p in group.parts)]
        else:
            fd, list_file = tempfile.mkstemp(suffix=".txt", prefix="breezy_concat_")
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                for p in group.parts:
                    escaped = str(p.path.resolve()).replace("\\", "/").replace("'", "'\\''")
                    f.write(f"file '{escaped}'\n")
            args = ["-f", "concat", "-safe", "0", "-i", list_file]
        args += ["-map", "0:v?", "-map", "0:a?", "-map", "0:s?", "-c", "copy",
                 "-map_metadata", "0", "-avoid_negative_ts", "make_zero"]
        if out.suffix.lower() in (".mp4", ".m4v", ".mov"):
            args += ["-movflags", "+faststart"]
        args.append(str(out))
        try:
            self.ff.run(args, group.total_duration, self.progress, self.log, self.cancel)
        finally:
            if list_file:
                _unlink(Path(list_file))

    def _join_copy_fixed(self, group: Group, out: Path):
        """Picture: lossless copy, each clip placed at its exact picture length.
        Sound: each clip's sound sped up/down to exactly its picture length, joined, encoded once."""
        work = Path(tempfile.mkdtemp(prefix="breezy_sync_", dir=working_dir(out)))
        try:
            ref = next((p.audio for p in group.parts if p.audio), None)
            sr = ref.sample_rate if ref and ref.sample_rate else 48000
            ch = ref.channels if ref and ref.channels else 2
            vlist, alist = [], []
            n = len(group.parts)
            for i, p in enumerate(group.parts):
                if self.cancel.is_set():
                    raise Cancelled("Cancelled by user")
                vd = p.video.duration if p.video and p.video.duration > 0 else p.duration
                # inpoint 0: start exactly at the first frame (the source's audio lead-in
                # would otherwise shift the picture later by ~0.13 s)
                vlist += [_concat_line(p.path), "inpoint 0", f"duration {vd:.6f}"]
                piece = work / f"a{i:04d}.wav"
                if p.audio:
                    r = tempo(p) if needs_fix(p, self._thr) else 1.0
                    chain = (f"atempo={r:.6f}," if abs(r - 1) > 1e-6 else "") + \
                        f"aresample={sr},apad,atrim=end={vd:.6f},asetpts=PTS-STARTPTS"
                    self.ff.run(["-i", str(p.path), "-map", "0:a:0", "-vn", "-sn", "-dn",
                                 "-af", chain, "-ac", str(ch), "-c:a", "pcm_s16le", str(piece)])
                else:   # clip without sound: silence of the same length
                    self.ff.run(["-f", "lavfi", "-t", f"{vd:.6f}", "-i", f"anullsrc=r={sr}:cl=mono",
                                 "-ac", str(ch), "-c:a", "pcm_s16le", str(piece)])
                alist += [_concat_line(piece), f"duration {vd:.6f}"]
                self.progress(0.6 * (i + 1) / n)
            (work / "v.txt").write_text("\n".join(vlist) + "\n", "utf-8")
            (work / "a.txt").write_text("\n".join(alist) + "\n", "utf-8")
            args = ["-f", "concat", "-safe", "0", "-i", str(work / "v.txt"),
                    "-f", "concat", "-safe", "0", "-i", str(work / "a.txt"),
                    "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy",
                    "-c:a", "aac", "-b:a", self._abr or audio_bitrate(group.parts[0]),
                    "-map_metadata", "0"]   # no ts shifting: the encoder's lead-in is handled by the edit list
            if out.suffix.lower() in (".mp4", ".m4v", ".mov"):
                args += ["-movflags", "+faststart"]
            args.append(str(out))
            self.ff.run(args, group.total_duration, lambda f: self.progress(0.6 + 0.4 * f), self.log, self.cancel)
        finally:
            shutil.rmtree(work, ignore_errors=True)

    def _join_reencode(self, group: Group, out: Path, preset: str, fix: bool = False):
        parts = group.parts
        # Target = the largest frame size, most common frame rate (weighted by duration)
        vids = [p.video for p in parts if p.video]
        if not vids:
            raise RuntimeError("No video streams to join")
        big = max(vids, key=lambda v: v.width * v.height)
        W, H = big.width + big.width % 2, big.height + big.height % 2
        fps_votes = Counter()
        for p in parts:
            if p.video and p.video.fps:
                fps_votes[p.video.fps] += p.duration or 1
        fps = fps_votes.most_common(1)[0][0] if fps_votes else 30
        any_audio = any(p.audio for p in parts)
        ch = max((p.audio.channels for p in parts if p.audio), default=2)
        layout = _LAYOUTS.get(ch, "stereo")
        sr = max((p.audio.sample_rate for p in parts if p.audio), default=48000)

        args, filters, concat_in = [], [], []
        n_inputs = 0
        for i, p in enumerate(parts):
            args += ["-i", str(p.path)]
            n_inputs += 1
        for i, p in enumerate(parts):
            filters.append(
                f"[{i}:v:0]scale={W}:{H}:force_original_aspect_ratio=decrease:flags=lanczos,"
                f"pad={W}:{H}:(ow-iw)/2:(oh-ih)/2,setsar=1,fps={fps}[v{i}]")
            vlabel = f"[v{i}]"
            if any_audio:
                if p.audio:
                    src = f"[{i}:a:0]"
                else:  # silent filler so concat stays in sync
                    args += ["-f", "lavfi", "-t", f"{p.duration:.3f}",
                             "-i", f"anullsrc=r={sr}:cl={layout}"]
                    src = f"[{n_inputs}:a:0]"
                    n_inputs += 1
                if fix and p.audio:   # sound sped to exactly the picture length
                    vd = p.video.duration if p.video and p.video.duration > 0 else p.duration
                    r = tempo(p) if needs_fix(p, self._thr) else 1.0
                    filters.append(f"{src}atempo={r:.6f},aresample={sr},apad,atrim=end={vd:.6f},asetpts=PTS-STARTPTS,"
                                   f"aformat=sample_rates={sr}:channel_layouts={layout}[a{i}]")
                else:
                    filters.append(f"{src}aresample={sr}:async=1,aformat=sample_rates={sr}:channel_layouts={layout}[a{i}]")
                concat_in.append(f"{vlabel}[a{i}]")
            else:
                concat_in.append(vlabel)
        a = 1 if any_audio else 0
        filters.append("".join(concat_in) + f"concat=n={len(parts)}:v=1:a={a}" + ("[v][a]" if a else "[v]"))
        args += ["-filter_complex", ";".join(filters), "-map", "[v]"]
        if a:
            args += ["-map", "[a]"]
        o = self._opts
        if preset == "lossless":
            enc = list(QUALITY_PRESETS[preset][2])
        else:
            from breezy.core.encoders import video_args
            codec = "hevc" if preset == "h265" else "h264"
            pix = ["-pix_fmt", "yuv420p10le"] if codec == "hevc" and not o.use_gpu else ["-pix_fmt", "yuv420p"]
            enc = video_args(codec, o.crf, o.use_gpu, pix) + (["-tag:v", "hvc1"] if codec == "hevc" else []) + \
                ["-c:a", "aac", "-b:a", o.audio_bitrate or "320k"]
        if out.suffix.lower() == ".mkv":
            enc = [x for x in enc if x not in ("-tag:v", "hvc1")]
        args += enc + ["-map_metadata", "0"]
        if out.suffix.lower() in (".mp4", ".mov"):
            args += ["-movflags", "+faststart"]
        args.append(str(out))
        self.log(f"Re-encoding to {W}x{H} @ {float(fps):.3f} fps")
        self.ff.run(args, group.total_duration, self.progress, self.log, self.cancel)

    # ------------------------------------------------------------- verify
    def _verify(self, group: Group, out: Path, fixed: bool = False) -> tuple[bool, str]:
        info = self.ff.probe(out)
        if info.error:
            return False, f"WARNING: output could not be read back ({info.error})"
        if fixed and info.drift is not None and abs(info.drift) > 0.1 + 0.02 * len(group.parts):
            return False, f"WARNING: sound and picture still differ by {info.drift:+.2f} s"
        expected = group.total_duration
        if expected <= 0:
            return True, f"Output duration {_fmt_dur(info.duration)}"
        diff = abs(info.duration - expected)
        tol = max(1.5, expected * 0.005)
        if diff <= tol:
            return True, f"Verified: {_fmt_dur(info.duration)} (expected {_fmt_dur(expected)})"
        return False, (f"WARNING: output is {_fmt_dur(info.duration)} but pieces add up to "
                       f"{_fmt_dur(expected)} - please check the result")


def _concat_line(path: Path) -> str:
    return "file '" + str(Path(path).resolve()).replace("\\", "/").replace("'", "'\\''") + "'"


def _unlink(p: Path):
    try:
        p.unlink()
    except OSError:
        pass


def _fmt_dur(s: float) -> str:
    s = int(round(s))
    return f"{s // 3600}:{s % 3600 // 60:02d}:{s % 60:02d}"


def _fmt_size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if n < 1024 or unit == "TB":
            return f"{n:.1f} {unit}" if unit != "B" else f"{n} B"
        n /= 1024
