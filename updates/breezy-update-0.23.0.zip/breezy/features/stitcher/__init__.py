"""Stitcher: find split video pieces in a folder and join them at maximum quality."""
from breezy.core.plugin import Feature
from . import tasks  # noqa: F401  (registers the task runners)


class StitcherFeature(Feature):
    id = "stitcher"
    name = "Stitcher"
    description = ("Find videos that are pieces of one recording (time-named clips, GoPro chapters, "
                   "\"part 1/part 2\", DVD VOBs, .001/.002 files…) and join them - losslessly when possible.")
    order = 10
    icon = "stitch"

    def create_widget(self):
        from .widget import StitcherWidget
        self.widget = StitcherWidget(self)
        return self.widget

    def theme_changed(self):
        self.widget._rebuild_tree()


FEATURE = StitcherFeature
