"""Figure out which files in a folder are pieces of one larger video.

Evidence used, combined into a confidence score per group:

* Start time in the file name (dashcams, action cams, HitPaw exports...):
  e.g. 19700101001713_60_A_... or 20240501_142233.mp4. Each clip's real,
  measured length is added to its start time to find where it ends; the
  next clip must start within `max_gap` seconds of that. Files that differ
  only in the time stamp form one "series" (different processing versions,
  clip-length sets, cameras... stay separate).
* Filename patterns
    - strong: GoPro chapters (GH01xxxx, GX02xxxx, GOPRxxxx/GPxxxxxx),
              "part 1", "pt2", "CD1", "disc 2", "seg03", "chunk_4"...,
              byte-split files (movie.mp4.001, .002 ...)
    - weak:   a trailing number (VTS_01_1, Recording_002, DJI_0007)
* Timestamps inside the file (creation time) or file modified times.
* Stream signature: identical codec / resolution / frame rate / audio format
  means the pieces can be joined losslessly with a stream copy.
* Duplicate copies ("clip(1).mp4", "clip (2).mp4") of the same size are skipped.
"""
from __future__ import annotations

import calendar
import re
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable, Iterable, Optional

from breezy.core.ffmpeg import FFmpeg, MediaInfo
from .scenes import SceneStore

VIDEO_EXTS = {".mp4", ".m4v", ".mov", ".mkv", ".avi", ".wmv", ".asf", ".flv", ".webm",
              ".ts", ".mts", ".m2ts", ".mpg", ".mpeg", ".vob", ".3gp", ".mxf", ".dv"}

DEFAULT_MAX_GAP = 150.0       # seconds of dead time allowed between consecutive clips
MAX_OVERLAP = 2.0             # clips may appear to overlap this much (1-s name rounding)
FPS_TOLERANCE = 0.005         # 59.99 vs 60 fps counts as the same frame rate

# Confidence scoring (see make_group)
BASE_CONFIDENCE = {"name_time": 0.35, "strong": 0.5, "weak": 0.25, "time_only": 0.2, "manual": 0.6}
AUTO_SELECT_CONFIDENCE = 0.6  # groups at/above this are ticked by default
MIN_CONFIDENCE = 0.35         # groups below this are not shown

METHOD_COPY = "copy"         # lossless stream copy
METHOD_REENCODE = "reencode" # formats differ, must re-encode
METHOD_BYTES = "bytes"       # raw byte-split pieces, concatenate bytes

# ---------------------------------------------------------------- name rules
_GOPRO_NEW = re.compile(r"^(G[HXL])(\d{2})(\d{4})$", re.I)
_GOPRO_OLD_FIRST = re.compile(r"^GOPR(\d{4})$", re.I)
_GOPRO_OLD_CHAP = re.compile(r"^GP(\d{2})(\d{4})$", re.I)
_PART_WORD = re.compile(
    r"^(?P<base>.*?)[\s._\-\[\(]*"
    r"(?<![A-Za-z])(?:part|pt|cd|disc|disk|seg|segment|chunk|piece|split)[\s._\-#]*"
    r"(?P<n>\d{1,3})(?:\s*(?:of|-|_|/)\s*\d{1,3})?[\]\)]?(?P<tail>.*)$", re.I)
_TRAILING_NUM = re.compile(r"^(?P<base>.*?\D)(?P<n>\d{1,4})$")
_RESOLUTION_END = re.compile(r"\d{2,5}[xX]\d{2,5}$")       # ..._3840x2160 is not a part number
_BYTE_SPLIT = re.compile(r"^(?P<base>.+\.[A-Za-z0-9]{2,4})\.(?P<n>\d{3})$")
_COPY_MARK = re.compile(r"\s*\((\d{1,3})\)")                # "(1)", " (2)" added by Windows/browsers
_NAME_TIMES = [
    # 20240501142233, 20240501_142233, 20240501-142233, 20240501T142233
    re.compile(r"(?<!\d)(?P<Y>(?:19|20)\d{2})(?P<m>\d{2})(?P<d>\d{2})[_\-T ]?"
               r"(?P<H>\d{2})(?P<M>\d{2})(?P<S>\d{2})(?!\d)"),
    # 2024-05-01 14.22.33, 2024_05_01_14-22-33, 2024-05-01T14:22:33
    re.compile(r"(?<!\d)(?P<Y>(?:19|20)\d{2})[-_.](?P<m>\d{2})[-_.](?P<d>\d{2})[ _T\-]+"
               r"(?P<H>\d{2})[-_.:](?P<M>\d{2})[-_.:](?P<S>\d{2})(?!\d)"),
]


@dataclass
class NameMatch:
    key: tuple
    index: int
    strength: str   # "strong" | "weak"
    label: str
    base: str       # suggested output base name


@dataclass
class NameTime:
    start: float     # seconds (relative scale is what matters; camera clock may be unset)
    series: str      # file name with the time removed -> identifies one camera/export series
    text: str        # the time as written in the name


def _norm(s: str) -> str:
    return re.sub(r"[\s._\-]+", " ", s).strip().lower()


def strip_copy_marks(stem: str) -> str:
    return _COPY_MARK.sub("", stem)


def has_copy_mark(stem: str) -> bool:
    return bool(_COPY_MARK.search(stem))


def name_time(path: Path) -> Optional[NameTime]:
    """Start time written in the file name, if any."""
    stem = path.stem
    for rx in _NAME_TIMES:
        m = rx.search(stem)
        if not m:
            continue
        try:
            parts = [int(m.group(k)) for k in ("Y", "m", "d", "H", "M", "S")]
            datetime(*parts)  # validates ranges
        except ValueError:
            continue
        start = float(calendar.timegm((*parts, 0, 0, 0)))
        series = strip_copy_marks(stem[:m.start()] + "{t}" + stem[m.end():])
        return NameTime(start, _norm(series) + "|" + path.suffix.lower(), m.group(0))
    return None


def match_name(path: Path) -> Optional[NameMatch]:
    stem, ext, folder = path.stem, path.suffix.lower(), str(path.parent).lower()
    m = _GOPRO_NEW.match(stem)
    if m:
        pre, chap, num = m.group(1).upper(), int(m.group(2)), m.group(3)
        return NameMatch((folder, "gopro", pre, num, ext), chap, "strong", "GoPro chapters", stem + "_joined")
    m = _GOPRO_OLD_FIRST.match(stem)
    if m:
        return NameMatch((folder, "gopro-old", m.group(1), ext), 0, "strong", "GoPro chapters", stem + "_joined")
    m = _GOPRO_OLD_CHAP.match(stem)
    if m:
        return NameMatch((folder, "gopro-old", m.group(2), ext), int(m.group(1)), "strong",
                         "GoPro chapters", f"GOPR{m.group(2)}_joined")
    m = _PART_WORD.match(stem)
    if m and (m.group("base").strip(" ._-[(") or m.group("tail").strip()):
        base = m.group("base").rstrip(" ._-[(") or "joined"
        return NameMatch((folder, "part", _norm(m.group("base")), _norm(m.group("tail")), ext),
                         int(m.group("n")), "strong", "Numbered parts", base + m.group("tail").rstrip(" ._-"))
    if _RESOLUTION_END.search(stem):
        return None
    m = _TRAILING_NUM.match(stem)
    if m:
        base = m.group("base").rstrip(" ._-")
        if base:
            return NameMatch((folder, "num", _norm(m.group("base")), ext),
                             int(m.group("n")), "weak", "Numbered files", stem + "_joined")
    return None


# ---------------------------------------------------------------- groups
@dataclass
class Group:
    parts: list[MediaInfo]
    reason: str
    confidence: float
    method: str
    output_name: str
    output_ext: str
    issues: list[str] = field(default_factory=list)
    evidence: list[str] = field(default_factory=list)
    selected: bool = False

    def __post_init__(self):
        self.selected = self.confidence >= AUTO_SELECT_CONFIDENCE

    @property
    def total_duration(self) -> float:
        return sum(p.duration for p in self.parts)

    @property
    def total_size(self) -> int:
        return sum(p.size for p in self.parts)

    @property
    def auto_selected(self) -> bool:
        return self.confidence >= AUTO_SELECT_CONFIDENCE

    def refresh_method(self) -> None:
        """Recompute method/issues after the user edits the part list."""
        if self.method == METHOD_BYTES:
            return
        self.method, diff = compatibility(self.parts)
        self.issues = [i for i in self.issues if not i.startswith("Formats differ")]
        if diff:
            self.issues.insert(0, "Formats differ - will re-encode: " + diff)


@dataclass
class Duplicate:
    info: MediaInfo        # the copy that is skipped
    original: MediaInfo    # the file used instead


@dataclass
class Detection:
    groups: list[Group]
    singles: list[MediaInfo]
    duplicates: list[Duplicate]


def _sig_without_fps(i: MediaInfo) -> tuple:
    return tuple(x[:-1] if isinstance(x, tuple) and x and x[0] == "v" else x for x in i.signature())


def same_format(a: MediaInfo, b: MediaInfo) -> bool:
    """Can a and b be joined losslessly? (frame rates within 0.5% count as equal)"""
    if _sig_without_fps(a) != _sig_without_fps(b):
        return False
    fa = float(a.video.fps) if a.video and a.video.fps else None
    fb = float(b.video.fps) if b.video and b.video.fps else None
    if fa is None or fb is None:
        return fa == fb
    return abs(fa - fb) <= FPS_TOLERANCE * max(fa, fb)


def compatibility(parts: list[MediaInfo]) -> tuple[str, str]:
    ref = parts[0]
    diffs = [f"{p.path.name}: {p.describe()} vs {ref.describe()}"
             for p in parts[1:] if not same_format(ref, p)]
    if not diffs:
        return METHOD_COPY, ""
    return METHOD_REENCODE, "; ".join(diffs[:3])


def _gap_ok(gap: float, max_gap: float) -> bool:
    return -MAX_OVERLAP <= gap <= max_gap


def continuity(a: MediaInfo, b: MediaInfo, max_gap: float = DEFAULT_MAX_GAP) -> Optional[bool]:
    """True if b starts within max_gap of where a ended, False if not, None if unknown.

    Uses a start time in the file names when present (most reliable), otherwise
    the creation time stored in the file, otherwise the file modified times.
    """
    na, nb = name_time(a.path), name_time(b.path)
    if na and nb and a.duration:
        return _gap_ok(nb.start - (na.start + a.duration), max_gap)
    verdicts = []
    if a.creation_time and b.creation_time and a.duration:
        if a.creation_time != b.creation_time:  # some cams stamp every chapter with the same time
            verdicts.append(_gap_ok(b.creation_time - (a.creation_time + a.duration), max_gap))
    if a.mtime and b.mtime and b.duration and a.mtime != b.mtime:
        verdicts.append(_gap_ok((b.mtime - b.duration) - a.mtime, max_gap))
    if not verdicts:
        return None
    return any(verdicts)


def _sort_key_time(p: MediaInfo):
    nt = name_time(p.path)
    if nt:
        start = nt.start
    elif p.creation_time is not None:
        start = p.creation_time
    else:
        start = p.mtime - p.duration if p.mtime else 0
    return (start, p.path.name.lower())


def _gap_text(parts: list[MediaInfo]) -> str:
    gaps = []
    for a, b in zip(parts, parts[1:]):
        na, nb = name_time(a.path), name_time(b.path)
        if na and nb:
            gaps.append(nb.start - (na.start + a.duration))
    if not gaps:
        return ""
    return f"largest gap between clips {max(0.0, max(gaps)):.0f}s"


def _day(p: MediaInfo) -> Optional[int]:
    """Calendar day number of the clip's start (name time, else stored time, else file time)."""
    nt = name_time(p.path)
    if nt:
        t = nt.start
    elif p.creation_time is not None:
        t = p.creation_time
    elif p.mtime:
        t = p.mtime - p.duration
    else:
        return None
    return int(t // 86400)


def _same_length(parts: list[MediaInfo]) -> bool:
    """All clips the same length (the last one may be shorter, as when a recording stops)."""
    body = [p.duration for p in parts[:-1] if p.duration > 0]
    if not body or len(body) < len(parts) - 1:
        return False
    ref = sorted(body)[len(body) // 2]
    tol = max(1.0, ref * 0.02)
    return all(abs(d - ref) <= tol for d in body) and parts[-1].duration <= ref + tol


def scene_delta(score: float) -> float:
    if score >= 0.75:
        return 0.20
    if score >= 0.55:
        return 0.10
    if score >= 0.35:
        return 0.0
    return -0.15


def make_group(parts: list[MediaInfo], reason: str, kind: str, base_name: str,
               numbers: list[int] | None = None, max_gap: float = DEFAULT_MAX_GAP,
               scenes: SceneStore | None = None, scene_weight: float = 1.0) -> Group:
    """Build a group and score how sure we are that it is one recording.

    evidence entries read like "Same date +10%" so the user can see why.
    """
    method, diff = compatibility(parts)
    conf = BASE_CONFIDENCE[kind]
    issues, evidence = [], [f"{reason} (base {conf:.0%})"]

    def add(label: str, delta: float):
        nonlocal conf
        conf += delta
        evidence.append(f"{label} {delta:+.0%}" if delta else label)

    links = [continuity(a, b, max_gap) for a, b in zip(parts, parts[1:])]
    known = [l for l in links if l is not None]
    if known:
        frac = sum(known) / len(known)
        label = ("Timestamps continuous" if frac == 1 else "Timestamps NOT continuous" if frac == 0
                 else f"Timestamps continuous for {sum(known)}/{len(known)} joins")
        gt = _gap_text(parts)
        add(label + (f" ({gt})" if gt else ""), 0.25 * frac - 0.25 * (1 - frac))

    days = [_day(p) for p in parts]
    if all(d is not None for d in days):
        span = max(days) - min(days)
        if span == 0:
            add("Same date", 0.10)
        elif span == 1:
            add("Within ±1 day", 0.04)
        else:
            evidence.append(f"Dates span {span} days")

    if len(parts) >= 2 and _same_length(parts):
        add("Same clip length", 0.10)

    if method == METHOD_COPY:
        add("Identical formats", 0.05)
    else:
        add("Formats differ", -0.15)
        issues.append("Formats differ - will re-encode: " + diff)

    if scenes is not None and len(parts) >= 2:
        sims = [scenes.link(a, b) for a, b in zip(parts, parts[1:])]
        known_s = [x for x in sims if x is not None]
        if known_s:
            avg = sum(known_s) / len(known_s)
            add(f"Scene match {avg:.0%}", scene_delta(avg) * scene_weight)
            worst = min(known_s)
            if worst < 0.35 <= avg:
                i = sims.index(worst)
                issues.append(f"Scene changes a lot between {parts[i].path.name} and "
                              f"{parts[i + 1].path.name} (match {worst:.0%})")

    cams = [different_camera(a, b, scenes) for a, b in zip(parts, parts[1:])]
    if any(cams):
        i = cams.index(True)
        issues.append(f"{parts[i].path.name} and {parts[i + 1].path.name} look like different cameras")
        add("Different cameras", -0.30)

    if numbers:
        expected = list(range(numbers[0], numbers[0] + len(numbers)))
        if numbers != expected:
            missing = sorted(set(range(numbers[0], numbers[-1] + 1)) - set(numbers))
            if missing:
                issues.append("Possible missing piece(s): #" + ", #".join(map(str, missing)))
                add("Numbering has gaps", -0.10)
    bad = [p.path.name for p in parts if p.duration <= 0]
    if bad:
        issues.append("Could not read duration of: " + ", ".join(bad))
    return Group(parts=parts, reason=reason, confidence=max(0.0, min(1.0, conf)), method=method,
                 output_name=base_name or parts[0].path.stem, output_ext=parts[0].path.suffix,
                 issues=issues, evidence=evidence)


def same_footage(a: MediaInfo, b: MediaInfo, scenes: SceneStore | None) -> bool:
    """Two versions of ONE video (e.g. exported with different enhancement models)?

    Same length, the same opening picture, and the end of `a` looks much less
    like the start of `b` than the two openings look like each other. (For real
    consecutive pieces of a still scene, the end of `a` matches the start of `b`
    at least as well, so they are not affected.)
    """
    if scenes is None or abs(a.duration - b.duration) > 0.25:
        return False
    starts, cont = scenes.start_match(a, b), scenes.link(a, b)
    return starts is not None and cont is not None and starts >= 0.8 and starts - cont >= 0.25


STILL_CAMERA = 0.6     # a clip whose start and end look this alike was filmed by a camera that doesn't move
CAMERA_GAP = 0.25      # ...and if the next clip looks this much less alike, it's another camera


def different_camera(a: MediaInfo, b: MediaInfo, scenes: SceneStore | None) -> bool:
    """Were a and b filmed by two different cameras (e.g. two cameras on the same subject, with
    timestamps that happen to line up)?

    - the files name different cameras (make/model/serial tags), or
    - both cameras stand still (each clip's start looks like its own end) but the end of a doesn't
      look like the start of b - the background changed between the clips (or one camera stands
      still and the next clip looks completely different).
    Moving cameras (phones, action cams) change scene all the time, so they're not judged by background.
    """
    if a.camera and b.camera and a.camera != b.camera:
        return True
    if scenes is None or not hasattr(scenes, "self_match"):
        return False
    link, sa, sb = scenes.link(a, b), scenes.self_match(a), scenes.self_match(b)
    if link is None or sa is None or sb is None:
        return False
    if sa >= STILL_CAMERA and sb >= STILL_CAMERA:          # two still cameras: the background must carry on
        return link < 0.45 and link < min(sa, sb) - CAMERA_GAP
    still = max(sa, sb)                                     # one still camera: only a clearly different picture
    return still >= STILL_CAMERA and link < 0.3 and link < still - 2 * CAMERA_GAP


def _chains(items: list, can_follow, score) -> list[list]:
    """Build recordings from time-sorted items, keeping several open at once: each item continues the
    open recording it fits best (can_follow(last, item)), or starts a new one. So clips from two cameras
    whose times interleave or overlap end up as two recordings instead of one mixed one."""
    runs: list[list] = []
    for it in items:
        cands = [r for r in runs if can_follow(r[-1], it)]
        if cands:
            max(cands, key=lambda r: score(r[-1], it)).append(it)
        else:
            runs.append([it])
    return runs


def _split_runs(parts: list[MediaInfo], max_gap: float,
                scenes: SceneStore | None = None) -> list[list[MediaInfo]]:
    """Split a sequence wherever timestamps say there is a break."""
    runs, cur = [], [parts[0]]
    for a, b in zip(parts, parts[1:]):
        if (continuity(a, b, max_gap) is False or not same_format(a, b)
                or same_footage(a, b, scenes) or (_keep_cameras and different_camera(a, b, scenes))):
            runs.append(cur)
            cur = []
        cur.append(b)
    runs.append(cur)
    return runs


def find_duplicates(infos: list[MediaInfo]) -> tuple[list[MediaInfo], list[Duplicate], dict]:
    """Drop exact copies like 'clip(1).mp4' (same name apart from the copy mark, same size).

    Returns (kept, duplicates, conflicts) where conflicts maps a kept file to
    same-named copies of a *different* size (shown to the user, not used).
    """
    buckets: dict[tuple, list[MediaInfo]] = defaultdict(list)
    for i in infos:
        buckets[(str(i.path.parent).lower(), strip_copy_marks(i.path.stem).lower(),
                 i.path.suffix.lower())].append(i)
    kept, dups, conflicts = [], [], {}
    for items in buckets.values():
        if len(items) == 1:
            kept.append(items[0])
            continue
        # the original = no copy mark, else the lowest copy number
        items.sort(key=lambda i: (has_copy_mark(i.path.stem), i.path.name.lower()))
        orig = items[0]
        kept.append(orig)
        for other in items[1:]:
            if other.size == orig.size:
                dups.append(Duplicate(other, orig))
            else:
                conflicts.setdefault(id(orig), []).append(other)
                kept.append(other)
    return kept, dups, conflicts


def _series_title(parts: list[MediaInfo], nt: NameTime) -> str:
    stem = strip_copy_marks(parts[0].path.stem)
    pretty = (datetime(1970, 1, 1) + timedelta(seconds=nt.start)).strftime("%Y-%m-%d %H.%M.%S")
    name = stem.replace(nt.text, pretty, 1)
    return re.sub(r"\s+", " ", name).strip(" _-") + "_joined"


_keep_cameras = True


def detect_groups(infos: Iterable[MediaInfo], max_gap: float = DEFAULT_MAX_GAP,
                  scenes: SceneStore | None = None, auto_select: float = AUTO_SELECT_CONFIDENCE,
                  scene_weight: float = 1.0, keep_cameras: bool = True) -> Detection:
    global _keep_cameras
    _keep_cameras = keep_cameras
    infos = [i for i in infos if not i.error]
    infos, duplicates, conflicts = find_duplicates(infos)
    conflict_ids = {id(o) for lst in conflicts.values() for o in lst}

    groups: list[Group] = []
    used: set[Path] = set()

    # 1) Start time in the file name -> chain each series by real clip length
    series: dict[tuple, list[tuple[NameTime, MediaInfo]]] = defaultdict(list)
    for i in infos:
        if id(i) in conflict_ids:
            continue  # different-size copy of a file that is used; listed separately
        nt = name_time(i.path)
        if nt:
            series[(str(i.path.parent).lower(), nt.series)].append((nt, i))

    def _follow_named(prev, cur):
        (na, a), (nb, b) = prev, cur
        # a real frame-rate/format change starts a new group (keeps joins lossless)
        return (a.duration > 0 and _gap_ok(nb.start - (na.start + a.duration), max_gap)
                and same_format(a, b) and not (_keep_cameras and different_camera(a, b, scenes)))

    def _link_score(a, b):
        sim = scenes.link(a, b) if scenes is not None else None
        return sim if sim is not None else 0.0

    for members in series.values():
        members.sort(key=lambda t: (t[0].start, t[1].path.name.lower()))
        for run in _chains(members, _follow_named, lambda p, c: _link_score(p[1], c[1])):
            if len(run) > 1:
                parts = [m[1] for m in run]
                g = make_group(parts, "Start time in file names", "name_time",
                               _series_title(parts, run[0][0]), max_gap=max_gap, scenes=scenes, scene_weight=scene_weight)
                for p in parts:
                    for c in conflicts.get(id(p), []):
                        g.issues.append(f"{c.path.name} has the same name but a different size "
                                        f"- not used (using {p.path.name})")
                groups.append(g)
                used.update(p.path for p in parts)
    named_time = {i.path for i in infos if name_time(i.path)}

    # 2) Filename patterns (GoPro, part 1/2, numbered files)
    by_key: dict[tuple, list[tuple[NameMatch, MediaInfo]]] = defaultdict(list)
    for info in infos:
        if info.path in used or info.path in named_time or id(info) in conflict_ids:
            continue
        nm = match_name(info.path)
        if nm:
            by_key[nm.key].append((nm, info))
    for key, members in by_key.items():
        if len(members) < 2:
            continue
        members.sort(key=lambda t: (t[0].index, t[1].path.name.lower()))
        nm0 = members[0][0]
        parts = [m[1] for m in members]
        nums = [m[0].index for m in members]
        if len(set(nums)) != len(nums):
            continue  # duplicate numbers -> not a clean sequence
        if nm0.strength == "strong":
            g = make_group(parts, nm0.label, "strong", nm0.base, nums, max_gap=max_gap, scenes=scenes, scene_weight=scene_weight)
            groups.append(g)
            used.update(p.path for p in parts)
        else:
            # weak names (e.g. DJI_0001, DJI_0002) - only consecutive, continuous runs count
            idx_of = {m[1].path: m[0].index for m in members}
            for run_parts in _split_runs(parts, max_gap, scenes):
                if len(run_parts) < 2:
                    continue
                run_nums = [idx_of[p.path] for p in run_parts]
                if run_nums != list(range(run_nums[0], run_nums[0] + len(run_parts))):
                    continue
                g = make_group(run_parts, nm0.label, "weak", nm0.base, run_nums, max_gap=max_gap,
                               scenes=scenes, scene_weight=scene_weight)
                if g.confidence >= MIN_CONFIDENCE:
                    groups.append(g)
                    used.update(p.path for p in run_parts)

    # 3) Timestamp-only chains for anything left (creation time / modified time)
    rest = [i for i in infos if i.path not in used and i.path not in named_time
            and id(i) not in conflict_ids]
    by_folder_sig: dict[tuple, list[MediaInfo]] = defaultdict(list)
    for i in rest:
        by_folder_sig[(str(i.path.parent), _sig_without_fps(i))].append(i)
    def _follow_time(a, b):
        return bool(continuity(a, b, max_gap) and same_format(a, b) and not same_footage(a, b, scenes)
                    and not (_keep_cameras and different_camera(a, b, scenes)))

    for items in by_folder_sig.values():
        if len(items) < 2:
            continue
        items.sort(key=_sort_key_time)
        for cur in _chains(items, _follow_time, _link_score):
            if len(cur) > 1:
                groups.append(make_group(cur, "Continuous recording (timestamps)", "time_only",
                                         cur[0].path.stem + "_joined", max_gap=max_gap,
                                         scenes=scenes, scene_weight=scene_weight))

    groups = [g for g in groups if g.confidence >= MIN_CONFIDENCE]
    used = {p.path for g in groups for p in g.parts}
    singles = [i for i in infos if i.path not in used]
    groups.sort(key=lambda g: (-g.confidence, str(g.parts[0].path).lower()))
    for g in groups:
        g.selected = g.confidence >= auto_select
    return Detection(groups, singles, duplicates)


def detect_byte_splits(paths: Iterable[Path]) -> list[Group]:
    """movie.mp4.001, movie.mp4.002, ... -> join bytes (always lossless)."""
    buckets: dict[tuple, list[tuple[int, Path]]] = defaultdict(list)
    for p in paths:
        m = _BYTE_SPLIT.match(p.name)
        if m and Path(m.group("base")).suffix.lower() in VIDEO_EXTS:
            buckets[(str(p.parent), m.group("base"))].append((int(m.group("n")), p))
    groups = []
    for (_, base), items in buckets.items():
        if len(items) < 2:
            continue
        items.sort()
        nums = [n for n, _ in items]
        parts = []
        for _, p in items:
            st = p.stat()
            parts.append(MediaInfo(path=p, size=st.st_size, mtime=st.st_mtime))
        issues = []
        missing = sorted(set(range(nums[0], nums[-1] + 1)) - set(nums))
        if missing or nums[0] not in (0, 1):
            issues.append("Sequence looks incomplete - check all pieces are present")
        g = Group(parts=parts, reason="Byte-split file (.001, .002…)", confidence=0.95 if not issues else 0.6,
                  method=METHOD_BYTES, output_name=Path(base).stem, output_ext=Path(base).suffix,
                  issues=issues, evidence=["Byte-split file (.001, .002…)"])
        groups.append(g)
    return groups


def list_candidates(folder: Path, recursive: bool) -> tuple[list[Path], list[Path]]:
    """(video files, byte-split pieces) in folder."""
    it = folder.rglob("*") if recursive else folder.glob("*")
    videos, splits = [], []
    for p in it:
        if not p.is_file():
            continue
        if p.suffix.lower() in VIDEO_EXTS:
            videos.append(p)
        elif _BYTE_SPLIT.match(p.name):
            splits.append(p)
    return sorted(videos), sorted(splits)


@dataclass
class ScanResult:
    infos: list[MediaInfo]          # every probed video (kept so we can regroup instantly)
    byte_groups: list[Group]
    unreadable: list[MediaInfo]
    detection: Detection
    scenes: SceneStore | None = None
    max_gap: float = DEFAULT_MAX_GAP

    @property
    def groups(self) -> list[Group]:
        return self.byte_groups + self.detection.groups

    def regroup(self, max_gap: float, auto_select: float = AUTO_SELECT_CONFIDENCE,
                scene_weight: float = 1.0, keep_cameras: bool = True) -> None:
        """Re-run grouping with new settings - no re-scanning needed."""
        self.max_gap = max_gap
        self.detection = detect_groups(self.infos, max_gap, self.scenes, auto_select, scene_weight, keep_cameras)


def scan_folder(ffmpeg: FFmpeg, folder: Path, recursive: bool = False,
                exclude_dirs: Iterable[Path] = (),
                on_progress: Callable[[int, int, str], None] | None = None,
                is_cancelled: Callable[[], bool] = lambda: False,
                max_gap: float = DEFAULT_MAX_GAP,
                scenes: SceneStore | None = None,
                on_scene_progress: Callable[[int, int, str], None] | None = None,
                workers: int = 6, scene_workers: int = 6, files: Iterable[Path] = (),
                auto_select: float = AUTO_SELECT_CONFIDENCE, scene_weight: float = 1.0,
                keep_cameras: bool = True) -> ScanResult:
    """Probe every video in folder, compare clip ends/starts, and group the pieces."""
    videos, splits = list_candidates(Path(folder), recursive) if folder else ([], [])
    for f in files:                                   # extra files (e.g. other modules' output)
        f = Path(f)
        if f.suffix.lower() in VIDEO_EXTS and f not in videos:
            videos.append(f)
    excl = [Path(d).resolve() for d in exclude_dirs]
    videos = [v for v in videos if not any(_is_within(v, d) for d in excl)]
    infos: list[MediaInfo] = []
    total = len(videos)
    from breezy.core import proc
    with proc.pool(workers) as pool:
        futures = [pool.submit(ffmpeg.probe, v) for v in videos]
        for n, fut in enumerate(futures, 1):
            if is_cancelled():
                pool.shutdown(cancel_futures=True)
                break
            info = fut.result()
            infos.append(info)
            if on_progress:
                on_progress(n, total, info.path.name)
    if scenes is not None and not is_cancelled():
        scenes.ensure(ffmpeg, infos, on_scene_progress, is_cancelled, workers=scene_workers)
    return ScanResult(infos=infos, byte_groups=detect_byte_splits(splits),
                      unreadable=[i for i in infos if i.error],
                      detection=detect_groups(infos, max_gap, scenes, auto_select, scene_weight, keep_cameras),
                      scenes=scenes, max_gap=max_gap)


def _is_within(path: Path, folder: Path) -> bool:
    try:
        path.resolve().relative_to(folder)
        return True
    except ValueError:
        return False
