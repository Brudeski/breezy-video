"""Stitcher task runners: scan, stitch, and automatic stitching of another task's output."""
from __future__ import annotations

from pathlib import Path

from breezy.core.outputs import output_dir
from breezy.core.proc import Cancelled
from breezy.core.settings import app_data_dir
from breezy.core.tasks import Task, TaskContext, register_runner
from .detector import Group, scan_folder
from .joiner import Joiner, JoinOptions
from .scenes import SceneStore


def group_spec(g: Group) -> dict:
    return {"parts": [str(p.path) for p in g.parts], "name": g.output_name, "ext": g.output_ext,
            "method": g.method, "reason": g.reason, "confidence": g.confidence,
            "duration": g.total_duration or 1.0}


def _scan(task: Task, ctx: TaskContext, folder, files):
    s = task.spec
    store = SceneStore(app_data_dir() / "scene_cache.json")
    return scan_folder(
        ctx.ffmpeg, Path(folder) if folder else None, s.get("recursive", False),
        [Path(x) for x in s.get("exclude", [])],
        on_progress=lambda n, t, name: ctx.item_progress(0.2 * n / max(t, 1), f"Reading {n}/{t}: {name}"),
        is_cancelled=ctx.cancel_event.is_set, max_gap=s.get("max_gap", 150.0), scenes=store,
        on_scene_progress=lambda n, t, name: ctx.item_progress(0.2 + 0.8 * n / max(t, 1),
                                                               f"Comparing scenes {n}/{t}: {name}"),
        workers=s.get("workers", 6), scene_workers=s.get("scene_workers", 6), files=[Path(f) for f in files],
        auto_select=s.get("auto_select", 0.6), scene_weight=s.get("scene_weight", 1.0),
        keep_cameras=s.get("keep_cameras", True))


def run_scan(task: Task, ctx: TaskContext):
    ctx.set_items(["scan"], [1.0], ["Scanning"])
    result = None
    for _i, _ in ctx.items():
        result = _scan(task, ctx, task.spec.get("folder"), task.spec.get("files", []))
        ctx.log(f"Found {len(result.groups)} group(s) in {len(result.infos)} video(s).")
    if ctx.cancel_event.is_set():
        raise Cancelled("Cancelled by user")
    return result


def _join_groups(task: Task, ctx: TaskContext):
    s = task.spec
    for i, gs in ctx.items():
        try:
            infos = [ctx.ffmpeg.probe(Path(p)) for p in gs["parts"]]
            bad = [i.path.name for i in infos if i.error]
            if bad:
                raise RuntimeError("Can't read: " + ", ".join(bad))
            g = Group(parts=infos, reason=gs.get("reason", ""), confidence=gs.get("confidence", 1.0),
                      method=gs["method"], output_name=gs["name"], output_ext=gs["ext"])
            opts = JoinOptions(output_dir=output_dir(s, Path(gs["parts"][0])), container=s.get("container", "same"),
                               reencode_preset=s.get("preset", "h264"), verify=s.get("verify", True),
                               fix_drift=s.get("fix_drift", True), crf=s.get("crf", 16),
                               use_gpu=s.get("use_gpu", True), audio_bitrate=s.get("audio_bitrate", ""),
                               drift_threshold=s.get("drift_threshold", 0.1),
                               name_pattern=s.get("name_pattern", "{name}"))
            joiner = Joiner(ctx.ffmpeg, log=ctx.log, progress=ctx.item_progress, cancel_event=ctx.cancel_event)
            r = joiner.join(g, opts)
            ctx.add_output(r.output)
            ctx.log(("✔ " if r.ok else "⚠ ") + f"{r.output.name}: {r.message}")
            if not r.ok:
                task.errors.append(f"{r.output.name}: {r.message}")
        except Cancelled:
            raise
        except Exception as e:  # keep going with the next group
            ctx.error(f"{gs['name']}: {e}")


def run_join(task: Task, ctx: TaskContext):
    groups = task.spec["groups"]
    ctx.set_items(groups, [g.get("duration", 1.0) for g in groups], [g["name"] for g in groups])
    _join_groups(task, ctx)


def run_auto(task: Task, ctx: TaskContext):
    """Input = files from another task: find the pieces, then stitch the ticked groups."""
    s = task.spec
    if "auto_groups" not in s:
        ctx.set_items(["scan"], [1.0], ["Finding pieces"])
        for _i, _ in ctx.items():
            result = _scan(task, ctx, None, s.get("input_files", []))
            s["auto_groups"] = [group_spec(g) for g in result.groups if g.selected]
            ctx.log(f"Found {len(s['auto_groups'])} group(s) to stitch.")
        task.done_items = []
    groups = s["auto_groups"]
    if not groups:
        ctx.log("Nothing to stitch in these files.")
        return
    task.media = True
    ctx.set_items(groups, [g.get("duration", 1.0) for g in groups], [g["name"] for g in groups])
    _join_groups(task, ctx)


register_runner("stitcher.scan", run_scan)
register_runner("stitcher.join", run_join)
register_runner("stitcher.auto", run_auto)
