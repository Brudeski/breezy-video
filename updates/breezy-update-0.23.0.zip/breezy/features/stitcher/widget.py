"""Stitcher page: find pieces, review groups, stitch - all long work runs as tasks."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (QAbstractItemView, QFileDialog, QHBoxLayout, QHeaderView, QLabel,
                               QLineEdit, QMessageBox, QPlainTextEdit, QPushButton, QSplitter,
                               QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

from breezy.core import theme
from breezy.core.outputs import output_spec
from breezy.core.settings import app_data_dir
from breezy.core.sync import drift_text, needs_fix
from breezy.core.tasks import Task
from breezy.core.ui import (Card, OutputCard, OutputPicker, SettingsColumn, TaskBar, check, combo,
                            open_in_explorer, spin)
from .detector import (DEFAULT_MAX_GAP, METHOD_BYTES, METHOD_COPY, METHOD_REENCODE, Group, ScanResult,
                       make_group, name_time)
from .joiner import QUALITY_PRESETS, _fmt_dur, _fmt_size
from .scenes import SceneStore
from .tasks import group_spec

ROLE = Qt.UserRole
DEFAULT_FOLDER = "Stitched"


class StitcherWidget(QWidget):
    def __init__(self, feature):
        super().__init__()
        self.feature = feature
        self.ctx = feature.context
        self.ff = self.ctx.ffmpeg
        self.tm = self.ctx.tasks
        self.groups: list[Group] = []
        self.singles, self.duplicates = [], []
        self.extra_files: list[Path] = []
        self.scan_result: ScanResult | None = None
        self.scan_task_id = None
        self.scenes = SceneStore(app_data_dir() / "scene_cache.json")
        self._build()
        self.tm.finished.connect(self._task_finished)
        self._update_buttons()
        self._install_tools()

    # ================================================================ layout

    def _build(self):
        st = self.feature.setting
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(14)

        # ---------- left: input, results, progress
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.setSpacing(8)
        src = Card()
        top = QHBoxLayout()
        self.folder_edit = QLineEdit(st("last_folder", ""))
        self.folder_edit.setPlaceholderText("Folder containing video pieces…")
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse_folder)
        self.recursive = check("Include subfolders", st("recursive", False))
        self.use_out = QPushButton("Use output from…")
        self.use_out.setToolTip("Add files made by any module - or queue automatic stitching of a task "
                                "that hasn't finished yet")
        self.use_out.clicked.connect(self._use_output)
        self.scan_btn = QPushButton("Scan", objectName="primary")
        self.scan_btn.clicked.connect(self.scan)
        top.addWidget(QLabel("Folder:"))
        top.addWidget(self.folder_edit, 1)
        top.addWidget(browse)
        add_files = QPushButton("Add files…")
        add_files.setToolTip("Choose one or more video files (they're added to the list)")
        add_files.clicked.connect(self._add_files)
        top.addWidget(add_files)
        clear_files = QPushButton("Clear")
        clear_files.setToolTip("Empty the list (folder and added files)")
        clear_files.clicked.connect(self._clear_files)
        top.addWidget(clear_files)
        top.addWidget(self.recursive)
        top.addWidget(self.use_out)
        top.addWidget(self.scan_btn)
        src.v.addLayout(top)
        self.extra_label = QLabel("", objectName="muted")
        src.v.addWidget(self.extra_label)
        lv.addWidget(src)

        mid = QHBoxLayout()
        self.tree = QTreeWidget()
        self.tree.setColumnCount(6)
        self.tree.setHeaderLabels(["Output name / pieces", "Duration", "Size", "Join method", "Confidence", "Details"])
        self.tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tree.setEditTriggers(QAbstractItemView.DoubleClicked | QAbstractItemView.EditKeyPressed)
        self.tree.setAlternatingRowColors(True)
        h = self.tree.header()
        h.resizeSection(0, 330)
        for c, w in ((1, 75), (2, 80), (3, 190), (4, 90)):
            h.resizeSection(c, w)
        h.setStretchLastSection(True)
        self.tree.itemChanged.connect(self._item_changed)
        self.tree.itemSelectionChanged.connect(self._update_buttons)
        mid.addWidget(self.tree, 1)
        side = QVBoxLayout()
        self.up_btn = QPushButton("▲ Move up")
        self.down_btn = QPushButton("▼ Move down")
        self.remove_btn = QPushButton("Remove from group")
        self.group_btn = QPushButton("Group selected")
        self.all_btn = QPushButton("Tick all")
        self.none_btn = QPushButton("Untick all")
        self.up_btn.clicked.connect(lambda: self._move(-1))
        self.down_btn.clicked.connect(lambda: self._move(1))
        self.remove_btn.clicked.connect(self._remove_parts)
        self.group_btn.clicked.connect(self._group_selected)
        self.all_btn.clicked.connect(lambda: self._tick_all(True))
        self.none_btn.clicked.connect(lambda: self._tick_all(False))
        for b in (self.up_btn, self.down_btn, self.remove_btn, self.group_btn):
            side.addWidget(b)
        side.addSpacing(10)
        side.addWidget(self.all_btn)
        side.addWidget(self.none_btn)
        side.addStretch()
        mid.addLayout(side)
        midw = QWidget()
        midw.setLayout(mid)

        self.log = QPlainTextEdit(readOnly=True)
        self.log.setMaximumBlockCount(1000)
        self.log.setPlaceholderText("Messages")
        split = QSplitter(Qt.Vertical)
        split.addWidget(midw)
        split.addWidget(self.log)
        split.setSizes([560, 90])
        lv.addWidget(split, 1)

        run = Card()
        rh = QHBoxLayout()
        self.taskbar = TaskBar(self.tm, "stitcher")
        self.taskbar.hide()                 # progress is shown in the bar at the bottom and on the Tasks page
        rh.addStretch(1)
        self.open_btn = QPushButton("Open output folder")
        self.open_btn.clicked.connect(self._open_output)
        self.stitch_btn = QPushButton("Stitch selected", objectName="primary")
        self.stitch_btn.clicked.connect(self.stitch)
        rh.addWidget(self.open_btn)
        rh.addWidget(self.stitch_btn)
        run.v.addLayout(rh)
        lv.addWidget(run)
        root.addWidget(left, 1)

        # ---------- right: every setting visible
        col = SettingsColumn(390)
        g = col.add(Card("Grouping", "How pieces are recognised as one recording"))
        self.max_gap = g.row("Max gap between clips:", spin(0, 3600, int(st("max_gap", DEFAULT_MAX_GAP)), " s", step=10),
                             "Largest pause allowed between the end of one clip and the start of the next")
        self.auto_tick = g.row("Auto-tick groups from:", spin(0, 100, int(st("auto_tick", 60)), " %", step=5),
                               "Groups with at least this confidence are ticked automatically")
        self.scene_on = g.full(check("Compare scenes (end of one clip vs start of the next)", st("scene_on", True)))
        self.scene_w = g.row("Scene check weight:", spin(0, 300, int(st("scene_weight", 100)), " %", step=25),
                             "100% = normal influence on confidence, 0% = ignore, 200% = double")
        self.keep_cams = g.full(check("Keep different cameras apart", st("keep_cameras", True),
                                      "Never joins clips from two cameras, even when their times line up:\n"
                                      "- the files name different cameras (make/model/serial), or\n"
                                      "- both cameras stand still but the background changes between the clips"))
        for w in (self.max_gap, self.auto_tick, self.scene_w):
            w.valueChanged.connect(self._regroup_soon)
        self.scene_on.toggled.connect(self._regroup_soon)
        self.keep_cams.toggled.connect(self._regroup_soon)

        j = col.add(Card("Joining"))
        self.container = j.row("Container:", combo([("Same as source", "same"), ("MP4", ".mp4"), ("MKV", ".mkv"),
                                                    ("MOV", ".mov")], st("container", "same")),
                               "Changing the container is still lossless")
        self.preset = j.row("If formats differ:", combo([(v[0], k) for k, v in QUALITY_PRESETS.items()], st("preset", "h264")),
                            "Only used when pieces can't be joined losslessly")
        self.crf = j.row("Re-encode quality:", spin(0, 40, int(st("crf", 16)), " CRF"),
                         "Lower = better quality, bigger file. 16-18 looks identical to the original")
        self.gpu = j.full(check("Use the graphics card for re-encoding (faster)", st("use_gpu", True)))
        self.verify = j.full(check("Check the result's length after joining", st("verify", True)))

        a = col.add(Card("Sound"))
        self.fix_drift = a.full(check("Fix audio drift (match each clip's sound to its picture)", st("fix_drift", True)))
        self.drift_thr = a.row("Count as drifting from:", spin(0.01, 5.0, float(st("drift_threshold", 0.1)), " s",
                                                               decimals=2, step=0.05))
        self.abr = a.row("Re-encoded sound bitrate:", combo([("Automatic", ""), ("64 kbps", "64k"), ("96 kbps", "96k"),
                                                            ("128 kbps", "128k"), ("192 kbps", "192k"), ("320 kbps", "320k")],
                                                           st("audio_bitrate", "")))
        self.fix_drift.toggled.connect(self._rebuild_tree)
        self.drift_thr.valueChanged.connect(self._rebuild_tree)

        p = col.add(Card("Performance"))
        self.workers = p.row("Files read at once:", spin(1, 32, int(st("workers", 6))))
        self.scene_workers = p.row("Scene checks at once:", spin(1, 32, int(st("scene_workers", 6))))

        self.out = col.add(OutputCard(self.feature, DEFAULT_FOLDER, [("name_pattern", "File name:", "{name}")]))
        root.addWidget(col)

        self._regroup_timer = QTimer(self, singleShot=True, interval=350)
        self._regroup_timer.timeout.connect(self._regroup)

    # ============================================================== helpers
    def _say(self, msg: str):
        self.log.appendPlainText(msg)

    def _browse_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Folder with video pieces", self.folder_edit.text())
        if d:
            self.folder_edit.setText(d)
            self.scan()

    def _settings(self) -> dict:
        return {"max_gap": float(self.max_gap.value()), "auto_select": self.auto_tick.value() / 100,
                "scene_weight": (self.scene_w.value() / 100) if self.scene_on.isChecked() else 0.0,
                "keep_cameras": self.keep_cams.isChecked(), "container": self.container.currentData(), "preset": self.preset.currentData(),
                "crf": self.crf.value(), "use_gpu": self.gpu.isChecked(), "verify": self.verify.isChecked(),
                "fix_drift": self.fix_drift.isChecked(), "drift_threshold": self.drift_thr.value(),
                "audio_bitrate": self.abr.currentData(), "workers": self.workers.value(),
                "scene_workers": self.scene_workers.value(), "name_pattern": self.out.pattern("name_pattern")}

    def _save_settings(self):
        s = self._settings()
        f = self.feature
        f.set_setting("last_folder", self.folder_edit.text().strip())
        f.set_setting("recursive", self.recursive.isChecked())
        for k in ("max_gap", "container", "preset", "crf", "use_gpu", "verify", "fix_drift", "drift_threshold",
                  "audio_bitrate", "workers", "scene_workers"):
            f.set_setting(k, s[k])
        f.set_setting("auto_tick", self.auto_tick.value())
        f.set_setting("scene_on", self.scene_on.isChecked())
        f.set_setting("keep_cameras", self.keep_cams.isChecked())
        f.set_setting("scene_weight", self.scene_w.value())

    def _busy(self) -> bool:
        t = self.tm.get(self.scan_task_id) if self.scan_task_id else None
        return bool(t and t.status in ("queued", "running", "paused"))

    def _update_buttons(self):
        busy = self._busy()
        parts = self._selected_part_items()
        in_group = [i for i in parts if i.parent() and i.parent().data(0, ROLE)[0] == "group"]
        self.scan_btn.setEnabled(not busy)
        self.stitch_btn.setEnabled(any(g.selected for g in self.groups))
        self.up_btn.setEnabled(len(in_group) == 1)
        self.down_btn.setEnabled(len(in_group) == 1)
        self.remove_btn.setEnabled(bool(in_group))
        self.group_btn.setEnabled(len(parts) >= 2)
        self.open_btn.setEnabled(True)
        for b in (self.all_btn, self.none_btn):
            b.setEnabled(bool(self.groups))
        n = len(self.extra_files)
        self.extra_label.setText(f"+ {n} added file(s)" if n else "")
        self.extra_label.setVisible(bool(n))

    # ================================================================= scan
    def _add_files(self):
        from breezy.core.ui import pick_videos
        files = pick_videos(self, self.folder_edit.text().strip())
        if files:
            self._add_paths(files)

    def _clear_files(self):
        self.folder_edit.setText("")
        self.extra_files = []
        self.groups, self.singles = [], []
        self.scan_result = None
        self._rebuild_tree()
        self._update_buttons()

    # ------------------------------------------------------------ drag & drop, list menu
    def _install_tools(self):
        from breezy.core.ui import install_drop, install_list_tools
        install_drop(self, self._drop_folder, self._add_paths)
        install_list_tools(self.tree, self._path_of_item, lambda _paths: self._remove_parts(), self.scan)

    def _path_of_item(self, it):
        d = it.data(0, ROLE) if it else None
        try:
            if isinstance(d, tuple) and d[0] == "part":
                return self.groups[d[1]].parts[d[2]].path
            if isinstance(d, tuple) and d[0] == "single":
                return self.singles[d[1]].path
        except (IndexError, AttributeError):
            pass
        return None

    def _drop_folder(self, d):
        self.folder_edit.setText(str(d))
        self.scan()

    def _add_paths(self, files):
        self.extra_files += [f for f in files if f not in self.extra_files]
        self._say(f"Added {len(files)} file(s).")
        self.scan()
        self._update_buttons()

    def reload_settings(self):
        from breezy.core.ui import reload_from
        reload_from(self.feature, {"crf": self.crf, "verify": self.verify, "use_gpu": self.gpu})

    def _use_output(self):
        dlg = OutputPicker(self.tm, self, "stitcher")
        if not dlg.exec():
            return
        files, future = dlg.selection()
        if files:
            self.extra_files += [Path(f) for f in files if Path(f) not in self.extra_files]
            self._say(f"Added {len(files)} file(s). Press Scan to look for pieces.")
        for tid in future:
            self._queue_auto(tid)
        self._update_buttons()

    def _queue_auto(self, task_id: str):
        out = output_spec(self.ctx.settings, "stitcher", DEFAULT_FOLDER, self, self.out.values())
        if out is None:
            return
        src = self.tm.get(task_id)
        spec = dict(self._settings(), output=out)
        t = Task("stitcher.auto", "stitcher", f"Auto-stitch output of '{src.title if src else task_id}'",
                 spec=spec, input_from=task_id, media=False)
        self.tm.submit(t)
        self._say(f"Queued: stitch the files from '{t.title[23:-1]}' when it finishes (ticked groups only).")

    def scan(self):
        folder = self.folder_edit.text().strip()
        if folder and not Path(folder).is_dir():
            QMessageBox.warning(self, "Stitcher", "That folder doesn't exist.")
            return
        if not folder and not self.extra_files:
            QMessageBox.information(self, "Stitcher", "Choose a folder, or add files with 'Use output from…'.")
            return
        if not self.ff.available:
            QMessageBox.warning(self, "Stitcher", "FFmpeg was not found. See the Settings page.")
            return
        self._save_settings()
        exclude = []
        root = self.ctx.settings.get("app", "output_root", "")
        if root:
            exclude.append(root)
        if folder:
            exclude.append(str(Path(folder) / self.out.values()["folder"]))
        spec = dict(self._settings(), folder=folder, recursive=self.recursive.isChecked(),
                    files=[str(f) for f in self.extra_files], exclude=exclude)
        name = Path(folder).name if folder else f"{len(self.extra_files)} file(s)"
        t = self.tm.submit(Task("stitcher.scan", "stitcher", f"Scan {name}", spec=spec, resumable=False, media=False))
        self.scan_task_id = t.id
        self.taskbar.follow(t.id)
        self._say(f"Scanning {folder or ''}{' + ' if folder and self.extra_files else ''}"
                  f"{f'{len(self.extra_files)} added file(s)' if self.extra_files else ''}…")
        self._update_buttons()

    def _task_finished(self, task_id: str):
        t = self.tm.get(task_id)
        if not t or t.module != "stitcher":
            return
        if task_id == self.scan_task_id:
            res = self.tm.results.pop(task_id, None)
            if res is not None:
                self.scan_result = res
                self._apply_result("Scan complete.")
                for u in res.unreadable:
                    self._say(f"  Could not read {u.path.name}: {u.error}")
            elif t.status != "done":
                self._say(f"Scan {t.status}: {t.message}")
        elif t.kind in ("stitcher.join", "stitcher.auto"):
            self._say(f"{t.title}: {t.message or t.status} ({len(t.outputs)} file(s) made)")
            self.feature.set_setting("last_outputs", list(t.outputs))
        self._update_buttons()

    def _apply_result(self, prefix: str):
        r = self.scan_result
        self.groups = r.groups
        self.singles = r.detection.singles
        self.duplicates = r.detection.duplicates
        self._rebuild_tree()
        sel = sum(g.selected for g in self.groups)
        clips = sum(len(g.parts) for g in self.groups)
        self._say(f"{prefix} {len(self.groups)} group(s) from {clips} clips ({sel} ticked), "
                  f"{len(self.singles)} standalone file(s), {len(self.duplicates)} duplicate copies skipped.")

    def _regroup_soon(self):
        self._save_settings()
        self._regroup_timer.start()

    def _regroup(self):
        if self.scan_result is None:
            return
        s = self._settings()
        self.scan_result.regroup(s["max_gap"], s["auto_select"], s["scene_weight"], s["keep_cameras"])
        self._apply_result("Regrouped:")

    # ================================================================= tree
    def _rebuild_tree(self, *_):
        c = theme.colors()
        thr = self.drift_thr.value()
        fix = self.fix_drift.isChecked()
        self.tree.blockSignals(True)
        self.tree.clear()
        for gi, g in enumerate(self.groups):
            top = QTreeWidgetItem(self.tree)
            top.setData(0, ROLE, ("group", gi))
            top.setFlags(top.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsEditable)
            top.setCheckState(0, Qt.Checked if g.selected else Qt.Unchecked)
            top.setText(0, g.output_name)
            top.setToolTip(0, "Double-click to rename the output file")
            top.setText(1, _fmt_dur(g.total_duration) if g.method != METHOD_BYTES else "")
            top.setText(2, _fmt_size(g.total_size))
            text = {METHOD_COPY: "Lossless (stream copy)", METHOD_BYTES: "Lossless (rebuild file)",
                    METHOD_REENCODE: "Re-encode (formats differ)"}[g.method]
            color = c["warn"] if g.method == METHOD_REENCODE else c["good"]
            drifting = sum(needs_fix(p, thr) for p in g.parts) if g.method != METHOD_BYTES else 0
            if drifting and fix:
                text += " + sound re-synced"
            top.setText(3, text)
            top.setForeground(3, QBrush(QColor(color)))
            top.setText(4, f"{g.confidence:.0%}")
            details = "; ".join(g.evidence)
            if drifting:
                details = f"{drifting} clip(s) with audio drift ({'will be fixed' if fix else 'NOT fixed'}); " + details
            if g.issues:
                details += "  ⚠ " + " ⚠ ".join(g.issues)
                top.setForeground(5, QBrush(QColor(c["warn"])))
            top.setText(5, details)
            top.setToolTip(5, "\n".join(g.evidence + g.issues))
            f = top.font(0)
            f.setBold(True)
            top.setFont(0, f)
            for pi, p in enumerate(g.parts):
                ch = QTreeWidgetItem(top)
                ch.setData(0, ROLE, ("part", gi, pi))
                ch.setText(0, f"{pi + 1}. {p.path.name}")
                ch.setToolTip(0, str(p.path))
                ch.setText(1, _fmt_dur(p.duration) if p.duration else "")
                ch.setText(2, _fmt_size(p.size))
                detail = p.describe() if g.method != METHOD_BYTES else "raw piece"
                d = p.drift if g.method != METHOD_BYTES else None
                if d is not None and abs(d) > thr:
                    detail = f"sound drifts {d:+.2f} s  |  " + detail
                if pi > 0:
                    prev = g.parts[pi - 1]
                    bits = []
                    na, nb = name_time(prev.path), name_time(p.path)
                    if na and nb:
                        bits.append(f"gap {nb.start - (na.start + prev.duration):+.0f}s")
                    sim = self.scenes.link(prev, p) if g.method != METHOD_BYTES else None
                    if sim is not None:
                        bits.append(f"scene match {sim:.0%}")
                        if sim < 0.35:
                            ch.setForeground(5, QBrush(QColor(c["warn"])))
                    if bits:
                        detail = "  ".join(bits) + "  |  " + detail
                ch.setText(5, detail)
            top.setExpanded(len(g.parts) <= 25)
        for title, items, kind in ((f"Standalone files ({len(self.singles)})", self.singles, "single"),):
            if not items:
                continue
            top = QTreeWidgetItem(self.tree)
            top.setData(0, ROLE, ("singles",))
            top.setText(0, title)
            top.setForeground(0, QBrush(QColor(c["muted"])))
            top.setFlags(Qt.ItemIsEnabled)
            for si, p in enumerate(items):
                ch = QTreeWidgetItem(top)
                ch.setData(0, ROLE, (kind, si))
                ch.setText(0, p.path.name)
                ch.setToolTip(0, str(p.path))
                ch.setText(1, _fmt_dur(p.duration))
                ch.setText(2, _fmt_size(p.size))
                ch.setText(5, (drift_text(p) + "  |  " if drift_text(p) else "") + p.describe())
            top.setExpanded(len(items) <= 15)
        if self.duplicates:
            top = QTreeWidgetItem(self.tree)
            top.setData(0, ROLE, ("dups",))
            top.setText(0, f"Skipped duplicate copies ({len(self.duplicates)})")
            top.setForeground(0, QBrush(QColor(c["muted"])))
            top.setFlags(Qt.ItemIsEnabled)
            for d in self.duplicates:
                ch = QTreeWidgetItem(top)
                ch.setFlags(Qt.ItemIsEnabled)
                ch.setText(0, d.info.path.name)
                ch.setText(2, _fmt_size(d.info.size))
                ch.setText(5, f"identical size to {d.original.path.name} (that one is used)")
        self.tree.blockSignals(False)
        self._update_buttons()

    def _item_changed(self, item: QTreeWidgetItem, col: int):
        data = item.data(0, ROLE)
        if not data or data[0] != "group":
            return
        g = self.groups[data[1]]
        g.selected = item.checkState(0) == Qt.Checked
        name = item.text(0).strip()
        if name:
            g.output_name = name
        self._update_buttons()

    def _tick_all(self, on: bool):
        for g in self.groups:
            g.selected = on
        self._rebuild_tree()

    def _selected_part_items(self):
        return [i for i in self.tree.selectedItems()
                if i.data(0, ROLE) and i.data(0, ROLE)[0] in ("part", "single")]

    def _move(self, delta: int):
        item = self._selected_part_items()[0]
        _, gi, pi = item.data(0, ROLE)
        g = self.groups[gi]
        ni = pi + delta
        if not 0 <= ni < len(g.parts):
            return
        g.parts[pi], g.parts[ni] = g.parts[ni], g.parts[pi]
        g.refresh_method()
        self._rebuild_tree()
        top = self.tree.topLevelItem(gi)
        if top and ni < top.childCount():
            self.tree.setCurrentItem(top.child(ni))

    def _remove_parts(self):
        picks = sorted((i.data(0, ROLE)[1:] for i in self._selected_part_items()
                        if i.data(0, ROLE)[0] == "part"), reverse=True)
        for gi, pi in picks:
            g = self.groups[gi]
            p = g.parts.pop(pi)
            if g.method != METHOD_BYTES:
                self.singles.append(p)
        keep = []
        for g in self.groups:
            if len(g.parts) >= 2:
                g.refresh_method()
                keep.append(g)
            elif g.method != METHOD_BYTES:
                self.singles.extend(g.parts)
        self.groups = keep
        self.singles.sort(key=lambda p: str(p.path).lower())
        self._rebuild_tree()

    def _group_selected(self):
        parts = []
        for i in self._selected_part_items():
            d = i.data(0, ROLE)
            if d[0] == "part":
                g = self.groups[d[1]]
                if g.method == METHOD_BYTES:
                    QMessageBox.information(self, "Stitcher", "Byte-split pieces can't be regrouped.")
                    return
                parts.append(g.parts[d[2]])
            else:
                parts.append(self.singles[d[1]])
        if len(parts) < 2:
            return
        ids = {id(p) for p in parts}
        for g in self.groups:
            g.parts = [p for p in g.parts if id(p) not in ids]
        self.singles = [p for p in self.singles if id(p) not in ids]
        parts.sort(key=lambda p: p.path.name.lower())
        new = make_group(parts, "Grouped manually", "manual", parts[0].path.stem + "_joined",
                         max_gap=float(self.max_gap.value()), scenes=self.scenes)
        new.selected = True
        survivors = []
        for g in self.groups:
            if len(g.parts) >= 2:
                g.refresh_method()
                survivors.append(g)
            else:
                self.singles.extend(g.parts)
        self.groups = [new] + survivors
        self._rebuild_tree()
        self._say(f"Created group '{new.output_name}' from {len(parts)} files (sorted by name).")

    # =============================================================== stitch
    def stitch(self):
        todo = [g for g in self.groups if g.selected]
        if not todo:
            return
        self._save_settings()
        reenc = [g for g in todo if g.method == METHOD_REENCODE]
        if reenc:
            names = "\n".join("• " + g.output_name for g in reenc[:8])
            if QMessageBox.question(self, "Re-encode needed",
                                    f"{len(reenc)} group(s) have pieces in different formats and will be "
                                    f"re-encoded ({self.preset.currentText()}, CRF {self.crf.value()}):\n\n{names}"
                                    "\n\nContinue?") != QMessageBox.Yes:
                return
        out = output_spec(self.ctx.settings, "stitcher", DEFAULT_FOLDER, self, self.out.values())
        if out is None:
            return
        self.out._update()
        spec = dict(self._settings(), output=out, groups=[group_spec(g) for g in todo])
        title = f"Stitch {len(todo)} group(s)" + (f" from {Path(self.folder_edit.text()).name}" if self.folder_edit.text() else "")
        t = self.tm.submit(Task("stitcher.join", "stitcher", title, spec=spec))
        self.taskbar.follow(t.id)
        self._say(f"Queued: {title}.")

    def _open_output(self):
        from breezy.core.ui import open_module_output
        folder = self.folder_edit.text().strip()
        open_module_output(self, self.tm, "stitcher", self.out,
                           Path(folder) if folder else (self.extra_files[0] if self.extra_files else None))
