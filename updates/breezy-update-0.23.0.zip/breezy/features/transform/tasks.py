"""Rotate, flip & crop: turn sideways video upright, mirror it, or cut away part of the picture."""
from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path

from breezy.core import encoders
from breezy.core.ffmpeg import FFmpeg, MediaInfo
from breezy.core.filepage import video_task_items
from breezy.core.outputs import apply_pattern, finish, output_dir, unique_path, working_path
from breezy.core.proc import Cancelled
from breezy.core.tasks import Task, TaskContext, register_runner

_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
ROTATIONS = [("Don't turn", 0), ("90° right (clockwise)", 90), ("90° left", -90), ("180° (upside down)", 180)]
_TRANSPOSE = {90: ["transpose=1"], -90: ["transpose=2"], 180: ["hflip", "vflip"], 0: []}


def norm_crop(c) -> list[float] | None:
    """[x, y, w, h] as fractions of the turned picture, or None for no crop."""
    if not c or len(c) != 4:
        return None
    x, y, w, h = (max(0.0, min(1.0, float(v))) for v in c)
    w, h = min(w, 1 - x), min(h, 1 - y)
    if w >= 0.999 and h >= 0.999:
        return None
    if w < 0.02 or h < 0.02:
        return None
    return [x, y, w, h]


def has_work(s: dict) -> bool:
    return bool(int(s.get("rotate", 0) or 0) or s.get("hflip") or s.get("vflip") or norm_crop(s.get("crop")))


def flag_only(s: dict) -> bool:
    """Just a turn, and the user allows it to be done by changing the rotation flag (no re-encoding)."""
    return bool(s.get("lossless", True)) and bool(int(s.get("rotate", 0) or 0)) and not s.get("hflip") \
        and not s.get("vflip") and not norm_crop(s.get("crop"))


def filters(s: dict) -> list[str]:
    f = list(_TRANSPOSE.get(int(s.get("rotate", 0) or 0), []))
    if s.get("hflip"):
        f.append("hflip")
    if s.get("vflip"):
        f.append("vflip")
    c = norm_crop(s.get("crop"))
    if c:
        x, y, w, h = c
        f.append(f"crop=w=trunc(iw*{w:.5f}/2)*2:h=trunc(ih*{h:.5f}/2)*2:x=trunc(iw*{x:.5f}):y=trunc(ih*{y:.5f})")
    return f


def result_size(width: int, height: int, s: dict) -> tuple[int, int]:
    """Picture size after turning and cropping (width/height as the video is shown)."""
    w, h = (height, width) if abs(int(s.get("rotate", 0) or 0)) == 90 else (width, height)
    c = norm_crop(s.get("crop"))
    if c:
        w, h = int(w * c[2]) // 2 * 2, int(h * c[3]) // 2 * 2
    return w, h


def rotation_of(ff: FFmpeg, path: Path) -> int:
    """The rotation flag stored in the file (degrees, as FFmpeg's -display_rotation counts them)."""
    out = subprocess.run([ff.ffprobe, "-v", "error", "-select_streams", "v:0", "-show_entries",
                          "stream_side_data=rotation", "-of", "csv=p=0", str(path)],
                         capture_output=True, text=True, creationflags=_NO_WINDOW).stdout
    for tok in out.replace(",", " ").split():
        try:
            return int(round(float(tok)))
        except ValueError:
            pass
    return 0


def shown_size(_ff: FFmpeg, info: MediaInfo) -> tuple[int, int]:
    """Width and height as players show the video (the probe already gives them that way)."""
    return info.video.width, info.video.height


def _flag_turn(ff: FFmpeg, info: MediaInfo, s: dict, out: Path, ctx: TaskContext) -> str:
    cur = rotation_of(ff, info.path)
    new = cur - int(s.get("rotate", 0))             # -display_rotation counts anticlockwise
    new = (new + 180) % 360 - 180
    tmp = working_path(out)
    try:
        ff.run(["-display_rotation:v:0", str(new), "-i", str(info.path), "-map", "0", "-c", "copy",
                "-map_metadata", "0", str(tmp)], info.duration or 1.0, lambda f: ctx.item_progress(f, "Turning"),
               None, ctx.cancel_event)
        finish(tmp, out)
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise
    return "turned by changing the rotation flag (instant, nothing re-encoded)"


def _encode(ff: FFmpeg, info: MediaInfo, s: dict, out: Path, ctx: TaskContext) -> str:
    v = info.video
    codec = "hevc" if v.codec == "hevc" else "h264"
    venc = encoders.video_args(codec, int(s.get("crf", 18)), bool(s.get("enc_gpu", True)), ["-pix_fmt", "yuv420p"],
                               speed=s.get("enc_speed", "balanced"))
    if codec == "hevc" and out.suffix.lower() in (".mp4", ".mov", ".m4v"):
        venc += ["-tag:v", "hvc1"]
    tmp = working_path(out)
    args = ["-i", str(info.path), "-map", "0:v:0", "-map", "0:a?", "-map_metadata", "0",
            "-vf", ",".join(filters(s) + ["setsar=1"]), *venc, "-c:a", "copy"]
    if out.suffix.lower() in (".mp4", ".mov", ".m4v"):
        args += ["-movflags", "+faststart"]
    try:
        ff.run(args + [str(tmp)], info.duration or 1.0, lambda f: ctx.item_progress(f, "Turning and cropping"),
               None, ctx.cancel_event)
        finish(tmp, out)
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise
    w, h = result_size(*shown_size(ff, info), s)
    return f"{w}×{h}"


def _run(task: Task, ctx: TaskContext, files: list[str]):
    base = task.spec
    per = base.get("per_file", {}) or {}
    if not has_work(base) and not any(has_work({**base, **g}) for g in per.values()):
        ctx.log("Nothing to do: no turn, flip or crop is set.")
        return
    pattern = base.get("name_pattern", "{name}_edit")
    video_task_items(ctx, files, task)
    for _i, f in ctx.items():
        src = Path(f)
        s = {**base, **per.get(str(f), {})}
        if not has_work(s):
            ctx.log(f"– {src.name}: nothing to change - skipped.")
            continue
        try:
            info = ctx.ffmpeg.probe(src)
            if info.error:
                raise RuntimeError(info.error)
            if not info.video:
                raise RuntimeError("no picture in this file")
            ext = src.suffix if src.suffix.lower() in (".mp4", ".mov", ".mkv", ".m4v") else ".mp4"
            out = unique_path(output_dir(s, src) / (apply_pattern(pattern, src.stem) + ext))
            ctx.log(f"=== {src.name} → {out}")
            msg = None
            if flag_only(s):
                try:
                    msg = _flag_turn(ctx.ffmpeg, info, s, out, ctx)
                except Cancelled:
                    raise
                except Exception as e:  # noqa - older FFmpeg or a format without a rotation flag
                    ctx.log(f"The rotation flag couldn't be changed ({str(e).splitlines()[0][:120]}); "
                            "re-encoding instead.")
            if msg is None:
                msg = _encode(ctx.ffmpeg, info, s, out, ctx)
            if s.get("keep_date", True):
                try:
                    st = src.stat()
                    os.utime(out, (st.st_atime, st.st_mtime))
                except OSError:
                    pass
            ctx.add_output(out)
            ctx.log(f"✔ {out.name}: {msg}")
        except Cancelled:
            raise
        except Exception as e:  # noqa - keep going with the next video
            ctx.error(f"{src.name}: {str(e).splitlines()[0] if str(e) else type(e).__name__}")


def run_transform(task: Task, ctx: TaskContext):
    _run(task, ctx, task.spec["files"])


def run_auto(task: Task, ctx: TaskContext):
    files = task.spec.get("input_files", [])
    if not files:
        ctx.log("No input files.")
        return
    _run(task, ctx, files)


register_runner("transform.run", run_transform)
register_runner("transform.auto", run_auto)
