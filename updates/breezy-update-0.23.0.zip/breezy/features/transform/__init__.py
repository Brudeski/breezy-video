"""Rotate, flip & crop: turn sideways video upright, mirror it, or cut away part of the picture."""
from breezy.core.plugin import Feature
from . import tasks as _tasks  # noqa: F401  (registers the task runners)


class TransformFeature(Feature):
    id = "transform"
    name = "Rotate & Crop"
    description = ("Turn sideways or upside-down video upright, mirror it, or crop it - free or to a shape like "
                   "9:16 for phones or 1:1 for posts. Turning alone can be done instantly without re-encoding. "
                   "Originals are never changed.")
    order = 26
    icon = "rotate"

    def create_widget(self):
        from .widget import TransformWidget
        self.widget = TransformWidget(self)
        return self.widget

    def theme_changed(self):
        self.widget.theme_changed()

    def shutdown(self):
        w = getattr(self, "widget", None)
        if w is not None:
            w.shutdown()


FEATURE = TransformFeature
