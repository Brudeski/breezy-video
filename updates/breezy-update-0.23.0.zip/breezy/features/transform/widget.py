"""Rotate, flip & crop page: the turn and flip are shown on a frame of the selected video, and the crop box
is drawn on it (drag inside to move it, drag a corner to resize, drag outside to draw a new one)."""
from __future__ import annotations

import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from PySide6.QtCore import QObject, QPointF, QRectF, Qt, Signal
from PySide6.QtGui import QColor, QImage, QPainter, QPen, QTransform
from PySide6.QtWidgets import QHBoxLayout, QLabel, QPushButton, QSizePolicy, QSlider, QVBoxLayout, QWidget

from breezy.core import theme
from breezy.core.filepage import VideoListPage
from breezy.core.ui import Card, check, combo, spin
from breezy.features.ends.editor import fmt
from breezy.features.stitcher.joiner import _fmt_size
from .tasks import ROTATIONS, flag_only, has_work, norm_crop, result_size

_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
ASPECTS = [("Off", None), ("Free (draw any box)", 0.0), ("16:9", 16 / 9), ("9:16 (upright)", 9 / 16),
           ("4:3", 4 / 3), ("1:1 (square)", 1.0), ("4:5 (portrait post)", 4 / 5)]


def grab(ffmpeg_exe: str, path: Path, t: float, width: int = 960) -> QImage:
    cmd = [ffmpeg_exe, "-v", "error", "-nostdin", "-ss", f"{max(0.0, t):.3f}", "-i", str(path), "-frames:v", "1",
           "-an", "-sn", "-vf", f"scale='min({width},iw)':-2", "-f", "image2pipe", "-vcodec", "png", "-"]
    try:
        data = subprocess.run(cmd, capture_output=True, timeout=60, creationflags=_NO_WINDOW).stdout
    except (subprocess.TimeoutExpired, OSError):
        data = b""
    img = QImage.fromData(data, "PNG")
    return img if not img.isNull() else QImage()


class Grabber(QObject):
    ready = Signal(str, QImage)

    def __init__(self, ffmpeg, parent=None):
        super().__init__(parent)
        self.ff = ffmpeg
        self._pool = ThreadPoolExecutor(max_workers=1)
        self._want = ""

    def request(self, path: Path, t: float):
        key = f"{path}|{t:.2f}"
        self._want = key
        self._pool.submit(self._work, key, path, t)

    def _work(self, key, path, t):
        if key != self._want:
            return
        img = grab(self.ff.ffmpeg, path, t)
        if key == self._want:
            self.ready.emit(key, img)

    def shutdown(self):
        self._pool.shutdown(wait=False, cancel_futures=True)


class CropView(QWidget):
    """The turned frame with the crop box. Box = [x, y, w, h] fractions of the turned picture."""
    changed = Signal(object)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.img = QImage()
        self.box: list[float] | None = None
        self.aspect: float | None = None          # None = no crop, 0 = free, else width / height
        self._drag = None
        self.setMinimumSize(320, 200)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setMouseTracking(True)
        self.message = "Click a video in the list to see it here."

    def set_image(self, img: QImage):
        self.img = img
        self.update()

    def _area(self) -> QRectF:
        if self.img.isNull():
            return QRectF()
        iw, ih = self.img.width(), self.img.height()
        s = min((self.width() - 8) / iw, (self.height() - 8) / ih)
        w, h = iw * s, ih * s
        return QRectF((self.width() - w) / 2, (self.height() - h) / 2, w, h)

    def paintEvent(self, _e):
        p = QPainter(self)
        p.fillRect(self.rect(), QColor("#11141a"))
        a = self._area()
        if a.isNull():
            p.setPen(QColor("#9ca3af"))
            p.drawText(self.rect(), Qt.AlignCenter | Qt.TextWordWrap, self.message)
            p.end()
            return
        p.setRenderHint(QPainter.SmoothPixmapTransform)
        p.drawImage(a, self.img)
        if self.box and self.aspect is not None:
            x, y, w, h = self.box
            r = QRectF(a.x() + x * a.width(), a.y() + y * a.height(), w * a.width(), h * a.height())
            shade = QColor(0, 0, 0, 150)
            for part in (QRectF(a.left(), a.top(), a.width(), r.top() - a.top()),
                         QRectF(a.left(), r.bottom(), a.width(), a.bottom() - r.bottom()),
                         QRectF(a.left(), r.top(), r.left() - a.left(), r.height()),
                         QRectF(r.right(), r.top(), a.right() - r.right(), r.height())):
                p.fillRect(part, shade)
            accent = QColor(theme.colors()["accent"])
            p.setPen(QPen(accent, 2))
            p.drawRect(r)
            p.setPen(QPen(QColor(255, 255, 255, 90), 1))
            for i in (1, 2):                                       # rule of thirds
                p.drawLine(QPointF(r.left() + r.width() * i / 3, r.top()), QPointF(r.left() + r.width() * i / 3, r.bottom()))
                p.drawLine(QPointF(r.left(), r.top() + r.height() * i / 3), QPointF(r.right(), r.top() + r.height() * i / 3))
            p.setBrush(accent)
            p.setPen(Qt.NoPen)
            for c in (r.topLeft(), r.topRight(), r.bottomLeft(), r.bottomRight()):
                p.drawRect(QRectF(c.x() - 5, c.y() - 5, 10, 10))
        p.end()

    # ------------------------------------------------------------ geometry in fractions
    def _frac(self, pos) -> tuple[float, float]:
        a = self._area()
        return (min(1.0, max(0.0, (pos.x() - a.x()) / a.width())), min(1.0, max(0.0, (pos.y() - a.y()) / a.height())))

    def _ratio(self) -> float:
        """Wanted width/height of the box in fractions (pixel aspect / picture aspect)."""
        if not self.aspect or self.img.isNull():
            return 0.0
        return self.aspect / (self.img.width() / self.img.height())

    def max_box(self):
        """The biggest centred box with the chosen shape."""
        r = self._ratio()
        if not r:
            return [0.0, 0.0, 1.0, 1.0]
        w, h = (1.0, 1.0 / r) if r >= 1.0 else (r, 1.0)
        return [(1 - w) / 2, (1 - h) / 2, w, h]

    def _corner(self, pos):
        if not self.box:
            return None
        a = self._area()
        x, y, w, h = self.box
        pts = {"tl": (x, y), "tr": (x + w, y), "bl": (x, y + h), "br": (x + w, y + h)}
        for k, (fx, fy) in pts.items():
            if abs(a.x() + fx * a.width() - pos.x()) < 10 and abs(a.y() + fy * a.height() - pos.y()) < 10:
                return k
        return None

    def mousePressEvent(self, e):
        if self.aspect is None or self._area().isNull():
            return
        pos = e.position()
        fx, fy = self._frac(pos)
        corner = self._corner(pos)
        if corner:
            x, y, w, h = self.box
            anchor = {"tl": (x + w, y + h), "tr": (x, y + h), "bl": (x + w, y), "br": (x, y)}[corner]
            self._drag = ("resize", anchor)
        elif self.box and self.box[0] <= fx <= self.box[0] + self.box[2] and self.box[1] <= fy <= self.box[1] + self.box[3]:
            self._drag = ("move", (fx - self.box[0], fy - self.box[1]))
        else:
            self._drag = ("resize", (fx, fy))

    def mouseMoveEvent(self, e):
        pos = e.position()
        if not self._drag:
            c = self._corner(pos) if self.aspect is not None else None
            self.setCursor(Qt.SizeFDiagCursor if c in ("tl", "br") else Qt.SizeBDiagCursor if c else Qt.CrossCursor
                           if self.aspect is not None else Qt.ArrowCursor)
            return
        fx, fy = self._frac(pos)
        kind, ref = self._drag
        if kind == "move":
            x, y, w, h = self.box
            nx, ny = min(max(0.0, fx - ref[0]), 1 - w), min(max(0.0, fy - ref[1]), 1 - h)
            self.box = [nx, ny, w, h]
        else:
            ax, ay = ref
            w, h = abs(fx - ax), abs(fy - ay)
            r = self._ratio()
            if r:
                if w / max(h, 1e-6) > r:
                    w = h * r
                else:
                    h = w / r
            sx = -1 if fx < ax else 1
            sy = -1 if fy < ay else 1
            x0, y0 = (ax - w if sx < 0 else ax), (ay - h if sy < 0 else ay)
            if w > 0.01 and h > 0.01:
                self.box = [max(0.0, x0), max(0.0, y0), min(w, 1 - max(0.0, x0)), min(h, 1 - max(0.0, y0))]
        self.update()
        self.changed.emit(list(self.box) if self.box else None)

    def mouseReleaseEvent(self, _e):
        self._drag = None


class TransformWidget(VideoListPage):
    MODULE = "transform"
    TITLE = "Rotate, flip & crop"
    DEFAULT_FOLDER = "Turned & cropped"
    DEFAULT_PATTERN = "{name}_edit"
    COLUMNS = [("Length", 70), ("Picture", 110), ("Size", 80), ("Result", 110), ("Details", 200)]
    RUN_TEXT = "Save ticked videos"
    RUN_TIP = "Make turned / cropped copies of the ticked videos. The originals are never changed."
    task_kind, auto_kind, task_verb = "transform.run", "transform.auto", "Turn/crop"

    GEO = ("rotate", "hflip", "vflip", "crop", "aspect_name")

    def __init__(self, feature):
        self.grabber = None
        self._raw = QImage()
        self.own: dict[Path, dict] = {}          # turn/flip/crop set for one video only
        self.shared: dict = {}
        if feature.setting("remember_own", False):
            for k, g in (feature.setting("own_geo", {}) or {}).items():
                if isinstance(g, dict):
                    self.own[Path(k)] = {x: g.get(x) for x in self.GEO}
        super().__init__(feature)
        self.grabber = Grabber(self.ff, self)
        self.grabber.ready.connect(self._frame)

    # ------------------------------------------------------------------ preview
    def build_middle(self):
        box = QWidget()
        v = QVBoxLayout(box)
        v.setContentsMargins(0, 4, 0, 0)
        v.setSpacing(6)
        self.view = CropView()
        self.view.changed.connect(self._box_changed)
        v.addWidget(self.view, 1)
        r = QHBoxLayout()
        r.addWidget(QLabel("Show frame at:"))
        self.pos = QSlider(Qt.Horizontal)
        self.pos.setRange(0, 0)
        self.pos.setToolTip("Which moment of the video is shown (only for looking - the whole video is saved)")
        self.pos.sliderReleased.connect(self._request)
        self.pos.valueChanged.connect(lambda val: self.pos_label.setText(fmt(val / 10)))
        r.addWidget(self.pos, 1)
        self.pos_label = QLabel("0:00.00")
        r.addWidget(self.pos_label)
        self.result = QLabel("", objectName="muted")
        r.addWidget(self.result)
        v.addLayout(r)
        r2 = QHBoxLayout()
        self.own_chk = check("Own turn & crop for this video", False,
                             "Ticked: the turn, flips and crop you set now are for this video only.\n"
                             "Unticked: this video uses the settings shared by all the other videos.\n\n"
                             "When to use: a batch where one or two videos need something different.")
        self.own_chk.setEnabled(False)
        self.own_chk.toggled.connect(self._own_toggled)
        r2.addWidget(self.own_chk)
        self.own_note = QLabel("", objectName="muted")
        r2.addWidget(self.own_note, 1)
        v.addLayout(r2)
        return box

    def _request(self):
        if self.current and self.grabber:
            self.grabber.request(self.current, self.pos.value() / 10)

    def _frame(self, _key, img: QImage):
        self._raw = img
        self._show()

    def _show(self):
        img = self._raw
        if img.isNull():
            self.view.set_image(QImage())
            return
        rot = self.rotate.currentData()
        if rot:
            img = img.transformed(QTransform().rotate(rot))
        if self.hflip.isChecked() or self.vflip.isChecked():
            img = img.mirrored(self.hflip.isChecked(), self.vflip.isChecked())
        self.view.set_image(img)
        self._update_result()

    def current_changed(self, p):
        info = self.infos.get(p) if p else None
        self.own_chk.blockSignals(True)
        self.own_chk.setChecked(bool(p) and p in self.own)
        self.own_chk.setEnabled(bool(p))
        self.own_chk.blockSignals(False)
        self._load_geo(self.own.get(p, self.shared) if p else self.shared)
        self._own_label()
        if not p or not self.usable(info):
            self._raw = QImage()
            self.view.message = "Click a video in the list to see it here." if not p else "Reading the video…"
            self.view.set_image(QImage())
            return
        self.pos.blockSignals(True)
        self.pos.setRange(0, int(max(0.0, info.duration - 0.2) * 10))
        self.pos.setValue(min(self.pos.maximum(), int(info.duration * 10 * 0.3)))
        self.pos.blockSignals(False)
        self.pos_label.setText(fmt(self.pos.value() / 10))
        self._request()

    # ------------------------------------------------------------------ settings
    def build_settings(self, col):
        st = self.st
        T = col.add(Card("Turn & flip"))
        self.rotate = T.row("Turn:", combo(ROTATIONS, int(st("rotate", 0))),
                            "Turns the picture. For phone video filmed sideways or upside down.")
        self.hflip = T.full(check("Mirror left ↔ right", bool(st("hflip", False)),
                                  "Like a mirror: for selfie-camera video that shows text backwards"))
        self.vflip = T.full(check("Flip upside down ↕", bool(st("vflip", False)),
                                  "Flips top and bottom (a camera mounted upside down)"))
        self.lossless = T.full(check("Turn without re-encoding when possible", bool(st("lossless", True)),
                                     "When only turning (no mirror or crop), the video's rotation flag is changed\n"
                                     "instead: instant and lossless. Nearly every player and phone follows it;\n"
                                     "a few old programs and TVs ignore it.\n\n"
                                     "When to use: on normally; off if an old player still shows the video sideways."))
        C = col.add(Card("Crop", "Cut away the edges of the picture"))
        self.aspect = C.row("Crop shape:", combo([(n, k) for n, k in ASPECTS], None),
                            "Off: keep the whole picture.\n"
                            "Free: draw any box on the picture.\n"
                            "A shape (16:9, 9:16, 1:1…): the box keeps that shape - e.g. 9:16 makes an upright\n"
                            "video for phones from a wide one.\n\n"
                            "Drag inside the box to move it, drag a corner to resize it, drag outside it to\n"
                            "draw a new one.")
        # (the combo's data is the shape; restore by name)
        idx = next((i for i, (n, _k) in enumerate(ASPECTS) if n == st("aspect_name", "Off")), 0)
        self.aspect.setCurrentIndex(idx)
        self.reset_crop = QPushButton("Biggest box of this shape")
        self.reset_crop.setToolTip("Put the box back to the biggest centred box of the chosen shape")
        self.reset_crop.clicked.connect(self._reset_box)
        C.full(self.reset_crop)
        V = col.add(Card("Video"))
        self.crf = V.row("Quality:", spin(0, 40, int(st("crf", 18)), " CRF"),
                         "Lower = better and bigger. 18 looks practically identical to the original.\n"
                         "Set by the Quality level (top left).")
        self.enc_gpu = V.row("Encoder:", combo([("Graphics card (faster)", True), ("Processor", False)],
                                               bool(st("enc_gpu", True))))
        self.keep_date = V.full(check("Give the new file the original's date", bool(st("keep_date", True))))
        self.remember = T.full(check("Remember each video's own settings after closing", bool(st("remember_own", False)),
                                     "Off: videos given their own turn/crop go back to the shared settings\n"
                                     "when the program is closed.\nOn: they keep them next time."))
        self.remember.toggled.connect(self._remember_toggled)
        self.view.aspect = self.aspect.currentData()
        saved = st("crop", None)
        self.view.box = list(saved) if saved and self.view.aspect is not None else None
        self.aspect.currentIndexChanged.connect(self._aspect_changed)
        self.rotate.currentIndexChanged.connect(self._turn_changed)
        self.hflip.toggled.connect(lambda *_: (self._show(), self._geo_changed()))
        self.vflip.toggled.connect(lambda *_: (self._show(), self._geo_changed()))
        self.connect_all(self.lossless, self.crf, self.enc_gpu, self.keep_date)
        self.shared = self._geo()

    # ------------------------------------------------------------------ shared / own settings
    def _geo(self) -> dict:
        box = norm_crop(self.view.box) if self.view.aspect is not None else None
        return {"rotate": self.rotate.currentData(), "hflip": self.hflip.isChecked(),
                "vflip": self.vflip.isChecked(), "crop": box, "aspect_name": self.aspect.currentText()}

    def _load_geo(self, g: dict):
        """Show a video's (or the shared) turn/flip/crop in the controls."""
        if not g or not hasattr(self, "rotate"):
            return
        ws = (self.rotate, self.hflip, self.vflip, self.aspect)
        for w in ws:
            w.blockSignals(True)
        self.rotate.setCurrentIndex(max(0, self.rotate.findData(int(g.get("rotate") or 0))))
        self.hflip.setChecked(bool(g.get("hflip")))
        self.vflip.setChecked(bool(g.get("vflip")))
        idx = next((i for i, (n, _k) in enumerate(ASPECTS) if n == g.get("aspect_name", "Off")), 0)
        self.aspect.setCurrentIndex(idx)
        for w in ws:
            w.blockSignals(False)
        self.view.aspect = self.aspect.currentData()
        crop = g.get("crop")
        if self.view.aspect is None:
            self.view.box = None
        else:
            self.view.box = list(crop) if crop else [0.0, 0.0, 1.0, 1.0]
        self.reset_crop.setEnabled(self.view.aspect is not None)
        self._show()
        self.view.update()

    def _geo_changed(self):
        g = self._geo()
        if self.current is not None and self.current in self.own:
            self.own[self.current] = g
            self._save_own()
        else:
            self.shared = g
        self.changed()

    def _own_toggled(self, on: bool):
        p = self.current
        if p is None:
            return
        if on:
            self.own[p] = dict(self.shared)
        else:
            self.own.pop(p, None)
            self._load_geo(self.shared)
        self._save_own()
        self._own_label()
        self.changed()

    def _own_label(self):
        n = len([p for p in self.own if p in self.files])
        cur = self.current is not None and self.current in self.own
        self.own_note.setText(("Changes now apply to this video only. " if cur else "") +
                              (f"{n} video(s) have their own settings." if n else ""))

    def _save_own(self):
        if self.remember.isChecked():
            self.feature.set_setting("own_geo", {str(p): g for p, g in list(self.own.items())[-2000:]})

    def _remember_toggled(self, on: bool):
        self.feature.set_setting("remember_own", on)
        if on:
            self._save_own()
        else:
            self.feature.set_setting("own_geo", {})

    def effective(self, p: Path) -> dict:
        return {**self.settings(), **self.own.get(p, {})}

    def _turn_changed(self, *_):
        if self.view.aspect is not None:          # the box belongs to the turned picture: start it again
            self.view.box = None
        self._show()
        if self.view.aspect is not None:
            self.view.box = self.view.max_box()
            self.view.update()
        self._geo_changed()

    def _aspect_changed(self, *_):
        self.view.aspect = self.aspect.currentData()
        if self.view.aspect is None:
            self.view.box = None
        elif self.view.aspect == 0.0:
            self.view.box = self.view.box or [0.1, 0.1, 0.8, 0.8]
        else:
            self.view.box = self.view.max_box()
        self.view.update()
        self._geo_changed()

    def _reset_box(self):
        if self.view.aspect is not None:
            self.view.box = self.view.max_box() if self.view.aspect else [0.1, 0.1, 0.8, 0.8]
            self.view.update()
            self._geo_changed()

    def _box_changed(self, _box):
        self._geo_changed()

    def settings_changed(self):
        self.reset_crop.setEnabled(self.view.aspect is not None)
        self._update_result()

    def _update_result(self):
        p = self.current
        info = self.infos.get(p) if p else None
        if not self.usable(info):
            self.result.setText("")
            return
        w, h = result_size(info.video.width, info.video.height, self.effective(p))
        self.result.setText(f"  Result: {w}×{h}")

    def settings(self) -> dict:
        g = self.shared or (self._geo() if hasattr(self, "rotate") else {})
        return {**g, "lossless": self.lossless.isChecked(), "crf": self.crf.value(),
                "enc_gpu": self.enc_gpu.currentData(), "keep_date": self.keep_date.isChecked()}

    def spec_for(self, files):
        per = {str(p): g for p, g in self.own.items() if str(p) in files}
        return dict(super().spec_for(files), enc_speed=self.st("enc_speed", "balanced"), per_file=per)

    def reload_settings(self):
        from breezy.core.ui import reload_from
        reload_from(self.feature, {"crf": self.crf, "enc_gpu": self.enc_gpu})

    def can_run(self) -> str:
        if not hasattr(self, "view") or not hasattr(self, "keep_date"):
            return ""
        jobs = [Path(f) for f in self.jobs()]
        if any(has_work(self.effective(p)) for p in jobs) or (not jobs and has_work(self.settings())):
            return ""
        return "Choose a turn, a flip or a crop"

    def fill_row(self, it, p: Path, info):
        v = info.video
        it.setText(1, fmt(info.duration, False))
        fps = f" {float(v.fps):.3g} fps" if v.fps else ""
        it.setText(2, f"{v.width}×{v.height}{fps}")
        it.setText(3, _fmt_size(info.size))
        if not hasattr(self, "keep_date"):
            return
        s = self.effective(p)
        own = "own settings · " if p in self.own else ""
        if not has_work(s):
            it.setText(5, own + "nothing to change - skipped")
            return
        w, h = result_size(v.width, v.height, s)
        it.setText(4, f"{w}×{h}")
        it.setText(5, own + ("rotation flag only (instant)" if flag_only(s) else "re-encoded"))

    def shutdown(self):
        super().shutdown()
        if self.grabber:
            self.grabber.shutdown()
