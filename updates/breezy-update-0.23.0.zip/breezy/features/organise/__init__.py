"""Organise: rename & sort videos by date or camera, and find duplicate videos."""
from breezy.core.plugin import Feature
from . import tasks  # noqa: F401  (registers the task runners)


class OrganiseFeature(Feature):
    id = "organise"
    name = "Organise"
    description = ("Rename videos by date and time (or camera) and sort them into folders - with a preview "
                   "first and undo afterwards.")
    order = 50
    icon = "files"

    def create_widget(self):
        from .widget import OrganiseWidget
        self.widget = OrganiseWidget(self)
        return self.widget

    def theme_changed(self):
        self.widget._make_plan()


FEATURE = OrganiseFeature
