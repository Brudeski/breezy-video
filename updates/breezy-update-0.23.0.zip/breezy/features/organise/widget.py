"""Organise page: rename & sort videos by date / camera."""
from __future__ import annotations

import sys
from pathlib import Path

from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (QFileDialog, QHBoxLayout, QLabel, QLineEdit, QMessageBox, QPlainTextEdit,
                               QPushButton, QSplitter, QTreeWidget, QTreeWidgetItem, QVBoxLayout,
                               QWidget)

from breezy.core import theme
from breezy.core.tasks import Task
from breezy.core.ui import Card, SettingsColumn, TaskBar, check, combo, spin
from . import logic

ROLE = Qt.UserRole


def _size(n: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024:
            return f"{n:.0f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


class OrganiseWidget(QWidget):
    def __init__(self, feature):
        super().__init__()
        self.feature = feature
        self.ctx = feature.context
        self.tm = self.ctx.tasks
        self.extra_files: list[Path] = []
        self.infos = []
        self.groups: list[logic.DupGroup] = []
        self.plan: list[logic.Move] = []
        self.keep: dict[Path, bool] = {}
        self._scan_id = None
        self._regen = QTimer(self, singleShot=True, interval=250)
        self._regen.timeout.connect(self._make_plan)
        st = feature.setting

        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)

        src = Card()
        top = QHBoxLayout()
        self.folder_edit = QLineEdit(st("last_folder", ""))
        self.folder_edit.setPlaceholderText("Folder of videos…")
        browse = QPushButton("Browse…")
        browse.clicked.connect(self._browse)
        add = QPushButton("Add files…")
        add.clicked.connect(self._add_files)
        clear = QPushButton("Clear")
        clear.clicked.connect(self._clear)
        self.recursive = check("Include subfolders", st("recursive", True))
        self.scan_btn = QPushButton("Read videos", objectName="primary")
        self.scan_btn.clicked.connect(lambda: self.scan(False))
        for wdg in (QLabel("Folder:"), self.folder_edit, browse, add, clear, self.recursive, self.scan_btn):
            top.addWidget(wdg, 1 if wdg is self.folder_edit else 0)
        src.v.addLayout(top)
        self.extra_label = QLabel("", objectName="muted")
        src.v.addWidget(self.extra_label)
        lv.addWidget(src)

        # ---- rename & sort
        rn = QWidget()
        rv = QVBoxLayout(rn)
        rv.setContentsMargins(0, 6, 0, 0)
        self.plan_tree = QTreeWidget()
        self.plan_tree.setHeaderLabels(["Video", "Goes to", "Date from"])
        self.plan_tree.setRootIsDecorated(False)
        self.plan_tree.header().resizeSection(0, 300)
        self.plan_tree.header().resizeSection(1, 460)
        rv.addWidget(self.plan_tree, 1)
        rb = QHBoxLayout()
        self.plan_label = QLabel("", objectName="muted")
        self.undo_btn = QPushButton("Undo last move")
        self.undo_btn.clicked.connect(self._undo)
        self.apply_btn = QPushButton("Rename && sort", objectName="primary")
        self.apply_btn.clicked.connect(self._apply_plan)
        rb.addWidget(self.plan_label, 1)
        rb.addWidget(self.undo_btn)
        rb.addWidget(self.apply_btn)
        rv.addLayout(rb)
        split = QSplitter(Qt.Vertical)
        split.addWidget(rn)
        self.log = QPlainTextEdit(readOnly=True)
        self.log.setMaximumBlockCount(2000)
        split.addWidget(self.log)
        split.setSizes([600, 120])
        lv.addWidget(split, 1)
        self.taskbar = TaskBar(self.tm, "organise")
        self.taskbar.hide()                 # progress is shown in the bar at the bottom and on the Tasks page
        root.addWidget(left, 1)

        # ---- settings
        col = SettingsColumn(380)
        r = col.add(Card("Rename & sort", "Nothing changes until you press 'Rename & sort'"))
        self.name_preset = r.row("New names:", combo(logic.NAME_PRESETS + [("Custom…", "custom")],
                                                     st("name_preset", "{date} {time}")))
        self.name_pat = r.row("Name pattern:", QLineEdit(st("name_pattern", "{date} {time}")),
                              "Tokens: " + logic.TOKENS)
        self.folder_preset = r.row("Folders:", combo(logic.FOLDER_PRESETS + [("Custom…", "custom")],
                                                     st("folder_preset", "{year}/{year}-{month}")))
        self.folder_pat = r.row("Folder pattern:", QLineEdit(st("folder_pattern", "{year}/{year}-{month}")),
                                "Use / for subfolders. Tokens: " + logic.TOKENS)
        self.where = r.row("Put them:", combo([("Where they are now (move)", "here"),
                                               ("In another folder (move)", "move"),
                                               ("In another folder (copy - originals stay)", "copy")],
                                              st("where", "here")))
        tw = QWidget()
        th = QHBoxLayout(tw)
        th.setContentsMargins(0, 0, 0, 0)
        self.target = QLineEdit(st("target", ""))
        self.target.setPlaceholderText("Pick a folder…")
        tb = QPushButton("Browse…")
        tb.clicked.connect(self._pick_target)
        th.addWidget(self.target, 1)
        th.addWidget(tb)
        self.target_row = r.row("Folder:", tw)
        r.note("Dates come from the time in the file name, else the date stored in the video, "
               "else the file date. Camera = the model the file names, else the picture height.")
        root.addWidget(col)

        for w in (self.name_pat, self.folder_pat, self.target):
            w.textChanged.connect(self._settings_changed)
        for w in (self.name_preset, self.folder_preset, self.where):
            w.currentIndexChanged.connect(self._preset_changed)
        self.tm.finished.connect(self._task_finished)
        self._preset_changed()
        from breezy.core.ui import install_drop, install_list_tools
        install_drop(self, self._drop_folder, self._add_paths)
        install_list_tools(self.plan_tree, lambda it: Path(it.data(0, ROLE)) if it and it.data(0, ROLE) else None)
        self._update_buttons()

    # ------------------------------------------------------------------ files
    def _say(self, msg: str):
        self.log.appendPlainText(msg)

    def _browse(self):
        d = QFileDialog.getExistingDirectory(self, "Folder of videos", self.folder_edit.text())
        if d:
            self._drop_folder(Path(d))

    def _drop_folder(self, d: Path):
        self.folder_edit.setText(str(d))
        self.scan(False)

    def _add_files(self):
        from breezy.core.ui import pick_videos
        files = pick_videos(self, self.folder_edit.text().strip())
        if files:
            self._add_paths(files)

    def _add_paths(self, files):
        self.extra_files += [f for f in files if f not in self.extra_files]
        self.scan(False)

    def _clear(self):
        self.folder_edit.setText("")
        self.extra_files, self.infos, self.groups, self.plan = [], [], [], []
        self.plan_tree.clear()
        self._update_buttons()

    def _pick_target(self):
        d = QFileDialog.getExistingDirectory(self, "Put the videos in", self.target.text())
        if d:
            self.target.setText(d)

    # --------------------------------------------------------------- settings
    def _preset_changed(self, *_):
        for combo_w, edit in ((self.name_preset, self.name_pat), (self.folder_preset, self.folder_pat)):
            v = combo_w.currentData()
            edit.setEnabled(v == "custom")
            if v != "custom":
                edit.blockSignals(True)
                edit.setText(v)
                edit.blockSignals(False)
        self.target_row.setEnabled(self.where.currentData() != "here")
        self._settings_changed()

    def _settings_changed(self, *_):
        f = self.feature
        f.set_setting("name_preset", self.name_preset.currentData())
        f.set_setting("name_pattern", self.name_pat.text())
        f.set_setting("folder_preset", self.folder_preset.currentData())
        f.set_setting("folder_pattern", self.folder_pat.text())
        f.set_setting("where", self.where.currentData())
        f.set_setting("target", self.target.text().strip())
        f.set_setting("last_folder", self.folder_edit.text().strip())
        f.set_setting("recursive", self.recursive.isChecked())
        self._regen.start()

    # ------------------------------------------------------------------ scan
    def scan(self, dups: bool):
        folder = self.folder_edit.text().strip()
        if not folder and not self.extra_files:
            QMessageBox.information(self, "Organise", "Choose a folder, or add files.")
            return
        spec = {"folder": folder, "recursive": self.recursive.isChecked(),
                "files": [str(f) for f in self.extra_files], "dups": False}
        name = Path(folder).name if folder else f"{len(self.extra_files)} file(s)"
        t = Task("organise.scan", "organise", ("Find duplicates in " if dups else "Read videos in ") + name,
                 spec=spec, resumable=False, media=False)
        self._scan_id = t.id
        self.tm.submit(t)
        self.taskbar.follow(t.id)
        self._say("Looking for duplicates…" if dups else "Reading the videos…")
        self._update_buttons()

    def _task_finished(self, task_id: str):
        t = self.tm.get(task_id)
        if not t or t.module != "organise":
            return
        res = self.tm.results.pop(task_id, None)
        if t.kind == "organise.scan" and res is not None and task_id == self._scan_id:
            self.infos = res["infos"]
            self._make_plan()
            self._say(f"{len(self.infos)} video(s) read." + (f" {len(self.groups)} set(s) of duplicates."
                                                            if t.spec.get("dups") else ""))
        elif t.kind in ("organise.apply", "organise.undo"):
            self._say(t.message or ("Done." if t.status == "done" else t.status))
            if t.status == "done":
                self.infos, self.groups = [], []
                self.plan_tree.clear()
                if self.folder_edit.text().strip() or self.extra_files:
                    self.extra_files = [Path(o) for o in t.outputs] if not self.folder_edit.text().strip() \
                        else self.extra_files
                    QTimer.singleShot(200, lambda: self.scan(False))
        self._update_buttons()

    # ---------------------------------------------------------------- rename
    def _target(self) -> Path | None:
        if self.where.currentData() == "here":
            return None
        t = self.target.text().strip()
        return Path(t) if t else None

    def _make_plan(self):
        self.plan_tree.clear()
        if not self.infos:
            self.plan = []
            self._update_buttons()
            return
        if self.where.currentData() != "here" and self._target() is None:
            self.plan = []
            self.plan_label.setText("Pick the folder to put them in.")
            self._update_buttons()
            return
        self.plan = logic.plan_renames(self.infos, self.name_pat.text().strip() or "{name}",
                                       self.folder_pat.text().strip(), self._target())
        c = theme.colors()
        changes = 0
        for m in self.plan:
            it = QTreeWidgetItem(self.plan_tree)
            it.setData(0, ROLE, str(m.src))
            it.setText(0, m.src.name)
            it.setToolTip(0, str(m.src))
            same = m.src.resolve() == m.dst.resolve()
            base = self._target() or m.src.parent
            try:
                shown = str(m.dst.relative_to(base))
            except ValueError:
                shown = str(m.dst)
            it.setText(1, "(no change)" if same else shown)
            it.setToolTip(1, str(m.dst))
            it.setText(2, m.source_of_date)
            if same:
                it.setForeground(1, QBrush(QColor(c["muted"])))
            else:
                changes += 1
        verb = "copied" if self.where.currentData() == "copy" else "moved/renamed"
        self.plan_label.setText(f"{changes} of {len(self.plan)} video(s) will be {verb}.")
        self._update_buttons()

    def _apply_plan(self):
        moves = [[str(m.src), str(m.dst)] for m in self.plan if m.src.resolve() != m.dst.resolve()]
        if not moves:
            return
        copy = self.where.currentData() == "copy"
        if QMessageBox.question(self, "Rename & sort",
                                f"{'Copy' if copy else 'Move/rename'} {len(moves)} video(s) as shown?"
                                + ("" if copy else "\n\nYou can undo it with 'Undo last move'.")) != QMessageBox.Yes:
            return
        t = Task("organise.apply", "organise", f"{'Copy' if copy else 'Rename & sort'} {len(moves)} video(s)",
                 spec={"moves": moves, "copy": copy, "what": "Copying" if copy else "Renaming & sorting"},
                 resumable=False)
        self.tm.submit(t)
        self.taskbar.follow(t.id)

    def _undo(self):
        from .tasks import undo_dir
        files = sorted(undo_dir().glob("*.json"))
        if not files:
            QMessageBox.information(self, "Undo", "There's nothing to undo.")
            return
        last = files[-1]
        import json
        n = len(json.loads(last.read_text("utf-8")).get("moves", []))
        if QMessageBox.question(self, "Undo", f"Put the {n} file(s) from the last move back where they were?") \
                != QMessageBox.Yes:
            return
        t = Task("organise.undo", "organise", f"Undo: put {n} file(s) back", spec={"undo": str(last)},
                 resumable=False, media=False)
        self.tm.submit(t)
        self.taskbar.follow(t.id)

    # --------------------------------------------------------------- buttons
    def _update_buttons(self):
        busy = any(t.module == "organise" and t.status in ("queued", "running") for t in self.tm.tasks)
        n = len(self.extra_files)
        self.extra_label.setText(f"+ {n} added file(s)" if n else "")
        self.extra_label.setVisible(bool(n))
        self.apply_btn.setEnabled(not busy and any(m.src.resolve() != m.dst.resolve() for m in self.plan))
        self.scan_btn.setEnabled(not busy)
        from .tasks import undo_dir
        self.undo_btn.setEnabled(not busy and any(undo_dir().glob("*.json")))
