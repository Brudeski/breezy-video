"""Organise: rename & sort videos by date/camera, and find duplicate videos.

Everything here is plain logic (no Qt) so it can be tested:
- plan_renames(): old path -> new path from name / folder patterns, without touching anything
- apply_moves(): carry a plan out (move or copy), writing an undo list
- duplicates(): identical files (same size + same content samples) and the same footage in other
  files (re-encoded, resized: same length + the same pictures at 9 points)
"""
from __future__ import annotations

import hashlib
import json
import re
import shutil
import time
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path
from typing import Callable, Optional

import numpy as np

from breezy.core.ffmpeg import MediaInfo

VIDEO_EXTS = {".mp4", ".m4v", ".mov", ".mkv", ".avi", ".wmv", ".asf", ".flv", ".webm", ".mts", ".m2ts", ".ts",
              ".mpg", ".mpeg", ".vob", ".3gp", ".dv"}
TOKENS = ("{date} {time} {year} {month} {day} {hour} {minute} {second} {camera} {res} {fps} {name} {n} "
          "{folder}")
NAME_PRESETS = [("Date and time (2025-07-01 15.24.51)", "{date} {time}"),
                ("Date, time and camera", "{date} {time} {camera}"),
                ("Date and original name", "{date} {name}"),
                ("Keep the name", "{name}")]
FOLDER_PRESETS = [("Don't sort into folders", ""), ("Year / month", "{year}/{year}-{month}"),
                  ("Year / day", "{year}/{date}"), ("Camera / year-month", "{camera}/{year}-{month}"),
                  ("Day", "{date}")]


# ------------------------------------------------------------------ when & what
def when(info: MediaInfo) -> tuple[Optional[float], str]:
    """Start time of a clip (epoch seconds, local clock as written) and where it came from."""
    from breezy.features.stitcher.detector import name_time
    nt = name_time(info.path)
    if nt and nt.start > 86400 * 365:           # 1970-01-01 names (camera clock not set) don't count
        return nt.start, "file name"
    if info.creation_time:
        return info.creation_time, "stored in the file"
    if info.mtime:
        return info.mtime - (info.duration or 0), "file date"
    return None, ""


def camera_label(info: MediaInfo) -> str:
    """A short camera name: the model the file names, else the picture size."""
    tags = dict(x.split("=", 1) for x in info.camera.split("; ") if "=" in x) if info.camera else {}
    for k in sorted(tags):
        if "model" in k and tags[k].strip():
            make = next((tags[m] for m in tags if "make" in m or "manufacturer" in m), "")
            model = tags[k].strip()
            return model if make.lower() in model.lower() else f"{make} {model}".strip()
    v = info.video
    return f"{v.height}p" if v and v.height else "unknown camera"


def _clean(s: str) -> str:
    s = "".join("_" if c in '<>:"\\|?*' or ord(c) < 32 else c for c in s)
    return re.sub(r"\s+", " ", s).strip(" .")


def fill(pattern: str, info: MediaInfo, n: int = 1) -> str:
    t, src = when(info)
    if t is None:
        d = None
    elif src == "file name":                     # the camera's clock as written in the name
        d = datetime(1970, 1, 1) + timedelta(seconds=t)
    else:                                        # real moments: show them in this PC's time zone
        d = datetime.fromtimestamp(t)
    v = info.video
    fps = float(v.fps) if v and v.fps else 0
    vals = {"date": d.strftime("%Y-%m-%d") if d else "no date", "time": d.strftime("%H.%M.%S") if d else "",
            "year": d.strftime("%Y") if d else "no date", "month": d.strftime("%m") if d else "",
            "day": d.strftime("%d") if d else "", "hour": d.strftime("%H") if d else "",
            "minute": d.strftime("%M") if d else "", "second": d.strftime("%S") if d else "",
            "camera": camera_label(info), "res": f"{v.width}x{v.height}" if v else "",
            "fps": f"{fps:.0f}fps" if fps else "", "name": info.path.stem, "n": f"{n:03d}",
            "folder": info.path.parent.name}
    out = pattern
    for k, val in vals.items():
        out = out.replace("{" + k + "}", val)
    return out


@dataclass
class Move:
    src: Path
    dst: Path
    source_of_date: str = ""


def plan_renames(infos: list[MediaInfo], name_pattern: str, folder_pattern: str, target: Optional[Path],
                 ) -> list[Move]:
    """Where each file would go. target None = the file's own folder. Never two files to one name."""
    plan: list[Move] = []
    taken: set[str] = set()
    ordered = sorted(infos, key=lambda i: (when(i)[0] or 0, i.path.name.lower()))
    for n, info in enumerate(ordered, 1):
        base = Path(target) if target else info.path.parent
        sub = [_clean(p) for p in fill(folder_pattern, info, n).replace("\\", "/").split("/") if _clean(p)] \
            if folder_pattern.strip() else []
        stem = _clean(fill(name_pattern, info, n)) or info.path.stem
        folder = base.joinpath(*sub)
        dst = folder / (stem + info.path.suffix.lower())
        k = 2
        while (str(dst).lower() in taken or (dst.exists() and dst.resolve() != info.path.resolve())):
            dst = folder / f"{stem} ({k}){info.path.suffix.lower()}"
            k += 1
        taken.add(str(dst).lower())
        plan.append(Move(info.path, dst, when(info)[1]))
    return plan


def apply_moves(moves: list[Move], copy: bool, undo_file: Optional[Path],
                progress: Callable[[float, str], None] = lambda f, s: None,
                cancel: Callable[[], None] = lambda: None) -> tuple[int, list[str]]:
    """Carry out a plan. Moves are recorded in undo_file (as they happen) so they can be undone."""
    done, errors, log = 0, [], []
    for i, m in enumerate(moves):
        cancel()
        if m.src.resolve() == m.dst.resolve():
            continue
        try:
            m.dst.parent.mkdir(parents=True, exist_ok=True)
            if m.dst.exists():
                raise FileExistsError(f"{m.dst.name} already exists")
            if copy:
                shutil.copy2(m.src, m.dst)
            else:
                shutil.move(str(m.src), str(m.dst))
                log.append([str(m.src), str(m.dst)])
                if undo_file:
                    undo_file.write_text(json.dumps({"time": time.time(), "moves": log}, indent=1), "utf-8")
            done += 1
        except Exception as e:  # noqa
            errors.append(f"{m.src.name}: {e}")
        progress((i + 1) / max(1, len(moves)), m.src.name)
    return done, errors


def undo(undo_file: Path) -> tuple[int, list[str]]:
    data = json.loads(Path(undo_file).read_text("utf-8"))
    n, errors = 0, []
    for src, dst in reversed(data.get("moves", [])):
        try:
            if Path(src).exists():
                raise FileExistsError(f"{Path(src).name} exists again")
            Path(src).parent.mkdir(parents=True, exist_ok=True)
            shutil.move(dst, src)
            n += 1
            for parent in Path(dst).parents:          # remove folders the sort created, if now empty
                try:
                    parent.rmdir()
                except OSError:
                    break
        except Exception as e:  # noqa
            errors.append(f"{Path(dst).name}: {e}")
    return n, errors


# ------------------------------------------------------------------ duplicates
def quick_hash(path: Path, chunk: int = 1 << 20) -> str:
    """Size + three 1 MB samples (start, middle, end): equal for identical files, practically never
    equal otherwise."""
    p = Path(path)
    size = p.stat().st_size
    h = hashlib.sha1(str(size).encode())
    with open(p, "rb") as f:
        for pos in (0, max(0, size // 2 - chunk // 2), max(0, size - chunk)):
            f.seek(pos)
            h.update(f.read(chunk))
    return h.hexdigest()


FP_W, FP_H, FP_N = 32, 18, 9


def fingerprint(ffmpeg, info: MediaInfo) -> Optional[list[int]]:
    """9 tiny grey pictures at 10%..90% of the clip (independent of size, codec and quality)."""
    from breezy.core import proc
    dur = info.duration or (info.video.duration if info.video else 0)
    if not dur or not info.video:
        return None
    out = bytearray()
    for k in range(FP_N):
        t = dur * (0.1 + 0.8 * k / (FP_N - 1))
        r = proc.run([ffmpeg.ffmpeg, "-v", "error", "-nostdin", "-ss", f"{t:.3f}", "-i", str(info.path),
                      "-frames:v", "1", "-vf", f"scale={FP_W}:{FP_H}:flags=area,format=gray", "-f", "rawvideo", "-"],
                     timeout=120)
        if len(r.stdout) < FP_W * FP_H:
            return None
        out += r.stdout[:FP_W * FP_H]
    return list(out)


def footage_match(a: list[int], b: list[int]) -> float:
    """0..1: how alike two fingerprints are (correlation of each picture, averaged)."""
    x = np.asarray(a, np.float32).reshape(FP_N, -1)
    y = np.asarray(b, np.float32).reshape(FP_N, -1)
    scores = []
    for p, q in zip(x, y):
        p, q = p - p.mean(), q - q.mean()
        d = float(np.sqrt((p * p).sum() * (q * q).sum()))
        if d < 1e-3:                                  # flat picture (black): compare brightness instead
            scores.append(1.0 - min(1.0, abs(float(x.mean() - y.mean())) / 40))
            continue
        scores.append(float((p * q).sum() / d))
    return max(0.0, float(np.mean(scores)))


@dataclass
class DupGroup:
    files: list[MediaInfo]
    kind: str                       # "identical" | "same footage"
    keep: Path = None
    score: float = 1.0
    notes: list = field(default_factory=list)


def best_of(files: list[MediaInfo]) -> MediaInfo:
    """The copy to keep: most pixels, then the highest bitrate, then the oldest file name."""
    def key(i: MediaInfo):
        v = i.video
        px = (v.width * v.height) if v else 0
        rate = i.size / i.duration if i.duration else i.size
        return (px, rate, -len(i.path.name))
    return max(files, key=key)


def duplicates(infos: list[MediaInfo], hashes: dict, prints: dict, threshold: float = 0.98,
               footage: bool = True) -> list[DupGroup]:
    """hashes: path -> quick_hash, prints: path -> fingerprint (either may lack entries).
    Identical files and same-footage matches are joined into one set (a copy, a re-encode and a resized
    version of one clip end up together)."""
    parent = {i.path: i.path for i in infos}

    def find(p):
        while parent[p] != p:
            parent[p] = parent[parent[p]]
            p = parent[p]
        return p

    def union(a, b):
        parent[find(a)] = find(b)

    by_hash: dict[str, list[MediaInfo]] = {}
    for i in infos:
        h = hashes.get(i.path)
        if h:
            by_hash.setdefault(h, []).append(i)
    for items in by_hash.values():
        for other in items[1:]:
            union(items[0].path, other.path)
    scores: dict = {}
    if footage:
        cand = sorted((i for i in infos if prints.get(i.path)), key=lambda i: i.duration)
        for k, a in enumerate(cand):
            for b in cand[k + 1:]:
                if b.duration - a.duration > max(1.0, a.duration * 0.01):
                    break                              # sorted by length: nothing further can match
                if find(a.path) == find(b.path):
                    continue
                s = footage_match(prints[a.path], prints[b.path])
                if s >= threshold:
                    union(a.path, b.path)
                    scores.setdefault(find(a.path), []).append(s)
    sets: dict = {}
    for i in infos:
        sets.setdefault(find(i.path), []).append(i)
    groups = []
    for root, members in sets.items():
        if len(members) < 2:
            continue
        same_hash = len({hashes.get(m.path) for m in members}) == 1 and hashes.get(members[0].path)
        sc = [x for r, v in scores.items() if find(r) == root for x in v]
        g = DupGroup(sorted(members, key=lambda i: str(i.path).lower()), "identical" if same_hash else "same footage",
                     score=min(sc) if sc else 1.0)
        g.keep = best_of(members).path
        groups.append(g)
    return groups


def to_recycle_bin(paths: list[Path]) -> tuple[int, list[str]]:
    """Send files to the Windows Recycle Bin (they can be restored from there)."""
    import sys
    if sys.platform != "win32":
        return 0, ["the Recycle Bin is only available on Windows"]
    import ctypes
    from ctypes import wintypes

    class SHFILEOPSTRUCTW(ctypes.Structure):
        _fields_ = [("hwnd", wintypes.HWND), ("wFunc", wintypes.UINT), ("pFrom", wintypes.LPCWSTR),
                    ("pTo", wintypes.LPCWSTR), ("fFlags", ctypes.c_uint16), ("fAnyOperationsAborted", wintypes.BOOL),
                    ("hNameMappings", ctypes.c_void_p), ("lpszProgressTitle", wintypes.LPCWSTR)]
    n, errors = 0, []
    for p in paths:
        op = SHFILEOPSTRUCTW(None, 3, str(Path(p).resolve()) + "\0", None,
                             0x0040 | 0x0010 | 0x0004 | 0x0400, False, None, None)   # ALLOWUNDO|NOCONFIRM|SILENT|NOERRORUI
        rc = ctypes.windll.shell32.SHFileOperationW(ctypes.byref(op))
        if rc == 0 and not op.fAnyOperationsAborted:
            n += 1
        else:
            errors.append(f"{Path(p).name}: error {rc}")
    return n, errors
