"""Organise task runners: scan (read + optional duplicate check), apply (move / copy), undo."""
from __future__ import annotations

import json
import threading
import time
from pathlib import Path

from breezy.core.settings import app_data_dir
from breezy.core.tasks import Task, TaskContext, register_runner
from . import logic

_cache_lock = threading.Lock()


def cache_file() -> Path:
    return app_data_dir() / "organise_cache.json"


def undo_dir() -> Path:
    d = app_data_dir() / "organise_undo"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _load_cache() -> dict:
    try:
        return json.loads(cache_file().read_text("utf-8"))
    except (OSError, ValueError):
        return {}


def gather(folder: str, recursive: bool, files: list[str]) -> list[Path]:
    out: list[Path] = []
    if folder and Path(folder).is_dir():
        it = Path(folder).rglob("*") if recursive else Path(folder).glob("*")
        out = sorted(p for p in it if p.is_file() and p.suffix.lower() in logic.VIDEO_EXTS
                     and ".breezy-working" not in p.parts and "Duplicates" not in p.relative_to(folder).parts[:-1])
    for f in files:
        p = Path(f)
        if p.is_file() and p not in out:
            out.append(p)
    return out


def run_scan(task: Task, ctx: TaskContext):
    s = task.spec
    paths = gather(s.get("folder", ""), s.get("recursive", False), s.get("files", []))
    ctx.set_items(["read", "dups"] if s.get("dups") else ["read"],
                  [1, 4] if s.get("dups") else [1], ["Reading videos", "Looking for duplicates"])
    infos, hashes, prints = [], {}, {}
    for _i, step in ctx.items():
        if step == "read":
            from breezy.core import proc
            with proc.pool(s.get("workers", 6)) as pool:
                futs = [pool.submit(ctx.ffmpeg.probe, p) for p in paths]
                for n, f in enumerate(futs, 1):
                    ctx.checkpoint()
                    infos.append(f.result())
                    ctx.item_progress(n / max(1, len(futs)), f"Reading {n}/{len(futs)}")
            infos = [i for i in infos if not i.error]
            ctx.log(f"Read {len(infos)} video(s).")
        else:
            cache = _load_cache()
            todo = []
            for i in infos:
                key = f"{i.path}|{i.size}|{int(i.mtime)}"
                c = cache.get(key, {})
                if c.get("hash"):
                    hashes[i.path] = c["hash"]
                if c.get("fp"):
                    prints[i.path] = c["fp"]
                if not c.get("hash") or (s.get("footage", True) and "fp" not in c):
                    todo.append((key, i))
            done = [0]

            def work(item):
                key, info = item
                ctx.checkpoint()
                h = logic.quick_hash(info.path)
                fp = logic.fingerprint(ctx.ffmpeg, info) if s.get("footage", True) else None
                with _cache_lock:
                    hashes[info.path] = h
                    if fp:
                        prints[info.path] = fp
                    cache[key] = {"hash": h, "fp": fp}
                    done[0] += 1
                    ctx.item_progress(done[0] / max(1, len(todo)), f"Comparing {done[0]}/{len(todo)}")
            from breezy.core import proc
            with proc.pool(s.get("workers", 6)) as pool:
                list(pool.map(work, todo))
            try:
                if len(cache) > 20000:
                    cache = dict(list(cache.items())[-15000:])
                cache_file().write_text(json.dumps(cache), "utf-8")
            except OSError:
                pass
    groups = logic.duplicates(infos, hashes, prints, s.get("threshold", 0.9), s.get("footage", True)) \
        if s.get("dups") else []
    if s.get("dups"):
        ctx.log(f"Found {len(groups)} set(s) of duplicates.")
    return {"infos": infos, "groups": groups}


def run_apply(task: Task, ctx: TaskContext):
    s = task.spec
    moves = [logic.Move(Path(a), Path(b)) for a, b in s["moves"]]
    undo = undo_dir() / f"{time.strftime('%Y-%m-%d %H.%M.%S')} {task.id}.json" if not s.get("copy") else None
    ctx.set_items(["apply"], [1], [s.get("what", "Moving files")])
    for _i, _ in ctx.items():
        n, errors = logic.apply_moves(moves, s.get("copy", False), undo,
                                      lambda f, name: ctx.item_progress(f, name), ctx.checkpoint)
        for e in errors:
            ctx.error(e)
        ctx.log(f"✔ {'Copied' if s.get('copy') else 'Moved'} {n} file(s)." + (f" Undo list: {undo.name}" if undo else ""))
        for m in moves:
            if m.dst.exists():
                ctx.task.outputs.append(str(m.dst))
    return {"undo": str(undo) if undo else ""}


def run_undo(task: Task, ctx: TaskContext):
    ctx.set_items(["undo"], [1], ["Undo"])
    for _i, _ in ctx.items():
        n, errors = logic.undo(Path(task.spec["undo"]))
        for e in errors:
            ctx.error(e)
        ctx.log(f"✔ Put {n} file(s) back.")
        try:
            Path(task.spec["undo"]).rename(Path(task.spec["undo"]).with_suffix(".undone"))
        except OSError:
            pass


register_runner("organise.scan", run_scan)
register_runner("organise.apply", run_apply)
register_runner("organise.undo", run_undo)
