"""Editor for one video: player, a timeline with draggable start/end handles, and the exact
first and last kept frames (grabbed with ffmpeg, so they show precisely what will be kept)."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QObject, QPointF, QRectF, QSize, Qt, QUrl, Signal
from PySide6.QtGui import QColor, QImage, QPainter, QPen, QPixmap, QPolygonF
from PySide6.QtWidgets import (QDoubleSpinBox, QGridLayout, QHBoxLayout, QLabel, QPushButton, QSizePolicy,
                               QStackedWidget, QVBoxLayout, QWidget)

from breezy.core import theme
from breezy.features.motion.preview import HAVE_PLAYER, find_vlc
from breezy.features.motion.thumbs import grab_frame

if HAVE_PLAYER:
    from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
    from PySide6.QtMultimediaWidgets import QVideoWidget


def fmt(sec: float, tenths: bool = True) -> str:
    sec = max(0.0, sec)
    m, s = divmod(sec, 60)
    h, m = divmod(int(m), 60)
    body = f"{s:05.2f}" if tenths else f"{int(s):02d}"
    return f"{h}:{m:02d}:{body}" if h else f"{m}:{body}"


class RangeBar(QWidget):
    """Whole-video timeline. Kept part highlighted; drag the handles to move the start / end,
    click anywhere else to move the playhead."""
    startMoved = Signal(float)
    endMoved = Signal(float)
    seek = Signal(float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.duration = 0.0
        self.start = self.end = 0.0
        self.pos_s = 0.0
        self._drag: Optional[str] = None
        self.setMinimumHeight(44)
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setMouseTracking(True)
        self.setToolTip("Drag the blue handles to set the new start and end.\n"
                        "Click anywhere else to jump there.")

    def sizeHint(self):
        return QSize(400, 44)

    def set_range(self, duration: float, start: float, end: float):
        self.duration, self.start, self.end = duration, start, end
        self.update()

    def set_pos(self, t: float):
        self.pos_s = t
        self.update()

    # ------------------------------------------------------------ geometry
    def _x(self, t: float) -> float:
        w = self.width() - 20
        return 10 + (t / self.duration * w if self.duration else 0)

    def _t(self, x: float) -> float:
        w = max(1, self.width() - 20)
        return min(self.duration, max(0.0, (x - 10) / w * self.duration))

    def paintEvent(self, _e):
        c = theme.colors()
        p = QPainter(self)
        p.setRenderHint(QPainter.Antialiasing)
        bar = QRectF(10, 14, self.width() - 20, 16)
        p.setPen(Qt.NoPen)
        p.setBrush(QColor(c["panel2"]))
        p.drawRoundedRect(bar, 4, 4)
        if self.duration > 0:
            xs, xe = self._x(self.start), self._x(self.end)
            accent = QColor(c["accent"])
            fill = QColor(accent)
            fill.setAlpha(110)
            p.setBrush(fill)
            p.drawRect(QRectF(xs, bar.top(), max(1.0, xe - xs), bar.height()))
            p.setBrush(accent)
            for x in (xs, xe):                              # handles
                p.drawRoundedRect(QRectF(x - 3, 6, 6, 32), 2, 2)
            p.setBrush(QColor(c["text"]))
            xp = self._x(self.pos_s)
            p.drawPolygon(QPolygonF([QPointF(xp - 5, 2), QPointF(xp + 5, 2), QPointF(xp, 9)]))
            p.setPen(QPen(QColor(c["text"]), 1.5))
            p.drawLine(QPointF(xp, 9), QPointF(xp, 36))
        p.end()

    def _near(self, x: float) -> Optional[str]:
        if not self.duration:
            return None
        ds, de = abs(x - self._x(self.start)), abs(x - self._x(self.end))
        if min(ds, de) > 8:
            return None
        return "start" if ds <= de else "end"

    def mousePressEvent(self, e):
        x = e.position().x()
        self._drag = self._near(x)
        if self._drag is None:
            self._drag = "seek"
            self.seek.emit(self._t(x))

    def mouseMoveEvent(self, e):
        x = e.position().x()
        if self._drag == "start":
            self.startMoved.emit(min(self._t(x), self.end - 0.1))
        elif self._drag == "end":
            self.endMoved.emit(max(self._t(x), self.start + 0.1))
        elif self._drag == "seek":
            self.seek.emit(self._t(x))
        else:
            self.setCursor(Qt.SizeHorCursor if self._near(x) else Qt.PointingHandCursor)

    def mouseReleaseEvent(self, _e):
        self._drag = None


class FrameGrabber(QObject):
    """Grabs single frames in the background; emits ready(tag, image)."""
    ready = Signal(str, QImage)

    def __init__(self, ffmpeg, parent=None):
        super().__init__(parent)
        self.ff = ffmpeg
        self._pool = ThreadPoolExecutor(max_workers=2)
        self._want: dict[str, str] = {}

    def request(self, tag: str, path: Path, t: float):
        key = f"{path}|{t:.3f}"
        self._want[tag] = key
        self._pool.submit(self._work, tag, key, path, t)

    def _work(self, tag, key, path, t):
        if self._want.get(tag) != key:
            return                                          # superseded by a newer request
        img = grab_frame(self.ff.ffmpeg, path, t)
        if self._want.get(tag) == key:
            self.ready.emit(tag, img)

    def shutdown(self):
        self._pool.shutdown(wait=False, cancel_futures=True)


class EditorPanel(QWidget):
    """Set the start and end of one video. Emits changed(start, end) when the user moves either."""
    changed = Signal(float, float)
    reset = Signal()

    def __init__(self, ffmpeg, parent=None):
        super().__init__(parent)
        self.ff = ffmpeg
        self.path: Optional[Path] = None
        self.duration = 0.0
        self.fps = 30.0
        self.start = self.end = 0.0
        self.player = None
        self._pending_pos: Optional[float] = None
        self._stop_at: Optional[float] = None
        self._preview_jump: Optional[tuple[float, float]] = None
        self.vlc = find_vlc()
        self.grabber = FrameGrabber(ffmpeg, self)
        self.grabber.ready.connect(self._frame_ready)

        v = QVBoxLayout(self)
        v.setContentsMargins(0, 4, 0, 0)
        v.setSpacing(6)
        self.title = QLabel("Click a video in the list to set where it starts and ends.")
        self.title.setWordWrap(True)
        v.addWidget(self.title)

        self.stack = QStackedWidget()
        self.stack.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.placeholder = QLabel(alignment=Qt.AlignCenter)
        self.placeholder.setMinimumSize(320, 160)
        self.placeholder.setStyleSheet("background:#11141a; color:#9ca3af;")
        self.stack.addWidget(self.placeholder)
        if HAVE_PLAYER:
            self.video = QVideoWidget()
            self.stack.addWidget(self.video)
        else:
            self.placeholder.setText("Video playback isn't available on this system.\n"
                                     "The first and last kept frames below still show exactly what's kept.")
        v.addWidget(self.stack, 1)

        self.bar = RangeBar()
        self.bar.startMoved.connect(lambda t: self.set_start(t, user=True))
        self.bar.endMoved.connect(lambda t: self.set_end(t, user=True))
        self.bar.seek.connect(self.seek)
        v.addWidget(self.bar)

        tr = QHBoxLayout()
        tr.setSpacing(4)

        def btn(text, tip, fn):
            b = QPushButton(text)
            b.setToolTip(tip)
            b.clicked.connect(fn)
            tr.addWidget(b)
            return b
        self.b_home = btn("« Start", "Jump to the new start", lambda: self.seek(self.start))
        self.b_back1 = btn("−1 s", "Back 1 second (Shift+Left)", lambda: self.step_seconds(-1))
        self.b_backf = btn("◀ Frame", "Back 1 frame (Left)", lambda: self.step_frames(-1))
        self.play_btn = btn("▶ Play", "Play / pause (Space)", self.toggle)
        self.play_btn.setMinimumWidth(84)
        self.b_fwdf = btn("Frame ▶", "Forward 1 frame (Right)", lambda: self.step_frames(1))
        self.b_fwd1 = btn("+1 s", "Forward 1 second (Shift+Right)", lambda: self.step_seconds(1))
        self.b_endj = btn("End »", "Jump to the last kept frame",
                          lambda: self.seek(max(self.start, self.end - 1 / self.fps)))
        self.time = QLabel("0:00.00 / 0:00.00")
        tr.addWidget(self.time, 1, Qt.AlignRight)
        v.addLayout(tr)

        g = QGridLayout()
        g.setHorizontalSpacing(6)
        self.set_start_btn = QPushButton("⟦ Start here")
        self.set_start_btn.setToolTip("The video will start at the frame shown now (I)")
        self.set_start_btn.clicked.connect(lambda: self.set_start(self.position(), user=True))
        self.set_end_btn = QPushButton("End here ⟧")
        self.set_end_btn.setToolTip("The video will end after the frame shown now (O)")
        self.set_end_btn.clicked.connect(lambda: self.set_end(self.position() + 1 / self.fps, user=True))
        self.start_spin = self._spin("New start, in seconds from the beginning of the video")
        self.end_spin = self._spin("New end, in seconds from the beginning of the video")
        self.start_spin.valueChanged.connect(lambda t: self.set_start(t, user=True, from_spin=True))
        self.end_spin.valueChanged.connect(lambda t: self.set_end(t, user=True, from_spin=True))
        self.preview_btn = QPushButton("▶ Preview cuts")
        self.preview_btn.setToolTip("Plays the first 3 seconds after the new start,\nthen the last 3 seconds "
                                    "before the new end")
        self.preview_btn.clicked.connect(self.preview_cuts)
        self.reset_btn = QPushButton("Reset")
        self.reset_btn.setToolTip("Forget the start and end set by hand for this video;\n"
                                  "it goes back to the amounts for all videos")
        self.reset_btn.clicked.connect(self.reset.emit)
        self.vlc_btn = QPushButton("Open in VLC")
        self.vlc_btn.setToolTip("Opens the kept part in VLC" if self.vlc else "VLC is not installed")
        self.vlc_btn.clicked.connect(self.open_vlc)
        g.addWidget(QLabel("Start:"), 0, 0)
        g.addWidget(self.start_spin, 0, 1)
        g.addWidget(self.set_start_btn, 0, 2)
        g.addWidget(QLabel("End:"), 0, 3)
        g.addWidget(self.end_spin, 0, 4)
        g.addWidget(self.set_end_btn, 0, 5)
        self.kept = QLabel("", objectName="muted")
        g.addWidget(self.kept, 1, 0, 1, 3)
        bh = QHBoxLayout()
        bh.addStretch(1)
        bh.addWidget(self.preview_btn)
        bh.addWidget(self.reset_btn)
        bh.addWidget(self.vlc_btn)
        g.addLayout(bh, 1, 3, 1, 3)
        v.addLayout(g)

        fr = QHBoxLayout()
        self.first_img, self.last_img = QLabel(alignment=Qt.AlignCenter), QLabel(alignment=Qt.AlignCenter)
        for lbl, cap in ((self.first_img, "First kept frame"), (self.last_img, "Last kept frame")):
            box = QVBoxLayout()
            box.setSpacing(2)
            lbl.setMinimumSize(192, 108)
            lbl.setStyleSheet("background:#11141a; color:#9ca3af;")
            box.addWidget(lbl)
            box.addWidget(QLabel(cap, objectName="muted"), 0, Qt.AlignHCenter)
            fr.addLayout(box)
        v.addLayout(fr)
        self._enable(False)

    @staticmethod
    def _spin(tip: str) -> QDoubleSpinBox:
        s = QDoubleSpinBox()
        s.setDecimals(2)
        s.setSingleStep(0.1)
        s.setSuffix(" s")
        s.setKeyboardTracking(False)
        s.setToolTip(tip)
        s.setMinimumWidth(96)
        return s

    def _enable(self, on: bool):
        for w in (self.bar, self.b_home, self.b_back1, self.b_backf, self.play_btn, self.b_fwdf, self.b_fwd1,
                  self.b_endj, self.set_start_btn, self.set_end_btn, self.start_spin, self.end_spin,
                  self.preview_btn, self.reset_btn):
            w.setEnabled(on)
        self.play_btn.setEnabled(on and HAVE_PLAYER)
        self.preview_btn.setEnabled(on and HAVE_PLAYER)
        self.vlc_btn.setEnabled(on and bool(self.vlc))

    # ----------------------------------------------------------------- api
    def load(self, path: Path, duration: float, fps: float, start: float, end: float, by_hand: bool):
        same = path == self.path
        self.path, self.duration, self.fps = path, duration, (fps or 30.0)
        self.title.setText(f"<b>{path.name}</b>  ·  {fmt(duration)}" + ("  ·  set by hand" if by_hand else ""))
        for s in (self.start_spin, self.end_spin):
            s.blockSignals(True)
            s.setRange(0.0, duration)
            s.blockSignals(False)
        self.start, self.end = start, end
        self._show_range()
        self._enable(True)
        if not same:
            self._stop()
            self.stack.setCurrentIndex(0)
            self.placeholder.setText("Press ▶ Play, or click the timeline, to see the video." if HAVE_PLAYER
                                     else self.placeholder.text())
            self.bar.set_pos(start)
            self._update_time(start)
        self._grab()

    def clear(self):
        self._stop()
        self.path = None
        self.duration = 0.0
        self.title.setText("Click a video in the list to set where it starts and ends.")
        self.bar.set_range(0, 0, 0)
        self.first_img.clear()
        self.last_img.clear()
        self.kept.setText("")
        self.stack.setCurrentIndex(0)
        self.placeholder.setText("")
        self._enable(False)

    def position(self) -> float:
        if self.player is not None and self.stack.currentIndex() == 1:
            return self.player.position() / 1000
        return self.bar.pos_s

    # ------------------------------------------------------------- editing
    def set_start(self, t: float, user: bool = False, from_spin: bool = False):
        if not self.path:
            return
        t = min(max(0.0, t), max(0.0, self.end - 0.1))
        if abs(t - self.start) < 1e-4 and not from_spin:
            return
        self.start = t
        self._show_range(skip_spin=from_spin)
        if user:
            self.changed.emit(self.start, self.end)
            self._grab()
            if not from_spin:
                self.seek(t)

    def set_end(self, t: float, user: bool = False, from_spin: bool = False):
        if not self.path:
            return
        t = max(min(self.duration, t), self.start + 0.1)
        if abs(t - self.end) < 1e-4 and not from_spin:
            return
        self.end = t
        self._show_range(skip_spin=from_spin)
        if user:
            self.changed.emit(self.start, self.end)
            self._grab()
            if not from_spin:
                self.seek(max(self.start, t - 1 / self.fps))

    def _show_range(self, skip_spin: bool = False):
        self.bar.set_range(self.duration, self.start, self.end)
        if not skip_spin:
            for s, val in ((self.start_spin, self.start), (self.end_spin, self.end)):
                s.blockSignals(True)
                s.setValue(val)
                s.blockSignals(False)
        cut_a, cut_b = self.start, max(0.0, self.duration - self.end)
        self.kept.setText(f"Keeps {fmt(self.end - self.start)} · removes {fmt(cut_a)} from the start "
                          f"and {fmt(cut_b)} from the end")

    def _grab(self):
        if not self.path:
            return
        self.grabber.request("first", self.path, self.start)
        self.grabber.request("last", self.path, max(self.start, self.end - 1 / self.fps))

    def _frame_ready(self, tag: str, img: QImage):
        lbl = self.first_img if tag == "first" else self.last_img
        lbl.setPixmap(QPixmap.fromImage(img))

    # ------------------------------------------------------------ playback
    def _ensure_player(self) -> bool:
        if self.player is None and HAVE_PLAYER:
            self.player = QMediaPlayer(self)
            if QAudioOutput is not None:
                self.audio = QAudioOutput(self)
                self.player.setAudioOutput(self.audio)
            self.player.setVideoOutput(self.video)
            self.player.positionChanged.connect(self._on_position)
            self.player.mediaStatusChanged.connect(self._on_status)
            self.player.playbackStateChanged.connect(self._on_state)
        return self.player is not None

    def _load_media(self) -> bool:
        if not (self.path and self._ensure_player()):
            return False
        url = QUrl.fromLocalFile(str(self.path))
        self.stack.setCurrentIndex(1)
        if self.player.source() != url:
            self.player.setSource(url)
            return False                                    # position is applied once it has loaded
        return True

    def seek(self, t: float):
        if not self.path:
            return
        t = min(max(0.0, t), self.duration)
        self.bar.set_pos(t)
        self._update_time(t)
        if not HAVE_PLAYER:
            return
        if self._load_media():
            self.player.setPosition(int(round(t * 1000)))
        else:
            self._pending_pos = t
            self.player.pause()

    def step_frames(self, n: int):
        self.seek(self.position() + n / self.fps)

    def step_seconds(self, n: float):
        self.seek(self.position() + n)

    def toggle(self):
        if not (self.path and HAVE_PLAYER):
            return
        self._preview_jump = None
        self._stop_at = None
        if self.player is not None and self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()
            return
        pos = self.position()
        if pos < self.start - 0.01 or pos >= self.end - 0.05:
            pos = self.start
        self._stop_at = self.end
        self._play_from(pos)

    def preview_cuts(self):
        if not (self.path and HAVE_PLAYER):
            return
        span = min(3.0, (self.end - self.start) / 2)
        self._preview_jump = (self.start + span, self.end - span)
        self._stop_at = self.end
        self._play_from(self.start)

    def _play_from(self, t: float):
        if self._load_media():
            self.player.setPosition(int(round(t * 1000)))
        else:
            self._pending_pos = t
        self.player.play()

    def _stop(self):
        if self.player is not None:
            self.player.stop()
        self._stop_at = self._preview_jump = None

    def _on_status(self, status):
        if self._pending_pos is not None and status in (QMediaPlayer.LoadedMedia, QMediaPlayer.BufferedMedia):
            t, self._pending_pos = self._pending_pos, None
            self.player.setPosition(int(round(t * 1000)))

    def _on_position(self, ms: int):
        t = ms / 1000
        self.bar.set_pos(t)
        self._update_time(t)
        if self.player.playbackState() != QMediaPlayer.PlayingState:
            return
        if self._preview_jump and t >= self._preview_jump[0]:
            jump_to = self._preview_jump[1]
            self._preview_jump = None
            self.player.setPosition(int(round(jump_to * 1000)))
        elif self._stop_at is not None and t >= self._stop_at - 0.02:
            self._stop_at = None
            self.player.pause()

    def _on_state(self, state):
        self.play_btn.setText("❚❚ Pause" if state == QMediaPlayer.PlayingState else "▶ Play")

    def _update_time(self, t: float):
        self.time.setText(f"{fmt(t)} / {fmt(self.duration)}")

    def open_vlc(self):
        if not (self.vlc and self.path):
            return
        import subprocess
        subprocess.Popen([self.vlc, f"--start-time={self.start:.2f}", f"--stop-time={self.end:.2f}",
                          "--play-and-pause", str(self.path)])

    def shutdown(self):
        self._stop()
        self.grabber.shutdown()
