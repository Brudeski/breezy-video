"""Trim Ends page: list of videos, the same cut amounts for all of them, or start/end set by hand
per video in the editor. The cutting runs as a task."""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from PySide6.QtCore import QObject, Qt, Signal
from PySide6.QtGui import QBrush, QColor, QKeySequence, QShortcut
from PySide6.QtWidgets import (QAbstractItemView, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                               QPlainTextEdit, QPushButton, QSplitter, QTreeWidget, QTreeWidgetItem,
                               QVBoxLayout, QWidget)

from breezy.core import theme
from breezy.core.outputs import output_spec
from breezy.core.tasks import Task
from breezy.core.ui import Card, OutputCard, OutputPicker, SettingsColumn, check, combo, spin
from breezy.features.motion.widget import BITRATES
from breezy.features.stitcher.detector import VIDEO_EXTS
from breezy.features.stitcher.joiner import _fmt_size
from .editor import EditorPanel, fmt
from .tasks import MIN_KEEP, plan

ROLE = Qt.UserRole
DEFAULT_FOLDER = "Cut"
DEFAULT_PATTERN = "{name}_cut"
MODES = [("Exact (frame-accurate)", "exact"),
         ("Fastest (start moves to a keyframe)", "keyframe")]


class Prober(QObject):
    """Reads video lengths in the background; emits done(path, MediaInfo)."""
    done = Signal(str, object)

    def __init__(self, ffmpeg, parent=None):
        super().__init__(parent)
        self.ff = ffmpeg
        self._pool = ThreadPoolExecutor(max_workers=4)

    def request(self, path: Path):
        self._pool.submit(lambda: self.done.emit(str(path), self.ff.probe(path)))

    def shutdown(self):
        self._pool.shutdown(wait=False, cancel_futures=True)


class EndsWidget(QWidget):
    def __init__(self, feature):
        super().__init__()
        self.feature = feature
        self.ctx = feature.context
        self.ff = self.ctx.ffmpeg
        self.tm = self.ctx.tasks
        self.files: list[Path] = []
        self.extra_files: list[Path] = []
        self.removed: set[Path] = set()
        self.infos: dict[Path, object] = {}
        self.manual: dict[Path, tuple[float, float]] = {}     # start/end set by hand
        self.unchecked: set[Path] = set()
        self.current: Path | None = None
        if feature.setting("remember_manual", False):
            for k, v in (feature.setting("manual_ranges", {}) or {}).items():
                try:
                    self.manual[Path(k)] = (float(v[0]), float(v[1]))
                except (TypeError, ValueError, IndexError):
                    pass
        self.prober = Prober(self.ff, self)
        self.prober.done.connect(self._probed)
        self._build()
        self._install_tools()
        self._update_buttons()

    # ================================================================ layout
    def _st(self, key: str, default=None):
        """Saved setting, else the current quality level's value, else the default."""
        v = self.feature.setting(key)
        if v is not None:
            return v
        q = getattr(self.ctx, "quality", None)
        try:
            exp = q.expected("ends") if q is not None else {}
        except Exception:
            exp = {}
        if key in exp:
            return exp[key]
        if key == "full_gpu":
            try:
                from breezy.core.quality import hardware_values
                return hardware_values(self.ctx.settings).get("ends", {}).get(key, default)
            except Exception:
                pass
        return default

    def _build(self):
        st = self._st
        self._loading = True
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(14)

        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.setSpacing(8)
        src = Card()
        top = QHBoxLayout()
        self.folder_edit = QLineEdit(st("last_folder", ""))
        self.folder_edit.setPlaceholderText("Folder of videos…")
        self.folder_edit.editingFinished.connect(self._reread)
        browse = QPushButton("Browse…")
        browse.setToolTip("Choose a folder: all its videos are listed")
        browse.clicked.connect(self._browse_folder)
        add_files = QPushButton("Add files…")
        add_files.setToolTip("Choose one or more video files (they're added to the list)")
        add_files.clicked.connect(self._add_files)
        clear_files = QPushButton("Clear")
        clear_files.setToolTip("Empty the list (folder and added files)")
        clear_files.clicked.connect(self._clear_files)
        self.recursive = check("Include subfolders", st("recursive", False))
        self.recursive.toggled.connect(self._reread)
        self.use_out = QPushButton("Use output from…")
        self.use_out.setToolTip("Add files made by any module - or queue cutting the same amounts off\n"
                                "the files of a task that hasn't finished yet")
        self.use_out.clicked.connect(self._use_output)
        top.addWidget(QLabel("Folder:"))
        for w in (self.folder_edit,):
            top.addWidget(w, 1)
        for w in (browse, add_files, clear_files, self.recursive, self.use_out):
            top.addWidget(w)
        src.v.addLayout(top)
        self.extra_label = QLabel("", objectName="muted")
        src.v.addWidget(self.extra_label)
        lv.addWidget(src)

        self.tree = QTreeWidget()
        self.tree.setRootIsDecorated(False)
        self.tree.setColumnCount(7)
        self.tree.setHeaderLabels(["Video", "Length", "New start", "New end", "Kept", "Size", "Details"])
        self.tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tree.setAlternatingRowColors(True)
        h = self.tree.header()
        h.resizeSection(0, 300)
        for c, w in ((1, 75), (2, 85), (3, 85), (4, 75), (5, 80)):
            h.resizeSection(c, w)
        h.setStretchLastSection(True)
        self.tree.itemChanged.connect(self._item_changed)
        self.tree.currentItemChanged.connect(self._current_changed)
        self.editor = EditorPanel(self.ff)
        self.editor.changed.connect(self._editor_changed)
        self.editor.reset.connect(self._reset_current)
        self.tree.setMinimumHeight(90)
        self.editor.setMinimumHeight(380)
        self.log = QPlainTextEdit(readOnly=True)
        self.log.setMaximumBlockCount(2000)
        self.log.setPlaceholderText("Messages")
        split = QSplitter(Qt.Vertical)
        split.setChildrenCollapsible(False)
        split.addWidget(self.tree)
        split.addWidget(self.editor)
        split.addWidget(self.log)
        split.setStretchFactor(0, 1)
        split.setStretchFactor(1, 4)
        split.setSizes([160, 560, 60])
        lv.addWidget(split, 1)

        run = Card()
        rh = QHBoxLayout()
        self.summary = QLabel("", objectName="muted")
        rh.addWidget(self.summary)
        rh.addStretch(1)
        self.open_btn = QPushButton("Open output folder")
        self.open_btn.setToolTip("Open where the cut videos are saved")
        self.open_btn.clicked.connect(self._open_output)
        self.cut_btn = QPushButton("Cut ticked videos", objectName="primary")
        self.cut_btn.setToolTip("Make cut copies of the ticked videos. The originals are never changed.")
        self.cut_btn.clicked.connect(self.cut)
        rh.addWidget(self.open_btn)
        rh.addWidget(self.cut_btn)
        run.v.addLayout(rh)
        lv.addWidget(run)
        root.addWidget(left, 1)

        # ---------- right: settings
        col = SettingsColumn(380)
        a = col.add(Card("For all videos", "Used for every video you haven't set by hand"))
        self.head = a.row("Remove from the start:", spin(0, 86400, float(st("head", 0.0)), " s", 1, 0.5),
                          "Seconds cut off the beginning of every video.\n\n"
                          "When to use: the same amount to remove from a batch, e.g. a camera's\n"
                          "first few seconds while it settles. 0 = keep the start.")
        self.tail = a.row("Remove from the end:", spin(0, 86400, float(st("tail", 0.0)), " s", 1, 0.5),
                          "Seconds cut off the end of every video.\n\n"
                          "When to use: e.g. the moment someone reaches for the stop button. 0 = keep the end.")
        self.head.valueChanged.connect(self._amounts_changed)
        self.tail.valueChanged.connect(self._amounts_changed)
        self.all_btn = QPushButton("Use these amounts for every video")
        self.all_btn.setToolTip("Forgets the start and end set by hand on every video in the list")
        self.all_btn.clicked.connect(self._reset_all)
        a.full(self.all_btn)
        a.note("Or click a video and set its start and end by hand: drag the handles,\n"
               "use 'Start here' / 'End here', or type the times. Keys: Space play,\n"
               "I start, O end, ←/→ one frame, Shift+←/→ one second.")

        c = col.add(Card("Cuts"))
        self.mode = c.row("How to cut:", combo(MODES, st("cut_mode", "exact")),
                          "Exact: starts on exactly the frame you chose. The video is copied and only\n"
                          "the frames from the new start to the next keyframe are re-encoded (usually\n"
                          "under a second, at a quality that looks identical).\n"
                          "Fastest: nothing is re-encoded at all and it finishes almost instantly, but the\n"
                          "start moves back to the keyframe before your point (often 1-5 seconds earlier).\n\n"
                          "When to use: Exact normally; Fastest for huge files when a few extra seconds\n"
                          "at the start don't matter. The end is exact either way.")
        self.mode.currentIndexChanged.connect(self._mode_changed)
        self.edge_gpu = c.row("Encoder at the cut:", combo([("Processor (most compatible)", False),
                                                            ("Graphics card (faster)", True)], st("edge_gpu", False)),
                              "Which encoder re-encodes the few frames at the new start")
        self.edge_crf = c.row("Cut quality:", spin(0, 40, int(st("edge_crf", 16)), " CRF"),
                              "Lower = better. 16 looks identical to the original")
        self.full_gpu = c.row("If a video must be re-encoded:", combo([("Graphics card (faster)", True),
                                                                      ("Processor", False)], st("full_gpu", True)),
                              "Used when a smart cut isn't possible (e.g. codecs other than H.264 / H.265)")
        self.full_crf = c.row("Re-encode quality:", spin(0, 40, int(st("full_crf", 16)), " CRF"),
                              "Lower = better. 16 looks identical to the original")

        s = col.add(Card("Sound"))
        self.fix_drift = s.full(check("Fix audio drift (match the sound to the picture)", st("fix_drift", True),
                                      "If the sound track is longer or shorter than the picture, it's\n"
                                      "stretched slightly so it stays in sync after the cut."))
        self.exact_audio = s.full(check("Exact sound cuts (re-encode the trimmed sound once)", st("exact_audio", True),
                                        "On: sound is cut sample-exactly and re-encoded once (tiny quality loss).\n"
                                        "Off: sound is copied losslessly but can lag up to ~0.13 s at the cut."))
        self.abr = s.row("Re-encoded sound bitrate:", combo(BITRATES, st("audio_bitrate", "")),
                         "Automatic matches the original's bitrate")

        self.remember = a.full(check("Remember start and end set by hand after closing the program",
                                     st("remember_manual", False),
                                     "Off: every video starts with the amounts for all videos each time you\n"
                                     "open the program.\n"
                                     "On: videos you set by hand keep their start and end next time.\n\n"
                                     "When to use: on if you work through a big folder over several sessions."))
        self.remember.toggled.connect(self._remember_toggled)
        self.out = col.add(OutputCard(self.feature, DEFAULT_FOLDER, [("name_pattern", "File name:", DEFAULT_PATTERN)]))
        root.addWidget(col)
        for w in (self.edge_gpu, self.full_gpu, self.abr):
            w.currentIndexChanged.connect(self._save_settings)
        for w in (self.edge_crf, self.full_crf):
            w.valueChanged.connect(self._save_settings)
        for w in (self.fix_drift, self.exact_audio):
            w.toggled.connect(self._save_settings)
        self._mode_changed()

        for keys, fn in (("Space", self.editor.toggle), ("I", lambda: self.editor.set_start_btn.click()),
                         ("O", lambda: self.editor.set_end_btn.click()),
                         ("Left", lambda: self.editor.step_frames(-1)), ("Right", lambda: self.editor.step_frames(1)),
                         ("Shift+Left", lambda: self.editor.step_seconds(-1)),
                         ("Shift+Right", lambda: self.editor.step_seconds(1))):
            sc = QShortcut(QKeySequence(keys), self)
            sc.setContext(Qt.WidgetWithChildrenShortcut)
            sc.activated.connect(fn)
        self._loading = False
        if self.folder_edit.text().strip():
            self._reread()

    # ============================================================== settings
    def _settings(self) -> dict:
        return {"head": self.head.value(), "tail": self.tail.value(), "cut_mode": self.mode.currentData(),
                "edge_gpu": self.edge_gpu.currentData(), "edge_crf": self.edge_crf.value(),
                "full_gpu": self.full_gpu.currentData(), "full_crf": self.full_crf.value(),
                "fix_drift": self.fix_drift.isChecked(), "exact_audio": self.exact_audio.isChecked(),
                "audio_bitrate": self.abr.currentData(), "name_pattern": self.out.pattern("name_pattern")}

    def _save_settings(self, *_):
        if getattr(self, "_loading", False):
            return
        f = self.feature
        f.set_setting("last_folder", self.folder_edit.text().strip())
        f.set_setting("recursive", self.recursive.isChecked())
        for k, v in self._settings().items():
            if k != "name_pattern":
                f.set_setting(k, v)

    def reload_settings(self):
        from breezy.core.ui import reload_from
        reload_from(self.feature, {"edge_crf": self.edge_crf, "full_crf": self.full_crf,
                                   "exact_audio": self.exact_audio, "full_gpu": self.full_gpu})

    def _mode_changed(self, *_):
        exact = self.mode.currentData() == "exact"
        for w in (self.edge_gpu, self.edge_crf, self.full_gpu, self.full_crf, self.fix_drift, self.exact_audio,
                  self.abr):
            w.setEnabled(exact)
        self._save_settings()

    # ================================================================= files
    def _say(self, msg: str):
        self.log.appendPlainText(msg)

    def _browse_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Folder of videos", self.folder_edit.text())
        if d:
            self.folder_edit.setText(d)
            self._reread()

    def _add_files(self):
        from breezy.core.ui import pick_videos
        files = pick_videos(self, self.folder_edit.text().strip())
        if files:
            self._add_paths(files)

    def _add_paths(self, files):
        files = [Path(f) for f in files]
        self.extra_files += [f for f in files if f not in self.extra_files]
        self.removed -= set(files)
        self._say(f"Added {len(files)} file(s).")
        self._reread()

    def _clear_files(self):
        self.folder_edit.setText("")
        self.extra_files, self.removed, self.files = [], set(), []
        self.unchecked.clear()
        self.editor.clear()
        self.current = None
        self._rebuild()

    def _drop_folder(self, d):
        self.folder_edit.setText(str(d))
        self._reread()

    def _remove_paths(self, paths):
        self.removed |= set(paths)
        self.extra_files = [f for f in self.extra_files if f not in paths]
        if self.current in paths:
            self.current = None
            self.editor.clear()
        self._say(f"Removed {len(paths)} file(s) from the list (nothing is deleted).")
        self._reread()

    def _install_tools(self):
        from breezy.core.ui import install_drop, install_list_tools
        install_drop(self, self._drop_folder, self._add_paths)
        install_list_tools(self.tree, self._path_of_item, self._remove_paths, self._reread)

    def _path_of_item(self, it):
        d = it.data(0, ROLE) if it else None
        return Path(d) if isinstance(d, str) else None

    def _gather_files(self) -> list[Path]:
        text = self.folder_edit.text().strip()
        folder = Path(text) if text else None
        files = []
        if folder and folder.is_dir():
            it = folder.rglob("*") if self.recursive.isChecked() else folder.glob("*")
            skip = {self.out.values()["folder"].lower(), "breezy output"}
            pat = self.out.pattern("name_pattern")
            tail = pat.split("{name}", 1)[1] if pat.startswith("{name}") and pat != "{name}" else ""
            files = sorted(p for p in it if p.is_file() and p.suffix.lower() in VIDEO_EXTS
                           and not (set(x.lower() for x in p.relative_to(folder).parts[:-1]) & skip)
                           and not (tail and p.stem.endswith(tail)))
        return [p for p in files if p not in self.removed] + \
            [p for p in self.extra_files if p not in files and p.is_file() and p not in self.removed]

    def _reread(self, *_):
        self.files = self._gather_files()
        self.feature.set_setting("last_folder", self.folder_edit.text().strip())
        self.feature.set_setting("recursive", self.recursive.isChecked())
        for p in self.files:
            if p not in self.infos:
                self.infos[p] = None
                self.prober.request(p)
        self._rebuild()

    def _probed(self, path: str, info):
        p = Path(path)
        self.infos[p] = info
        it = self._item_for(p)
        if it is not None:
            self._fill(it, p)
        self._update_buttons()
        if p == self.current:
            self._load_editor(p)

    def _use_output(self):
        dlg = OutputPicker(self.tm, self, "ends")
        if not dlg.exec():
            return
        files, future = dlg.selection()
        if files:
            self._add_paths([Path(f) for f in files])
        for tid in future:
            self._queue_auto(tid)
        self._update_buttons()

    def _queue_auto(self, task_id: str):
        out = output_spec(self.ctx.settings, "ends", DEFAULT_FOLDER, self, self.out.values())
        if out is None:
            return
        self._save_settings()
        src = self.tm.get(task_id)
        name = src.title if src else task_id
        t = Task("ends.auto", "ends", f"Cut ends of output of '{name}'",
                 spec=dict(self._settings(), output=out), input_from=task_id)
        self.tm.submit(t)
        self._say(f"Queued: cut {self.head.value():g} s from the start and {self.tail.value():g} s from the end "
                  f"of the files from '{name}' when it finishes.")

    # ================================================================== list
    def range_for(self, p: Path) -> tuple[float, float] | None:
        info = self.infos.get(p)
        if not info or info.error or not info.duration:
            return None
        if p in self.manual:
            return self.manual[p]
        return plan(info.duration, self.head.value(), self.tail.value())

    def _item_for(self, p: Path):
        for i in range(self.tree.topLevelItemCount()):
            it = self.tree.topLevelItem(i)
            if it.data(0, ROLE) == str(p):
                return it
        return None

    def _rebuild(self):
        self.tree.blockSignals(True)
        self.tree.clear()
        for p in self.files:
            it = QTreeWidgetItem(self.tree)
            it.setData(0, ROLE, str(p))
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(0, Qt.Unchecked if p in self.unchecked else Qt.Checked)
            it.setText(0, p.name)
            it.setToolTip(0, str(p))
            self._fill(it, p)
            if p == self.current:
                self.tree.setCurrentItem(it)
        self.tree.blockSignals(False)
        n = len(self.extra_files)
        self.extra_label.setText(f"+ {n} added file(s)" if n else "")
        self.extra_label.setVisible(bool(n))
        self._update_buttons()

    def _fill(self, it: QTreeWidgetItem, p: Path):
        c = theme.colors()
        was = self.tree.blockSignals(True)
        info = self.infos.get(p)
        for col in range(1, 7):
            it.setText(col, "")
        it.setForeground(6, QBrush(QColor(c["muted"])))
        if info is None:
            it.setText(6, "Reading…")
        elif info.error or not info.duration:
            it.setText(6, "Could not read")
            it.setForeground(6, QBrush(QColor(c["warn"])))
        else:
            s, e = self.range_for(p)
            it.setText(1, fmt(info.duration, False))
            it.setText(2, fmt(s))
            it.setText(3, fmt(e))
            kept = e - s
            it.setText(4, fmt(kept, False) if kept >= MIN_KEEP else "nothing")
            it.setText(5, _fmt_size(info.size))
            f = it.font(2)
            f.setBold(p in self.manual)
            for col in (2, 3):
                it.setFont(col, f)
            if kept < MIN_KEEP:
                it.setText(6, "Nothing would be left - skipped")
                it.setForeground(6, QBrush(QColor(c["warn"])))
            elif s <= 0.01 and e >= info.duration - 0.01:
                it.setText(6, "Nothing to cut - skipped")
            else:
                it.setText(6, "Set by hand" if p in self.manual else "Amounts for all videos")
                it.setForeground(6, QBrush(QColor(c["accent"] if p in self.manual else c["muted"])))
        self.tree.blockSignals(was)

    def _refresh_rows(self):
        for i in range(self.tree.topLevelItemCount()):
            it = self.tree.topLevelItem(i)
            self._fill(it, Path(it.data(0, ROLE)))
        self._update_buttons()

    def _item_changed(self, it: QTreeWidgetItem, _col: int):
        p = self._path_of_item(it)
        if p is None:
            return
        if it.checkState(0) == Qt.Checked:
            self.unchecked.discard(p)
        else:
            self.unchecked.add(p)
        self._update_buttons()

    def _current_changed(self, cur, _prev):
        p = self._path_of_item(cur)
        self.current = p
        if p is None:
            self.editor.clear()
            return
        self._load_editor(p)

    def _load_editor(self, p: Path):
        info = self.infos.get(p)
        r = self.range_for(p)
        if not info or r is None:
            self.editor.clear()
            return
        fps = float(info.video.fps) if info.video and info.video.fps else 30.0
        self.editor.load(p, info.duration, fps, r[0], r[1], p in self.manual)

    # ================================================================ edits
    def _save_manual(self):
        if self.remember.isChecked():
            keep = list(self.manual.items())[-5000:]
            self.feature.set_setting("manual_ranges", {str(p): [round(a, 3), round(b, 3)] for p, (a, b) in keep})

    def _remember_toggled(self, on: bool):
        self.feature.set_setting("remember_manual", on)
        if on:
            self._save_manual()
        else:
            self.feature.set_setting("manual_ranges", {})

    def _editor_changed(self, s: float, e: float):
        p = self.current
        if p is None:
            return
        self.manual[p] = (s, e)
        self._save_manual()
        it = self._item_for(p)
        if it is not None:
            self._fill(it, p)
        self._update_buttons()

    def _reset_current(self):
        if self.current is None:
            return
        self.manual.pop(self.current, None)
        self._save_manual()
        self._refresh_rows()
        self._load_editor(self.current)

    def _reset_all(self):
        self.manual.clear()
        self._save_manual()
        self._refresh_rows()
        if self.current:
            self._load_editor(self.current)
        self._say("Every video now uses the amounts for all videos.")

    def _amounts_changed(self, *_):
        self.feature.set_setting("head", self.head.value())
        self.feature.set_setting("tail", self.tail.value())
        self._refresh_rows()
        if self.current and self.current not in self.manual:
            self._load_editor(self.current)

    # ================================================================== run
    def _jobs(self) -> list[dict]:
        out = []
        for p in self.files:
            if p in self.unchecked:
                continue
            info = self.infos.get(p)
            r = self.range_for(p)
            if r is None:
                continue
            s, e = r
            if e - s < MIN_KEEP or (s <= 0.01 and e >= info.duration - 0.01):
                continue
            out.append({"path": str(p), "start": round(s, 3), "end": round(e, 3)})
        return out

    def _update_buttons(self):
        jobs = self._jobs()
        self.cut_btn.setEnabled(bool(jobs))
        reading = sum(1 for p in self.files if self.infos.get(p) is None)
        txt = f"{len(jobs)} of {len(self.files)} video(s) will be cut" if self.files else ""
        if reading:
            txt += f" · reading {reading}…"
        self.summary.setText(txt)

    def _open_output(self):
        from breezy.core.ui import open_module_output
        open_module_output(self, self.tm, "ends", self.out, self.files[0] if self.files else None)

    def cut(self):
        jobs = self._jobs()
        if not jobs:
            return
        if not self.ff.available:
            QMessageBox.warning(self, "Trim Ends", "FFmpeg was not found. See the Settings page.")
            return
        out = output_spec(self.ctx.settings, "ends", DEFAULT_FOLDER, self, self.out.values())
        if out is None:
            return
        self._save_settings()
        self.editor._stop()
        title = f"Cut ends of {len(jobs)} video(s)" if len(jobs) > 1 else f"Cut ends of {Path(jobs[0]['path']).name}"
        t = self.tm.submit(Task("ends.cut", "ends", title, spec=dict(self._settings(), items=jobs, output=out)))
        self._say(f"Queued: {title}.")
        return t

    def theme_changed(self):
        self._refresh_rows()
        self.editor.bar.update()

    def shutdown(self):
        self.editor.shutdown()
        self.prober.shutdown()
