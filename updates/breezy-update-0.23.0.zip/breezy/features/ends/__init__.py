"""Trim Ends: cut the start and/or end off videos."""
from breezy.core.plugin import Feature
from . import tasks as _tasks  # noqa: F401  (registers the task runners)


class EndsFeature(Feature):
    id = "ends"
    name = "Trim Ends"
    description = ("Cut the start and/or end off videos: the same amounts for a whole batch, or set "
                   "each video's start and end by hand with the player. The video is copied losslessly "
                   "and only the few frames at the new start are re-encoded. Originals are never changed.")
    order = 25
    icon = "trim"

    def create_widget(self):
        from .widget import EndsWidget
        self.widget = EndsWidget(self)
        return self.widget

    def theme_changed(self):
        self.widget.theme_changed()

    def shutdown(self):
        w = getattr(self, "widget", None)
        if w is not None:
            w.shutdown()


FEATURE = EndsFeature
