"""Trim Ends task runners: cut the start and/or end off videos.

Two ways to cut:
* exact (default) - the Motion Trimmer's smart cut: the video is copied losslessly and only
  the few frames from the new start to the next keyframe are re-encoded;
* keyframe - pure copy, nothing re-encoded (instant), but the start moves back to the
  keyframe at or before the chosen point.
"""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from breezy.core.ffmpeg import FFmpeg, MediaInfo
from breezy.core.outputs import apply_pattern, finish, output_dir, unique_path, working_path
from breezy.core.proc import Cancelled
from breezy.core.tasks import Task, TaskContext, register_runner
from breezy.features.motion.cutter import Cutter
from breezy.features.motion.tasks import cut_options

_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
MIN_KEEP = 0.1          # seconds; anything shorter is refused


def plan(duration: float, head: float, tail: float) -> tuple[float, float]:
    """(start, end) when `head` seconds are removed from the start and `tail` from the end."""
    s = max(0.0, head)
    e = max(0.0, duration - max(0.0, tail))
    return s, e


def keyframe_before(ff: FFmpeg, info: MediaInfo, t: float) -> float:
    """Time of the last keyframe at or before `t` (only reads the part of the file near `t`)."""
    if t <= 0.01:
        return 0.0
    for back in (15.0, 60.0, 300.0, None):
        lo = 0.0 if back is None else max(0.0, t - back)
        cmd = [ff.ffprobe, "-v", "error", "-select_streams", "v:0", "-read_intervals", f"{lo:.3f}%{t + 0.5:.3f}",
               "-show_entries", "packet=pts_time,flags", "-of", "csv=p=0", str(info.path)]
        out = subprocess.run(cmd, capture_output=True, text=True, creationflags=_NO_WINDOW).stdout
        st = subprocess.run([ff.ffprobe, "-v", "error", "-select_streams", "v:0", "-show_entries",
                             "stream=start_time", "-of", "csv=p=0", str(info.path)],
                            capture_output=True, text=True, creationflags=_NO_WINDOW).stdout
        try:
            start = float(st.strip().strip(",") or 0)
        except ValueError:
            start = 0.0
        keys = []
        for line in out.splitlines():
            parts = line.strip().split(",")
            if len(parts) >= 2 and "K" in parts[1]:
                try:
                    keys.append(float(parts[0]) - start)
                except ValueError:
                    pass
        best = [k for k in keys if k <= t + 0.001]
        if best:
            return max(0.0, max(best))
        if lo <= 0.0:
            return 0.0
    return 0.0


def copy_cut(ff: FFmpeg, info: MediaInfo, start: float, end: float, out: Path, ctx: TaskContext) -> tuple[float, str]:
    """Pure stream copy from the keyframe at/before `start` to `end`. Returns (real start, message)."""
    kf = keyframe_before(ff, info, start)
    tmp = working_path(out)
    args = (["-ss", f"{kf:.3f}"] if kf > 0 else []) + [
        "-i", str(info.path), "-t", f"{end - kf:.3f}", "-map", "0:v:0", "-map", "0:a?", "-c", "copy",
        "-map_metadata", "0", "-avoid_negative_ts", "make_zero"]
    if out.suffix.lower() in (".mp4", ".mov", ".m4v"):
        args += ["-movflags", "+faststart"]
    try:
        ff.run(args + [str(tmp)], end - kf, lambda f: ctx.item_progress(f, "Copying"), None, ctx.cancel_event)
        finish(tmp, out)
    except BaseException:
        try:
            tmp.unlink()
        except OSError:
            pass
        raise
    moved = start - kf
    msg = "Copied without re-encoding (lossless)"
    if moved > 0.05:
        msg += f"; start moved {moved:.2f} s earlier to the nearest keyframe"
    return kf, msg


def _cut(task: Task, ctx: TaskContext):
    s = task.spec
    opts = cut_options(s)
    pattern = s.get("name_pattern", "{name}_cut")
    mode = s.get("cut_mode", "exact")
    for _i, it in ctx.items():
        src = Path(it["path"])
        try:
            info = ctx.ffmpeg.probe(src)
            if info.error:
                raise RuntimeError(info.error)
            if "start" in it:
                start, end = float(it["start"]), float(it["end"])
            else:                                            # automatic: amounts for every video
                start, end = plan(info.duration, s.get("head", 0.0), s.get("tail", 0.0))
            end = min(end, info.duration) if info.duration else end
            if end - start < MIN_KEEP:
                ctx.error(f"{src.name}: nothing would be left after cutting - skipped.")
                continue
            if start <= 0.01 and info.duration and end >= info.duration - 0.01:
                ctx.log(f"– {src.name}: nothing to cut - skipped.")
                continue
            out = unique_path(output_dir(s, src) / (apply_pattern(pattern, src.stem) + src.suffix))
            ctx.log(f"=== {src.name} ({start:.2f} s – {end:.2f} s) → {out}")
            if mode == "keyframe":
                _, msg = copy_cut(ctx.ffmpeg, info, start, end, out, ctx)
            else:
                cutter = Cutter(ctx.ffmpeg, log=ctx.log, progress=ctx.item_progress,
                                cancel_event=ctx.cancel_event, options=opts)
                r = cutter.cut(info, [(start, end)], out, fix_drift=s.get("fix_drift", True),
                               exact_audio=s.get("exact_audio", True))
                msg = r.message
            ctx.add_output(out)
            ctx.log(f"✔ {out.name}: {msg}")
        except Cancelled:
            raise
        except Exception as e:  # noqa - keep going with the next video
            ctx.error(f"{src.name}: {str(e).splitlines()[0] if str(e) else type(e).__name__}")


def run_cut(task: Task, ctx: TaskContext):
    items = task.spec["items"]
    ctx.set_items(items, [max(float(i.get("end", 1)) - float(i.get("start", 0)), 1.0) for i in items],
                  [Path(i["path"]).name for i in items])
    _cut(task, ctx)


def run_auto(task: Task, ctx: TaskContext):
    """Input = files from another task: cut the same amounts off each."""
    items = [{"path": f} for f in task.spec.get("input_files", [])]
    if not items:
        ctx.log("No files to cut.")
        return
    ctx.set_items(items, None, [Path(i["path"]).name for i in items])
    _cut(task, ctx)


register_runner("ends.cut", run_cut)
register_runner("ends.auto", run_auto)
