"""Subtitles: write captions from the speech in videos (Whisper), as a .srt file, a subtitle track, or burned
into the picture."""
from __future__ import annotations

import os
import shutil
import tempfile
from pathlib import Path

from breezy.core import encoders
from breezy.core.filepage import video_task_items
from breezy.core.outputs import apply_pattern, finish, output_dir, unique_path, working_path
from breezy.core.proc import Cancelled
from breezy.core.tasks import Task, TaskContext, register_runner
from breezy.features.enhance import speech
from breezy.features.enhance.filters import _esc

SRT_PLACES = [("Next to the original video (players load it automatically)", "beside"),
              ("In the output folder", "output"), ("Don't save a .srt file", "off")]


def has_output(s: dict) -> bool:
    return s.get("srt_place", "beside") != "off" or bool(s.get("embed")) or bool(s.get("burn"))


def _srt_path(src: Path, s: dict) -> Path | None:
    place = s.get("srt_place", "beside")
    if place == "off":
        return None
    folder = src.parent if place == "beside" else output_dir(s, src)
    folder.mkdir(parents=True, exist_ok=True)
    suffix = s.get("srt_suffix", "")
    p = folder / f"{src.stem}{suffix}.srt"
    return p if not p.exists() or s.get("overwrite_srt", False) else unique_path(p)


def _make_video(ctx: TaskContext, src: Path, srt: Path, lang: str, s: dict, out: Path, _start: float = 0.0):
    info = ctx.ffmpeg.probe(src)
    tmp = working_path(out)
    burn = bool(s.get("burn"))
    embed = bool(s.get("embed"))
    args = ["-i", str(src)]
    if embed:
        args += ["-i", str(srt)]
    args += ["-map", "0:v:0", "-map", "0:a?"]
    if embed:
        args += ["-map", "1:0"]
    args += ["-map_metadata", "0"]
    if burn:
        size = int(s.get("text_size", 22))
        style = f"FontSize={size},Outline=2,Shadow=0,MarginV=20"
        if s.get("text_box"):
            style += ",BorderStyle=4,BackColour=&H80000000"
        args += ["-vf", f"subtitles=filename='{_esc(str(srt))}':force_style='{style}'"]
        codec = "hevc" if info.video.codec == "hevc" else "h264"
        args += encoders.video_args(codec, int(s.get("crf", 18)), bool(s.get("enc_gpu", True)),
                                    ["-pix_fmt", "yuv420p"], speed=s.get("enc_speed", "balanced"))
        if codec == "hevc" and out.suffix.lower() in (".mp4", ".mov", ".m4v"):
            args += ["-tag:v", "hvc1"]
    else:
        args += ["-c:v", "copy"]
    args += ["-c:a", "copy"]
    if embed:
        lang3 = speech_lang3(lang)
        args += ["-c:s", "mov_text" if out.suffix.lower() in (".mp4", ".mov", ".m4v") else "srt",
                 "-metadata:s:s:0", f"language={lang3}", "-disposition:s:0", "default" if s.get("track_on") else "0"]
    if out.suffix.lower() in (".mp4", ".mov", ".m4v"):
        args += ["-movflags", "+faststart"]
    try:
        ctx.ffmpeg.run(args + [str(tmp)], info.duration or 1.0,
                       lambda f: ctx.item_progress((0.6 if s.get("mode", "direct") == "direct" else 0.0)
                                                   + (0.4 if s.get("mode", "direct") == "direct" else 1.0) * f, "Burning in the subtitles" if burn
                                                   else "Adding the subtitle track"), None, ctx.cancel_event)
        finish(tmp, out)
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise


def speech_lang3(lang: str) -> str:
    return {"en": "eng", "fr": "fra", "es": "spa", "de": "deu", "it": "ita", "pt": "por", "nl": "nld", "ru": "rus",
            "zh": "zho", "ja": "jpn", "ko": "kor", "ar": "ara", "hi": "hin", "uk": "ukr", "pl": "pol", "tr": "tur",
            "vi": "vie", "tl": "tgl"}.get(lang, "und")


def _listen(ctx: TaskContext, src: Path, info, s: dict, share: float):
    """Speech -> [(start, end, text)], language."""
    def check():
        if ctx.cancel_event.is_set():
            raise Cancelled("Cancelled by user")
        ctx.checkpoint()
    ctx.item_progress(0.0, "Listening to the speech")
    return speech.transcribe(ctx.ffmpeg, src, s.get("model", "small"), s.get("language", ""),
                             bool(s.get("translate")), bool(s.get("ai_gpu", True)),
                             progress=lambda p: ctx.item_progress(share * p, "Writing subtitles from the speech"),
                             cancel=check, log=ctx.log)


def _save_outputs(ctx: TaskContext, src: Path, info, segs, lang: str, s: dict, work: Path, start: float = 0.0):
    """Make the .srt / track / burned-in copy from finished subtitle lines."""
    pattern = s.get("name_pattern", "{name}_subtitled")
    srt_work = work / "subs.srt"
    speech.write_srt(segs, srt_work, int(s.get("line_chars", 42)))
    srt_out = _srt_path(src, s)
    if srt_out is not None:
        shutil.copyfile(srt_work, srt_out)
        ctx.add_output(srt_out)
        ctx.log(f"✔ {srt_out.name}: subtitle file")
    if (s.get("embed") or s.get("burn")) and info.video:
        ext = src.suffix if src.suffix.lower() in (".mp4", ".mov", ".mkv", ".m4v") else ".mp4"
        out = unique_path(output_dir(s, src) / (apply_pattern(pattern, src.stem) + ext))
        _make_video(ctx, src, srt_work, lang, s, out, start)
        if s.get("keep_date", True):
            try:
                st = src.stat()
                os.utime(out, (st.st_atime, st.st_mtime))
            except OSError:
                pass
        ctx.add_output(out)
        what = " + ".join(x for x, on in (("burned in", s.get("burn")), ("subtitle track", s.get("embed"))) if on)
        ctx.log(f"✔ {out.name}: video with subtitles ({what})")


def _run(task: Task, ctx: TaskContext, files: list[str]):
    """mode 'direct' (listen and save), 'listen' (listen, keep a draft to check) or 'save' (save the drafts)."""
    from . import drafts
    s = task.spec
    mode = s.get("mode", "direct")
    if mode != "save" and not speech.available():
        raise RuntimeError("the speech component isn't installed yet (it installs the next time the app starts)")
    if mode != "listen" and not has_output(s):
        ctx.log("Nothing to do: no .srt file, subtitle track or burned-in subtitles chosen.")
        return
    video_task_items(ctx, files, task)
    for _i, f in ctx.items():
        src = Path(f)
        work = Path(tempfile.mkdtemp(prefix="breezy_subs_"))
        try:
            info = ctx.ffmpeg.probe(src)
            if info.error:
                raise RuntimeError(info.error)
            ctx.log(f"=== {src.name}")
            if mode == "save":
                d = drafts.load(src)
                if not d or not d.get("segments"):
                    ctx.log(f"– {src.name}: no subtitles written yet - skipped.")
                    continue
                segs = [tuple(x) for x in d["segments"]]
                lang = d.get("lang", "")
                _save_outputs(ctx, src, info, segs, lang, s, work)
                continue
            if not info.audio:
                ctx.log(f"– {src.name}: no sound - skipped.")
                continue
            share = 1.0 if mode == "listen" else (0.6 if (s.get("embed") or s.get("burn")) and info.video else 1.0)
            segs, lang = _listen(ctx, src, info, s, share)
            if s.get("translate"):
                lang = "en"
            if not segs:
                ctx.log(f"– {src.name}: no speech found.")
                continue
            ctx.log(f"✔ {len(segs)} subtitle line(s) ({lang})")
            if mode == "listen":
                drafts.save(src, segs, lang)
                ctx.log(f"✔ {src.name}: ready to check - click it in the list")
                continue
            _save_outputs(ctx, src, info, segs, lang, s, work)
        except Cancelled:
            raise
        except Exception as e:  # noqa - keep going with the next video
            ctx.error(f"{src.name}: {str(e).splitlines()[0] if str(e) else type(e).__name__}")
        finally:
            shutil.rmtree(work, ignore_errors=True)


def run_subtitles(task: Task, ctx: TaskContext):
    _run(task, ctx, task.spec["files"])


def run_auto(task: Task, ctx: TaskContext):
    files = task.spec.get("input_files", [])
    if not files:
        ctx.log("No input files.")
        return
    _run(task, ctx, files)


register_runner("subtitles.run", run_subtitles)
register_runner("subtitles.auto", run_auto)
