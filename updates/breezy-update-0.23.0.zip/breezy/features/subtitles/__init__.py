"""Subtitles: captions written from the speech in videos."""
from breezy.core.plugin import Feature
from . import tasks as _tasks  # noqa: F401  (registers the task runners)


class SubtitlesFeature(Feature):
    id = "subtitles"
    name = "Subtitles"
    description = ("Write subtitles from the speech in videos with the Whisper AI - in their own language or "
                   "translated into English. Save a .srt file, add a subtitle track, or burn them into the "
                   "picture. Originals are never changed.")
    order = 35
    icon = "subtitles"

    def create_widget(self):
        from .widget import SubtitlesWidget
        self.widget = SubtitlesWidget(self)
        return self.widget

    def theme_changed(self):
        self.widget.theme_changed()

    def shutdown(self):
        w = getattr(self, "widget", None)
        if w is not None:
            w.shutdown()


FEATURE = SubtitlesFeature
