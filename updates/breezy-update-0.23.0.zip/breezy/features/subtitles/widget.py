"""Subtitles page."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import QMessageBox, QPushButton

from breezy.core.filepage import VideoListPage
from breezy.core.tasks import Task
from breezy.core.outputs import output_spec
from breezy.core.ui import Card, check, combo, spin
from breezy.features.ends.editor import fmt
from breezy.features.enhance import speech
from breezy.features.stitcher.joiner import _fmt_size
from . import drafts
from .editor import SubtitleEditor
from .tasks import SRT_PLACES, has_output


class SubtitlesWidget(VideoListPage):
    MODULE = "subtitles"
    TITLE = "Subtitles"
    DEFAULT_FOLDER = "Subtitled"
    DEFAULT_PATTERN = "{name}_subtitled"
    COLUMNS = [("Length", 70), ("Sound", 150), ("Size", 80), ("Details", 220)]
    RUN_TEXT = "Write subtitles"
    RUN_TIP = ("Listen to the ticked videos and write their subtitles. With 'Check the text before saving'\n"
               "they wait for you below; otherwise they're saved straight away. The originals are never changed.")
    task_kind, auto_kind, task_verb = "subtitles.run", "subtitles.auto", "Subtitle"
    needs_video = False

    def build_settings(self, col):
        st = self.st
        A = col.add(Card("Speech", "Captions are written from the speech by the Whisper AI"))
        self.model = A.row("Speech model:", combo(speech.SIZES, st("model", "small")),
                           "Bigger models understand more (accents, noise, quiet voices) but are slower.\n"
                           "Downloaded the first time it's used (base 150 MB, small 480 MB, medium 1.5 GB).\n\n"
                           "When to use: Good for most videos; Best for hard-to-hear speech.")
        self.language = A.row("Language:", combo(speech.LANGS, st("language", "")),
                              "The language spoken. Automatic works well; choose it if a video starts\n"
                              "with music or silence and the wrong language is picked.")
        self.translate = A.full(check("Translate into English", bool(st("translate", False)),
                                      "Writes English subtitles for speech in any language"))
        self.review = A.full(check("Check the text before saving", bool(st("review", True)),
                                   "On: 'Write subtitles' only writes the text; read and correct it below,\n"
                                   "then press 'Save ticked'.\n"
                                   "Off: the subtitles are saved straight away.\n\n"
                                   "When to use: on for anything people will read; off for big batches."))
        self.ai_gpu = A.row("Run on:", combo([("Graphics card when possible", True), ("Processor", False)],
                                             bool(st("ai_gpu", True))),
                            "NVIDIA graphics cards are much faster; everything else uses the processor")
        self.line_chars = A.row("Line length:", spin(20, 70, int(st("line_chars", 42)), " characters", step=2),
                                "Longest line before it wraps (2 lines at most). 42 is the TV standard;\n"
                                "fewer for upright phone video.")
        O = col.add(Card("What to make"))
        self.srt_place = O.row("Subtitle file (.srt):", combo(SRT_PLACES, st("srt_place", "beside")),
                               "A .srt file with the same name as the video, next to it, is loaded\n"
                               "automatically by VLC, Windows Media Player, Plex and most TVs.")
        self.embed = O.full(check("Video with a subtitle track (can be switched on/off)", bool(st("embed", False)),
                                  "A copy of the video with the subtitles inside it as a track.\n"
                                  "Nothing is re-encoded, so it's quick and loses no quality."))
        self.track_on = O.full(check("Show the track by default", bool(st("track_on", True)),
                                     "Players show the subtitles straight away (they can still be turned off)"))
        self.burn = O.full(check("Video with the subtitles burned in (always visible)", bool(st("burn", False)),
                                 "The text becomes part of the picture: shows everywhere (phones, social media),\n"
                                 "but can't be turned off. The video is re-encoded."))
        self.text_size = O.row("Burned-in text size:", spin(10, 60, int(st("text_size", 22)), step=2))
        self.text_box = O.full(check("Dark box behind the burned-in text", bool(st("text_box", False)),
                                     "Easier to read over bright or busy pictures"))
        self.crf = O.row("Burned-in video quality:", spin(0, 40, int(st("crf", 18)), " CRF"),
                         "Lower = better and bigger. Set by the Quality level (top left).")
        self.enc_gpu = O.row("Encoder:", combo([("Graphics card (faster)", True), ("Processor", False)],
                                               bool(st("enc_gpu", True))))
        self.connect_all(self.review, self.model, self.language, self.translate, self.ai_gpu, self.line_chars, self.srt_place,
                         self.embed, self.track_on, self.burn, self.text_size, self.text_box, self.crf, self.enc_gpu)
        self._enable()

    def _enable(self):
        if hasattr(self, "save_btn"):
            self.save_btn.setVisible(self.review.isChecked())
        self.track_on.setEnabled(self.embed.isChecked())
        for w in (self.text_size, self.text_box, self.crf, self.enc_gpu):
            w.setEnabled(self.burn.isChecked())

    def settings_changed(self):
        self._enable()

    def settings(self) -> dict:
        return {"review": self.review.isChecked(), "model": self.model.currentData(),
                "language": self.language.currentData(),
                "translate": self.translate.isChecked(), "ai_gpu": self.ai_gpu.currentData(),
                "line_chars": self.line_chars.value(), "srt_place": self.srt_place.currentData(),
                "embed": self.embed.isChecked(), "track_on": self.track_on.isChecked(),
                "burn": self.burn.isChecked(), "text_size": self.text_size.value(),
                "text_box": self.text_box.isChecked(), "crf": self.crf.value(), "enc_gpu": self.enc_gpu.currentData()}

    def spec_for(self, files):
        mode = "listen" if self.review.isChecked() and files else "direct"
        return dict(super().spec_for(files), enc_speed=self.st("enc_speed", "balanced"), mode=mode)

    # ------------------------------------------------------------------ editor
    def build_middle(self):
        self.editor = SubtitleEditor()
        self.editor.changed.connect(self._edited)
        self.editor.load_srt.connect(self._load_srt)
        return self.editor

    def extra_buttons(self):
        self.save_btn = QPushButton("Save ticked")
        self.save_btn.setToolTip("Save the checked subtitles of the ticked videos (.srt, track and/or burned in,\n"
                                 "as chosen on the right)")
        self.save_btn.clicked.connect(self.save_drafts)
        return [self.save_btn]

    def current_changed(self, p):
        info = self.infos.get(p) if p else None
        if p is None:
            self.editor.load(None, None)
            return
        if info is not None and not self.usable(info):
            self.editor.load(p, None, message="This file has no sound.")
            return
        self.editor.load(p, drafts.load(p), p.with_suffix(".srt").is_file())

    def _edited(self, segs):
        p = self.editor.path
        if p is None:
            return
        old = drafts.load(p) or {}
        drafts.save(p, segs, old.get("lang", ""), edited=True, source=old.get("source", "speech"))
        it = self.item_for(p)
        if it is not None:
            self._fill(it, p)
        self.update_buttons()

    def _load_srt(self):
        p = self.editor.path
        srt = p.with_suffix(".srt") if p else None
        if not srt or not srt.is_file():
            return
        try:
            segs = drafts.parse_srt(srt.read_text("utf-8", errors="replace"))
        except OSError as e:
            QMessageBox.warning(self, "Subtitles", f"Couldn't read {srt.name}: {e}")
            return
        if not segs:
            QMessageBox.information(self, "Subtitles", f"No subtitle lines found in {srt.name}.")
            return
        drafts.save(p, segs, "", edited=False, source="srt")
        self.current_changed(p)
        self.refresh_rows()

    def run(self):
        if self.review.isChecked():
            have = [Path(f) for f in self.jobs() if (drafts.load(Path(f)) or {}).get("edited")]
            if have and QMessageBox.question(
                    self, "Subtitles", f"{len(have)} of the ticked videos have subtitles you corrected.\n"
                    "Write them again from the speech? Your corrections will be replaced.") != QMessageBox.Yes:
                return None
        return super().run()

    def _draft_jobs(self) -> list[str]:
        return [f for f in self.jobs() if drafts.load(Path(f))]

    def save_drafts(self):
        files = self._draft_jobs()
        if not files:
            QMessageBox.information(self, "Subtitles", "None of the ticked videos has subtitles written yet.\n"
                                    "Press 'Write subtitles' first.")
            return
        if not has_output(self.settings()):
            QMessageBox.information(self, "Subtitles", "Choose what to make on the right (.srt, track or burned in).")
            return
        out = output_spec(self.ctx.settings, self.MODULE, self.DEFAULT_FOLDER, self, self.out.values())
        if out is None:
            return
        self.save_settings()
        title = f"Save subtitles of {len(files)} video(s)" if len(files) > 1 else f"Save subtitles of {Path(files[0]).name}"
        self.tm.submit(Task("subtitles.run", self.MODULE, title,
                            spec=dict(super().spec_for(files), enc_speed=self.st("enc_speed", "balanced"),
                                      mode="save", files=files, output=out)))
        self.say(f"Queued: {title}.")

    def update_buttons(self):
        super().update_buttons()
        if hasattr(self, "save_btn") and hasattr(self, "review"):
            self.save_btn.setEnabled(bool(self._draft_jobs()))

    def task_finished(self, t):
        self.refresh_rows()
        if self.current is not None:
            self.current_changed(self.current)

    def reload_settings(self):
        from breezy.core.ui import reload_from
        reload_from(self.feature, {"crf": self.crf, "enc_gpu": self.enc_gpu})

    def usable(self, info) -> bool:
        return bool(info and not info.error and info.audio)

    def can_run(self) -> str:
        if not speech.available():
            return "The speech component installs the next time the app starts"
        if hasattr(self, "burn") and not self.review.isChecked() and not has_output(self.settings()):
            return "Choose what to make"
        return ""

    def fill_row(self, it, p: Path, info):
        a = info.audio
        it.setText(1, fmt(info.duration, False))
        it.setText(2, f"{a.codec} {a.sample_rate // 1000 if a.sample_rate else '?'} kHz"
                      f"{' stereo' if a.channels == 2 else ' mono' if a.channels == 1 else ''}")
        it.setText(3, _fmt_size(info.size))
        d = drafts.load(p)
        if d and d.get("segments"):
            state = "corrected" if d.get("edited") else "check them" if d.get("source") == "speech" else "from .srt"
            it.setText(4, f"{len(d['segments'])} lines written · {state}")
        elif p.with_suffix(".srt").exists():
            it.setText(4, "already has a .srt file next to it")
        elif not info.video:
            it.setText(4, "sound file: only a .srt is made")
