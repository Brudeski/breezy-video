"""Subtitle editor: the lines written from the speech, with the video playing above them.

Click a line to see it in the video; edit the text or the times straight in the table. Every change is
kept in the video's draft right away."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt, QUrl, Signal
from PySide6.QtWidgets import (QAbstractItemView, QDoubleSpinBox, QHBoxLayout, QHeaderView, QLabel, QPushButton,
                               QSizePolicy, QSplitter, QStackedWidget, QTableWidget, QTableWidgetItem, QVBoxLayout,
                               QWidget)

from breezy.core import theme
from breezy.features.motion.preview import HAVE_PLAYER
from .drafts import fmt_time, parse_time

if HAVE_PLAYER:
    from PySide6.QtMultimedia import QAudioOutput, QMediaPlayer
    from PySide6.QtMultimediaWidgets import QVideoWidget


class SubtitleEditor(QWidget):
    changed = Signal(list)          # the edited lines [[start, end, text], ...]
    load_srt = Signal()             # the user wants to edit the .srt next to the video

    def __init__(self, parent=None):
        super().__init__(parent)
        self.path: Path | None = None
        self.segs: list[list] = []
        self.player = None
        self._stop_at = None
        self._filling = False

        v = QVBoxLayout(self)
        v.setContentsMargins(0, 4, 0, 0)
        v.setSpacing(6)
        self.title = QLabel("Click a video in the list to check its subtitles.")
        self.title.setWordWrap(True)
        v.addWidget(self.title)

        split = QSplitter(Qt.Horizontal)
        split.setChildrenCollapsible(False)
        # ---- left: video + the line being shown
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.setSpacing(4)
        self.stack = QStackedWidget()
        self.stack.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.note = QLabel(alignment=Qt.AlignCenter)
        self.note.setWordWrap(True)
        self.note.setMinimumSize(260, 150)
        self.note.setStyleSheet("background:#11141a; color:#9ca3af;")
        self.stack.addWidget(self.note)
        if HAVE_PLAYER:
            self.video = QVideoWidget()
            self.stack.addWidget(self.video)
        lv.addWidget(self.stack, 1)
        self.caption = QLabel("", alignment=Qt.AlignCenter)
        self.caption.setWordWrap(True)
        self.caption.setMinimumHeight(44)
        self.caption.setStyleSheet("background:#000; color:#fff; font-size:15px; padding:4px;")
        lv.addWidget(self.caption)
        tr = QHBoxLayout()
        self.play_btn = QPushButton("▶ Play")
        self.play_btn.setToolTip("Play / pause the video from where it is")
        self.play_btn.clicked.connect(self.toggle)
        self.line_btn = QPushButton("▶ Play this line")
        self.line_btn.setToolTip("Play just the selected line (double-click a line does the same)")
        self.line_btn.clicked.connect(self.play_line)
        self.time = QLabel("0:00:00.000")
        tr.addWidget(self.play_btn)
        tr.addWidget(self.line_btn)
        tr.addStretch(1)
        tr.addWidget(self.time)
        lv.addLayout(tr)
        split.addWidget(left)

        # ---- right: the lines
        right = QWidget()
        rv = QVBoxLayout(right)
        rv.setContentsMargins(0, 0, 0, 0)
        rv.setSpacing(4)
        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Start", "End", "Text"])
        self.table.verticalHeader().setVisible(False)
        hh = self.table.horizontalHeader()
        hh.setSectionResizeMode(0, QHeaderView.Interactive)
        hh.setSectionResizeMode(1, QHeaderView.Interactive)
        hh.setSectionResizeMode(2, QHeaderView.Stretch)
        self.table.setColumnWidth(0, 100)
        self.table.setColumnWidth(1, 100)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setWordWrap(True)
        self.table.setToolTip("Double-click a cell to change it. Times: 0:01:02.500 or 62.5")
        self.table.itemChanged.connect(self._cell_changed)
        self.table.currentCellChanged.connect(lambda r, *_: self._row_selected(r))
        self.table.cellDoubleClicked.connect(lambda r, c: c == 2 or self.play_line())
        rv.addWidget(self.table, 1)
        b1 = QHBoxLayout()
        self.add_btn = self._btn("Add line", "Adds an empty line after the selected one", self.add_line, b1)
        self.del_btn = self._btn("Delete", "Deletes the selected lines", self.delete_lines, b1)
        self.merge_btn = self._btn("Join with next", "Joins the selected line with the one after it", self.merge, b1)
        self.split_btn = self._btn("Split", "Splits the selected line in two at its middle word", self.split, b1)
        b1.addStretch(1)
        rv.addLayout(b1)
        b2 = QHBoxLayout()
        b2.addWidget(QLabel("Move all lines by:"))
        self.shift = QDoubleSpinBox()
        self.shift.setRange(-60.0, 60.0)
        self.shift.setDecimals(2)
        self.shift.setSingleStep(0.1)
        self.shift.setSuffix(" s")
        self.shift.setToolTip("Negative = earlier. For subtitles that are all a little early or late")
        b2.addWidget(self.shift)
        self._btn("Move", "Moves every line by this much", self.shift_all, b2)
        b2.addStretch(1)
        self.srt_btn = self._btn("Edit the .srt next to this video", "Loads the subtitle file that's already next to "
                                 "the video, to correct it here", self.load_srt.emit, b2)
        self.srt_btn.hide()
        rv.addLayout(b2)
        split.addWidget(right)
        split.setStretchFactor(0, 1)
        split.setStretchFactor(1, 1)
        split.setSizes([440, 520])
        v.addWidget(split, 1)
        self._enable(False)

    @staticmethod
    def _btn(text, tip, fn, lay):
        b = QPushButton(text)
        b.setToolTip(tip)
        b.clicked.connect(fn)
        lay.addWidget(b)
        return b

    def _enable(self, on: bool):
        for w in (self.table, self.add_btn, self.del_btn, self.merge_btn, self.split_btn, self.shift,
                  self.line_btn):
            w.setEnabled(on)
        self.play_btn.setEnabled(on and HAVE_PLAYER)
        self.line_btn.setEnabled(on and HAVE_PLAYER)

    # ----------------------------------------------------------------- api
    def load(self, path: Path | None, draft: dict | None, has_srt: bool = False, message: str = ""):
        if path != self.path:
            self._stop()
            self.stack.setCurrentIndex(0)
        self.path = path
        self.segs = [list(x) for x in (draft or {}).get("segments", [])]
        self._fill()
        self.srt_btn.setVisible(bool(path) and has_srt and not draft)
        if not path:
            self.title.setText("Click a video in the list to check its subtitles.")
            self.note.setText("")
            self._enable(False)
            return
        if not draft:
            self.title.setText(f"<b>{path.name}</b> - no subtitles written yet")
            self.note.setText(message or "Press 'Write subtitles' to write them from the speech, then check them here.")
            self._enable(False)
            return
        edited = " · corrected" if draft.get("edited") else ""
        self.title.setText(f"<b>{path.name}</b> - {len(self.segs)} lines ({draft.get('lang') or '?'}){edited}. "
                           "Double-click to correct; changes are kept straight away.")
        self.note.setText("Click a line to see it in the video.")
        self._enable(True)

    def _fill(self):
        self._filling = True
        self.table.setRowCount(len(self.segs))
        for r, (a, b, t) in enumerate(self.segs):
            for c, val in enumerate((fmt_time(a), fmt_time(b), t)):
                self.table.setItem(r, c, QTableWidgetItem(val))
        self.table.resizeRowsToContents()
        self._filling = False

    def _emit(self):
        self.segs.sort(key=lambda x: x[0])
        self.changed.emit([list(x) for x in self.segs])

    # -------------------------------------------------------------- editing
    def _cell_changed(self, item: QTableWidgetItem):
        if self._filling:
            return
        r, c = item.row(), item.column()
        if r >= len(self.segs):
            return
        if c == 2:
            self.segs[r][2] = item.text().strip()
        else:
            t = parse_time(item.text())
            if t is None:
                self._filling = True
                item.setText(fmt_time(self.segs[r][c]))
                self._filling = False
                return
            self.segs[r][c] = t
            if self.segs[r][1] <= self.segs[r][0]:
                self.segs[r][1] = self.segs[r][0] + 0.5
        self._emit()
        if c != 2:
            self._fill()
            self.table.selectRow(next((i for i, s in enumerate(self.segs) if s[0] == self.segs[r][0]), r))

    def _selected_rows(self) -> list[int]:
        return sorted({i.row() for i in self.table.selectedIndexes()}) or \
            ([self.table.currentRow()] if self.table.currentRow() >= 0 else [])

    def add_line(self):
        rows = self._selected_rows()
        if rows:
            r = rows[-1]
            a = self.segs[r][1] + 0.05
            nxt = self.segs[r + 1][0] if r + 1 < len(self.segs) else a + 2.0
            b = max(a + 0.5, min(a + 2.0, nxt - 0.05))
        else:
            a = self.position()
            b = a + 2.0
        self.segs.append([a, b, ""])
        self._emit()
        self._fill()
        r = next(i for i, s in enumerate(self.segs) if s[0] == a and s[2] == "")
        self.table.selectRow(r)
        self.table.editItem(self.table.item(r, 2))

    def delete_lines(self):
        rows = self._selected_rows()
        if not rows:
            return
        for r in reversed(rows):
            del self.segs[r]
        self._emit()
        self._fill()

    def merge(self):
        rows = self._selected_rows()
        if not rows or rows[0] + 1 >= len(self.segs):
            return
        r = rows[0]
        a, b = self.segs[r], self.segs[r + 1]
        self.segs[r] = [a[0], max(a[1], b[1]), (a[2] + " " + b[2]).strip()]
        del self.segs[r + 1]
        self._emit()
        self._fill()
        self.table.selectRow(r)

    def split(self):
        rows = self._selected_rows()
        if not rows:
            return
        r = rows[0]
        a, b, t = self.segs[r]
        words = t.split()
        if len(words) < 2:
            return
        half = len(words) // 2
        mid = a + (b - a) * len(" ".join(words[:half])) / max(1, len(t))
        self.segs[r] = [a, mid, " ".join(words[:half])]
        self.segs.insert(r + 1, [mid, b, " ".join(words[half:])])
        self._emit()
        self._fill()
        self.table.selectRow(r)

    def shift_all(self):
        d = self.shift.value()
        if not d or not self.segs:
            return
        self.segs = [[max(0.0, a + d), max(0.05, b + d), t] for a, b, t in self.segs]
        self._emit()
        self._fill()

    # ------------------------------------------------------------- playback
    def _ensure_player(self) -> bool:
        if self.player is None and HAVE_PLAYER:
            self.player = QMediaPlayer(self)
            if QAudioOutput is not None:
                self.audio = QAudioOutput(self)
                self.player.setAudioOutput(self.audio)
            self.player.setVideoOutput(self.video)
            self.player.positionChanged.connect(self._on_position)
            self.player.playbackStateChanged.connect(
                lambda st: self.play_btn.setText("❚❚ Pause" if st == QMediaPlayer.PlayingState else "▶ Play"))
        if self.player is not None and self.path is not None:
            url = QUrl.fromLocalFile(str(self.path))
            if self.player.source() != url:
                self.player.setSource(url)
            self.stack.setCurrentIndex(1)
        return self.player is not None

    def position(self) -> float:
        return self.player.position() / 1000 if self.player is not None else 0.0

    def _row_selected(self, r: int):
        if self._filling or r < 0 or r >= len(self.segs):
            return
        self.caption.setText(self.segs[r][2])
        if self.player is not None and self.player.playbackState() == QMediaPlayer.PlayingState:
            return
        if self._ensure_player():
            self.player.setPosition(int(self.segs[r][0] * 1000) + 50)
            self.player.pause()

    def play_line(self):
        rows = self._selected_rows()
        if not rows or not self._ensure_player():
            return
        a, b, _t = self.segs[rows[0]]
        self._stop_at = b + 0.2
        self.player.setPosition(int(max(0.0, a - 0.2) * 1000))
        self.player.play()

    def toggle(self):
        if not self._ensure_player():
            return
        self._stop_at = None
        if self.player.playbackState() == QMediaPlayer.PlayingState:
            self.player.pause()
        else:
            self.player.play()

    def _on_position(self, ms: int):
        t = ms / 1000
        self.time.setText(fmt_time(t))
        line = next((s for s in self.segs if s[0] <= t <= s[1]), None)
        self.caption.setText(line[2] if line else "")
        if self._stop_at is not None and t >= self._stop_at:
            self._stop_at = None
            self.player.pause()

    def _stop(self):
        if self.player is not None:
            self.player.stop()
            self.player.setSource(QUrl())
        self.caption.setText("")

    def theme_changed(self):
        _c = theme.colors()
