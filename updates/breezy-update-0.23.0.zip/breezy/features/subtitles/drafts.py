"""Subtitle drafts: the text written from the speech, kept (and edited) until it's saved.

One JSON file per video in the app's data folder, keyed by the video's path, size and date, so a
changed video doesn't pick up an old draft."""
from __future__ import annotations

import hashlib
import json
import re
import time
from pathlib import Path

from breezy.core.settings import app_data_dir


def drafts_dir() -> Path:
    d = app_data_dir() / "subtitle_drafts"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _key(video: Path) -> str:
    try:
        st = Path(video).stat()
        sig = f"{Path(video).resolve()}|{st.st_size}|{int(st.st_mtime)}"
    except OSError:
        sig = str(video)
    return hashlib.sha1(sig.lower().encode()).hexdigest()[:20]


def path_for(video: Path) -> Path:
    return drafts_dir() / f"{_key(video)}.json"


def load(video: Path) -> dict | None:
    p = path_for(video)
    if not p.is_file():
        return None
    try:
        d = json.loads(p.read_text("utf-8"))
        d["segments"] = [[float(a), float(b), str(t)] for a, b, t in d.get("segments", [])]
        return d
    except (OSError, ValueError, TypeError):
        return None


def save(video: Path, segments, lang: str, edited: bool = False, source: str = "speech") -> dict:
    d = {"video": str(video), "lang": lang, "segments": [[round(float(a), 3), round(float(b), 3), str(t)]
                                                          for a, b, t in segments],
         "edited": edited, "source": source, "saved": time.time()}
    path_for(video).write_text(json.dumps(d, ensure_ascii=False, indent=1), "utf-8")
    return d


def delete(video: Path) -> None:
    path_for(video).unlink(missing_ok=True)


# ------------------------------------------------------------------ .srt reading and times
_TIME = re.compile(r"(\d+):(\d\d):(\d\d)[,.](\d{1,3})")


def parse_srt(text: str) -> list[list]:
    out = []
    for block in re.split(r"\n\s*\n", text.replace("\r\n", "\n").replace("﻿", "").strip()):
        lines = [x for x in block.split("\n") if x.strip() != ""]
        for i, line in enumerate(lines):
            if "-->" in line:
                a, b = (_TIME.search(x) for x in line.split("-->", 1))
                if a and b:
                    out.append([_secs(a), _secs(b), "\n".join(lines[i + 1:]).strip()])
                break
    return out


def _secs(m) -> float:
    h, mi, s, ms = m.groups()
    return int(h) * 3600 + int(mi) * 60 + int(s) + int(ms.ljust(3, "0")) / 1000


def fmt_time(t: float) -> str:
    t = max(0.0, t)
    h, rem = divmod(t, 3600)
    m, s = divmod(rem, 60)
    return f"{int(h)}:{int(m):02d}:{s:06.3f}"


def parse_time(text: str) -> float | None:
    """'1:02.5', '0:01:02.500', '62.5' -> seconds."""
    text = text.strip().replace(",", ".")
    try:
        parts = [float(x) for x in text.split(":")]
    except ValueError:
        return None
    if not parts or len(parts) > 3 or any(x < 0 for x in parts):
        return None
    secs = 0.0
    for x in parts:
        secs = secs * 60 + x
    return secs
