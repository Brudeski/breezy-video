"""Tasks page: every queued, running and finished task from all modules."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QMessageBox, QHBoxLayout, QHeaderView, QLabel, QPlainTextEdit, QProgressBar,
                               QPushButton, QSplitter, QToolButton, QTreeWidget, QTreeWidgetItem,
                               QVBoxLayout, QWidget)

from breezy.core import theme
from breezy.core.icons import icon
from breezy.core.plugin import Feature
from breezy.core.tasks import ACTIVE, FINISHED, PAUSED, QUEUED, RUNNING, describe
from breezy.core.ui import MODULE_NAMES, open_in_explorer

STATUS_TEXT = {"queued": "Waiting", "running": "Running", "paused": "Paused", "done": "Done",
               "failed": "Failed", "cancelled": "Cancelled", "skipped": "Skipped"}


def quality_text(t) -> str:
    """'Balanced', 'Custom', '★ Mine' - plus Enhance's 'What to fix' when it isn't General."""
    from breezy.core.quality import CONTENT, level_name
    q = level_name((t.spec or {}).get("quality_level"))
    base = level_name((t.spec or {}).get("quality_base"))
    if q == "Custom" and base and base != "Custom":
        q = f"Custom (changed from {base})"
    c = (t.spec or {}).get("content_type")
    if q and c and c != "general":
        q += " · " + dict((k, n) for n, k in CONTENT).get(c, c)
    return q


def result_target(outputs: list) -> tuple[str, Path] | None:
    """What double-clicking a task opens: ("file", the video) when it made one video (side files such as
    subtitles or lists don't count), else ("folder", the folder most of its files are in)."""
    from breezy.core.tasks import NOT_MEDIA
    files = [Path(o) for o in outputs if Path(o).exists()]
    if not files:
        return None
    media = [f for f in files if f.suffix.lower() not in NOT_MEDIA] or files
    if len(media) == 1:
        return "file", media[0]
    folders: dict = {}
    for f in media:
        folders[f.parent] = folders.get(f.parent, 0) + 1
    return "folder", max(folders, key=folders.get)


class TaskDetail(QWidget):
    """Everything about one task: overall and current-file progress, times, speed, every file's state, results."""

    def __init__(self, manager):
        super().__init__()
        from PySide6.QtCore import QTimer
        from PySide6.QtWidgets import QFormLayout, QListWidget
        self.m = manager
        self.task_id = None
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 6, 0)
        self.title = QLabel("Select a task to see its details", objectName="taskTitle")
        self.title.setWordWrap(True)
        v.addWidget(self.title)
        self.total = QProgressBar()
        self.total.setRange(0, 1000)
        self.total.setFormat("Overall %p%")
        self.total.setToolTip("How much of the whole task is done (weighted by video length)")
        v.addWidget(self.total)
        self.item_bar = QProgressBar()
        self.item_bar.setRange(0, 1000)
        self.item_bar.setToolTip("How far the file being worked on now is")
        v.addWidget(self.item_bar)
        form = QFormLayout()
        form.setHorizontalSpacing(14)
        self.f_status, self.f_elapsed, self.f_left, self.f_done, self.f_speed, self.f_files = (QLabel() for _ in range(6))
        self.f_quality = QLabel()
        self.f_stage = QLabel()
        self.f_stage.setWordWrap(True)
        for lab, w, tip in (("Status:", self.f_status, ""),
                            ("Quality:", self.f_quality, "The global quality level the task was started with"),
                            ("Now:", self.f_stage, "The step being done right now (for each file being worked on)"),("Working time:", self.f_elapsed, "Pauses don't count"),
                            ("Time left:", self.f_left, "Estimated from the speed so far"),
                            ("Finishes at:", self.f_done, "Estimated clock time when it will be done"),
                            ("Speed:", self.f_speed, "How many seconds of video are processed per second"),
                            ("Files:", self.f_files, "")):
            w.setToolTip(tip)
            form.addRow(lab, w)
        v.addLayout(form)
        self.items = QListWidget()
        self.items.setToolTip("Every file in this task: ✔ done, ▶ working, … waiting, ✖ problem.\n"
                              "Double-click a finished result to open it")
        self.items.itemDoubleClicked.connect(self._open)
        v.addWidget(self.items, 1)
        self.timer = QTimer(self, interval=1000)
        self.timer.timeout.connect(self.refresh)
        self.timer.start()
        manager.changed.connect(lambda tid: tid == self.task_id and self.refresh())

    def show_task(self, task_id):
        self.task_id = task_id
        self.refresh(rebuild=True)

    def _open(self, it):
        p = it.data(Qt.UserRole)
        if p:
            open_in_explorer(Path(p))

    def refresh(self, rebuild: bool = False):
        from datetime import datetime, timedelta
        from PySide6.QtWidgets import QListWidgetItem
        from breezy.core.tasks import clock, fmt_secs
        t = self.m.get(self.task_id) if self.task_id else None
        if not t:
            self.title.setText("Select a task to see its details")
            for w in (self.total, self.item_bar):
                w.setValue(0)
            self.items.clear()
            return
        self.title.setText(f"{MODULE_NAMES.get(t.module, t.module.title())}: {t.title}")
        self.total.setValue(int(t.progress * 1000))
        running = t.status in (RUNNING, PAUSED)
        self.item_bar.setVisible(running and bool(t.items))
        cur = t.current or ""
        vp = t.video_position()
        self.item_bar.setFormat((cur[:60] + " - " if cur else "Current file - ")
                                + (f"{clock(vp[0])} of {clock(vp[1])} - " if vp else "") + "%p%")
        self.item_bar.setValue(int(max(0.0, min(1.0, t.item_frac)) * 1000))
        self.f_status.setText(STATUS_TEXT.get(t.status, t.status) + (f" - {t.message}" if t.message else ""))
        self.f_stage.setText((t.stage or "-") if running else "-")
        self.f_quality.setText(quality_text(t) or "-")
        self.f_elapsed.setText(fmt_secs(t.active_seconds) if t.active_seconds else "-")
        eta = t.eta_seconds() if t.status == RUNNING else None
        self.f_left.setText(fmt_secs(eta) if eta is not None else ("-" if not running else "estimating…"))
        self.f_done.setText((datetime.now() + timedelta(seconds=eta)).strftime("%I:%M %p").lstrip("0")
                            if eta is not None else "-")
        sp = t.speed() if (t.media and running) else None
        self.f_speed.setText(f"{sp:.2f}× real-time" if sp else "-")
        n = len(t.items)
        length = f" ({clock(sum(t.weights))} of video in all)" if (t.media and t.weights and n) else ""
        self.f_files.setText(f"{len(t.done_items)} of {n} done" + length
                             + (f", {len(t.errors)} problem(s)" if t.errors else "")
                             + (f", {len(t.outputs)} file(s) made" if t.outputs else "") if n else
                             (f"{len(t.outputs)} file(s) made" if t.outputs else "-"))
        # file list (rebuilt when its shape changes)
        rows = []
        for i in range(n):
            name = t.names[i] if i < len(t.names) else str(t.items[i])
            if i in t.done_items:
                err = any(str(name) in e for e in t.errors)
                rows.append(("✖ " if err else "✔ ") + str(name))
            elif running and name in (t.current or "").split(", "):
                rows.append(f"▶ {name}" + (f"  {t.item_frac:.0%}" if t.item_frac and "," not in (t.current or "") else ""))
            else:
                rows.append(f"…  {name}" if t.status in ("queued", "running", "paused") else f"-  {name}")
        outs = [("📄 " + Path(o).name, o) for o in t.outputs]
        texts = rows + (["Results:"] + [x for x, _o in outs] if outs else [])
        if rebuild or self.items.count() != len(texts):
            self.items.clear()
            for r in rows:
                self.items.addItem(r)
            if outs:
                head = QListWidgetItem("Results:")
                head.setFlags(Qt.ItemIsEnabled)
                self.items.addItem(head)
                for text, o in outs:
                    it = QListWidgetItem(text)
                    it.setData(Qt.UserRole, o)
                    it.setToolTip(o)
                    self.items.addItem(it)
        else:
            for i, r in enumerate(rows):
                if self.items.item(i).text() != r:
                    self.items.item(i).setText(r)


class TasksWidget(QWidget):
    def __init__(self, feature):
        super().__init__()
        self.feature = feature
        self.m = feature.context.tasks
        v = QVBoxLayout(self)
        v.setContentsMargins(0, 0, 0, 0)
        bar = QHBoxLayout()
        self.summary = QLabel("", objectName="muted")
        self.pause_all = QPushButton("Pause all")
        self.pause_all.clicked.connect(self.m.pause_all)
        self.resume_all = QPushButton("Resume all")
        self.resume_all.clicked.connect(lambda: [self.m.resume(t.id) for t in self.m.tasks if t.status == PAUSED])
        self.clear_btn = QPushButton("Clear finished")
        self.clear_btn.clicked.connect(self.m.clear_finished)
        bar.addWidget(self.summary, 1)
        from breezy.core.notify import AFTER
        from breezy.core.ui import check, combo
        st = feature.context.settings
        self.notify = check("Notify me", st.get("app", "notify", True),
                            "A Windows notification when a task finishes (while you're in another window)")
        self.notify.toggled.connect(lambda on: st.set("app", "notify", on))
        self.after = combo(AFTER, st.get("app", "after_queue", "nothing"),
                           "What the PC does when every task is finished (60 s countdown, can be cancelled).\n"
                           "Applies once - it goes back to 'Nothing' afterwards")
        from breezy.core import notify
        self.after.currentIndexChanged.connect(lambda: notify.set_after(st, self.after.currentData()))
        notify.listeners.append(lambda _k: self._summary())
        bar.addWidget(self.notify)
        bar.addWidget(QLabel("When all done:"))
        bar.addWidget(self.after)
        for b in (self.pause_all, self.resume_all, self.clear_btn):
            bar.addWidget(b)
        v.addLayout(bar)

        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Task", "Status", "Quality", "Progress", "Details", ""])
        self.tree.setRootIsDecorated(False)
        self.tree.setUniformRowHeights(False)
        h = self.tree.header()
        h.resizeSection(0, 330)
        h.resizeSection(1, 90)
        h.resizeSection(2, 220)
        h.resizeSection(3, 160)
        h.setSectionResizeMode(4, QHeaderView.Stretch)
        h.resizeSection(5, 190)
        self.tree.headerItem().setToolTip(2, "The global quality level the task was started with")
        h.setToolTip("Drag the lines between the column titles to make a column wider or narrower")
        h.setStretchLastSection(False)
        self.tree.currentItemChanged.connect(self._show_log)
        self.tree.itemDoubleClicked.connect(lambda it, _col: self._open_result(it.data(0, Qt.UserRole)))
        self.tree.setToolTip("Double-click a finished task to open its result: the video itself when it made\n"
                             "one file, or the folder when it made several")
        self.log = QPlainTextEdit(readOnly=True)
        self.log.setPlaceholderText("Select a task to see its log")
        self.log.setMaximumBlockCount(3000)
        self.detail = TaskDetail(self.m)
        low = QSplitter(Qt.Horizontal)
        low.addWidget(self.detail)
        low.addWidget(self.log)
        low.setSizes([560, 520])
        split = QSplitter(Qt.Vertical)
        split.addWidget(self.tree)
        split.addWidget(low)
        split.setSizes([360, 360])
        v.addWidget(split, 1)

        self.rows: dict[str, QTreeWidgetItem] = {}
        self.m.listChanged.connect(self.rebuild)
        self.m.changed.connect(self.update_row)
        self.m.finished.connect(self.update_row)
        self.m._log.connect(self._log_line)
        self.rebuild()

    # ---------------------------------------------------------------- rows
    def rebuild(self):
        cur = self.tree.currentItem()
        cur_id = cur.data(0, Qt.UserRole) if cur else None
        self.tree.clear()
        self.rows = {}
        for t in self.m.tasks:
            it = QTreeWidgetItem(self.tree)
            it.setData(0, Qt.UserRole, t.id)
            self.rows[t.id] = it
            bar = QProgressBar()
            bar.setRange(0, 1000)
            bar.setFixedHeight(12)
            bar.setTextVisible(False)
            self.tree.setItemWidget(it, 3, bar)
            self.tree.setItemWidget(it, 5, self._buttons(t.id))
            self.update_row(t.id)
            if t.id == cur_id:
                self.tree.setCurrentItem(it)
        self._summary()

    def _buttons(self, tid: str) -> QWidget:
        w = QWidget()
        h = QHBoxLayout(w)
        h.setContentsMargins(0, 0, 0, 0)
        h.setSpacing(2)
        c = theme.colors()["text"]
        spec = [("up", "Move up in the queue", lambda: self.m.move(tid, -1)),
                ("down", "Move down in the queue", lambda: self.m.move(tid, 1)),
                ("pause", "Pause / resume", lambda: self._toggle(tid)),
                ("x", "Cancel", lambda: self.m.cancel(tid)),
                ("folder", "Open the output folder", lambda: self._open(tid)),
                ("trash", "Remove from the list", lambda: self.m.remove(tid))]
        for name, tip, fn in spec:
            b = QToolButton()
            b.setIcon(icon(name, c, 16))
            b.setToolTip(tip)
            b.setObjectName(name)
            b.clicked.connect(fn)
            h.addWidget(b)
        h.addStretch()
        return w

    def update_row(self, tid: str):
        t = self.m.get(tid)
        it = self.rows.get(tid)
        if not t or not it:
            return
        c = theme.colors()
        it.setText(0, f"{MODULE_NAMES.get(t.module, t.module.title())}: {t.title}")
        it.setToolTip(0, t.title)
        it.setText(1, STATUS_TEXT.get(t.status, t.status))
        color = {"done": c["good"], "failed": c["bad"], "running": c["accent"], "paused": c["warn"]}.get(t.status)
        it.setForeground(1, Qt.GlobalColor.gray if not color else __import__("PySide6.QtGui", fromlist=["QColor"]).QColor(color))
        q = quality_text(t)
        it.setText(2, q or "-")
        it.setToolTip(2, ("Started with the quality level: " + q) if q else "The quality level doesn't apply here")
        it.setText(4, describe(t))
        it.setToolTip(4, describe(t) + ("\n" + "\n".join(t.errors[-3:]) if t.errors else ""))
        bar = self.tree.itemWidget(it, 3)
        if bar:
            bar.setValue(int(t.progress * 1000))
        btns = self.tree.itemWidget(it, 5)
        if btns:
            active = t.status in ACTIVE
            for name in ("up", "down"):
                btns.findChild(QToolButton, name).setVisible(t.status in (QUEUED, PAUSED) and not self.m.is_running(t))
            pb = btns.findChild(QToolButton, "pause")
            pb.setVisible(active)
            pb.setIcon(icon("play" if t.status == PAUSED else "pause", c["text"], 16))
            btns.findChild(QToolButton, "x").setVisible(active)
            btns.findChild(QToolButton, "folder").setVisible(bool(t.outputs))
            btns.findChild(QToolButton, "trash").setVisible(t.status in FINISHED or (t.status in (QUEUED, PAUSED) and not self.m.is_running(t)))
        self._summary()

    def _summary(self):
        cur = self.feature.context.settings.get("app", "after_queue", "nothing")
        if self.after.currentData() != cur:
            self.after.blockSignals(True)
            self.after.setCurrentIndex(max(0, self.after.findData(cur)))
            self.after.blockSignals(False)
        runs = self.m.running_all()
        waiting = sum(1 for t in self.m.tasks if t.status == QUEUED)
        paused = sum(1 for t in self.m.tasks if t.status == PAUSED)
        parts = [("Running: " + " + ".join(r.title for r in runs)) if runs else "Nothing running"]
        if waiting:
            parts.append(f"{waiting} waiting")
        if paused:
            parts.append(f"{paused} paused")
        self.summary.setText("   ·   ".join(parts))

    def _toggle(self, tid):
        t = self.m.get(tid)
        if t and t.status == PAUSED:
            self.m.resume(tid)
        elif t:
            self.m.pause(tid)

    def _open(self, tid):
        t = self.m.get(tid)
        if t and t.outputs:
            open_in_explorer(Path(t.outputs[-1]))

    def _open_result(self, tid):
        """Double-click: one result -> open (play) it; several -> open their folder."""
        from breezy.core.ui import play_file
        t = self.m.get(tid) if tid else None
        if t is None or t.status in ("queued",):
            return
        target = result_target(t.outputs)
        if target is None:
            msg = "This task didn't make any files." if not t.outputs else "Its files are no longer there."
            self.summary.setText(msg)
            return
        kind, path = target
        try:
            if kind == "file":
                play_file(path)
            else:
                open_in_explorer(path)
        except OSError as e:
            QMessageBox.warning(self, "Open", f"Couldn't open {path}:\n{e}")

    # ----------------------------------------------------------------- log
    def _show_log(self, item, _prev=None):
        self.log.clear()
        if not item:
            self.detail.show_task(None)
            return
        t = self.m.get(item.data(0, Qt.UserRole))
        self.detail.show_task(t.id if t else None)
        if t:
            self.log.setPlainText("\n".join(t.log_lines[-1500:]))
            self.log.verticalScrollBar().setValue(self.log.verticalScrollBar().maximum())

    def _log_line(self, tid, line):
        cur = self.tree.currentItem()
        if cur and cur.data(0, Qt.UserRole) == tid:
            self.log.appendPlainText(line)


class TasksFeature(Feature):
    id = "tasks"
    name = "Tasks"
    description = "Everything queued, running and finished - from every module. Pause, resume, reorder or cancel."
    order = 900
    icon = "tasks"

    def create_widget(self):
        self.widget = TasksWidget(self)
        return self.widget

    def theme_changed(self):
        self.widget.rebuild()


FEATURE = TasksFeature
