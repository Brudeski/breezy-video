"""Pipelines page: make, change and run saved pipelines."""
from __future__ import annotations

from pathlib import Path

from PySide6.QtWidgets import (QHBoxLayout, QInputDialog, QLabel, QListWidget, QListWidgetItem, QMenu, QMessageBox,
                               QPushButton, QToolButton, QVBoxLayout, QWidget)

from breezy.core import pipelines as pl
from breezy.core.filepage import VideoListPage
from breezy.core.outputs import output_spec
from breezy.core.ui import Card, check, combo
from breezy.features.ends.editor import fmt
from breezy.features.stitcher.joiner import _fmt_size


class PipelinesWidget(VideoListPage):
    MODULE = "pipelines"
    TITLE = "Pipelines"
    DEFAULT_FOLDER = "Pipeline results"
    PATTERNS = []
    COLUMNS = [("Length", 70), ("Picture", 130), ("Size", 80), ("Details", 200)]
    RUN_TEXT = "Run pipeline on ticked videos"
    RUN_TIP = "Queues every step of the pipeline for the ticked videos. The originals are never changed."
    task_kind, auto_kind, task_verb = "", "", "Run"
    needs_video = False

    def __init__(self, feature):
        self.pipes: dict = {}
        super().__init__(feature)

    # ------------------------------------------------------------------ editor
    def build_middle(self):
        self.pipes = pl.load_all(self.ctx.settings)
        box = QWidget()
        v = QVBoxLayout(box)
        v.setContentsMargins(0, 4, 0, 0)
        v.setSpacing(6)
        top = QHBoxLayout()
        top.addWidget(QLabel("Pipeline:"))
        self.choose = combo([], None, "The saved pipeline to change or run")
        self.choose.setMinimumWidth(220)
        self.choose.currentIndexChanged.connect(self._chosen)
        top.addWidget(self.choose, 1)
        for text, tip, fn in (("New…", "Make a new, empty pipeline", self._new),
                              ("Rename…", "Give this pipeline another name", self._rename),
                              ("Copy…", "Make a copy of this pipeline to change", self._copy),
                              ("Delete", "Delete this pipeline (no videos are touched)", self._delete)):
            b = QPushButton(text)
            b.setToolTip(tip)
            b.clicked.connect(fn)
            top.addWidget(b)
        v.addLayout(top)
        self.steps = QListWidget()
        self.steps.setToolTip("The steps, in order. Each next step works on the files the step before it made.")
        self.steps.currentRowChanged.connect(lambda *_: self._enable())
        self.steps.itemDoubleClicked.connect(lambda *_: self._open_page())
        v.addWidget(self.steps, 1)
        row = QHBoxLayout()
        self.add_btn = QToolButton()
        self.add_btn.setText("Add step ▾")
        self.add_btn.setToolTip("Adds a module as the next step, with the settings its page has right now")
        self.add_btn.setPopupMode(QToolButton.InstantPopup)
        self.add_menu = QMenu(self.add_btn)
        self.add_menu.aboutToShow.connect(self._fill_add_menu)
        self.add_btn.setMenu(self.add_menu)
        row.addWidget(self.add_btn)
        self.update_btn = self._b(row, "Update from its page", "Takes the settings the step's page has right now\n"
                                  "(change them on that page first, then press this)", self._update_step)
        self.open_btn2 = self._b(row, "Open its page", "Shows the step's page so you can change its settings",
                                 self._open_page)
        self.up_btn = self._b(row, "▲", "Move the step earlier", lambda: self._move(-1))
        self.down_btn = self._b(row, "▼", "Move the step later", lambda: self._move(1))
        self.del_btn = self._b(row, "Remove", "Remove the step from the pipeline", self._remove)
        row.addStretch(1)
        v.addLayout(row)
        self.keep = check("Keep the in-between files", False,
                          "Off: only the last step's results are kept; what the steps in between made is\n"
                          "deleted once the pipeline has finished.\n"
                          "On: every step's results stay in that step's usual folder.\n\n"
                          "When to use: on if you also want e.g. the trimmed videos before they were stabilised.")
        self.keep.toggled.connect(self._keep_toggled)
        v.addWidget(self.keep)
        self.hint = QLabel("Each step uses the settings its page had when it was added. To change a step, change "
                           "its page, then press 'Update from its page'.", objectName="muted")
        self.hint.setWordWrap(True)
        v.addWidget(self.hint)
        self._fill_names(self.feature.setting("last_pipeline", ""))
        return box

    @staticmethod
    def _b(row, text, tip, fn):
        b = QPushButton(text)
        b.setToolTip(tip)
        b.clicked.connect(fn)
        row.addWidget(b)
        return b

    def build_settings(self, col):
        c = col.add(Card("How it works"))
        c.note("1. Make a pipeline and add steps (each takes its page's\n"
               "    current settings).\n"
               "2. Tick videos on the left and press 'Run pipeline'.\n"
               "3. The steps run one after the other; the last step's\n"
               "    results go to the folder below.\n\n"
               "A watch folder (Settings) can run a pipeline on new\n"
               "videos automatically.")

    # ------------------------------------------------------------------ data
    def _name(self) -> str:
        return self.choose.currentData() or ""

    def _pipe(self) -> dict | None:
        return self.pipes.get(self._name())

    def _store(self):
        pl.save_all(self.ctx.settings, self.pipes)

    def _fill_names(self, select: str = ""):
        self.choose.blockSignals(True)
        self.choose.clear()
        for n in sorted(self.pipes, key=str.lower):
            self.choose.addItem(n, n)
        if not self.pipes:
            self.choose.addItem("(no pipelines yet - press New…)", "")
        i = self.choose.findData(select)
        self.choose.setCurrentIndex(max(0, i))
        self.choose.blockSignals(False)
        self._chosen()

    def _chosen(self, *_):
        self.feature.set_setting("last_pipeline", self._name())
        p = self._pipe()
        self.steps.clear()
        for i, st in enumerate((p or {}).get("steps", []), 1):
            it = QListWidgetItem(f"{i}.  {st.get('name', st['module'])}  -  {st.get('summary', '')}")
            it.setToolTip(f"Settings saved {fmt_when(st.get('saved'))}")
            self.steps.addItem(it)
        self.keep.blockSignals(True)
        self.keep.setChecked(bool((p or {}).get("keep_between", False)))
        self.keep.blockSignals(False)
        self._enable()
        self.update_buttons()

    def _enable(self):
        has = self._pipe() is not None
        row = self.steps.currentRow()
        n = self.steps.count()
        self.add_btn.setEnabled(has)
        self.keep.setEnabled(has and n > 1)
        for b in (self.update_btn, self.open_btn2, self.del_btn):
            b.setEnabled(has and row >= 0)
        self.up_btn.setEnabled(has and row > 0)
        self.down_btn.setEnabled(has and 0 <= row < n - 1)

    def _ask_name(self, title: str, start: str = "") -> str:
        while True:
            name, ok = QInputDialog.getText(self, title, "Name:", text=start)
            name = (name or "").strip()
            if not ok:
                return ""
            if name and name not in self.pipes:
                return name
            QMessageBox.information(self, "Pipelines", "Please choose a name that isn't used yet.")
            start = name

    def _new(self):
        name = self._ask_name("New pipeline")
        if name:
            self.pipes[name] = {"steps": [], "keep_between": False}
            self._store()
            self._fill_names(name)
            self.say(f"Pipeline '{name}' made. Add its steps with 'Add step'.")

    def _rename(self):
        old = self._name()
        if not old:
            return
        name = self._ask_name("Rename pipeline", old)
        if name:
            self.pipes[name] = self.pipes.pop(old)
            self._store()
            self._fill_names(name)
            self._rename_in_watch(old, name)

    def _rename_in_watch(self, old: str, new: str):
        w = list(self.ctx.settings.get("app", "watch_folders") or [])
        changed = False
        for x in w:
            if x.get("pipeline") == old:
                x["pipeline"] = new
                changed = True
        if changed:
            self.ctx.settings.set("app", "watch_folders", w)

    def _copy(self):
        old = self._name()
        if not old:
            return
        name = self._ask_name("Copy pipeline", old + " (copy)")
        if name:
            import copy
            self.pipes[name] = copy.deepcopy(self.pipes[old])
            self._store()
            self._fill_names(name)

    def _delete(self):
        name = self._name()
        if not name:
            return
        used = [x["folder"] for x in (self.ctx.settings.get("app", "watch_folders") or []) if x.get("pipeline") == name]
        extra = f"\n\nWatch folders using it will stop: {', '.join(used)}" if used else ""
        if QMessageBox.question(self, "Pipelines", f"Delete the pipeline '{name}'?{extra}") != QMessageBox.Yes:
            return
        self.pipes.pop(name, None)
        self._store()
        self._fill_names()

    def _features(self) -> dict:
        win = self.ctx.window
        return {f.id: f for f in getattr(win, "features", [])} if win else {}

    def _fill_add_menu(self):
        self.add_menu.clear()
        feats = self._features()
        for mod in pl.step_modules():
            f = feats.get(mod)
            if f is None:
                continue
            a = self.add_menu.addAction(f.name)
            a.triggered.connect(lambda _=False, m=mod: self._add(m))

    def _add(self, mod: str):
        p = self._pipe()
        f = self._features().get(mod)
        if p is None or f is None:
            return
        st = pl.snapshot(f)
        if st is None:
            QMessageBox.information(self, "Pipelines", f"Open the {f.name} page once first.")
            return
        p["steps"].append(st)
        self._store()
        self._chosen()
        self.steps.setCurrentRow(self.steps.count() - 1)
        self.say(f"Added {f.name}: {st['summary']}")

    def _update_step(self):
        p, row = self._pipe(), self.steps.currentRow()
        if p is None or row < 0:
            return
        mod = p["steps"][row]["module"]
        f = self._features().get(mod)
        st = pl.snapshot(f) if f else None
        if st is None:
            return
        p["steps"][row] = st
        self._store()
        self._chosen()
        self.steps.setCurrentRow(row)
        self.say(f"Step {row + 1} ({f.name}) updated: {st['summary']}")

    def _open_page(self):
        p, row = self._pipe(), self.steps.currentRow()
        if p is None or row < 0 or self.ctx.window is None:
            return
        self.ctx.window.show_feature(p["steps"][row]["module"])

    def _move(self, d: int):
        p, row = self._pipe(), self.steps.currentRow()
        if p is None or not (0 <= row + d < len(p["steps"])):
            return
        s = p["steps"]
        s[row], s[row + d] = s[row + d], s[row]
        self._store()
        self._chosen()
        self.steps.setCurrentRow(row + d)

    def _remove(self):
        p, row = self._pipe(), self.steps.currentRow()
        if p is None or row < 0:
            return
        del p["steps"][row]
        self._store()
        self._chosen()

    def _keep_toggled(self, on: bool):
        p = self._pipe()
        if p is not None:
            p["keep_between"] = on
            self._store()

    # ------------------------------------------------------------------ list + run
    def settings(self) -> dict:
        return {}

    def can_run(self) -> str:
        if not hasattr(self, "choose"):
            return ""
        p = self._pipe()
        if p is None:
            return "Make a pipeline first (New…)"
        if not p.get("steps"):
            return "Add the pipeline's steps first"
        return ""

    def fill_row(self, it, p: Path, info):
        v = info.video
        it.setText(1, fmt(info.duration, False))
        if v:
            fps = f" {float(v.fps):.3g} fps" if v.fps else ""
            it.setText(2, f"{v.width}×{v.height}{fps}")
        else:
            it.setText(2, "sound only")
        it.setText(3, _fmt_size(info.size))

    def final_out(self):
        return output_spec(self.ctx.settings, self.MODULE, self.DEFAULT_FOLDER, self, self.out.values())

    def run(self):
        jobs = self.jobs()
        if not jobs or self.can_run():
            return None
        out = self.final_out()
        if out is None:
            return None
        runner = getattr(self.ctx, "pipelines", None)
        tasks = runner.run(self._name(), self._pipe(), files=jobs, final_out=out, parent=self)
        self.say(f"Queued: '{self._name()}' on {len(jobs)} video(s) - {len(tasks)} step(s).")
        return tasks

    def _queue_auto(self, task_id: str):
        why = self.can_run()
        if why:
            QMessageBox.information(self, self.TITLE, why)
            return
        out = self.final_out()
        if out is None:
            return
        src = self.tm.get(task_id)
        runner = getattr(self.ctx, "pipelines", None)
        runner.run(self._name(), self._pipe(), input_from=task_id, final_out=out, parent=self,
                   label=f"(output of '{src.title if src else task_id}')")
        self.say(f"Queued: '{self._name()}' on the files from '{src.title if src else task_id}' when it finishes.")


def fmt_when(t) -> str:
    import time
    return time.strftime("%Y-%m-%d %H:%M", time.localtime(t)) if t else "?"
