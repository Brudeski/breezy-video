"""Pipelines: several modules one after the other, saved under a name."""
from breezy.core.plugin import Feature


class PipelinesFeature(Feature):
    id = "pipelines"
    name = "Pipelines"
    description = ("Save several steps under one name - e.g. Trim Ends, then Stabilizer, then Enhance - and run "
                   "them on videos with one click. Each step keeps the settings its page had when you added it. "
                   "Watch folders can run a pipeline on new videos automatically.")
    order = 5
    icon = "pipeline"

    def create_widget(self):
        from .widget import PipelinesWidget
        self.widget = PipelinesWidget(self)
        return self.widget

    def theme_changed(self):
        self.widget.theme_changed()

    def shutdown(self):
        w = getattr(self, "widget", None)
        if w is not None:
            w.shutdown()


FEATURE = PipelinesFeature
