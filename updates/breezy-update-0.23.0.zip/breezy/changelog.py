"""What changed in each version (newest first). Shown once after an update and in Settings."""

CHANGES = [
    ("0.23.0", ["New page: Pipelines - save several steps under one name (e.g. Trim Ends, then Stabilizer, then "
                "Enhance) and run them on videos with one click. Each step keeps the settings its page had when "
                "you added it ('Update from its page' to change them). In-between files are deleted when done, or "
                "kept if you tick 'Keep the in-between files'.",
                "Watch folders (Settings): new videos in a folder are run through a pipeline automatically - only "
                "once they've finished copying. Breezy can start with Windows and keeps running in the tray while "
                "it watches (right-click the tray icon to pause or quit).",
                "New 'When done' button in the bottom bar: close Breezy, sleep, hibernate or shut down the PC "
                "when every task is finished (60-second countdown; once). 'Close Breezy' is new.",
                "Updates: Breezy looks for new versions once a day (Settings → Updates) and installs them when you "
                "say so - downloaded from GitHub, checked, with a backup of the old version.",
                "There is now a Windows installer for other PCs (no administrator rights needed).",
                "Only one Breezy runs at a time: starting it again brings the running one to the front."]),
    ("0.22.0", ["Subtitles: new editor. With 'Check the text before saving' (on by default), 'Write subtitles' "
                "writes the text first; read it next to the playing video, correct words and times, add, delete, "
                "join or split lines, move them all earlier or later, then 'Save ticked'. Corrections are kept "
                "straight away, also after closing the program. A .srt next to a video can be corrected too.",
                "Rotate & Crop: 'Own turn & crop for this video' gives one video its own settings; the others "
                "keep the shared ones. Optionally remembered after closing."]),
    ("0.21.0", ["New module: Convert & Compress - change format (MP4, MKV, MOV, WebM, MP3/M4A sound only, or "
                "MP4 without re-encoding), shrink to a target file size (with quick sizes like 10 MB), to a share "
                "of the original, or by quality; lower the resolution or frame rate. Shows the expected size.",
                "New module: Rotate & Crop - turn 90°/180°, mirror, and crop free or to 16:9, 9:16, 4:3, 1:1 or "
                "4:5 by drawing on a frame. Turning alone is instant and lossless.",
                "New module: Subtitles - moved out of Enhance onto its own page: .srt next to the video, a "
                "switchable track and/or burned in, with a dark box option and adjustable line length.",
                "Fixed: phone videos with a rotation flag (filmed upright) came out as garbage from Enhance's AI "
                "steps and the Stabilizer's wobble fix / horizon levelling. They now come out upright."]),
    ("0.20.0", ["New module: Stabilizer. Stabilising, the rolling-shutter wobble fix and levelling the horizon "
                "moved here from Enhance, so they can be done on their own.",
                "New: 'Camera movement' - smooth the shake but keep the camera's own moves, or lock the view still "
                "like a tripod.",
                "New: 'Edges' - zoom in to hide the moving edges, zoom only as much as needed, or keep the whole "
                "picture with black edges.",
                "'Make preview' stabilises 5, 10 or 20 seconds from any point and plays it side by side with the "
                "original (looping).",
                "Enhance no longer stabilises; its quality levels and the 'Phone & action camera' type changed to "
                "match."]),
    ("0.19.1", ["Trim Ends: new option to remember the start and end you set by hand after closing the "
                "program (off by default)."]),
    ("0.19.0", ["New module: Trim Ends - cut the start and/or end off videos. Set the same amounts for a whole "
                "batch, or click a video and set its start and end by hand: drag the handles on the timeline, "
                "use 'Start here' / 'End here' while playing, or type the times. Shows the exact first and last "
                "kept frames, and 'Preview cuts' plays both ends. Keys: Space, I, O, arrows.",
                "Trim Ends cuts are exact (only the few frames at the new start are re-encoded), or choose "
                "'Fastest' for an instant, fully lossless cut that starts at the nearest keyframe.",
                "Trim Ends can also cut the files of another task when it finishes ('Use output from…').",
                "Motion Trimmer: 'Merge pauses shorter than' now defaults to 30 s.",
                "Motion Trimmer: new option to remember unticked motion parts after closing the program "
                "(off by default). Choices survive small setting changes."]),
    ("0.18.0", ["Motion Trimmer: every motion part now has its own tick box. Untick the parts you don't want "
                "and only the ticked ones are saved; the video row shows how many are ticked and the new kept time.",
                "New option: 'Save each motion part as its own file' (off by default) - makes name_part01, "
                "name_part02... instead of one joined video.",
                "Partly-ticked boxes now show a dash so they're easy to tell apart from unticked ones."]),
    ("0.17.4", ["Fixed: with NVIDIA TensorRT, AI deblur could turn the whole video into coloured noise. Its "
                "half-precision TensorRT version was broken and was used without a check. Every TensorRT model is "
                "now compared with the processor's result before it's used (also with several pieces per call); "
                "if it differs, half precision is switched off for it, and if it still differs that model uses "
                "CUDA instead. Earlier prepared TensorRT models are deleted and prepared again"]),
    ("0.17.3", ["Fixed: 'elapsed' could become negative and 'time left' stay on 'estimating…' after the PC's clock "
                "was set back (time sync, time zone or daylight-saving change). Working time now uses a steady "
                "clock, time while the PC sleeps isn't counted, and negative values from before are repaired"]),
    ("0.17.2", ["Enhance → Encoding: with 'Set by quality' the unused Target size is hidden and an estimated file "
                "size is shown instead (for the selected video, or a minute of 720p video); the estimate starts from "
                "the source's own bitrate and learns from your finished videos"]),
    ("0.17.1", ["Fixed: coloured blotches in still parts of the picture with 'Reuse AI results'. Lighting and colour "
                "steps that run before the AI (per-scene light & colour, low light) change the colours slowly; parts "
                "that reused an earlier AI result kept the old colours. Changes are now checked in colour, and kept "
                "parts take over the smooth brightness/colour changes of the current frame"]),
    ("0.17.0", [
        "Enhance: on fixed cameras (security, tripod, webcam) the big AI models reuse their result for parts of the "
        "picture that didn't change - often 2-5x faster (2.75x on a test clip, practically identical result). "
        "Enhance → Performance, on by default",
        "NVIDIA TensorRT: compiles each big AI model for your graphics card - usually 2-3x faster than CUDA. "
        "Downloaded once (about 1.2 GB) on RTX 20xx / GTX 16xx and newer and tested; the first time a model is used "
        "with a new tile size it is prepared for the card (a few minutes). Settings → AI engine",
        "AI models get several picture pieces per call, all the same size, so the graphics card picks its fastest "
        "method once and stays busy",
        "Bigger AI pieces when the graphics memory allows (less overlap - faster); up to 1024 px",
        "Encoders work faster on the performance levels and more thoroughly on the quality levels (NVIDIA "
        "presets p3 / p5 / p6, processor: veryfast / medium / slow)",
    ]),
    ("0.16.4", ["Enhance: long videos now continue from the last finished minute after a stop, crash or 'Pause & save' "
                "also when stabilising, slow motion or AI-made frames for a new frame rate are on (the camera shake "
                "measured before is kept too) - the result is the same as an unbroken run"]),
    ("0.16.3", ["The lines between column titles are visible, so it's clear where to drag to resize a column "
                "(Tasks page and every list)",
                "Tasks page: a Quality column (and a line in the details) shows the quality level each task was "
                "started with - e.g. 'Balanced', 'Custom (changed from High Quality)', and Enhance's 'What to fix' "
                "when it isn't General"]),
    ("0.16.2", ["Tasks page: double-click a finished task to open its result - the video itself when it made one "
                "file, or the folder when it made several"]),
    ("0.16.1", ["Enhance: 'New frames by' sits next to the frame rate and is your own choice (kept when the quality "
                "level changes): Automatic (the level decides - AI frames on Max Quality to Balanced, blending below), "
                "AI, classic interpolation or blending. The level descriptions' time estimates follow it"]),
    ("0.16.0", [
        "Nine quality levels instead of five, so the time between neighbouring levels is much more even: Max Quality, "
        "Very High Quality, High Quality, Balanced Quality, Balanced, Balanced Performance, High Performance (no AI), "
        "Very High Performance (no AI), Max Performance (no AI). In the AI half each level takes about twice as long "
        "as the next faster one; one bigger jump remains where the first large AI model starts (AI deblur)",
        "Hover over a level in the open list for a detailed description - what it does, what it leaves out, when to "
        "use it, and how long it takes on this PC",
        "Levels without AI never add AI steps (also not through 'What to fix' or a video's scan)",
        "Faster AI on newer NVIDIA cards: the big AI models (upscaling, AI deblur, AI noise clean-up) run in half "
        "precision - usually 1.5-2x faster. Each model is checked once against full precision. On by default where "
        "the card supports it (Enhance → Performance)",
        "Time estimates are learned separately for heavy-AI, light-AI and no-AI work",
        "Your current level was re-applied with its new settings (Balanced no longer runs AI upscaling)",
    ]),
    ("0.15.4", ["Fixed: text in Enhance's 'What to fix' box (and other settings) was cut off on the right - "
                "drop-down lists with long choices no longer make the settings column wider than it is, and the "
                "column always fits its widest setting"]),
    ("0.15.3", ["Enhance: unfinished 1-minute parts left by the 0.15.1 frame-rate bug are made again, never reused"]),
    ("0.15.2", ["Fixed: Enhance failed with 'length check failed' (result a fraction of the original length) when "
                "the frame rate was raised by blending (e.g. 15 → 60 fps) together with steps such as lighting per "
                "scene, the wobble fix or AI steps"]),
    ("0.15.1", [
        "Progress shows how far into the current video the step has got and the video's length "
        "(e.g. 'garden.mp4 (1:42 of 3:15)'), and the Tasks page shows the total length of all videos in the task",
        "The app learns how fast your PC really is: every finished task teaches it, so the time left is close "
        "from the start of the next task (tested: within 4% from the first estimate on a repeat run), and "
        "Enhance's 'work per minute' estimate and quality suggestion are corrected too",
    ]),
    ("0.15.0", [
        "Progress shows the step being worked on, e.g. 'Stabilising - measuring the camera shake', "
        "'Enhancing (AI upscaling to 1920x1080, restoring faces) - part 3 of 12', 'Cutting part 2 of 5', "
        "'Joining 6 clips losslessly' - in the bottom bar and as 'Now:' on the Tasks page",
        "More accurate time left: once a file is finished, the time left comes from how long the finished files "
        "really took (tested: within 2-3% for the rest of the task), and files are weighed by how much work they "
        "are (size, AI steps), not just their length - a 4K AI upscale no longer counts the same as a small clip",
        "Enhance: the progress bar no longer races through the quick passes (stabilise, scene scan) and then crawls",
        "Time left after resuming a paused-and-restarted task is no longer too long",
    ]),
    ("0.14.4", ["Duplicates: 'Count as the same from' now defaults to 98%"]),
    ("0.14.3", ["Bottom bar: one-click switch between '⚡ Full speed' and '🍃 Spare power' (same as Settings → "
                "Computer use; Full speed is the default)"]),
    ("0.14.2", [
        "Settings → Computer use: 'Full speed' or 'Spare power only' - the app and its tools (FFmpeg, AI) get "
        "the lowest processor and graphics-card priority, so whatever you do on the PC comes first",
        "Settings → Computer use: optionally pause tasks while you use the PC; they continue by themselves after "
        "it has been idle for a few minutes (default 5)",
        "Enhance: 'Suggest a faster quality from' sets how many hours of work (default 8) make the "
        "recommendation suggest a faster global quality level",
    ]),
    ("0.14.1", [
        "Global quality starts on Balanced (your choice is remembered)",
        "Longer tooltips: every control also says when to use it",
        "Enhance: the recommendation also suggests a global quality level when another would suit the "
        "videos better (e.g. a faster one for many hours of video) - it is never applied by itself",
        "Leaving 'Custom' asks whether to save your custom settings first",
    ]),
    ("0.14.0", [
        "New name and icon: Breezy Video (a cartoon cinema screen with a big B), shown at the top of the sidebar; "
        "the desktop shortcut is renamed to match",
        "Global quality at the top of the sidebar: Max Quality, High Quality, Balanced, High Performance, "
        "Max Performance - the same on every PC, with graphics-card speed-ups switched on wherever this PC "
        "supports them. It sets every module at once",
        "Changing a setting on any page switches the global quality to 'Custom'; your choices stay until you "
        "pick another global level. '⋯' saves the current settings under your own name (★) or deletes one",
        "Duplicates is now its own module, under Stitcher in the menu",
        "Enhance: 'What to fix' (General, Old film & VHS, Phone & action camera, Night & security camera, "
        "Upscale only) works on top of the global quality; videos are scanned when added and a recommendation "
        "for their content is shown - one click applies it",
        "Explanatory tooltips on every control (Settings → Look, on by default)",
        "Progress is shown in the bar at the bottom and in a new detailed panel on the Tasks page (overall and "
        "current file, times, speed, every file's state and the results); the extra bar on each page is gone",
        "Motion Trimmer sensitivity and Subject Tracker smoothness now default to 10; AI strength to 70%",
    ]),
    ("0.13.1", ["Enhance: 'Videos at once - Automatic' now uses 3 videos on graphics cards with 12 GB+ "
                "(2 with 8 GB+, else 1)"]),
    ("0.13.0", [
        "New module Organise: rename videos by date/time or camera and sort them into folders (preview "
        "first, undo afterwards), and find duplicate videos - identical copies and re-encoded/resized "
        "versions of the same footage; extra copies go to a 'Duplicates' folder or the Recycle Bin",
        "NVIDIA AI engine: on an NVIDIA card the CUDA engine (usually much faster than DirectML) is "
        "downloaded once (~1.8 GB), tested, and used from the next start. Settings → AI engine",
        "Enhance: several videos at once on the graphics card (Automatic: 2 with 8 GB+ graphics memory)",
        "Enhance: the best-quality noise filter runs on the graphics card (OpenCL) when the PC supports it",
        "Enhance: long videos are made in 1-minute parts - a stopped or crashed render continues where it was",
        "Faster previews: graphics-card decoding and already-decoded pictures are reused",
        "Drag & drop files or folders onto any page; right-click menus (play, show in folder, copy path, "
        "remove from list) and keys (Enter = play, Delete = remove, F5 = read again) in the file lists",
        "Notifications when tasks finish, and 'When all done: sleep / hibernate / shut down' on the Tasks page "
        "(60 s countdown you can cancel)",
    ]),
    ("0.12.0", [
        "Enhance is faster: every step runs in its own thread, so the processor prepares the next frames "
        "while the graphics card works on the current one (frames stay in order)",
        "Enhance logs the time each step takes per frame and which step sets the speed",
        "Enhance now comes before Subject Tracker in the menu",
    ]),
    ("0.11.1", [
        "Tasks can run side by side when they don't compete - e.g. Enhance on the graphics card while "
        "Motion Trimmer uses the processor; two graphics-card jobs still take turns. "
        "Settings → Tasks: one at a time / when they don't compete (default) / any (up to 2-6)",
        "The bottom bar and the Tasks page show every task that is running",
    ]),
    ("0.11.0", [
        "Files appear in the output folder only when they're complete (they're made in a hidden "
        "'.breezy-working' folder first), and each one as soon as it's done",
        "'Open output folder' can always be clicked, on every module (the newest file, or the output folder)",
        "Every module: 'Add files…' to pick one or more videos, and 'Clear' to empty the list",
        "Processor and graphics-card load (and graphics memory) shown in the bar at the bottom",
        "Stitcher: keeps different cameras apart - clips are never joined across cameras when the files "
        "name different cameras, or when still cameras show different backgrounds; interleaved or "
        "overlapping clips from two cameras become one recording per camera ('Keep different cameras "
        "apart', on)",
    ]),
    ("0.10.1", [
        "Enhance: quality is never lowered for a slower PC - fitting to your PC only sets the graphics card "
        "use and AI tile size",
        "Enhance: Night & security camera uses low-light AI only on dark videos",
        "Enhance: Phone & action camera no longer includes AI deblur (much faster; turn it on when needed)",
    ]),
    ("0.10.0", [
        "Your PC is scanned on first start (graphics card, memory, processor and a real AI speed test); "
        "see Settings → Your PC, with 'Scan my PC again'",
        "Enhance: shows how long the current settings take per minute of the selected video on your PC",
        "Enhance: presets use the best performance settings for your PC (graphics card, AI tile size) and a "
        "'Fit to my PC' button",
        "Enhance: new preset lineup - Maximum restoration, Old film & VHS, Phone & action camera, "
        "Night & security camera, Upscale only (AI)",
        "Enhance: the check suggests a preset for each video",
        "Enhance: AI strength defaults to 70% (100% can look painted)",
    ]),
    ("0.9.1", [
        "Enhance: the Maximum restoration preset now also uses per-scene lighting & colour, light sound "
        "repair, automatic picture-shape fix and AI deblur",
        "Enhance: rolling-shutter fix is now an on/off box with its own strength (Strong by default)",
    ]),
    ("0.9.0", [
        "Enhance: AI deblur (NAFNet) - removes blur from camera shake, movement or slightly missed focus",
        "Enhance: fix rolling-shutter wobble - straightens the lean and 'jelly' of phone and action-camera video",
        "Enhance: picture shape - fixes squashed/stretched video automatically (file info, or the shape of "
        "faces found by the check) or to a chosen shape, optionally keeping the frame size with black bars",
        "Enhance: fix lighting & colour per scene - finds the cuts and gives every scene its own exposure "
        "and white balance",
        "Enhance - sound: separate voices & music (MDX-Net AI) - keep only the voices, turn the music down, "
        "or keep only the music",
        "Enhance - sound: repair distorted (clipped) sound, remove wind noise",
        "The two new AI models download automatically the first time the app starts",
    ]),
    ("0.8.1", [
        "Enhance: subtitles use the Medium speech model by default (best accuracy; still selectable)",
        "Enhance: removing people/vehicles/animals now picks the fill automatically - the real background "
        "while the camera is still, AI fill while it moves",
        "Enhance: the Maximum restoration preset now uses AI denoise instead of the classic noise filter",
        "Enhance: AI denoise steadiness defaults to light (less smearing on fast motion)",
        "Enhance: the target file size always keeps your last value; built-in presets no longer change "
        "subtitle, before/after or file-size choices",
    ]),
    ("0.8.0", [
        "Enhance: save your own presets ('Save as my preset…', shown with ★ in the list) and delete them",
        "Enhance: 'Apply suggestions' sets the page to what the check found for the selected video; "
        "optionally every video gets its own suggestions automatically",
        "Enhance: aim for a file size (e.g. 25 MB) - the quality is worked out automatically",
        "Enhance: before/after video (side by side or split screen) next to the result",
        "Enhance: subtitles from speech (Whisper AI) - .srt file, switchable track and/or burned in; "
        "any language, optional translation into English",
        "Enhance: AI denoise (SCUNet) with motion-following steadiness - much cleaner than the classic filters",
        "Enhance: remove people, vehicles or animals from the video (AI fill, or the background from other "
        "frames for a camera that doesn't move)",
    ]),
    ("0.7.1", [
        "Enhance: hidden areas (stamps/logos) are remembered per video; 'Use on all videos' copies them",
        "Enhance: 'Longest freeze to fix' setting for stutter repair",
        "Enhance: the Maximum restoration preset now also fixes stutter (AI), removes flicker and uses "
        "low-light AI on dark videos",
    ]),
    ("0.7.0", [
        "Enhance - sound: AI sound rebuild (AP-BWE) turns phone-like 8 kHz sound into full 48 kHz sound; "
        "widen sound (mono becomes stereo)",
        "Enhance - hide stamps & logos: drag boxes on the preview; AI fill (LaMa), blur or black box",
        "Enhance - fix stutter: frozen/repeated frames are rebuilt as in-between frames (AI or blend)",
        "Enhance - privacy: blur or pixelate faces and licence plates",
        "Enhance - remove flicker, remove haze/fog, old film dust & specks",
        "Enhance - lens: straighten fisheye bend, fix colour fringes, brighten dark corners",
        "Enhance - low-light AI (Zero-DCE), optionally only for dark videos",
        "Enhance - looks (LUTs: 6 built in or your own .cube) and 'match colours to' another video",
        "Enhance - HDR: turn HDR phone video into normal video, or make HDR10",
        "Enhance - slow motion 2×/4×/8× with AI in-between frames; level the horizon",
        "The check now also spots HDR video and low-quality sound",
    ]),
    ("0.6.2", [
        "Self-repair: AI models are checked at every start and missing or damaged ones are downloaded again",
        "Self-repair: if FFmpeg lacks a filter the modules need (or isn't found), a complete FFmpeg is "
        "downloaded into the app's bin folder",
        "Downloads run as a normal task with progress; on/off and 'Check & repair now' in Settings → Repair",
    ]),
    ("0.6.1", ["Enhance: face restoration is now off by default (also in the Maximum restoration preset)"]),
    ("0.6.0", [
        "Enhance: restore faces (GFPGAN AI) with strength and minimum face size",
        "Enhance: colourise black & white video (DDColor AI) - automatically only for B&W videos, or always",
        "Enhance: AI frame interpolation (RIFE) for smoother 30/60 fps and double frame rate - now the default method",
        "Enhance: AI voice clean-up (RNNoise) - standard, noisy places or strong",
        "Enhance: the preview updates quickly without AI; 'Preview with AI' shows the full result",
        "Enhance: AI upscaling is skipped automatically for videos already 4K (option); "
        "choice of AI or no AI at 'same size'; presets can optionally change encoding & hardware too",
        "Enhance: starts from the Maximum restoration preset; the check spots black & white videos",
    ]),
    ("0.5.0", [
        "New module: Enhance - improve and restore videos",
        "Upscale 2×/3×/4× or to 720p-4K with AI (Real-ESRGAN fast or best) or classic Lanczos; AI strength mix",
        "Clean-up: deinterlace, crop black borders, stabilise, remove noise and compression blocks, smooth banding",
        "Light & colour: auto exposure, auto white balance, shadows/highlights, brightness, contrast, midtones, "
        "saturation, vibrance",
        "Sharpen, film grain, smoother motion (30/60 fps or double, interpolated)",
        "Sound: noise reduction, hum removal, even loudness, drift fix",
        "'Check videos' finds interlacing, black borders, dark or noisy footage and suggests fixes",
        "Before/after preview of any moment with a draggable divider and zoom, plus an AI time estimate",
        "Presets: restore, fix dark footage, upscale only, light touch, maximum restoration",
    ]),
    ("0.4.1", [
        "Subject Tracker: Play button in the preview plays the reframed result",
        "Subject Tracker: new options - camera timing (anticipate / react after they move), "
        "what to do with videos that have nobody in them (skip / copy unchanged), videos analyzed at once",
        "Subject Tracker: 'Only the parts with subjects' is now on by default (combined with the reframing)",
        "Motion Trimmer: now checks 10 frames per second and analyzes 4 videos at once by default",
    ]),
    ("0.4.0", [
        "New module: Subject Tracker - finds people (or cars, dogs, bikes...) with an AI model and can "
        "smoothly zoom/pan to keep them framed, cut to just the parts they appear in, and list when they appear",
        "Tasks: every job runs in a shared queue with progress, time left, finish time, elapsed time, "
        "speed and current file; a Tasks page shows them all and a bar at the bottom shows the current one",
        "Pause and resume any task instantly; unfinished tasks can be resumed after closing the app",
        "Closing while tasks run asks: finish first, pause & save, or quit",
        "'Use output from…' on every page: pick files any module made - or the future output of a queued task",
        "Everything saves into one 'Breezy Output' folder by default (older save options still available)",
        "More settings on every page: quality, audio bitrate, thresholds, GPU/CPU, threads, file naming",
        "GPU video encoding (AMD / NVIDIA / Intel) when available",
        "Motion Trimmer: finding motion again in the same videos is instant (results are remembered); "
        "new settings for the busy-area filter, analysis rate and cut encoders",
        "New look: light/dark theme that follows Windows, icons, collapsible sidebar",
        "Version number in the window title, and this 'What's new' list",
        "After an update, any new components install automatically the first time the app starts",
    ]),
    ("0.3.0", [
        "Audio drift fix in Stitcher and Motion Trimmer (sound sped up/slowed to match the picture)",
        "Exact sound cuts option in the Motion Trimmer",
    ]),
    ("0.2.1", [
        "Motion Trimmer: merge-pause and minimum-motion settings, thumbnail strips, preview player, Open in VLC",
    ]),
    ("0.2.0", [
        "New module: Motion Trimmer with smart (near-lossless) cuts",
        "Stitcher: scene check, start times in file names, confidence scoring",
    ]),
    ("0.1.0", ["First version: Stitcher"]),
]


def since(version: str | None) -> list[tuple[str, list[str]]]:
    """Changes newer than `version` (all if None)."""
    if not version:
        return CHANGES[:1]
    out = []
    for v, items in CHANGES:
        if v == version:
            break
        out.append((v, items))
    return out
