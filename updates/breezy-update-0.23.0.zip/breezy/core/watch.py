"""Watch folders: new videos that appear in a folder are run through a pipeline automatically.

Folders are looked at every 15 seconds. A video counts as arrived once its size and date haven't changed
between two looks (so files still being copied are left alone). Files Breezy made itself are never picked up
again. Which files were handled is remembered (watch_seen.json), so a restart doesn't run them twice.

Also: start Breezy with Windows (in the tray), via the current user's Run key.
"""
from __future__ import annotations

import json
import sys
import time
from pathlib import Path

from PySide6.QtCore import QObject, QTimer, Signal

from breezy.core.settings import app_data_dir

SCAN_MS = 15000
RUN_KEY = r"Software\Microsoft\Windows\CurrentVersion\Run"
RUN_NAME = "BreezyVideo"


def _video_exts():
    from breezy.features.stitcher.detector import VIDEO_EXTS
    return VIDEO_EXTS


class WatchService(QObject):
    """settings app/watch_folders = [{"folder", "subfolders", "pipeline", "on"}]"""
    started = Signal(str, int, str)          # folder, number of videos, pipeline
    changed = Signal()

    def __init__(self, settings, manager, runner, history=None, parent=None):
        super().__init__(parent)
        self.settings, self.tm, self.runner, self.history = settings, manager, runner, history
        self.paused = False
        self._pending: dict[str, tuple] = {}      # path -> (size, mtime) at the last look
        self.seen_file = app_data_dir() / "watch_seen.json"
        try:
            self.seen: dict = json.loads(self.seen_file.read_text("utf-8"))
        except (OSError, ValueError):
            self.seen = {}
        self.timer = QTimer(self, interval=SCAN_MS)
        self.timer.timeout.connect(self.scan)
        self.refresh()

    # ------------------------------------------------------------------ config
    def watches(self) -> list[dict]:
        return list(self.settings.get("app", "watch_folders") or [])

    def active(self) -> list[dict]:
        return [w for w in self.watches() if w.get("on", True) and w.get("folder")]

    def save_watches(self, ws: list[dict]):
        self.settings.set("app", "watch_folders", ws)
        self.refresh()

    def add(self, folder: str, pipeline: str, subfolders: bool = False, existing: bool = False):
        ws = [w for w in self.watches() if w.get("folder") != folder]
        ws.append({"folder": folder, "pipeline": pipeline, "subfolders": subfolders, "on": True})
        if not existing:                                    # only videos that arrive from now on
            for p in self._videos(Path(folder), subfolders):
                self._mark(folder, p)
            self._save_seen()
        self.save_watches(ws)

    def refresh(self):
        if self.active() and not self.paused:
            if not self.timer.isActive():
                self.timer.start()
        else:
            self.timer.stop()
        self.changed.emit()

    def set_paused(self, on: bool):
        self.paused = on
        self.refresh()

    # ------------------------------------------------------------------ scanning
    def _videos(self, folder: Path, sub: bool) -> list[Path]:
        if not folder.is_dir():
            return []
        exts = _video_exts()
        it = folder.rglob("*") if sub else folder.glob("*")
        out = []
        for p in it:
            try:
                if p.is_file() and p.suffix.lower() in exts and \
                        not any(part.startswith(".breezy") for part in p.relative_to(folder).parts):
                    out.append(p)
            except OSError:
                pass
        return out

    def _key(self, p: Path) -> tuple:
        st = p.stat()
        return st.st_size, int(st.st_mtime)

    def _mark(self, folder: str, p: Path):
        try:
            self.seen.setdefault(folder, {})[str(p)] = list(self._key(p))
        except OSError:
            pass

    def _save_seen(self):
        try:
            self.seen_file.write_text(json.dumps(self.seen), "utf-8")
        except OSError:
            pass

    def _made_by_us(self) -> set[str]:
        out = set()
        for t in getattr(self.tm, "tasks", []):
            out.update(str(Path(o)).lower() for o in t.outputs)
        for r in getattr(self.history, "runs", []) or []:
            out.update(str(Path(o)).lower() for o in r.get("outputs", []))
        return out

    def scan(self):
        if self.paused:
            return
        pipes = self.settings.get("app", "pipelines") or {}
        ours = None
        for w in self.active():
            folder, pipe_name = w["folder"], w.get("pipeline", "")
            pipe = pipes.get(pipe_name)
            if not pipe or not pipe.get("steps"):
                continue
            seen = self.seen.setdefault(folder, {})
            ready = []
            for p in self._videos(Path(folder), bool(w.get("subfolders"))):
                sp = str(p)
                try:
                    key = self._key(p)
                except OSError:
                    continue
                if seen.get(sp) == list(key):
                    continue
                if ours is None:
                    ours = self._made_by_us()
                if sp.lower() in ours:
                    seen[sp] = list(key)
                    continue
                if self._pending.get(sp) == key and time.time() - key[1] >= 10:
                    ready.append(sp)                   # unchanged since the last look: fully arrived
                    seen[sp] = list(key)
                    self._pending.pop(sp, None)
                else:
                    self._pending[sp] = key
            if ready:
                self._save_seen()
                out = self._final_out()
                if out is None:
                    continue
                self.runner.run(pipe_name, pipe, files=sorted(ready), final_out=out,
                                label=f"(watch: {Path(folder).name})")
                self.started.emit(folder, len(ready), pipe_name)

    def _final_out(self):
        from breezy.core.outputs import output_spec
        g = lambda k, d: self.settings.get("pipelines", k, d)       # noqa: E731
        values = {"mode": g("out_mode2", "root"), "folder": g("out_folder", "Pipeline results"),
                  "custom": g("out_custom", "")}
        if values["mode"] == "root" and not self.settings.get("app", "output_root"):
            return None
        return output_spec(self.settings, "pipelines", "Pipeline results", None, values)


# ------------------------------------------------------------------ start with Windows
def launch_command() -> str:
    exe = Path(sys.executable)
    if exe.name.lower() == "python.exe" and (exe.parent / "pythonw.exe").is_file():
        exe = exe.parent / "pythonw.exe"
    if getattr(sys, "frozen", False):                       # a built .exe
        return f'"{exe}" --tray'
    main = Path(__file__).resolve().parents[2] / "main.py"
    return f'"{exe}" "{main}" --tray'


def autostart_enabled() -> bool:
    if sys.platform != "win32":
        return False
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY) as k:
            winreg.QueryValueEx(k, RUN_NAME)
            return True
    except OSError:
        return False


def set_autostart(on: bool) -> bool:
    if sys.platform != "win32":
        return False
    import winreg
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, RUN_KEY, 0, winreg.KEY_SET_VALUE) as k:
            if on:
                winreg.SetValueEx(k, RUN_NAME, 0, winreg.REG_SZ, launch_command())
            else:
                try:
                    winreg.DeleteValue(k, RUN_NAME)
                except OSError:
                    pass
        return True
    except OSError:
        return False
