"""Which engine runs the AI models: NVIDIA CUDA (fastest on NVIDIA cards) or DirectML (any graphics card).

The normal install has ONNX Runtime with DirectML. On a PC with a suitable NVIDIA card, the CUDA build of
ONNX Runtime plus NVIDIA's CUDA/cuDNN libraries (~1.8 GB) are downloaded once into their own folder
(.venv/ai-cuda) by the task "app.cuda", and a self-test checks that they work. From the next start,
activate() puts that folder first on the import path, so `import onnxruntime` gets the CUDA build.
(The two builds can't be loaded in one process, which is why the switch happens at start-up.)

The same NVIDIA libraries also let the speech AI (subtitles) run on the graphics card.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
PACKAGES = ["onnxruntime-gpu==1.26.0", "nvidia-cuda-runtime-cu12==12.9.79", "nvidia-cublas-cu12==12.9.1.4",
            "nvidia-cudnn-cu12==9.27.0.42", "nvidia-cufft-cu12==11.4.1.4", "nvidia-curand-cu12==10.3.10.19",
            "nvidia-cuda-nvrtc-cu12==12.9.86"]
MIN_DRIVER = 528.0          # CUDA 12 on Windows
DOWNLOAD_GB = 1.8
ENGINES = [("Automatic (NVIDIA TensorRT / CUDA when the card supports it)", "auto"),
           ("NVIDIA TensorRT (fastest)", "tensorrt"), ("NVIDIA CUDA", "cuda"),
           ("DirectML (any graphics card)", "directml")]

# TensorRT: compiles each big AI model for this exact graphics card (2-3x faster than plain CUDA). The
# libraries come from NVIDIA's package index and go into the same folder as the CUDA engine.
TRT_PACKAGES = ["tensorrt-cu12-libs==10.13.3.9"]
TRT_INDEX = "https://pypi.nvidia.com"
TRT_GB = 1.2
TRT_MIN_CC = 7.5            # TensorRT 10 supports RTX 20xx / GTX 16xx and newer

active = "directml"         # what this process uses (set by activate())
trt_active = False          # TensorRT used for the big models in this process


def app_root() -> Path:
    return Path(__file__).resolve().parents[2]


def engine_dir() -> Path:
    venv = Path(sys.prefix)
    base = venv if (venv / "pyvenv.cfg").is_file() else app_root()
    return base / "ai-cuda"


def _stamp() -> str:
    return hashlib.sha1("|".join(PACKAGES).encode()).hexdigest()[:12]


def installed() -> bool:
    d = engine_dir()
    try:
        return (d / "onnxruntime").is_dir() and (d / "installed.txt").read_text("utf-8").strip() == _stamp()
    except OSError:
        return False


def selftest_result() -> dict:
    try:
        return json.loads((engine_dir() / "selftest.json").read_text("utf-8"))
    except (OSError, ValueError):
        return {}


def nvidia() -> dict:
    """{"ok": bool, "name", "driver", "why"} - is there an NVIDIA card the CUDA engine supports?"""
    exe = shutil.which("nvidia-smi")
    if not exe:
        return {"ok": False, "why": "no NVIDIA graphics card (or driver) found"}
    try:
        r = subprocess.run([exe, "--query-gpu=name,driver_version,compute_cap", "--format=csv,noheader"],
                           capture_output=True, text=True, timeout=10, creationflags=NO_WINDOW)
        name, driver, cap = [x.strip() for x in r.stdout.strip().splitlines()[0].split(",")][:3]
    except Exception as e:  # noqa
        return {"ok": False, "why": f"nvidia-smi failed ({e})"}
    try:
        drv = float(".".join(driver.split(".")[:2]))
    except ValueError:
        drv = 0.0
    try:
        cc = float(cap)
    except ValueError:
        cc = 5.0
    if drv and drv < MIN_DRIVER:
        return {"ok": False, "name": name, "driver": driver,
                "why": f"the graphics driver is too old ({driver}; {MIN_DRIVER:g} or newer is needed)"}
    if cc < 5.0:
        return {"ok": False, "name": name, "driver": driver, "why": f"{name} is too old for CUDA 12"}
    return {"ok": True, "name": name, "driver": driver, "why": ""}


def dll_dirs() -> list[Path]:
    root = engine_dir() / "nvidia"
    out = sorted(p for p in root.glob("*/bin") if p.is_dir()) if root.is_dir() else []
    trt = engine_dir() / "tensorrt_libs"
    if trt.is_dir():
        out.append(trt)
    return out


def _trt_stamp() -> str:
    return hashlib.sha1("|".join(TRT_PACKAGES).encode()).hexdigest()[:12]


def trt_installed() -> bool:
    d = engine_dir()
    try:
        return (d / "tensorrt_libs").is_dir() and (d / "trt_installed.txt").read_text("utf-8").strip() == _trt_stamp()
    except OSError:
        return False


def trt_selftest_result() -> dict:
    try:
        return json.loads((engine_dir() / "trt_selftest.json").read_text("utf-8"))
    except (OSError, ValueError):
        return {}


def trt_cache_dir() -> Path:
    """Prepared TensorRT models. 'v2': engines from 0.17.0-0.17.3 were used without being checked (one gave
    a broken picture) - they are deleted and made again."""
    from breezy.core.settings import app_data_dir
    root = app_data_dir() / "trt_cache"
    d = root / "v2"
    if not d.is_dir():
        d.mkdir(parents=True, exist_ok=True)
        for f in root.iterdir():
            if f.is_file():
                try:
                    f.unlink()
                except OSError:
                    pass
    return d


def _compute_cap() -> float:
    exe = shutil.which("nvidia-smi")
    if not exe:
        return 0.0
    try:
        r = subprocess.run([exe, "--query-gpu=compute_cap", "--format=csv,noheader"], capture_output=True, text=True,
                           timeout=10, creationflags=NO_WINDOW)
        return float(r.stdout.strip().splitlines()[0])
    except Exception:
        return 0.0


def _add_dll_dirs():
    dirs = dll_dirs()
    if not dirs:
        return
    os.environ["PATH"] = os.pathsep.join(str(d) for d in dirs) + os.pathsep + os.environ.get("PATH", "")
    if hasattr(os, "add_dll_directory"):
        for d in dirs:
            try:
                os.add_dll_directory(str(d))
            except OSError:
                pass


def wanted(settings) -> str:
    return (settings.get("app", "ai_engine", "auto") if settings is not None else "auto") or "auto"


def activate(settings) -> str:
    """Call before anything imports onnxruntime. Returns the engine this run uses."""
    global active
    if "onnxruntime" in sys.modules:
        return active
    if installed():
        _add_dll_dirs()                      # also lets the speech AI find cuBLAS / cuDNN
    choice = wanted(settings)
    global trt_active
    ok = installed() and selftest_result().get("ok") and choice in ("auto", "cuda", "tensorrt")
    if ok:
        sys.path.insert(0, str(engine_dir()))
        active = "cuda"
        trt_active = choice in ("auto", "tensorrt") and trt_installed() and bool(trt_selftest_result().get("ok"))
    else:
        active = "directml"
        trt_active = False
    return active


def should_install(settings) -> bool:
    if sys.platform != "win32" or installed():
        return False
    return wanted(settings) in ("auto", "cuda", "tensorrt") and nvidia()["ok"]


def should_install_trt(settings) -> bool:
    """CUDA engine working + a card TensorRT supports + not installed yet."""
    if sys.platform != "win32" or trt_installed() or not (installed() and selftest_result().get("ok")):
        return False
    return wanted(settings) in ("auto", "tensorrt") and _compute_cap() >= TRT_MIN_CC


_SELFTEST = r"""
import json, os, sys
d = sys.argv[1]
sys.path.insert(0, d)
for b in sorted(os.path.join(d, 'nvidia', x, 'bin') for x in os.listdir(os.path.join(d, 'nvidia'))):
    if os.path.isdir(b):
        os.environ['PATH'] = b + os.pathsep + os.environ['PATH']
        try:
            os.add_dll_directory(b)
        except Exception:
            pass
out = {'ok': False}
try:
    import numpy as np, onnxruntime as ort
    out['version'] = ort.__version__
    out['providers'] = ort.get_available_providers()
    s = ort.InferenceSession(sys.argv[2], providers=[('CUDAExecutionProvider', {'device_id': 0}), 'CPUExecutionProvider'])
    out['used'] = s.get_providers()[0]
    i = s.get_inputs()[0]
    shape = [x if isinstance(x, int) else 64 for x in i.shape]
    s.run(None, {i.name: np.zeros(shape, np.float32)})
    out['ok'] = out['used'] == 'CUDAExecutionProvider'
    if not out['ok']:
        out['error'] = 'CUDA could not be started (the processor would have been used)'
except Exception as e:
    out['error'] = str(e).splitlines()[0] if str(e) else type(e).__name__
print(json.dumps(out))
"""


def selftest(model: Path) -> dict:
    """Load the CUDA engine in a separate Python and run a small model on the graphics card."""
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe":
        exe = exe.with_name("python.exe")
    try:
        r = subprocess.run([str(exe), "-c", _SELFTEST, str(engine_dir()), str(model)], capture_output=True,
                           text=True, timeout=300, creationflags=NO_WINDOW)
        res = json.loads((r.stdout or "").strip().splitlines()[-1])
    except Exception as e:  # noqa
        res = {"ok": False, "error": str(e)}
    res["driver"] = nvidia().get("driver", "")
    try:
        (engine_dir() / "selftest.json").write_text(json.dumps(res), "utf-8")
    except OSError:
        pass
    return res


_TRT_SELFTEST = r"""
import json, os, sys, tempfile
d = sys.argv[1]
sys.path.insert(0, d)
dirs = [os.path.join(d, 'nvidia', x, 'bin') for x in os.listdir(os.path.join(d, 'nvidia'))] + [os.path.join(d, 'tensorrt_libs')]
for b in dirs:
    if os.path.isdir(b):
        os.environ['PATH'] = b + os.pathsep + os.environ['PATH']
        try:
            os.add_dll_directory(b)
        except Exception:
            pass
out = {'ok': False}
try:
    import numpy as np, onnxruntime as ort
    out['version'] = ort.__version__
    out['providers'] = ort.get_available_providers()
    s0 = ort.InferenceSession(sys.argv[2], providers=['CPUExecutionProvider'])
    i = s0.get_inputs()[0]
    shape = f'{i.name}:1x3x64x64'
    opts = {'device_id': 0, 'trt_fp16_enable': True, 'trt_engine_cache_enable': True,
            'trt_engine_cache_path': tempfile.mkdtemp(), 'trt_profile_min_shapes': shape,
            'trt_profile_max_shapes': shape, 'trt_profile_opt_shapes': shape}
    s = ort.InferenceSession(sys.argv[2], providers=[('TensorrtExecutionProvider', opts), 'CUDAExecutionProvider',
                                                      'CPUExecutionProvider'])
    out['used'] = s.get_providers()[0]
    x = np.random.default_rng(1).random((1, 3, 64, 64), dtype=np.float32)
    y = s.run(None, {i.name: x})[0]
    y0 = s0.run(None, {i.name: x})[0]
    err = float(np.mean(np.abs(y - y0)))
    out['error_vs_cpu'] = err
    out['ok'] = out['used'] == 'TensorrtExecutionProvider' and bool(np.all(np.isfinite(y))) and err < 0.02
    if not out['ok']:
        out['error'] = 'TensorRT could not be started' if out['used'] != 'TensorrtExecutionProvider' else 'results differ'
except Exception as e:
    out['error'] = str(e).splitlines()[0] if str(e) else type(e).__name__
print(json.dumps(out))
"""


def selftest_trt(model: Path) -> dict:
    """Build a TensorRT engine for a small model in a separate Python and compare it with the processor."""
    exe = Path(sys.executable)
    if exe.name.lower() == "pythonw.exe":
        exe = exe.with_name("python.exe")
    try:
        r = subprocess.run([str(exe), "-c", _TRT_SELFTEST, str(engine_dir()), str(model)], capture_output=True,
                           text=True, timeout=900, creationflags=NO_WINDOW)
        res = json.loads((r.stdout or "").strip().splitlines()[-1])
    except Exception as e:  # noqa
        res = {"ok": False, "error": str(e)}
    try:
        (engine_dir() / "trt_selftest.json").write_text(json.dumps(res), "utf-8")
    except OSError:
        pass
    return res


def status_text(settings) -> str:
    nv = nvidia() if sys.platform == "win32" else {"ok": False, "why": "only on Windows"}
    st = selftest_result()
    if active == "cuda":
        if trt_active:
            return (f"✔ Using NVIDIA TensorRT for the big AI models on {nv.get('name', 'the graphics card')} "
                    "(each model is prepared for this card once - the first use takes a few minutes).")
        text = f"✔ Using NVIDIA CUDA on {nv.get('name', 'the graphics card')} (ONNX Runtime {st.get('version', '')})."
        ts = trt_selftest_result()
        if trt_installed() and ts.get("ok") and wanted(settings) in ("auto", "tensorrt"):
            text += " TensorRT is installed and tested - restart the app to use it."
        elif trt_installed() and ts and not ts.get("ok"):
            text += f" TensorRT didn't pass its test ({ts.get('error', '?')}), so CUDA is used."
        elif not trt_installed() and _compute_cap() >= TRT_MIN_CC:
            text += f" TensorRT (2-3x faster AI, {TRT_GB:g} GB) can be added: 'Install NVIDIA TensorRT'."
        return text
    if not nv["ok"]:
        return f"Using DirectML. NVIDIA CUDA isn't available here: {nv['why']}."
    if not installed():
        return (f"Using DirectML. NVIDIA CUDA can run on {nv['name']} - its components ({DOWNLOAD_GB:g} GB) "
                "are downloaded automatically, or press 'Install NVIDIA engine'.")
    if not st.get("ok"):
        return f"Using DirectML. The NVIDIA engine is installed but its self-test failed: {st.get('error', '?')}"
    if wanted(settings) == "directml":
        return "Using DirectML (chosen). The NVIDIA engine is installed and ready."
    return "The NVIDIA engine is installed and tested - restart the app to use it."


# --------------------------------------------------------------- task runner
def run_install(task, ctx):
    from breezy.core.ffmpeg import Cancelled
    from breezy.features.tracker.detector import models_dir
    ctx.set_items(["download", "test"], [10, 1], ["Downloading the NVIDIA AI engine", "Testing it"])
    for _i, step in ctx.items():
        if step == "download":
            d = engine_dir()
            d.mkdir(parents=True, exist_ok=True)
            exe = Path(sys.executable)
            if exe.name.lower() == "pythonw.exe":
                exe = exe.with_name("python.exe")
            cmd = [str(exe), "-m", "pip", "install", "--disable-pip-version-check", "--no-deps", "--upgrade",
                   "--only-binary", ":all:", "--target", str(d), *PACKAGES]
            ctx.log(f"Downloading about {DOWNLOAD_GB:g} GB (one time only)…")
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                 creationflags=NO_WINDOW)
            seen = 0
            try:
                for line in p.stdout:
                    line = line.rstrip()
                    if line.startswith(("Collecting", "Downloading", "Installing", "Successfully")):
                        ctx.log(line)
                    if line.startswith("Collecting"):
                        seen += 1
                        ctx.item_progress(min(0.95, seen / (len(PACKAGES) + 1)), line[11:60])
                    ctx.checkpoint()
            except Cancelled:
                p.kill()
                raise
            if p.wait() != 0:
                raise RuntimeError("the download didn't finish (check the internet connection)")
            (d / "installed.txt").write_text(_stamp(), "utf-8")
        else:
            res = selftest(models_dir() / "face_detection_yunet_2023mar.onnx")
            if res.get("ok"):
                ctx.log("✔ The NVIDIA engine works. It is used from the next start of the app.")
            else:
                ctx.error("The NVIDIA engine didn't pass its test: " + res.get("error", "?") +
                          " - the app keeps using DirectML.")


def run_install_trt(task, ctx):
    from breezy.core.ffmpeg import Cancelled
    from breezy.features.tracker.detector import models_dir
    ctx.set_items(["download", "test"], [10, 3], ["Downloading NVIDIA TensorRT", "Testing it (a few minutes)"])
    for _i, step in ctx.items():
        if step == "download":
            d = engine_dir()
            exe = Path(sys.executable)
            if exe.name.lower() == "pythonw.exe":
                exe = exe.with_name("python.exe")
            cmd = [str(exe), "-m", "pip", "install", "--disable-pip-version-check", "--no-deps", "--upgrade",
                   "--only-binary", ":all:", "--extra-index-url", TRT_INDEX, "--target", str(d), *TRT_PACKAGES]
            ctx.log(f"Downloading about {TRT_GB:g} GB (one time only)…")
            p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                 creationflags=NO_WINDOW)
            try:
                for line in p.stdout:
                    line = line.rstrip()
                    if line.startswith(("Collecting", "Downloading", "Installing", "Successfully", "ERROR")):
                        ctx.log(line)
                    ctx.checkpoint()
            except Cancelled:
                p.kill()
                raise
            if p.wait() != 0:
                raise RuntimeError("the download didn't finish (check the internet connection)")
            (d / "trt_installed.txt").write_text(_trt_stamp(), "utf-8")
        else:
            ctx.stage("Preparing a test model for the graphics card")
            res = selftest_trt(models_dir() / "esrgan_general_x4v3.onnx")
            if res.get("ok"):
                ctx.log("✔ TensorRT works. It is used for the big AI models from the next start of the app.")
            else:
                ctx.error("TensorRT didn't pass its test: " + res.get("error", "?") + " - the app keeps using CUDA.")


def register():
    from breezy.core.tasks import register_runner
    register_runner("app.cuda", run_install)
    register_runner("app.trt", run_install_trt)
