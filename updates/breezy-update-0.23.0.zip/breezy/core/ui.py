"""Shared UI building blocks for module pages."""
from __future__ import annotations

import os
import subprocess
import sys
import time
from pathlib import Path
from typing import Optional

from PySide6.QtCore import QEvent, Qt, Signal
from PySide6.QtWidgets import (QCheckBox, QComboBox, QDialog, QDialogButtonBox, QDoubleSpinBox,
                               QFileDialog, QFormLayout, QFrame, QHBoxLayout, QLabel, QLineEdit,
                               QMessageBox, QProgressBar, QPushButton, QScrollArea, QSizePolicy, QSpinBox,
                               QToolButton, QTreeWidget, QTreeWidgetItem, QVBoxLayout, QWidget)

from breezy.core import theme
from breezy.core.icons import icon
from breezy.core.outputs import MODES
from breezy.core.tasks import NOT_MEDIA, ACTIVE, PAUSED, RUNNING, Task, TaskManager, describe

MODULE_NAMES = {"app": "Breezy", "stitcher": "Stitcher", "motion": "Motion Trimmer", "tracker": "Subject Tracker", "enhance": "Enhance", "organise": "Organise", "duplicates": "Duplicates"}


def open_in_explorer(path: Path):
    path = Path(path)
    if sys.platform == "win32":
        if path.is_file():
            subprocess.Popen(["explorer", "/select,", str(path)])
        else:
            os.startfile(str(path))  # noqa
    else:
        subprocess.Popen(["xdg-open", str(path if path.is_dir() else path.parent)])


# ------------------------------------------------------------------ controls
def spin(lo, hi, val, suffix="", decimals=None, step=None, tip="") -> QWidget:
    w = QDoubleSpinBox() if decimals else QSpinBox()
    if decimals:
        w.setDecimals(decimals)
    w.setRange(lo, hi)
    w.setValue(val)
    if suffix:
        w.setSuffix(suffix)
    if step:
        w.setSingleStep(step)
    if tip:
        w.setToolTip(tip)
    w.setMinimumWidth(90)
    return w


def combo(items: list[tuple[str, object]], current=None, tip="") -> QComboBox:
    c = QComboBox()
    for text, data in items:
        c.addItem(text, data)
    if current is not None:
        i = c.findData(current)
        c.setCurrentIndex(max(0, i))
    if tip:
        c.setToolTip(tip)
    return c


def check(text, on=True, tip="") -> QCheckBox:
    c = QCheckBox(text)
    c.setChecked(bool(on))
    if tip:
        c.setToolTip(tip)
    return c


class Card(QFrame):
    """A rounded panel with an optional title and a form layout for settings."""

    def __init__(self, title: str = "", tip: str = ""):
        super().__init__()
        self.setObjectName("card")
        self.v = QVBoxLayout(self)
        self.v.setContentsMargins(14, 12, 14, 12)
        self.v.setSpacing(8)
        if title:
            t = QLabel(title, objectName="cardTitle")
            if tip:
                t.setToolTip(tip)
            self.v.addWidget(t)
        self.form = QFormLayout()
        self.form.setLabelAlignment(Qt.AlignLeft)
        self.form.setHorizontalSpacing(12)
        self.form.setVerticalSpacing(7)
        self.form.setFieldGrowthPolicy(QFormLayout.ExpandingFieldsGrow)
        self.v.addLayout(self.form)

    def row(self, label: str, widget, tip: str = ""):
        lab = QLabel(label)
        if tip:
            lab.setToolTip(tip)
            if isinstance(widget, QWidget) and not widget.toolTip():
                widget.setToolTip(tip)
        if isinstance(widget, QWidget):
            self.form.addRow(lab, widget)
        else:
            self.form.addRow(lab, widget)
        return widget

    def full(self, widget):
        self.form.addRow(widget)
        return widget

    def note(self, text: str):
        lab = QLabel(text)
        lab.setWordWrap(True)
        lab.setProperty("muted", True)
        self.form.addRow(lab)
        return lab


class SettingsColumn(QScrollArea):
    """Scrollable column of setting cards (all settings visible - user's choice)."""

    def __init__(self, width=380):
        super().__init__()
        self.setWidgetResizable(True)
        self.setFrameShape(QFrame.NoFrame)
        self._base_width = width
        self.setMinimumWidth(width)
        self.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        inner = QWidget()
        inner.setObjectName("content")
        self.v = QVBoxLayout(inner)
        self.v.setContentsMargins(0, 0, 6, 0)
        self.v.setSpacing(10)
        self.v.addStretch()
        self.setWidget(inner)
        inner.installEventFilter(self)

    def add(self, card: QWidget):
        self.v.insertWidget(self.v.count() - 1, card)
        return card

    def eventFilter(self, obj, ev):  # noqa: N802
        # never cut the cards off on the right: the column is at least as wide as its widest card
        if obj is self.widget() and ev.type() in (QEvent.LayoutRequest, QEvent.Show):
            for c in obj.findChildren(QComboBox):
                if not c.property("breezyCompact"):
                    c.setProperty("breezyCompact", True)
                    compact_combo(c)
            need = obj.minimumSizeHint().width() + self.verticalScrollBar().sizeHint().width() + 2
            self.setMinimumWidth(max(self._base_width, need))
        return super().eventFilter(obj, ev)


def compact_combo(c: QComboBox, chars: int = 16, wide: int = 260):
    """A drop-down list with long choices no longer makes its column wider than the window allows: it takes
    the room there is (and shortens the shown text if it must); the open list still shows the whole text."""
    if c.sizeHint().width() <= wide:
        return
    c.setSizeAdjustPolicy(QComboBox.AdjustToMinimumContentsLengthWithIcon)
    c.setMinimumContentsLength(chars)
    c.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
    try:
        c.view().setMinimumWidth(c.view().sizeHintForColumn(0) + 30)
    except Exception:
        pass


# -------------------------------------------------------------- output card
class OutputCard(Card):
    """Where to save + file naming (Breezy Output folder by default)."""
    changed = Signal()

    def __init__(self, feature, default_folder: str, patterns: list[tuple[str, str, str]]):
        """patterns: [(settings key, label, default pattern)]"""
        super().__init__("Output", "Where the new files go and how they're named")
        self.feature, self.default_folder = feature, default_folder
        st = feature.setting
        self.mode = self.row("Save to:", combo([(t, k) for k, t in MODES], st("out_mode2", "root")))
        self.folder = self.row("Folder name:", QLineEdit(st("out_folder", default_folder)),
                               "Subfolder name inside Breezy Output (or next to each video)")
        cust = QWidget()
        h = QHBoxLayout(cust)
        h.setContentsMargins(0, 0, 0, 0)
        self.custom = QLineEdit(st("out_custom", ""))
        self.custom.setPlaceholderText("Pick a folder…")
        b = QPushButton("Browse…")
        b.clicked.connect(self._browse)
        h.addWidget(self.custom, 1)
        h.addWidget(b)
        self.custom_row = self.row("Custom folder:", cust)
        self.patterns = {}
        for key, label, default in patterns:
            e = QLineEdit(st(key, default))
            e.setToolTip("{name} = the original file name (without extension)")
            self.patterns[key] = (self.row(label, e), default)
        self.root_label = self.note("")
        for w in (self.mode,):
            w.currentIndexChanged.connect(self._update)
        for w in [self.folder, self.custom] + [e for e, _ in self.patterns.values()]:
            w.textChanged.connect(self._save)
        self._update()

    def _browse(self):
        d = QFileDialog.getExistingDirectory(self, "Output folder", self.custom.text())
        if d:
            self.custom.setText(d)

    def _update(self):
        m = self.mode.currentData()
        self.custom.parentWidget().setEnabled(m == "custom")
        self.folder.setEnabled(m in ("root", "subfolder"))
        root = self.feature.context.settings.get("app", "output_root", "")
        self.root_label.setText({"root": f"Breezy Output: {root or 'you will be asked the first time'}",
                                 "subfolder": "Saved in a subfolder beside each source video",
                                 "same": "Saved beside each source video",
                                 "custom": "Saved in the folder above"}[m])
        self._save()

    def _save(self):
        f = self.feature
        f.set_setting("out_mode2", self.mode.currentData())
        f.set_setting("out_folder", self.folder.text().strip() or self.default_folder)
        f.set_setting("out_custom", self.custom.text().strip())
        for key, (e, default) in self.patterns.items():
            f.set_setting(key, e.text().strip() or default)
        self.changed.emit()

    def values(self) -> dict:
        return {"mode": self.mode.currentData(), "folder": self.folder.text().strip() or self.default_folder,
                "custom": self.custom.text().strip()}

    def pattern(self, key: str) -> str:
        e, default = self.patterns[key]
        return e.text().strip() or default

    def folder_for(self, sample: Optional[Path] = None) -> Optional[Path]:
        """The folder new files will go to (for 'beside each video' modes: beside `sample`)."""
        v = self.values()
        if v["mode"] == "root":
            root = self.feature.context.settings.get("app", "output_root", "")
            return Path(root) / v["folder"] if root else None
        if v["mode"] == "custom":
            return Path(v["custom"]) if v["custom"] else None
        if sample is None:
            return None
        base = Path(sample) if Path(sample).is_dir() else Path(sample).parent
        return base / v["folder"] if v["mode"] == "subfolder" else base


VIDEO_FILTER = ("Videos (*.mp4 *.m4v *.mov *.mkv *.avi *.wmv *.asf *.flv *.webm *.mts *.m2ts *.ts *.mpg *.mpeg "
                "*.vob *.3gp *.dv);;All files (*)")


def pick_videos(parent, start: str = "") -> list[Path]:
    files, _ = QFileDialog.getOpenFileNames(parent, "Choose one or more videos", start, VIDEO_FILTER)
    return [Path(f) for f in files]


def open_module_output(parent, manager, module: str, card: "OutputCard", sample: Optional[Path] = None):
    """Open where this module's files are: the newest finished file (even while a task is still running),
    otherwise the output folder the page is set to."""
    for t in reversed(manager.for_module(module)):
        for o in reversed(t.outputs):
            if Path(o).exists():
                open_in_explorer(Path(o))
                return
    folder = card.folder_for(sample)
    if folder is None:
        QMessageBox.information(parent, "Output folder",
                                "Nothing has been made yet, and the output folder isn't decided yet\n"
                                "(choose a folder, or set the Breezy Output folder in Settings).")
        return
    folder.mkdir(parents=True, exist_ok=True)
    open_in_explorer(folder)


# ------------------------------------------------------------------ task bar
def m_running(manager) -> list:
    return manager.running_all() if hasattr(manager, "running_all") else [x for x in [manager.running()] if x]


class TaskBar(QFrame):
    """Progress of one task: bar + time left/finish time/elapsed/speed/file n of N + pause/cancel."""

    def __init__(self, manager: TaskManager, module: Optional[str] = None, bottom: bool = False):
        super().__init__()
        self.manager, self.module, self.bottom = manager, module, bottom
        self.task_id: Optional[str] = None
        if bottom:
            self.setObjectName("taskbar")
        h = QHBoxLayout(self)
        h.setContentsMargins(12 if bottom else 0, 6, 12 if bottom else 0, 6)
        h.setSpacing(10)
        col = QVBoxLayout()
        col.setSpacing(3)
        top = QHBoxLayout()
        self.title = QLabel("", objectName="taskTitle")
        self.info = QLabel("", objectName="taskInfo")
        self.info.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Preferred)
        top.addWidget(self.title)
        top.addWidget(self.info, 1)
        col.addLayout(top)
        self.bar = QProgressBar()
        self.bar.setRange(0, 1000)
        self.bar.setTextVisible(False)
        self.bar.setFixedHeight(10)
        col.addWidget(self.bar)
        h.addLayout(col, 1)
        self.pause_btn = QToolButton()
        self.pause_btn.clicked.connect(self._pause)
        self.cancel_btn = QToolButton()
        self.cancel_btn.setToolTip("Cancel this task")
        self.cancel_btn.clicked.connect(lambda: self.task_id and self.manager.cancel(self.task_id))
        h.addWidget(self.pause_btn)
        h.addWidget(self.cancel_btn)
        if bottom:                      # live processor / graphics card load, always shown
            from PySide6.QtCore import QTimer
            from breezy.core import usage
            usage.start()
            from breezy.core import power
            self.power_btn = QToolButton(objectName="powerSwitch")
            self.power_btn.setCheckable(True)
            self.power_btn.setAutoRaise(True)
            self.power_btn.setToolTip(
                "Click to switch how much of the PC the app may use:\n"
                "Full speed - tasks finish as fast as possible, the PC may feel slow meanwhile.\n"
                "Spare power - the app gets the lowest priority, whatever you do comes first.\n"
                "(Also in Settings → Computer use.)\n\n"
                "When to use: spare power while you work or game, full speed when you're away.")
            self.power_btn.toggled.connect(self._power_clicked)
            power.listeners.append(self._power_shown)
            self._power_shown(power.mode())
            h.addWidget(self.power_btn)
            self.usage = QLabel("", objectName="taskInfo")
            self.usage.setMinimumWidth(150)
            self.usage.setAlignment(Qt.AlignRight | Qt.AlignVCenter)
            h.addWidget(self.usage)
            self._usage_timer = QTimer(self, interval=1500)
            self._usage_timer.timeout.connect(self._show_usage)
            self._usage_timer.start()
        manager.changed.connect(self._changed)
        manager.listChanged.connect(self.refresh)
        manager.finished.connect(lambda _id: self.refresh())
        self.refresh()

    def _power_shown(self, mode: str):
        b = self.power_btn
        b.blockSignals(True)
        b.setChecked(mode == "spare")
        b.setText("🍃 Spare power" if mode == "spare" else "⚡ Full speed")
        b.blockSignals(False)

    def _power_clicked(self, on: bool):
        from breezy.core import power
        power.switch(self.manager.settings, "spare" if on else "full")

    def _show_usage(self):
        from breezy.core import usage
        t, tip = usage.text()
        self.usage.setText(t)
        self.usage.setToolTip(tip or "Processor and graphics card load")

    def follow(self, task_id: str):
        self.task_id = task_id
        self.refresh()

    def _pick(self) -> Optional[Task]:
        m = self.manager
        run = m.running()
        if self.module is None:
            if run:
                return run
            return next((t for t in m.tasks if t.status == PAUSED), None)
        if run and run.module == self.module:
            return run
        mine = m.for_module(self.module)
        act = [t for t in mine if t.status in ACTIVE]
        if act:
            return act[0]
        t = m.get(self.task_id) if self.task_id else None
        return t or (mine[-1] if mine else None)

    def _changed(self, task_id: str):
        if task_id == self.task_id or self.task_id is None or self.manager.running() is not None:
            self.refresh()

    def refresh(self):
        t = self._pick()
        c = theme.colors()
        self.task_id = t.id if t else None
        if not t:
            self.title.setText("" if self.bottom else "No task yet")
            self.info.setText("")
            self.bar.setValue(0)
            self.bar.setVisible(not self.bottom)
            for b in (self.pause_btn, self.cancel_btn):
                b.setVisible(False)
            return
        self.bar.setVisible(True)
        prefix = (MODULE_NAMES.get(t.module, t.module) + ": ") if self.bottom else ""
        others = [r for r in m_running(self.manager) if r.id != t.id] if self.bottom else []
        self.title.setText(prefix + t.title)
        self.info.setText(describe(t) + (f"   (+ {len(others)} more running: "
                                         + ", ".join(r.title for r in others) + ")" if others else ""))
        self.bar.setValue(int(t.progress * 1000))
        active = t.status in (RUNNING, PAUSED, "queued")
        self.pause_btn.setVisible(active)
        self.cancel_btn.setVisible(active)
        paused = t.status == PAUSED
        self.pause_btn.setIcon(icon("play" if paused else "pause", c["text"], 16))
        self.pause_btn.setToolTip("Resume" if paused else "Pause")
        self.cancel_btn.setIcon(icon("x", c["text"], 16))

    def _pause(self):
        t = self.manager.get(self.task_id) if self.task_id else None
        if not t:
            return
        if t.status == PAUSED:
            self.manager.resume(t.id)
        else:
            self.manager.pause(t.id)


# -------------------------------------------------------------- output picker
class OutputPicker(QDialog):
    """'Use output from…': files made earlier by any module, or a queued task's future output."""

    def __init__(self, manager: TaskManager, parent=None, exclude_module: str = ""):
        super().__init__(parent)
        self.setWindowTitle("Use output from…")
        self.resize(760, 520)
        self.manager = manager
        v = QVBoxLayout(self)
        v.addWidget(QLabel("Tick earlier results to add their files, or a queued/running task to use "
                           "its files once it finishes."))
        self.tree = QTreeWidget()
        self.tree.setHeaderLabels(["Run / file", "When", "Files"])
        self.tree.header().resizeSection(0, 470)
        v.addWidget(self.tree, 1)
        bb = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        bb.accepted.connect(self.accept)
        bb.rejected.connect(self.reject)
        v.addWidget(bb)

        future = [t for t in manager.tasks if t.status in ACTIVE and t.kind.split(".")[-1] not in ("scan", "analyze")]
        if future:
            top = QTreeWidgetItem(self.tree, ["Queued / running (use their files when they finish)"])
            top.setFlags(Qt.ItemIsEnabled)
            for t in future:
                it = QTreeWidgetItem(top, [f"{MODULE_NAMES.get(t.module, t.module)}: {t.title}", t.status, ""])
                it.setData(0, Qt.UserRole, ("future", t.id))
                it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
                it.setCheckState(0, Qt.Unchecked)
            top.setExpanded(True)
        by_mod: dict[str, list[dict]] = {}
        for r in reversed(manager.history.runs):
            by_mod.setdefault(r.get("module", "?"), []).append(r)
        for mod, runs in by_mod.items():
            top = QTreeWidgetItem(self.tree, [MODULE_NAMES.get(mod, mod)])
            top.setFlags(Qt.ItemIsEnabled)
            for r in runs:
                files = [f for f in r.get("outputs", []) if Path(f).is_file()]
                if not files:
                    continue
                when = time.strftime("%b %d %H:%M", time.localtime(r.get("finished", 0)))
                it = QTreeWidgetItem(top, [r.get("title", "run"), when, str(len(files))])
                it.setFlags(it.flags() | Qt.ItemIsUserCheckable | Qt.ItemIsAutoTristate)
                it.setCheckState(0, Qt.Unchecked)
                for f in files:
                    c = QTreeWidgetItem(it, [Path(f).name, "", ""])
                    c.setToolTip(0, f)
                    c.setData(0, Qt.UserRole, ("file", f))
                    c.setFlags(c.flags() | Qt.ItemIsUserCheckable)
                    c.setCheckState(0, Qt.Unchecked)
            top.setExpanded(True)
        if self.tree.topLevelItemCount() == 0:
            QTreeWidgetItem(self.tree, ["Nothing yet - run a module first."])

    def selection(self) -> tuple[list[str], list[str]]:
        files, future = [], []

        def walk(it):
            d = it.data(0, Qt.UserRole)
            if d and it.checkState(0) == Qt.Checked:
                (files if d[0] == "file" else future).append(d[1])
            for i in range(it.childCount()):
                walk(it.child(i))
        for i in range(self.tree.topLevelItemCount()):
            walk(self.tree.topLevelItem(i))
        return [f for f in files if Path(f).suffix.lower() not in NOT_MEDIA], future


def page_header(title: str, desc: str, right: QWidget | None = None) -> QWidget:
    w = QWidget()
    h = QHBoxLayout(w)
    h.setContentsMargins(0, 0, 0, 0)
    v = QVBoxLayout()
    v.setSpacing(2)
    v.addWidget(QLabel(title, objectName="pageTitle"))
    d = QLabel(desc, objectName="pageDesc")
    d.setWordWrap(True)
    v.addWidget(d)
    h.addLayout(v, 1)
    if right:
        h.addWidget(right, 0, Qt.AlignTop)
    return w


# ------------------------------------------------------------ drag & drop, list menus
def install_drop(widget: QWidget, on_folder, on_files):
    """Let files and folders be dropped onto a page: a folder becomes the page's folder, files are added."""
    from PySide6.QtCore import QEvent, QObject

    class F(QObject):
        def eventFilter(self, obj, ev):
            t = ev.type()
            if t in (QEvent.DragEnter, QEvent.DragMove):
                if ev.mimeData().hasUrls():
                    ev.acceptProposedAction()
                    return True
            elif t == QEvent.Drop and ev.mimeData().hasUrls():
                paths = [Path(u.toLocalFile()) for u in ev.mimeData().urls() if u.isLocalFile()]
                folders = [p for p in paths if p.is_dir()]
                files = [p for p in paths if p.is_file()]
                if folders and not files and len(folders) == 1:
                    on_folder(folders[0])
                else:
                    for d in folders:             # several folders / a mix: add the videos inside
                        files += sorted(x for x in d.rglob("*") if x.is_file())
                    vids = [f for f in files if f.suffix.lower() in VIDEO_EXTS_ALL]
                    if vids:
                        on_files(vids)
                ev.acceptProposedAction()
                return True
            return False

    widget.setAcceptDrops(True)
    f = F(widget)
    widget.installEventFilter(f)
    for child in widget.findChildren(QWidget):
        if isinstance(child, (QTreeWidget, QLineEdit)) or child.acceptDrops():
            child.setAcceptDrops(True)
            child.installEventFilter(f)
    widget._drop_filter = f
    return f


VIDEO_EXTS_ALL = {".mp4", ".m4v", ".mov", ".mkv", ".avi", ".wmv", ".asf", ".flv", ".webm", ".mts", ".m2ts", ".ts",
                  ".mpg", ".mpeg", ".vob", ".3gp", ".dv"}


def play_file(path: Path):
    path = Path(path)
    if sys.platform == "win32":
        os.startfile(str(path))  # noqa
    else:
        subprocess.Popen(["xdg-open", str(path)])


def install_list_tools(tree: QTreeWidget, path_of, remove=None, refresh=None, extra=None):
    """Right-click menu + keys for a file list.
    path_of(item) -> Path | None; remove(list[Path]) removes them from the list (not from disk);
    refresh() re-reads the folder; extra(menu, paths) adds module-specific actions."""
    from PySide6.QtGui import QGuiApplication, QKeySequence, QShortcut
    from PySide6.QtWidgets import QMenu

    def selected() -> list[Path]:
        items = tree.selectedItems() or ([tree.currentItem()] if tree.currentItem() else [])
        out = []
        for it in items:
            p = path_of(it)
            if p and p not in out:
                out.append(Path(p))
        return out

    def do_play():
        s = selected()
        if s:
            play_file(s[0])

    def do_show():
        s = selected()
        if s:
            open_in_explorer(s[0])

    def do_copy():
        s = selected()
        if s:
            QGuiApplication.clipboard().setText("\n".join(str(p) for p in s))

    def do_remove():
        s = selected()
        if s and remove:
            remove(s)

    def menu(pos):
        s = selected()
        m = QMenu(tree)
        a = m.addAction("Play", do_play)
        a.setShortcut(QKeySequence(Qt.Key_Return))
        a.setEnabled(bool(s))
        m.addAction("Show in folder", do_show).setEnabled(bool(s))
        m.addAction("Copy path", do_copy).setEnabled(bool(s))
        if remove:
            m.addSeparator()
            r = m.addAction(f"Remove from list ({len(s)})" if len(s) > 1 else "Remove from list", do_remove)
            r.setShortcut(QKeySequence.Delete)
            r.setEnabled(bool(s))
        if extra:
            extra(m, s)
        if refresh:
            m.addSeparator()
            f5 = m.addAction("Read the folder again", refresh)
            f5.setShortcut(QKeySequence(Qt.Key_F5))
        m.exec(tree.viewport().mapToGlobal(pos))

    tree.setContextMenuPolicy(Qt.CustomContextMenu)
    tree.customContextMenuRequested.connect(menu)
    if tree.selectionMode() in (QTreeWidget.SingleSelection, QTreeWidget.NoSelection):
        tree.setSelectionMode(QTreeWidget.ExtendedSelection)
    keys = [(Qt.Key_Return, do_play), (Qt.Key_Enter, do_play)]
    if remove:
        keys.append((QKeySequence.Delete, do_remove))
    if refresh:
        keys.append((Qt.Key_F5, refresh))
    tree._shortcuts = []
    for k, fn in keys:
        sc = QShortcut(QKeySequence(k), tree)
        sc.setContext(Qt.WidgetWithChildrenShortcut)
        sc.activated.connect(fn)
        tree._shortcuts.append(sc)


def set_value(w, v) -> None:
    """Show a stored setting in a control (combo box, tick box, number box, slider)."""
    from PySide6.QtWidgets import QAbstractSlider
    if v is None:
        return
    if isinstance(w, QComboBox):
        i = w.findData(v)
        if i < 0 and isinstance(v, (int, float)) and not isinstance(v, bool):
            i = next((k for k in range(w.count()) if isinstance(w.itemData(k), (int, float))
                      and abs(float(w.itemData(k)) - float(v)) < 1e-6), -1)
        if i >= 0:
            w.setCurrentIndex(i)
    elif isinstance(w, QCheckBox):
        w.setChecked(bool(v))
    elif isinstance(w, QDoubleSpinBox):
        w.setValue(float(v))
    elif isinstance(w, (QSpinBox, QAbstractSlider)):
        w.setValue(int(round(float(v))))


def reload_from(feature, mapping: dict) -> None:
    """mapping: settings key -> control. Puts the stored values back into the controls."""
    for key, w in mapping.items():
        set_value(w, feature.setting(key))
