"""Shared base for pages that work on a list of videos (folder / added files / another task's output).

A page subclasses VideoListPage and provides:
    MODULE, DEFAULT_FOLDER, DEFAULT_PATTERN, COLUMNS (after "Video"), RUN_TEXT
    build_settings(col)        - add its Cards to the right-hand SettingsColumn
    build_middle()             - optional widget between the list and the messages (preview etc.)
    fill_row(it, p, info)      - fill columns 1.. of a row for a readable video
    settings() -> dict         - the page's settings (saved, and sent with the task)
    task_kind / auto_kind      - task runner names; spec_for(files) to add more to the spec
    can_run() -> str           - "" when ready, else why not
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from pathlib import Path

from PySide6.QtCore import QObject, Qt, Signal
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (QAbstractItemView, QFileDialog, QHBoxLayout, QLabel, QLineEdit, QMessageBox,
                               QPlainTextEdit, QPushButton, QSplitter, QTreeWidget, QTreeWidgetItem,
                               QVBoxLayout, QWidget)

from breezy.core import theme
from breezy.core.outputs import output_spec
from breezy.core.tasks import Task
from breezy.core.ui import Card, OutputCard, OutputPicker, SettingsColumn, check

ROLE = Qt.UserRole


class Prober(QObject):
    """Reads video information in the background; emits done(path, MediaInfo)."""
    done = Signal(str, object)

    def __init__(self, ffmpeg, parent=None):
        super().__init__(parent)
        self.ff = ffmpeg
        self._pool = ThreadPoolExecutor(max_workers=4)

    def request(self, path: Path):
        self._pool.submit(lambda: self.done.emit(str(path), self.ff.probe(path)))

    def shutdown(self):
        self._pool.shutdown(wait=False, cancel_futures=True)


class VideoListPage(QWidget):
    MODULE = "module"
    TITLE = "Module"
    DEFAULT_FOLDER = "Output"
    DEFAULT_PATTERN = "{name}_new"
    COLUMNS: list[tuple[str, int]] = []        # (header, width) after the "Video" column
    RUN_TEXT = "Start"
    RUN_TIP = "Process the ticked videos. The originals are never changed."
    task_kind = ""
    auto_kind = ""
    task_verb = "Process"
    SETTINGS_WIDTH = 390
    PATTERNS = None                            # None = one "File name:" pattern (DEFAULT_PATTERN); [] = none
    needs_video = True                         # files without a picture can't be used

    def __init__(self, feature):
        super().__init__()
        self.feature = feature
        self.ctx = feature.context
        self.ff = self.ctx.ffmpeg
        self.tm = self.ctx.tasks
        self.files: list[Path] = []
        self.extra_files: list[Path] = []
        self.removed: set[Path] = set()
        self.infos: dict[Path, object] = {}
        self.unchecked: set[Path] = set()
        self.current: Path | None = None
        self.prober = Prober(self.ff, self)
        self.prober.done.connect(self._probed)
        self._loading = True
        self._build()
        self._loading = False
        from breezy.core.ui import install_drop, install_list_tools
        install_drop(self, self._drop_folder, self._add_paths)
        install_list_tools(self.tree, self._path_of_item, self._remove_paths, self._reread)
        self.tm.finished.connect(self._task_finished)
        if self.folder_edit.text().strip():
            self._reread()
        self.update_buttons()

    # ================================================================ settings helpers
    def st(self, key: str, default=None):
        """Saved setting, else the current quality level's value, else the hardware default, else `default`."""
        v = self.feature.setting(key)
        if v is not None:
            return v
        q = getattr(self.ctx, "quality", None)
        try:
            exp = q.expected(self.MODULE) if q is not None else {}
        except Exception:
            exp = {}
        if key in exp:
            return exp[key]
        try:
            from breezy.core.quality import hardware_values
            hv = hardware_values(self.ctx.settings).get(self.MODULE, {})
            if key in hv:
                return hv[key]
        except Exception:
            pass
        return default

    def settings(self) -> dict:
        return {}

    def save_settings(self, *_):
        if self._loading:
            return
        f = self.feature
        f.set_setting("last_folder", self.folder_edit.text().strip())
        f.set_setting("recursive", self.recursive.isChecked())
        for k, v in self.settings().items():
            f.set_setting(k, v)

    def changed(self, *_):
        """Call from every setting control."""
        self.save_settings()
        self.refresh_rows()
        self.settings_changed()

    def settings_changed(self):
        pass

    def connect_all(self, *widgets):
        from PySide6.QtWidgets import QAbstractButton, QAbstractSpinBox, QComboBox
        for w in widgets:
            if isinstance(w, QComboBox):
                w.currentIndexChanged.connect(self.changed)
            elif isinstance(w, QAbstractButton):
                w.toggled.connect(self.changed)
            elif isinstance(w, QAbstractSpinBox):
                w.valueChanged.connect(self.changed)

    # ================================================================ layout
    def _build(self):
        st = self.st
        root = QHBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(14)
        left = QWidget()
        lv = QVBoxLayout(left)
        lv.setContentsMargins(0, 0, 0, 0)
        lv.setSpacing(8)
        src = Card()
        top = QHBoxLayout()
        self.folder_edit = QLineEdit(st("last_folder", ""))
        self.folder_edit.setPlaceholderText("Folder of videos…")
        self.folder_edit.editingFinished.connect(self._reread)
        browse = QPushButton("Browse…")
        browse.setToolTip("Choose a folder: all its videos are listed")
        browse.clicked.connect(self._browse_folder)
        add_files = QPushButton("Add files…")
        add_files.setToolTip("Choose one or more video files (they're added to the list)")
        add_files.clicked.connect(self._add_files)
        clear_files = QPushButton("Clear")
        clear_files.setToolTip("Empty the list (folder and added files)")
        clear_files.clicked.connect(self._clear_files)
        self.recursive = check("Include subfolders", bool(st("recursive", False)))
        self.recursive.toggled.connect(self._reread)
        self.use_out = QPushButton("Use output from…")
        self.use_out.setToolTip("Add files made by any module - or queue this page's work on the files of\n"
                                "a task that hasn't finished yet (with the current settings)")
        self.use_out.clicked.connect(self._use_output)
        top.addWidget(QLabel("Folder:"))
        top.addWidget(self.folder_edit, 1)
        for w in (browse, add_files, clear_files, self.recursive, self.use_out):
            top.addWidget(w)
        src.v.addLayout(top)
        self.extra_label = QLabel("", objectName="muted")
        src.v.addWidget(self.extra_label)
        lv.addWidget(src)

        self.tree = QTreeWidget()
        self.tree.setRootIsDecorated(False)
        heads = ["Video"] + [h for h, _w in self.COLUMNS]
        self.tree.setColumnCount(len(heads))
        self.tree.setHeaderLabels(heads)
        self.tree.setSelectionMode(QAbstractItemView.ExtendedSelection)
        self.tree.setAlternatingRowColors(True)
        h = self.tree.header()
        h.resizeSection(0, 300)
        for i, (_h, w) in enumerate(self.COLUMNS, 1):
            h.resizeSection(i, w)
        h.setStretchLastSection(True)
        self.tree.setMinimumHeight(90)
        self.tree.itemChanged.connect(self._item_changed)
        self.tree.currentItemChanged.connect(self._current_changed)

        self.log = QPlainTextEdit(readOnly=True)
        self.log.setMaximumBlockCount(2000)
        self.log.setPlaceholderText("Messages")
        middle = self.build_middle()
        split = QSplitter(Qt.Vertical)
        split.setChildrenCollapsible(False)
        split.addWidget(self.tree)
        if middle is not None:
            split.addWidget(middle)
            split.addWidget(self.log)
            split.setStretchFactor(0, 1)
            split.setStretchFactor(1, 4)
            split.setSizes([170, 540, 60])
        else:
            split.addWidget(self.log)
            split.setStretchFactor(0, 4)
            split.setSizes([600, 90])
        lv.addWidget(split, 1)

        run = Card()
        rh = QHBoxLayout()
        self.summary = QLabel("", objectName="muted")
        rh.addWidget(self.summary)
        rh.addStretch(1)
        self.open_btn = QPushButton("Open output folder")
        self.open_btn.setToolTip("Open where this page's results are saved")
        self.open_btn.clicked.connect(self._open_output)
        self.run_btn = QPushButton(self.RUN_TEXT, objectName="primary")
        self.run_btn.setToolTip(self.RUN_TIP)
        self.run_btn.clicked.connect(self.run)
        rh.addWidget(self.open_btn)
        for b in self.extra_buttons():
            rh.addWidget(b)
        rh.addWidget(self.run_btn)
        run.v.addLayout(rh)
        lv.addWidget(run)
        root.addWidget(left, 1)

        col = SettingsColumn(self.SETTINGS_WIDTH)
        self.build_settings(col)
        pats = [("name_pattern", "File name:", self.DEFAULT_PATTERN)] if self.PATTERNS is None else self.PATTERNS
        self.out = col.add(OutputCard(self.feature, self.DEFAULT_FOLDER, pats))
        self.build_after_output(col)
        root.addWidget(col)

    def build_settings(self, col: SettingsColumn):
        pass

    def extra_buttons(self) -> list:
        """More buttons next to the run button (left of it)."""
        return []

    def build_after_output(self, col: SettingsColumn):
        pass

    def build_middle(self) -> QWidget | None:
        return None

    # ================================================================= files
    def say(self, msg: str):
        self.log.appendPlainText(msg)

    def _browse_folder(self):
        d = QFileDialog.getExistingDirectory(self, "Folder of videos", self.folder_edit.text())
        if d:
            self.folder_edit.setText(d)
            self._reread()

    def _add_files(self):
        from breezy.core.ui import pick_videos
        files = pick_videos(self, self.folder_edit.text().strip())
        if files:
            self._add_paths(files)

    def _add_paths(self, files):
        files = [Path(f) for f in files]
        self.extra_files += [f for f in files if f not in self.extra_files]
        self.removed -= set(files)
        self.say(f"Added {len(files)} file(s).")
        self._reread()

    def _clear_files(self):
        self.folder_edit.setText("")
        self.extra_files, self.removed, self.files = [], set(), []
        self.unchecked.clear()
        self.current = None
        self._rebuild()
        self.current_changed(None)

    def _drop_folder(self, d):
        self.folder_edit.setText(str(d))
        self._reread()

    def _remove_paths(self, paths):
        self.removed |= set(paths)
        self.extra_files = [f for f in self.extra_files if f not in paths]
        if self.current in paths:
            self.current = None
            self.current_changed(None)
        self.say(f"Removed {len(paths)} file(s) from the list (nothing is deleted).")
        self._reread()

    def _path_of_item(self, it):
        d = it.data(0, ROLE) if it else None
        return Path(d) if isinstance(d, str) else None

    def _gather_files(self) -> list[Path]:
        from breezy.features.stitcher.detector import VIDEO_EXTS
        text = self.folder_edit.text().strip()
        folder = Path(text) if text else None
        files = []
        if folder and folder.is_dir():
            it = folder.rglob("*") if self.recursive.isChecked() else folder.glob("*")
            skip = {self.out.values()["folder"].lower(), "breezy output"}
            pat = self.out.pattern("name_pattern") if "name_pattern" in self.out.patterns else "{name}"
            tail = pat.split("{name}", 1)[1] if pat.startswith("{name}") and pat != "{name}" else ""
            files = sorted(p for p in it if p.is_file() and p.suffix.lower() in VIDEO_EXTS
                           and not (set(x.lower() for x in p.relative_to(folder).parts[:-1]) & skip)
                           and not (tail and p.stem.endswith(tail)))
        return [p for p in files if p not in self.removed] + \
            [p for p in self.extra_files if p not in files and p.is_file() and p not in self.removed]

    def _reread(self, *_):
        self.files = self._gather_files()
        if not self._loading:
            self.feature.set_setting("last_folder", self.folder_edit.text().strip())
            self.feature.set_setting("recursive", self.recursive.isChecked())
        for p in self.files:
            if p not in self.infos:
                self.infos[p] = None
                self.prober.request(p)
        self._rebuild()

    def _probed(self, path: str, info):
        p = Path(path)
        self.infos[p] = info
        it = self.item_for(p)
        if it is not None:
            self._fill(it, p)
        if p == self.current:
            self.current_changed(p)
        self.update_buttons()

    def _use_output(self):
        dlg = OutputPicker(self.tm, self, self.MODULE)
        if not dlg.exec():
            return
        files, future = dlg.selection()
        if files:
            self._add_paths([Path(f) for f in files])
        for tid in future:
            self._queue_auto(tid)
        self.update_buttons()

    def _queue_auto(self, task_id: str):
        why = self.can_run()
        if why:
            QMessageBox.information(self, self.TITLE, why)
            return
        out = output_spec(self.ctx.settings, self.MODULE, self.DEFAULT_FOLDER, self, self.out.values())
        if out is None:
            return
        self.save_settings()
        src = self.tm.get(task_id)
        name = src.title if src else task_id
        self.tm.submit(Task(self.auto_kind, self.MODULE, f"{self.task_verb} output of '{name}'",
                            spec=dict(self.spec_for([]), output=out), input_from=task_id))
        self.say(f"Queued: {self.task_verb.lower()} the files from '{name}' when it finishes (current settings).")

    # ================================================================== list
    def item_for(self, p: Path):
        for i in range(self.tree.topLevelItemCount()):
            it = self.tree.topLevelItem(i)
            if it.data(0, ROLE) == str(p):
                return it
        return None

    def _rebuild(self):
        was = self.tree.blockSignals(True)
        self.tree.clear()
        for p in self.files:
            it = QTreeWidgetItem(self.tree)
            it.setData(0, ROLE, str(p))
            it.setFlags(it.flags() | Qt.ItemIsUserCheckable)
            it.setCheckState(0, Qt.Unchecked if p in self.unchecked else Qt.Checked)
            it.setText(0, p.name)
            it.setToolTip(0, str(p))
            self._fill(it, p)
            if p == self.current:
                self.tree.setCurrentItem(it)
        self.tree.blockSignals(was)
        n = len(self.extra_files)
        self.extra_label.setText(f"+ {n} added file(s)" if n else "")
        self.extra_label.setVisible(bool(n))
        self.update_buttons()

    def usable(self, info) -> bool:
        return bool(info and not info.error and (info.video or not self.needs_video))

    def _fill(self, it: QTreeWidgetItem, p: Path):
        c = theme.colors()
        was = self.tree.blockSignals(True)
        info = self.infos.get(p)
        last = len(self.COLUMNS)
        for col in range(1, last + 1):
            it.setText(col, "")
            it.setForeground(col, QBrush(QColor(c["text"])))
        it.setForeground(last, QBrush(QColor(c["muted"])))
        if info is None:
            it.setText(last, "Reading…")
        elif not self.usable(info):
            it.setText(last, "Could not read" if info.error else "No picture")
            it.setForeground(last, QBrush(QColor(c["warn"])))
        else:
            self.fill_row(it, p, info)
        self.tree.blockSignals(was)

    def fill_row(self, it: QTreeWidgetItem, p: Path, info):
        pass

    def warn(self, it: QTreeWidgetItem, col: int, text: str):
        it.setText(col, text)
        it.setForeground(col, QBrush(QColor(theme.colors()["warn"])))

    def refresh_rows(self):
        if not hasattr(self, "tree"):
            return
        for i in range(self.tree.topLevelItemCount()):
            it = self.tree.topLevelItem(i)
            self._fill(it, Path(it.data(0, ROLE)))
        self.update_buttons()

    def _item_changed(self, it: QTreeWidgetItem, _col: int):
        p = self._path_of_item(it)
        if p is None:
            return
        if it.checkState(0) == Qt.Checked:
            self.unchecked.discard(p)
        else:
            self.unchecked.add(p)
        self.update_buttons()

    def _current_changed(self, cur, _prev):
        self.current = self._path_of_item(cur)
        self.current_changed(self.current)

    def current_changed(self, p: Path | None):
        pass

    # ================================================================== run
    def jobs(self) -> list[str]:
        return [str(p) for p in self.files if p not in self.unchecked and self.usable(self.infos.get(p))]

    def can_run(self) -> str:
        return ""

    def spec_for(self, files: list[str]) -> dict:
        if "name_pattern" not in self.out.patterns:
            return dict(self.settings())
        return dict(self.settings(), name_pattern=self.out.pattern("name_pattern"))

    def update_buttons(self):
        if not hasattr(self, "run_btn"):
            return
        jobs = self.jobs()
        why = self.can_run()
        self.run_btn.setEnabled(bool(jobs) and not why)
        reading = sum(1 for p in self.files if self.infos.get(p) is None)
        txt = f"{len(jobs)} of {len(self.files)} video(s) ticked" if self.files else ""
        if reading:
            txt += f" · reading {reading}…"
        if why:
            txt = why + (f" · {txt}" if txt else "")
        self.summary.setText(txt)

    def _open_output(self):
        from breezy.core.ui import open_module_output
        open_module_output(self, self.tm, self.MODULE, self.out, self.files[0] if self.files else None)

    def run(self):
        jobs = self.jobs()
        if not jobs or self.can_run():
            return None
        if not self.ff.available:
            QMessageBox.warning(self, self.TITLE, "FFmpeg was not found. See the Settings page.")
            return None
        out = output_spec(self.ctx.settings, self.MODULE, self.DEFAULT_FOLDER, self, self.out.values())
        if out is None:
            return None
        self.save_settings()
        self.before_run()
        title = (f"{self.task_verb} {len(jobs)} video(s)" if len(jobs) > 1
                 else f"{self.task_verb} {Path(jobs[0]).name}")
        t = self.tm.submit(Task(self.task_kind, self.MODULE, title, spec=dict(self.spec_for(jobs), files=jobs,
                                                                              output=out)))
        self.say(f"Queued: {title}.")
        return t

    def before_run(self):
        pass

    def _task_finished(self, task_id: str):
        t = self.tm.get(task_id)
        if t and t.module == self.MODULE:
            self.task_finished(t)

    def task_finished(self, t):
        pass

    def theme_changed(self):
        self.refresh_rows()

    def shutdown(self):
        self.prober.shutdown()


def video_task_items(ctx, files: list[str], task) -> None:
    """Set a task's items to the files, weighted by their length (for speed and time left)."""
    if not task.items:
        durs = [max(ctx.ffmpeg.probe(Path(f)).duration or 1.0, 1.0) for f in files]
        ctx.set_items(files, durs, [Path(f).name for f in files])
