"""Feature (plugin) system.

Every feature is a Python package that exposes a module-level ``FEATURE``
class deriving from :class:`Feature`. Features are discovered from:

1. ``breezy/features/<name>/``  - built-in features shipped with the app
2. ``<app folder>/plugins/<name>/`` - drop-in add-ons, no code changes needed

To add a new feature, copy ``plugins/_template`` and edit it.
"""
from __future__ import annotations

import importlib
import importlib.util
import logging
import pkgutil
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import TYPE_CHECKING, Callable

if TYPE_CHECKING:  # pragma: no cover
    from PySide6.QtWidgets import QWidget
    from breezy.core.settings import Settings
    from breezy.core.ffmpeg import FFmpeg

log = logging.getLogger(__name__)


@dataclass
class AppContext:
    """Shared services handed to every feature."""
    settings: "Settings"
    ffmpeg: "FFmpeg"
    status: Callable[[str], None] = field(default=lambda msg: None)
    tasks: object = None        # breezy.core.tasks.TaskManager
    history: object = None      # breezy.core.tasks.OutputHistory
    window: object = None       # the main window (for dialogs / navigation)
    quality: object = None      # breezy.core.quality.QualityManager (the global quality setting)
    pipelines: object = None    # breezy.core.pipelines.PipelineRunner


class Feature:
    """Base class for a feature tab in the app."""

    id: str = "feature"            # unique, used as settings section
    name: str = "Unnamed feature"  # shown in sidebar
    description: str = ""          # shown as tooltip / header
    order: int = 100               # sidebar sort order (lower = higher)
    icon: str = "target"           # breezy.core.icons name

    def __init__(self, context: AppContext):
        self.context = context

    def create_widget(self) -> "QWidget":  # pragma: no cover - UI
        raise NotImplementedError

    def theme_changed(self) -> None:
        """Called after the light/dark theme changes (refresh custom colours/icons)."""

    # Convenience settings accessors scoped to this feature
    def setting(self, key: str, default=None):
        return self.context.settings.get(self.id, key, default)

    def set_setting(self, key: str, value) -> None:
        self.context.settings.set(self.id, key, value)
        q = getattr(self.context, "quality", None)
        if q is not None:
            q.changed(self.id, key, value)

    def reload_settings(self) -> None:
        """The global quality setting changed this feature's settings: show them on the page."""
        w = getattr(self, "widget", None)
        if w is not None and hasattr(w, "reload_settings"):
            w.reload_settings()


def _features_from_package(package_name: str, paths) -> list[type[Feature]]:
    found = []
    for mod in pkgutil.iter_modules(paths):
        if mod.name.startswith("_"):
            continue
        full = f"{package_name}.{mod.name}"
        try:
            module = importlib.import_module(full)
        except Exception:  # a broken plugin must never crash the app
            log.exception("Failed to load feature %s", full)
            continue
        cls = getattr(module, "FEATURE", None)
        if isinstance(cls, type) and issubclass(cls, Feature):
            found.append(cls)
    return found


def discover_features(extra_plugin_dir: Path | None = None) -> list[type[Feature]]:
    import breezy.features as builtin

    classes = _features_from_package("breezy.features", builtin.__path__)
    if not classes:  # discovery unavailable (packaged build) -> use the known list
        for name in getattr(builtin, "BUILTIN", []):
            try:
                cls = getattr(importlib.import_module(f"breezy.features.{name}"), "FEATURE", None)
                if cls:
                    classes.append(cls)
            except Exception:
                log.exception("Failed to load feature %s", name)

    if extra_plugin_dir and extra_plugin_dir.is_dir():
        parent = str(extra_plugin_dir.parent)
        if parent not in sys.path:
            sys.path.insert(0, parent)
        pkg = extra_plugin_dir.name
        try:
            importlib.import_module(pkg)
            classes += _features_from_package(pkg, [str(extra_plugin_dir)])
        except Exception:
            log.exception("Failed to load plugin folder %s", extra_plugin_dir)

    unique: dict[str, type[Feature]] = {}
    for cls in classes:
        unique.setdefault(cls.id, cls)
    return sorted(unique.values(), key=lambda c: (c.order, c.name))
