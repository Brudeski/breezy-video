"""Video encoder choice: GPU (AMD AMF / NVIDIA NVENC / Intel QSV) when available, else CPU.

GPU encoders are detected once (a tiny test encode) and remembered per FFmpeg build.
`video_args(codec, quality, use_gpu)` returns FFmpeg arguments; quality uses the
CRF scale (lower = better, ~16-18 is visually lossless).
"""
from __future__ import annotations

import threading
from typing import Optional

from breezy.core import proc

_CANDIDATES = {
    "hevc": ["hevc_amf", "hevc_nvenc", "hevc_qsv"],
    "h264": ["h264_amf", "h264_nvenc", "h264_qsv"],
}
_found: dict[str, Optional[str]] = {}
_lock = threading.Lock()


def _works(ffmpeg_exe: str, enc: str) -> bool:
    try:
        r = proc.run([ffmpeg_exe, "-v", "error", "-f", "lavfi", "-i", "testsrc2=size=320x240:rate=10",
                      "-frames:v", "5", "-pix_fmt", "yuv420p", "-c:v", enc, "-f", "null", "-"], timeout=30)
        return r.returncode == 0
    except Exception:
        return False


def detect(ffmpeg, settings=None) -> dict[str, Optional[str]]:
    """{'hevc': 'hevc_amf' | None, 'h264': ...} - cached in settings per FFmpeg version."""
    with _lock:
        if _found:
            return dict(_found)
        key = ffmpeg.version() if ffmpeg and ffmpeg.available else ""
        cached = settings.get("app", "gpu_encoders", {}) if settings else {}
        if cached.get("key") == key and "hevc" in cached:
            _found.update({"hevc": cached["hevc"], "h264": cached["h264"]})
            return dict(_found)
        for codec, cands in _CANDIDATES.items():
            _found[codec] = next((c for c in cands if ffmpeg and ffmpeg.available and _works(ffmpeg.ffmpeg, c)), None)
        if settings:
            settings.set("app", "gpu_encoders", {"key": key, **_found})
        return dict(_found)


def gpu_name() -> str:
    enc = _found.get("hevc") or _found.get("h264") or ""
    return {"amf": "AMD", "nvenc": "NVIDIA", "qsv": "Intel"}.get(enc.split("_")[-1], "") if enc else ""


def found(codec: str) -> Optional[str]:
    """The GPU encoder detected for this codec, or None."""
    return _found.get("hevc" if codec == "hevc" else "h264")


# encoder speed per quality level: slower presets compress better at the same quality
NVENC_PRESET = {"quality": "p6", "balanced": "p5", "fast": "p3"}
X26X_PRESET = {"quality": "slow", "balanced": "medium", "fast": "veryfast"}


def enc_speed() -> str:
    """The encoder speed of the task running in this thread (set from its quality level)."""
    from breezy.core import proc
    s = proc.current()
    return getattr(s, "enc_speed", "balanced") if s is not None else "balanced"


def video_args(codec: str, quality: int, use_gpu: bool, pix_args: list[str] | None = None,
               closed_gop: bool = True, speed: str | None = None) -> list[str]:
    codec = "hevc" if codec == "hevc" else "h264"
    speed = speed or enc_speed()
    nv, x = NVENC_PRESET.get(speed, "p5"), X26X_PRESET.get(speed, "medium")
    enc = _found.get(codec) if use_gpu else None
    pix = list(pix_args or ["-pix_fmt", "yuv420p"])
    q = str(int(quality))
    if enc and enc.endswith("_amf"):
        return ["-c:v", enc, "-quality", "quality", "-rc", "cqp", "-qp_i", q, "-qp_p", q,
                *(["-qp_b", q] if codec == "h264" else []), *pix]
    if enc and enc.endswith("_nvenc"):
        return ["-c:v", enc, "-preset", nv, "-rc", "vbr", "-cq", q, "-b:v", "0", *pix]
    if enc and enc.endswith("_qsv"):
        return ["-c:v", enc, "-global_quality", q, *pix]
    if codec == "hevc":
        params = "log-level=error" + (":open-gop=0" if closed_gop else "")
        return ["-c:v", "libx265", "-preset", x, "-crf", q, "-x265-params", params, *pix]
    return ["-c:v", "libx264", "-preset", x, "-crf", q, *pix]


def provider_args(provs: list[str], same_shape: bool = False) -> list:
    """Provider names -> what InferenceSession takes. CUDA: for models fed same-size tiles, cuDNN tries
    every method once and keeps the fastest; otherwise a quick guess suits changing sizes."""
    out = []
    for p in provs:
        if p == "CUDAExecutionProvider":
            out.append((p, {"device_id": 0, "cudnn_conv_algo_search": "EXHAUSTIVE" if same_shape else "HEURISTIC",
                            "arena_extend_strategy": "kSameAsRequested"}))
        else:
            out.append(p)
    return out


def onnx_providers(use_gpu: bool) -> list[str]:
    try:
        import onnxruntime as ort
        avail = ort.get_available_providers()
    except Exception:
        return ["CPUExecutionProvider"]
    order = (["DmlExecutionProvider", "CUDAExecutionProvider"] if use_gpu else []) + ["CPUExecutionProvider"]
    return [p for p in order if p in avail] or ["CPUExecutionProvider"]
