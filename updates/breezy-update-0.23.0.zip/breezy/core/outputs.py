"""Where modules save their files.

Default (user's choice): one 'Breezy Output' folder for all modules, chosen by
the user the first time it's needed, with a subfolder per module. Each page
also keeps the older choices as alternatives:

    "root"      Breezy Output\\<module folder>\\          (default)
    "subfolder" <module folder> next to each source video
    "same"      same folder as each source video
    "custom"    a folder picked on the page

File names come from an editable pattern per module, e.g. "{name}_motion".
"""
from __future__ import annotations

import sys
from pathlib import Path
from typing import Optional

MODES = [("root", "Breezy Output folder"), ("subfolder", "Subfolder next to each video"),
         ("same", "Same folder as each video"), ("custom", "Custom folder…")]


def output_root(settings) -> Optional[Path]:
    p = settings.get("app", "output_root", "")
    return Path(p) if p else None


def ensure_root(settings, parent=None) -> Optional[Path]:
    """Return the Breezy Output folder, asking the user to pick it the first time."""
    root = output_root(settings)
    if root:
        root.mkdir(parents=True, exist_ok=True)
        return root
    from PySide6.QtWidgets import QFileDialog, QMessageBox
    QMessageBox.information(parent, "Breezy Output folder",
                            "Choose where Breezy should save everything it makes.\n"
                            "A 'Breezy Output' folder will be created there, with a subfolder per module.\n"
                            "You can change this later in Settings.")
    d = QFileDialog.getExistingDirectory(parent, "Where should the 'Breezy Output' folder go?")
    if not d:
        return None
    root = Path(d) if Path(d).name.lower() == "breezy output" else Path(d) / "Breezy Output"
    root.mkdir(parents=True, exist_ok=True)
    settings.set("app", "output_root", str(root))
    return root


def apply_pattern(pattern: str, name: str) -> str:
    try:
        out = pattern.format(name=name)
    except (KeyError, IndexError, ValueError):
        out = f"{name}_out"
    bad = '<>:"/\\|?*'
    out = "".join("_" if c in bad or ord(c) < 32 else c for c in out).strip(" .")
    return out or name


def unique_path(path: Path) -> Path:
    if not path.exists():
        return path
    n = 2
    while True:
        cand = path.with_name(f"{path.stem} ({n}){path.suffix}")
        if not cand.exists():
            return cand
        n += 1


def output_dir(spec: dict, source: Path) -> Path:
    """Folder for one output, from a task spec's 'output' block."""
    o = spec.get("output", {})
    mode, folder = o.get("mode", "root"), o.get("folder", "Output")
    if mode == "same":
        return source.parent
    if mode == "subfolder":
        return source.parent / folder
    if mode == "custom" and o.get("custom"):
        return Path(o["custom"])
    return Path(o.get("root") or source.parent) / folder


def output_spec(settings, module: str, default_folder: str, parent=None, page_values: dict | None = None):
    """Collect a page's output choices into a spec block (asks for the root if needed)."""
    v = page_values or {}
    mode = v.get("mode", "root")
    spec = {"mode": mode, "folder": v.get("folder") or default_folder, "custom": v.get("custom", "")}
    if mode == "root":
        root = ensure_root(settings, parent)
        if root is None:
            return None
        spec["root"] = str(root)
    return spec


# ------------------------------------------------------------ files in progress
WORKING = ".breezy-working"      # hidden folder next to the outputs; files only appear when complete


def _hide(path: Path) -> None:
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.kernel32.SetFileAttributesW(str(path), 0x02)    # FILE_ATTRIBUTE_HIDDEN
        except Exception:
            pass


def working_dir(out: Path) -> Path:
    """A hidden folder beside the output (same drive, so finishing is an instant rename)."""
    d = Path(out).parent / WORKING
    if not d.is_dir():
        d.mkdir(parents=True, exist_ok=True)
        _hide(d)
    return d


def working_path(out: Path, suffix: str | None = None) -> Path:
    """Where to write `out` while it's being made."""
    out = Path(out)
    return working_dir(out) / (out.stem + ".partial" + (suffix or out.suffix))


def finish(tmp: Path, out: Path) -> Path:
    """Move a finished file into the output folder and tidy the working folder if it's empty."""
    out = Path(out)
    Path(tmp).replace(out)
    tidy_working(out.parent)
    return out


def tidy_working(folder: Path) -> None:
    d = Path(folder) / WORKING
    try:
        d.rmdir()               # only succeeds when nothing else is still being made there
    except OSError:
        pass
