"""Self-repair: download missing or damaged AI models, and a complete FFmpeg when a needed filter is missing.

At start-up (in the background) every model file is checked against its SHA-256 (results are
remembered by size + date, so each file is only hashed once) and FFmpeg is asked for its list of
filters. Anything missing is fetched by a normal task ("Download missing parts"), so it shows
progress, can be paused, and resumes after a restart.
"""
from __future__ import annotations

import hashlib
import json
import shutil
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path
from typing import Callable, Optional

from breezy.core.proc import Cancelled

HF = "https://huggingface.co"
QAI = "https://qaihub-public-assets.s3.us-west-2.amazonaws.com/qai-hub-models/models"

# file (relative to breezy/models) -> sources; each source: (url, sha256 of the download, how to unpack)
#   unpack None: the download is the file itself
#   unpack ("zip", member, {other member: other file}): take members out of a zip
MODELS: dict[str, dict] = {
    "yolov10n.onnx": dict(sha=["a77dd863933f184a19e84361c64b788228a7c7dacc2c78939239a96ad3efca3b"],
                          url=f"{HF}/onnx-community/yolov10n/resolve/main/onnx/model.onnx", size=9386116),
    "yolov10s.onnx": dict(sha=["e2df1b4f5190e1ab4b7305181b2a80eb84ed7cc36d11aee0318781e91b0ad0b8"],
                          url=f"{HF}/onnx-community/yolov10s/resolve/main/onnx/model.onnx", size=29187904),
    "yolov10m.onnx": dict(sha=["89b526498a6d55f869a6ab52e3a2eb20ad45b3711c1f7de3dd9ca0b399dfd6d7"],
                          url=f"{HF}/onnx-community/yolov10m/resolve/main/onnx/model.onnx", size=61659339),
    "real_esrgan_x2plus.onnx": dict(sha=["7115ba92e8a1bfa63d68558ef006ef3d91273a068d321b1439f8bb1c9179002c"],
                                    url=f"{HF}/SceneWorks/real-esrgan-onnx/resolve/main/real_esrgan_x2.onnx",
                                    size=67073434),
    "real_esrgan_x4plus.onnx": dict(sha=["5c586662929cbc686c1a5c38d9c060dbdb4ea5863a1f7672b8c0761e6b89c033"],
                                    url=f"{HF}/SceneWorks/real-esrgan-onnx/resolve/main/real_esrgan_x4.onnx",
                                    size=67051616),
    # shipped: single-file version with any picture size; repaired: Qualcomm's original (fixed 128 px tiles)
    "esrgan_general_x4v3.onnx": dict(
        sha=["ae5ae0cb93425761acbe86d0f2663eaf0da1fba3178989df633cb1aacbe6c9a1",
             "09e6b675a0a18a97e1057c8dd7e984ef878a0a02ce104430da525b6241c858e7"],
        url=f"{QAI}/real_esrgan_general_x4v3/releases/v0.65.0/real_esrgan_general_x4v3-onnx-float.zip",
        zip_sha="fc094329b24a00c936ebc1cc4c51bc59633e7dc36f4a553344342171cbd3c7cf",
        zip_member="real_esrgan_general_x4v3-onnx-float/real_esrgan_general_x4v3.onnx",
        extra={"real_esrgan_general_x4v3-onnx-float/real_esrgan_general_x4v3.data": "real_esrgan_general_x4v3.data"},
        size=161087),
    "gfpgan_v1.4_fp16.onnx": dict(sha=["6b12e9428c2a0983b2726604f09c4eec9e2e250370c79946a31b139f9befc1ea"],
                                  url=f"{HF}/sidkonduru/gfpgan-v1.4-onnx/resolve/main/gfpgan14-fp16.onnx",
                                  size=170362246),
    "face_detection_yunet_2023mar.onnx": dict(
        sha=["8f2383e4dd3cfbb4553ea8718107fc0423210dc964f9f4280604804ed2552fa4"],
        url=f"{HF}/opencv/face_detection_yunet/resolve/main/face_detection_yunet_2023mar.onnx", size=232589),
    "rife_v4.9.onnx": dict(sha=["76e4cef9ab42fa7dd4e8f6e4aba47462051e3faa969e4bca6479784fbab0ac6f"],
                           url=f"{HF}/yuvraj108c/rife-onnx/resolve/main/rife49_ensemble_True_scale_1_sim.onnx",
                           size=21458882),
    "ddcolor.onnx": dict(sha=["310d0c66a38cd8cfd7d9d93fdb5500fef79d584fe59e25a417aea5915a6b3733"],
                         url=f"{QAI}/ddcolor/releases/v0.65.0/ddcolor-onnx-float.zip",
                         zip_sha="512e788cab02db6796ede174af0db2302247130284a3a00eab9aafddafa48a49",
                         zip_member="ddcolor-onnx-float/ddcolor.onnx",
                         extra={"ddcolor-onnx-float/ddcolor.data": "ddcolor.data"}, size=2750675),
    "ddcolor.data": dict(sha=["5b65cb3eab9fa4ae9ecacd539b148fa51157655732022913b1cf47346f93940c"],
                         same_as="ddcolor.onnx", size=225312128),
    "ap_bwe_8k_48k.onnx": dict(sha=["dc147c930f135e1f78bd74fa76ad182882e3c7fc5cca2e5d273e00ebe61a344d"],
                               url=f"{HF}/mhavo/ap-bwe-onnx/resolve/main/ap_bwe_8k_48k.onnx", size=119105097),
    "lama_fp32.onnx": dict(sha=["1faef5301d78db7dda502fe59966957ec4b79dd64e16f03ed96913c7a4eb68d6"],
                           url=f"{HF}/Carve/LaMa-ONNX/resolve/main/lama_fp32.onnx", size=208044816),
    "license_plate_yolov11n.onnx": dict(
        sha=["693133a1db97a3ba1e90068986f80afb72c3fcddb681e57181a89a9a3dc351d6"],
        url=f"{HF}/morsetechlab/yolov11-license-plate-detection/resolve/main/license-plate-finetune-v1n.onnx",
        size=10481682),
    # converted for Breezy from the original Zero-DCE weights - ships with the app, can't be re-downloaded
    "scunet_color_real_psnr.onnx": dict(
        sha=["231be201ab413dbc999d7951caa9844846b93a12a40a41e037d6b5888ed4e88c"],
        url=f"{HF}/Heliosoph/scunet-onnx/resolve/main/scunet_color_real_psnr.onnx", size=3798678),
    "scunet_color_real_psnr.onnx.data": dict(
        sha=["98825ea1210b641c71e5f052f582c70c49fd44b35387ebe2c034268c17df3feb"],
        url=f"{HF}/Heliosoph/scunet-onnx/resolve/main/scunet_color_real_psnr.onnx.data", size=73138176),
    "yolo11n-seg.onnx": dict(sha=["dcbabbdc3d9ef9d52d0fd0178d2fcc9558a18d59257001da4c474e841385203b"],
                             url=f"{HF}/mobilint/YOLO11n-seg/resolve/main/yolo11n-seg.onnx", size=11711584),
    "NAFNet-GoPro-width64.onnx": dict(
        sha=["00c07294585512d162bc2313a2a12cd8d9cd532d0981d0d01f444bd48c4330cd"],
        url=f"{HF}/deepghs/image_restoration/resolve/main/NAFNet-GoPro-width64.onnx", size=275371113),
    "UVR-MDX-NET-Voc_FT.onnx": dict(
        sha=["534b2070fcc7df514b13ef660dc8cbb328679c2374d04354a5c42bb14ecce111"],
        url=f"{HF}/Politrees/UVR_resources/resolve/main/models/MDXNet/UVR-MDX-NET-Voc_FT.onnx", size=66762490),
    "zero_dce.onnx": dict(sha=["f72140279a9d0e63b94741fb99bc9946cd6f441d4dc5d82e4bff2ad602403c4c"], url=None, size=0),
    "voice/std.rnnn": dict(sha=["bf5d58f9d0cd7548f5d6ff6ee8991000b6b939bbd3344d46564b7a1ebddf3aec"],
                           url=f"{HF}/niobures/RNNoise/resolve/main/models/arnndn-models/std.rnnn", size=302925),
    "voice/sh.rnnn": dict(sha=["c4bde2c57fa396c3059827f1e649642134a5cfe3896711a8a8b583a61bdce07b"],
                          url=f"{HF}/niobures/RNNoise/resolve/main/models/arnndn-models/sh.rnnn", size=297668),
    "voice/bd.rnnn": dict(sha=["894764b7a4df78cb8badd50a684ca09e23824ba0330bef07729a55ed430a726f"],
                          url=f"{HF}/niobures/RNNoise/resolve/main/models/arnndn-models/bd.rnnn", size=299715),
}

# FFmpeg filters the modules use
NEEDED_FILTERS = {"bwdif", "cropdetect", "idet", "hqdn3d", "nlmeans", "deblock", "deband", "normalize", "grayworld",
                  "curves", "eq", "vibrance", "cas", "noise", "minterpolate", "framerate", "vidstabdetect",
                  "vidstabtransform", "afftdn", "arnndn", "loudnorm", "highpass", "bandreject", "atempo", "scale",
                  "crop", "concat", "atrim", "apad", "aresample", "fps", "format", "deflicker", "lenscorrection",
                  "vignette", "lut3d", "lutrgb", "zscale", "tonemap", "haas", "extrastereo", "setparams", "split",
                  "blend", "subtitles", "hstack", "drawbox", "adeclip", "adeclick", "acrossover", "acompressor", "amix", "pad",
                  "setsar"}
FFMPEG_BUILDS = [  # complete Windows builds (GPL, static) - newest stable first
    "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-n9.0-latest-win64-gpl-9.0.zip",
    "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-n8.1-latest-win64-gpl-8.1.zip",
    "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip",
]
FFMPEG_CHECKSUMS = "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/checksums.sha256"


def models_dir() -> Path:
    from breezy.features.tracker.detector import models_dir as md
    return md()


def _cache_path() -> Path:
    from breezy.core.settings import app_data_dir
    return app_data_dir() / "verified_files.json"


def sha256(path: Path, cancel: Optional[Callable] = None) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            if cancel:
                cancel()
            b = f.read(4 << 20)
            if not b:
                break
            h.update(b)
    return h.hexdigest()


# ------------------------------------------------------------------ checking
def check_models(cancel: Optional[Callable] = None) -> list[str]:
    """Model files that are missing or damaged."""
    try:
        cache = json.loads(_cache_path().read_text("utf-8"))
    except (OSError, ValueError):
        cache = {}
    bad, changed = [], False
    root = models_dir()
    for name, m in MODELS.items():
        p = root / name
        if not p.is_file():
            bad.append(name)
            continue
        st = p.stat()
        key = f"{st.st_size}|{int(st.st_mtime)}"
        if cache.get(name) == key:
            continue
        if sha256(p, cancel) in m["sha"]:
            cache[name] = key
            changed = True
        else:
            bad.append(name)
    if changed:
        try:
            _cache_path().write_text(json.dumps(cache), "utf-8")
        except OSError:
            pass
    return bad


def missing_filters(ffmpeg) -> set[str]:
    if not ffmpeg or not ffmpeg.available:
        return set(NEEDED_FILTERS)
    from breezy.features.enhance.filters import available_filters
    have = available_filters(ffmpeg.ffmpeg)
    return {f for f in NEEDED_FILTERS if f not in have} if have else set()


def problems(ffmpeg, settings=None) -> dict:
    """{'models': [...], 'ffmpeg': [missing filters]} - FFmpeg only on Windows (where we can install it),
    and only once per app version so a build without a filter doesn't trigger endless downloads."""
    from breezy import __version__
    miss = sorted(missing_filters(ffmpeg))
    bad = check_models()

    def fixable(n):
        m = MODELS[n]
        return bool(m.get("url") or MODELS.get(m.get("same_as", ""), {}).get("url"))
    out = {"models": [n for n in bad if fixable(n)], "unfixable": [n for n in bad if not fixable(n)],
           "ffmpeg": [], "ffmpeg_missing": miss}
    tried = settings.get("app", "ffmpeg_repair_tried", "") if settings else ""
    if miss and sys.platform == "win32" and tried != __version__:
        out["ffmpeg"] = miss
    return out


# ---------------------------------------------------------------- downloading
def download(url: str, dest: Path, progress: Callable[[float], None] = lambda f: None,
             checkpoint: Callable[[], None] = lambda: None, expect_size: int = 0) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp = dest.with_name(dest.name + ".download")
    req = urllib.request.Request(url, headers={"User-Agent": "BreezyVideoEdit"})
    with urllib.request.urlopen(req, timeout=60) as r, open(tmp, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0) or expect_size
        got = 0
        while True:
            checkpoint()
            b = r.read(1 << 20)
            if not b:
                break
            f.write(b)
            got += len(b)
            if total:
                progress(min(1.0, got / total))
    tmp.replace(dest)


def repair_model(name: str, progress=lambda f: None, checkpoint=lambda: None, log=print) -> None:
    m = MODELS[name]
    if "same_as" in m:
        name, m = m["same_as"], MODELS[m["same_as"]]
    root = models_dir()
    with tempfile.TemporaryDirectory(prefix="breezy_dl_") as td:
        tmp = Path(td) / "download"
        log(f"Downloading {name}…")
        download(m["url"], tmp, progress, checkpoint, m.get("size", 0))
        if "zip_member" in m:
            if sha256(tmp) != m["zip_sha"]:
                raise RuntimeError(f"{name}: the download is damaged (checksum mismatch)")
            with zipfile.ZipFile(tmp) as z:
                pairs = {m["zip_member"]: name, **m.get("extra", {})}
                for member, target in pairs.items():
                    dst = root / target
                    with z.open(member) as src, open(dst.with_name(dst.name + ".new"), "wb") as out:
                        shutil.copyfileobj(src, out)
                    dst.with_name(dst.name + ".new").replace(dst)
        else:
            if sha256(tmp) not in m["sha"]:
                raise RuntimeError(f"{name}: the download is damaged (checksum mismatch)")
            dst = root / name
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.move(str(tmp), str(dst))
    log(f"✔ {name} repaired")


def install_ffmpeg(bin_dir: Path, progress=lambda f: None, checkpoint=lambda: None, log=print) -> str:
    """Download a complete FFmpeg build and put ffmpeg.exe + ffprobe.exe in bin_dir. Returns the URL used."""
    sums = {}
    try:
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "sums"
            download(FFMPEG_CHECKSUMS, p)
            for line in p.read_text("utf-8", "replace").splitlines():
                parts = line.split()
                if len(parts) == 2:
                    sums[parts[1].lstrip("*")] = parts[0].lower()
    except Exception as e:  # noqa - checksums are a bonus; continue without them
        log(f"(couldn't get FFmpeg checksums: {e})")
    last = None
    for url in FFMPEG_BUILDS:
        name = url.rsplit("/", 1)[1]
        try:
            with tempfile.TemporaryDirectory(prefix="breezy_ff_") as td:
                z = Path(td) / name
                log(f"Downloading FFmpeg ({name})…")
                download(url, z, lambda f: progress(0.95 * f), checkpoint)
                if name in sums and sha256(z) != sums[name]:
                    raise RuntimeError("checksum mismatch")
                bin_dir.mkdir(parents=True, exist_ok=True)
                with zipfile.ZipFile(z) as zf:
                    for exe in ("ffmpeg.exe", "ffprobe.exe"):
                        member = next(n for n in zf.namelist() if n.endswith("/bin/" + exe))
                        dst = bin_dir / exe
                        with zf.open(member) as src, open(dst.with_name(exe + ".new"), "wb") as out:
                            shutil.copyfileobj(src, out)
                        if dst.exists():
                            try:
                                dst.replace(dst.with_name(exe + ".old"))
                            except OSError:
                                pass
                        dst.with_name(exe + ".new").replace(dst)
                progress(1.0)
                return url
        except Cancelled:
            raise
        except Exception as e:  # noqa - try the next build
            last = e
            log(f"  {name}: {e}")
    raise RuntimeError(f"couldn't download FFmpeg ({last})")


# --------------------------------------------------------------- task runner
def run_repair(task, ctx):
    from breezy import __version__
    spec = task.spec
    items = [["model", n] for n in spec.get("models", []) if "same_as" not in MODELS.get(n, {})] + \
            [["model", MODELS[n]["same_as"]] for n in spec.get("models", []) if "same_as" in MODELS.get(n, {})]
    seen, uniq = set(), []
    for it in items:
        if it[1] not in seen:
            seen.add(it[1])
            uniq.append(it)
    if spec.get("ffmpeg"):
        uniq.append(["ffmpeg", ""])
    if not task.items:
        weights = [(MODELS[n].get("size", 1) + sum(MODELS[k].get("size", 0) for k, v in MODELS.items()
                                                   if v.get("same_as") == n)) / 1e6 if kind == "model" else 160
                   for kind, n in uniq]
        ctx.set_items(uniq, weights, [n or "FFmpeg (complete build)" for _k, n in uniq])
    for _i, (kind, name) in ctx.items():
        try:
            if kind == "model":
                repair_model(name, ctx.item_progress, ctx.checkpoint, ctx.log)
            else:
                from breezy.core.ffmpeg import _app_root
                ctx.settings.set("app", "ffmpeg_repair_tried", __version__)
                url = install_ffmpeg(_app_root() / "bin", ctx.item_progress, ctx.checkpoint, ctx.log)
                ctx.log(f"✔ FFmpeg installed from {url}")
                task.spec["ffmpeg_installed"] = True
        except Cancelled:
            raise
        except Exception as e:  # noqa
            ctx.error(f"{name or 'FFmpeg'}: {e}")


def register():
    from breezy.core.tasks import register_runner
    register_runner("app.repair", run_repair)
