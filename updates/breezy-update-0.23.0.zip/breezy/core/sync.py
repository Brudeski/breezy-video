"""Audio drift: when a file's sound track is longer/shorter than its picture.

Seen in the user's HitPaw exports: the picture is ~0.4% shorter than the sound
(60 s clips: 59.80 s vs 60.03 s), so the sound slowly falls out of sync.
The fix (user's choice) speeds the sound up/down to exactly match the picture;
the picture itself is never changed.
"""
from __future__ import annotations

from typing import Optional

from breezy.core.ffmpeg import MediaInfo

DRIFT_THRESHOLD = 0.1   # seconds by the end of the clip


def drift(info: MediaInfo) -> Optional[float]:
    return info.drift


def needs_fix(info: MediaInfo, threshold: float = DRIFT_THRESHOLD) -> bool:
    d = info.drift
    return d is not None and abs(d) > threshold


def tempo(info: MediaInfo) -> float:
    """atempo factor that makes the sound exactly as long as the picture."""
    v, a = info.video, info.audio
    if not (v and a and v.duration > 0 and a.duration > 0):
        return 1.0
    return a.duration / v.duration


def drift_text(info: MediaInfo) -> str:
    d = info.drift
    return f"sound drifts {d:+.2f} s" if d is not None and abs(d) > DRIFT_THRESHOLD else ""


def audio_bitrate(info: MediaInfo) -> str:
    ch = info.audio.channels if info.audio and info.audio.channels else 2
    return f"{min(320, 96 * ch)}k"
