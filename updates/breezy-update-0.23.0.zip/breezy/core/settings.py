"""Tiny JSON settings store, saved under %APPDATA%\\BreezyVideoEdit (or ~/.config)."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any

from breezy import APP_ID


def app_data_dir() -> Path:
    base = os.environ.get("APPDATA") or os.path.join(Path.home(), ".config")
    path = Path(base) / APP_ID
    path.mkdir(parents=True, exist_ok=True)
    return path


class Settings:
    """Namespaced key/value settings. Each feature gets its own section."""

    def __init__(self, path: Path | None = None):
        self.path = path or (app_data_dir() / "settings.json")
        try:
            self._data: dict[str, dict[str, Any]] = json.loads(self.path.read_text("utf-8"))
        except (OSError, ValueError):
            self._data = {}

    def get(self, section: str, key: str, default: Any = None) -> Any:
        return self._data.get(section, {}).get(key, default)

    def set(self, section: str, key: str, value: Any) -> None:
        self._data.setdefault(section, {})[key] = value
        self.save()

    def save(self) -> None:
        try:
            self.path.write_text(json.dumps(self._data, indent=2), "utf-8")
        except OSError:
            pass
