"""Run a function on a background thread and get Qt signals back on the UI thread."""
from __future__ import annotations

import threading
import traceback
from typing import Callable

from PySide6.QtCore import QObject, QThread, Signal


class Worker(QObject):
    progress = Signal(float, str)   # fraction 0..1, label
    log = Signal(str)
    done = Signal(object)           # return value
    failed = Signal(str)
    finished = Signal()

    def __init__(self, fn: Callable, *args, **kwargs):
        super().__init__()
        self.fn, self.args, self.kwargs = fn, args, kwargs
        self.cancel_event = threading.Event()

    def run(self):
        try:
            result = self.fn(self, *self.args, **self.kwargs)
            self.done.emit(result)
        except Exception as e:  # noqa
            self.log.emit(traceback.format_exc())
            self.failed.emit(str(e))
        finally:
            self.finished.emit()

    def cancel(self):
        self.cancel_event.set()


def run_in_thread(owner: QObject, fn: Callable, *args, **kwargs) -> Worker:
    """fn(worker, *args) runs off the UI thread. Connect to worker signals, then it starts.

    Connect the signals to *bound methods of a QWidget/QObject* (e.g. self._on_done),
    not lambdas - lambdas would run on the worker thread and must not touch the UI.
    """
    thread = QThread(owner)
    worker = Worker(fn, *args, **kwargs)
    worker.moveToThread(thread)
    thread.started.connect(worker.run)
    worker.finished.connect(thread.quit)
    worker.finished.connect(worker.deleteLater)
    thread.finished.connect(thread.deleteLater)
    # keep python refs alive until finished
    owner._bg_jobs = getattr(owner, "_bg_jobs", set())
    owner._bg_jobs.add((thread, worker))
    thread.finished.connect(lambda: owner._bg_jobs.discard((thread, worker)))
    from PySide6.QtCore import QTimer
    QTimer.singleShot(0, thread.start)  # start after caller connects signals
    return worker
