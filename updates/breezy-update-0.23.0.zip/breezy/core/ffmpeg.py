"""FFmpeg / FFprobe helpers shared by all features."""
from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import threading
from dataclasses import dataclass, field
from fractions import Fraction
from pathlib import Path
from typing import Callable, Optional

# Hide console windows spawned by ffmpeg on Windows
_NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


def _app_root() -> Path:
    if getattr(sys, "frozen", False):  # PyInstaller exe
        return Path(sys.executable).parent
    return Path(__file__).resolve().parents[2]


_CAMERA_KEYS = ("make", "model", "serial", "firmware", "device", "camera", "manufacturer", "software")


def _camera_id(fmt_tags: dict, streams: list) -> str:
    """What the file says about the camera that made it ('' if nothing useful). Encoders that only
    say a file was converted (Lavf…, HandBrake…) don't identify a camera."""
    found = {}
    all_tags = [fmt_tags] + [{k.lower(): v for k, v in (s.get("tags") or {}).items()} for s in streams
                             if s.get("codec_type") == "video"]
    for tags in all_tags:
        for k, v in tags.items():
            if any(c in k for c in _CAMERA_KEYS) and str(v).strip():
                found[k] = str(v).strip()
        enc = str(tags.get("encoder", "")).strip()
        if enc and not enc.lower().startswith(("lav", "handbrake", "x264", "x265", "ffmpeg", "google")):
            found["encoder"] = enc
    return "; ".join(f"{k}={found[k]}" for k in sorted(found))


def _sar(text) -> float:
    try:
        a, b = str(text).split(":")
        a, b = int(a), int(b)
        return a / b if a > 0 and b > 0 else 1.0
    except (ValueError, AttributeError):
        return 1.0


class FFmpegNotFound(RuntimeError):
    pass


from breezy.core import proc as _proc
from breezy.core.proc import Cancelled  # noqa: F401  (re-exported for older imports)


@dataclass
class StreamInfo:
    index: int
    kind: str                 # video / audio / subtitle / data
    codec: str
    profile: str = ""
    width: int = 0
    height: int = 0
    pix_fmt: str = ""
    fps: Optional[Fraction] = None
    sample_rate: int = 0
    channels: int = 0
    channel_layout: str = ""
    duration: float = 0.0     # this stream's own length (picture and sound can differ)
    sar: float = 1.0          # pixel shape (sample aspect ratio); 1 = square pixels
    rotation: int = 0         # rotation flag (degrees, FFmpeg's sign). width/height are already as SHOWN:
                              # FFmpeg turns the picture while decoding, so that is the size frames come out at


@dataclass
class MediaInfo:
    path: Path
    duration: float = 0.0
    size: int = 0
    format_name: str = ""
    creation_time: Optional[float] = None   # epoch seconds, from metadata
    mtime: float = 0.0                       # file modified time
    streams: list[StreamInfo] = field(default_factory=list)
    error: str = ""
    camera: str = ""                         # make/model/serial/firmware tags, when the file has them

    @property
    def video(self) -> Optional[StreamInfo]:
        return next((s for s in self.streams if s.kind == "video"), None)

    @property
    def audio(self) -> Optional[StreamInfo]:
        return next((s for s in self.streams if s.kind == "audio"), None)

    def signature(self) -> tuple:
        """Everything that must match for a lossless stream-copy join."""
        sig = [self.path.suffix.lower()]
        for s in self.streams:
            if s.kind == "video":
                sig.append(("v", s.codec, s.profile, s.width, s.height, s.pix_fmt,
                            round(float(s.fps), 2) if s.fps else None))
            elif s.kind == "audio":
                sig.append(("a", s.codec, s.sample_rate, s.channels))
        return tuple(sig)

    @property
    def drift(self) -> Optional[float]:
        """How much longer the sound is than the picture, in seconds (None if unknown)."""
        v, a = self.video, self.audio
        if v and a and v.duration > 0 and a.duration > 0:
            return a.duration - v.duration
        return None

    def describe(self) -> str:
        parts = []
        v, a = self.video, self.audio
        if v:
            fps = f"{float(v.fps):.3g}fps" if v.fps else ""
            parts.append(f"{v.codec} {v.width}x{v.height} {fps}".strip())
        if a:
            parts.append(f"{a.codec} {a.sample_rate // 1000 if a.sample_rate else '?'}kHz {a.channels}ch")
        return " | ".join(parts) or "no A/V streams"


def _parse_time(value: str | None) -> Optional[float]:
    if not value:
        return None
    from datetime import datetime
    v = value.strip().replace("Z", "+00:00")
    for fmt in (None, "%Y-%m-%d %H:%M:%S"):
        try:
            dt = datetime.fromisoformat(v) if fmt is None else datetime.strptime(v, fmt)
            if dt.year < 1990:  # cameras with unset clocks write 1904/1970
                return None
            return dt.timestamp()
        except ValueError:
            continue
    return None


def _stream_duration(s: dict, tags: dict) -> float:
    try:
        if s.get("duration"):
            return float(s["duration"])
        d = tags.get("duration")                 # Matroska: "00:01:00.032000000"
        if d:
            h, m, sec = d.split(":")
            return int(h) * 3600 + int(m) * 60 + float(sec)
    except (ValueError, TypeError):
        pass
    return 0.0


def _fraction(text: str | None) -> Optional[Fraction]:
    try:
        f = Fraction(text)
        return f if f > 0 else None
    except (TypeError, ValueError, ZeroDivisionError):
        return None


class FFmpeg:
    """Locates and runs ffmpeg / ffprobe."""

    def __init__(self, custom_dir: str | None = None):
        self.ffmpeg, self.ffprobe = self._locate(custom_dir)

    @staticmethod
    def _locate(custom_dir: str | None):
        exe = ".exe" if sys.platform == "win32" else ""
        candidates = []
        if custom_dir:
            candidates.append(Path(custom_dir))
        candidates.append(_app_root() / "bin")
        for d in candidates:
            f, p = d / f"ffmpeg{exe}", d / f"ffprobe{exe}"
            if f.is_file() and p.is_file():
                return str(f), str(p)
        f, p = shutil.which("ffmpeg"), shutil.which("ffprobe")
        if f and p:
            return f, p
        # winget installs into a versioned folder that may not be on PATH yet
        local = os.environ.get("LOCALAPPDATA")
        if local:
            for f in Path(local, "Microsoft", "WinGet", "Packages").glob("Gyan.FFmpeg*/**/bin/ffmpeg.exe"):
                p = f.with_name("ffprobe.exe")
                if p.is_file():
                    return str(f), str(p)
        return None, None

    @property
    def available(self) -> bool:
        return bool(self.ffmpeg and self.ffprobe)

    def require(self):
        if not self.available:
            raise FFmpegNotFound(
                "FFmpeg was not found. Run install_ffmpeg.bat, or put ffmpeg.exe and "
                "ffprobe.exe in the 'bin' folder next to the app.")

    def version(self) -> str:
        if not self.available:
            return "not found"
        out = subprocess.run([self.ffmpeg, "-version"], capture_output=True, text=True,
                             creationflags=_NO_WINDOW).stdout
        return out.splitlines()[0] if out else "unknown"

    # ------------------------------------------------------------------ probe
    def probe(self, path: Path) -> MediaInfo:
        self.require()
        path = Path(path)
        info = MediaInfo(path=path)
        try:
            st = path.stat()
            info.size, info.mtime = st.st_size, st.st_mtime
        except OSError as e:
            info.error = str(e)
            return info
        cmd = [self.ffprobe, "-v", "error", "-print_format", "json",
               "-show_format", "-show_streams", str(path)]
        try:
            res = _proc.run(cmd, timeout=120, text=True)
        except subprocess.TimeoutExpired:
            info.error = "ffprobe timed out"
            return info
        if res.returncode != 0:
            info.error = (res.stderr or "ffprobe failed").strip().splitlines()[-1]
            return info
        data = json.loads(res.stdout or "{}")
        fmt = data.get("format", {})
        info.format_name = fmt.get("format_name", "")
        info.duration = float(fmt.get("duration") or 0)
        tags = {k.lower(): v for k, v in (fmt.get("tags") or {}).items()}
        info.creation_time = _parse_time(tags.get("creation_time"))
        info.camera = _camera_id(tags, data.get("streams", []))
        for s in data.get("streams", []):
            kind = s.get("codec_type", "")
            disp = s.get("disposition", {}) or {}
            if kind == "video" and disp.get("attached_pic"):
                continue  # cover art, not real video
            st_tags = {k.lower(): v for k, v in (s.get("tags") or {}).items()}
            if info.creation_time is None:
                info.creation_time = _parse_time(st_tags.get("creation_time"))
            if not info.duration and s.get("duration"):
                info.duration = float(s["duration"])
            rot = _rotation(s, st_tags) if kind == "video" else 0
            w, h = s.get("width", 0) or 0, s.get("height", 0) or 0
            sar = _sar(s.get("sample_aspect_ratio"))
            if abs(rot) % 180 == 90:                       # shown upright: decoded frames come out turned
                w, h = h, w
                sar = 1.0 / sar if sar else 1.0
            info.streams.append(StreamInfo(
                index=s.get("index", 0), kind=kind, codec=s.get("codec_name", "?"),
                profile=s.get("profile", "") or "",
                width=w, height=h, rotation=rot,
                pix_fmt=s.get("pix_fmt", "") or "",
                fps=_fraction(s.get("avg_frame_rate")) or _fraction(s.get("r_frame_rate")),
                sample_rate=int(s.get("sample_rate") or 0),
                channels=s.get("channels", 0) or 0,
                channel_layout=s.get("channel_layout", "") or "",
                duration=_stream_duration(s, st_tags),
                sar=sar,
            ))
        return info

    # -------------------------------------------------------------------- run
    def run(self, args: list[str], total_seconds: float = 0.0,
            on_progress: Callable[[float], None] | None = None,
            on_log: Callable[[str], None] | None = None,
            cancel_event: threading.Event | None = None) -> None:
        """Run ffmpeg with machine-readable progress. Raises on failure/cancel."""
        self.require()
        cmd = [self.ffmpeg, "-hide_banner", "-nostdin", "-y",
               "-progress", "pipe:1", "-nostats", *args]
        if on_log:
            on_log("> " + subprocess.list2cmdline(cmd))
        _proc.checkpoint()
        scope = _proc.current()
        if cancel_event is None and scope is not None:
            cancel_event = scope.cancel_event
        proc = _proc.popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           text=True, encoding="utf-8", errors="replace")
        stderr_lines: list[str] = []

        def pump_err():
            for line in proc.stderr:
                stderr_lines.append(line.rstrip())
                if on_log and line.strip():
                    on_log(line.rstrip())

        t = threading.Thread(target=pump_err, daemon=True)
        t.start()
        for line in proc.stdout:
            if cancel_event and cancel_event.is_set():
                proc.kill()
                proc.wait()
                raise Cancelled("Cancelled by user")
            key, _, val = line.strip().partition("=")
            if key == "out_time_us" and total_seconds > 0 and on_progress:
                try:
                    on_progress(min(1.0, int(val) / 1e6 / total_seconds))
                except ValueError:
                    pass
        proc.wait()
        t.join(timeout=2)
        if scope:
            scope.remove(proc)
        if cancel_event and cancel_event.is_set():
            raise Cancelled("Cancelled by user")
        if proc.returncode != 0:
            tail = "\n".join(stderr_lines[-8:])
            raise RuntimeError(f"ffmpeg failed (exit {proc.returncode}):\n{tail}")
        if on_progress:
            on_progress(1.0)


def _rotation(stream: dict, tags: dict) -> int:
    """Rotation flag of a video stream: display-matrix side data (newer FFmpeg) or the old 'rotate' tag."""
    for sd in stream.get("side_data_list") or []:
        if "rotation" in sd:
            try:
                return int(round(float(sd["rotation"])))
            except (TypeError, ValueError):
                pass
    try:
        return -int(round(float(tags.get("rotate", 0))))     # old tag counts clockwise
    except (TypeError, ValueError):
        return 0
