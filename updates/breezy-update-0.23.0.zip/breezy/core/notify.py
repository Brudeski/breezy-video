"""Tell the user when work finishes: a Windows notification, and optionally sleep / hibernate / shut
down the PC when the whole queue is done (with a countdown that can be cancelled)."""
from __future__ import annotations

import subprocess
import sys

AFTER = [("Nothing", "nothing"), ("Close Breezy", "close"), ("Sleep", "sleep"), ("Hibernate", "hibernate"),
         ("Shut down", "shutdown")]
listeners: list = []          # called with the new choice when it changes (bottom bar, Tasks page)


def set_after(settings, key: str):
    settings.set("app", "after_queue", key)
    for cb in list(listeners):
        try:
            cb(key)
        except Exception:
            pass
NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


class Notifier:
    def __init__(self, window, settings):
        self.window, self.settings = window, settings
        self.tray = None
        try:
            from PySide6.QtWidgets import QSystemTrayIcon
            if QSystemTrayIcon.isSystemTrayAvailable():
                self.tray = QSystemTrayIcon(window.windowIcon(), window)
                self.tray.setToolTip("Breezy Video")
                self.tray.messageClicked.connect(self._bring_up)
                self.tray.show()
        except Exception:
            self.tray = None

    def _bring_up(self):
        w = self.window
        w.showNormal()
        w.raise_()
        w.activateWindow()

    def task_done(self, task, queue_empty: bool):
        """Called when any task ends."""
        if self.settings.get("app", "notify", True) and self.tray is not None:
            from breezy.core.tasks import DONE
            ok = task.status == DONE
            n = len(task.outputs)
            text = (f"{n} file(s) made" if n else task.message or task.status) if ok else (task.message or task.status)
            if queue_empty:
                text += " - all tasks finished"
            if not self.window.isActiveWindow() or queue_empty:
                self.tray.showMessage(("✔ " if ok else "✖ ") + task.title, text)
        if queue_empty:
            action = self.settings.get("app", "after_queue", "nothing")
            if action != "nothing":
                set_after(self.settings, "nothing")                    # one-off: asked for this queue only
                self._countdown(action)

    def _countdown(self, action: str):
        from PySide6.QtCore import QTimer
        from PySide6.QtWidgets import QMessageBox
        name = {"close": "close Breezy"}.get(action, dict((v, k) for k, v in AFTER).get(action, action).lower())
        box = QMessageBox(self.window)
        box.setWindowTitle("All tasks finished")
        box.setIcon(QMessageBox.Information)
        cancel = box.addButton("Cancel", QMessageBox.RejectRole)
        now = box.addButton(f"{name.capitalize()} now", QMessageBox.AcceptRole)
        left = [60]

        def tick():
            left[0] -= 1
            box.setText(f"All tasks are finished. {'Breezy will close' if action == 'close' else 'The PC will ' + name}"
                        f" in {left[0]} s.")
            if left[0] <= 0:
                timer.stop()
                box.done(0)
                self._run(action)
        timer = QTimer(box, interval=1000)
        timer.timeout.connect(tick)
        who = "Breezy will" if action == "close" else "The PC will"
        box.setText(f"All tasks are finished. {who} {name.replace('close Breezy', 'close')} in 60 s.")
        timer.start()
        self._bring_up()
        box.exec()
        timer.stop()
        if box.clickedButton() is now:
            self._run(action)
        elif box.clickedButton() is cancel:
            pass

    def _run(self, action: str):
        if action == "close":
            getattr(self.window, "quit_app", self.window.close)()
            return
        self._do(action)
        if action == "shutdown":
            getattr(self.window, "quit_app", self.window.close)()

    @staticmethod
    def _do(action: str):
        if sys.platform != "win32":
            return
        try:
            if action == "shutdown":
                subprocess.Popen(["shutdown", "/s", "/t", "0"], creationflags=NO_WINDOW)
            elif action in ("sleep", "hibernate"):
                import ctypes
                ctypes.windll.powrprof.SetSuspendState(action == "hibernate", False, False)
        except Exception:
            pass
