"""Bottom-bar button for 'when all tasks are done' (the same setting as on the Tasks page)."""
from __future__ import annotations

from PySide6.QtWidgets import QMenu, QToolButton

from breezy.core import notify


class WhenDoneButton(QToolButton):
    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.setObjectName("powerSwitch")
        self.settings = settings
        self.setAutoRaise(True)
        self.setPopupMode(QToolButton.InstantPopup)
        self.setToolTip("What to do when every task is finished (once - it goes back to 'Nothing' afterwards).\n"
                        "A 60-second countdown lets you cancel. Also on the Tasks page.\n\n"
                        "When to use: leave long renders running overnight and let the PC sleep or\n"
                        "shut down afterwards.")
        menu = QMenu(self)
        for text, key in notify.AFTER:
            a = menu.addAction(text)
            a.triggered.connect(lambda _=False, k=key: notify.set_after(self.settings, k))
        self.setMenu(menu)
        notify.listeners.append(self._shown)
        self._shown(settings.get("app", "after_queue", "nothing"))

    def _shown(self, key: str):
        name = dict((k, t) for t, k in notify.AFTER).get(key, "Nothing")
        self.setText("⏻ When done" if key == "nothing" else f"⏻ When done: {name}")
