"""Live processor and graphics-card usage for the status bar.

A background thread samples every ~1.5 s:
- processor: psutil
- graphics card: nvidia-smi (NVIDIA: load, video encoder/decoder load, memory), otherwise Windows'
  'GPU Engine' performance counters (any make - the same numbers Task Manager shows)
"""
from __future__ import annotations

import shutil
import subprocess
import sys
import threading
import time

NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0
_state = {"cpu": None, "gpu": None, "enc": None, "dec": None, "mem": None, "mem_total": None, "name": ""}
_started = False
_lock = threading.Lock()


def snapshot() -> dict:
    with _lock:
        return dict(_state)


def _nvidia() -> bool:
    exe = shutil.which("nvidia-smi")
    if not exe:
        return False
    for fields in ("utilization.gpu,utilization.encoder,utilization.decoder,memory.used,memory.total,name",
                   "utilization.gpu,memory.used,memory.total,name"):
        try:
            r = subprocess.run([exe, f"--query-gpu={fields}", "--format=csv,noheader,nounits"], capture_output=True,
                               text=True, timeout=5, creationflags=NO_WINDOW)
        except Exception:
            return False
        line = (r.stdout or "").strip().splitlines()[:1]
        if r.returncode != 0 or not line:
            continue
        v = [x.strip() for x in line[0].split(",")]

        def num(x):
            try:
                return float(x)
            except ValueError:
                return None
        with _lock:
            if len(v) == 6:
                _state.update(gpu=num(v[0]), enc=num(v[1]), dec=num(v[2]), mem=num(v[3]), mem_total=num(v[4]),
                              name=v[5])
            else:
                _state.update(gpu=num(v[0]), mem=num(v[1]), mem_total=num(v[2]), name=v[3])
        return True
    return False


_PS = ("$s=(Get-Counter '\\GPU Engine(*)\\Utilization Percentage' -ErrorAction SilentlyContinue).CounterSamples;"
       "$g=@{}; foreach($x in $s){ if($x.InstanceName -match 'engtype_(\\w+)'){ $k=$matches[1];"
       " $g[$k]=$g[$k]+$x.CookedValue } };"
       "($g.GetEnumerator() | ForEach-Object { $_.Key + '=' + [math]::Round($_.Value,1) }) -join ';'")


def _windows_counters() -> bool:
    if sys.platform != "win32":
        return False
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-Command", _PS], capture_output=True, text=True,
                           timeout=15, creationflags=NO_WINDOW)
    except Exception:
        return False
    parts = dict(p.split("=", 1) for p in (r.stdout or "").strip().split(";") if "=" in p)
    if not parts:
        return False
    vals = {k.lower(): float(v) for k, v in parts.items() if v.replace(".", "", 1).isdigit()}
    busiest = max(vals.values()) if vals else 0.0
    with _lock:
        _state.update(gpu=min(100.0, busiest), enc=min(100.0, vals.get("videoencode", 0.0)) if vals else None,
                      dec=min(100.0, vals.get("videodecode", 0.0)) if vals else None)
    return True


def _loop():
    import psutil
    psutil.cpu_percent(None)
    use_nv, use_win, n = True, True, 0
    while True:
        time.sleep(1.5)
        with _lock:
            _state["cpu"] = psutil.cpu_percent(None)
        if use_nv:
            use_nv = _nvidia()
        if not use_nv and use_win and n % 2 == 0:     # the counters are slower to read: every 3 s
            use_win = _windows_counters()
        n += 1


def start():
    global _started
    if not _started:
        _started = True
        threading.Thread(target=_loop, daemon=True, name="usage").start()


def text(s: dict | None = None) -> tuple[str, str]:
    """(short text for the bar, details for the tooltip)"""
    s = s or snapshot()
    bits = []
    if s["cpu"] is not None:
        bits.append(f"CPU {s['cpu']:.0f}%")
    if s["gpu"] is not None:
        bits.append(f"GPU {s['gpu']:.0f}%")
    tip = []
    if s["name"]:
        tip.append(s["name"])
    if s["gpu"] is not None:
        tip.append(f"Graphics card load: {s['gpu']:.0f}%")
    if s["enc"] is not None:
        tip.append(f"Video encoder: {s['enc']:.0f}%   Video decoder: {s['dec'] or 0:.0f}%")
    if s["mem"] is not None and s["mem_total"] and s["gpu"] is not None:
        tip.append(f"Graphics memory: {s['mem'] / 1024:.1f} of {s['mem_total'] / 1024:.1f} GB")
        bits[-1] += f" · {s['mem'] / 1024:.1f}/{s['mem_total'] / 1024:.0f} GB"
    return "   ".join(bits), "\n".join(tip)
