"""How much of the PC the app may use (Settings → Computer use).

- "full"  : normal priority - the app uses everything it can (default, as before 0.14.2).
- "spare" : only spare power - the app and every tool it starts (FFmpeg...) run at the lowest
            processor priority, and on Windows also at the lowest graphics-card priority, so
            anything you do on the PC comes first.

Optionally, tasks are paused while you use the PC and resumed after it has been idle a while
(IdleWatcher).
"""
from __future__ import annotations

import logging
import os
import sys

log = logging.getLogger(__name__)

MODES = [("Full speed - use all of the PC's power", "full"),
         ("Spare power only - whatever I'm doing comes first", "spare")]

_mode = "full"
listeners: list = []          # called with the new mode after every change (Settings page, bottom bar)


def mode() -> str:
    return _mode


# ------------------------------------------------------------ priorities
def _gpu_priority(pid: int, low: bool) -> None:
    """Windows: graphics-card scheduling priority of a process (idle vs normal)."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        k32 = ctypes.windll.kernel32
        h = k32.OpenProcess(0x0200 | 0x0400, False, pid)      # PROCESS_SET_INFORMATION | QUERY_INFORMATION
        if not h:
            return
        try:
            # D3DKMT_SCHEDULINGPRIORITYCLASS: 0 idle, 1 below normal, 2 normal
            ctypes.windll.gdi32.D3DKMTSetProcessSchedulingPriorityClass(h, 0 if low else 2)
        finally:
            k32.CloseHandle(h)
    except Exception:
        log.debug("GPU priority not set for %s", pid, exc_info=True)


def _cpu_priority(proc, low: bool) -> None:
    import psutil
    try:
        if sys.platform == "win32":
            proc.nice(psutil.IDLE_PRIORITY_CLASS if low else psutil.NORMAL_PRIORITY_CLASS)
        elif low:
            proc.nice(19)
        else:
            try:
                proc.nice(0)              # raising priority again may need rights outside Windows
            except Exception:
                pass
    except Exception:
        log.debug("CPU priority not set", exc_info=True)


def _keep_ui_responsive(low: bool) -> None:
    """In idle priority the window itself would also lag; keep the main (UI) thread a bit higher."""
    if sys.platform != "win32":
        return
    try:
        import ctypes
        k32 = ctypes.windll.kernel32
        k32.SetThreadPriority(k32.GetCurrentThread(), 2 if low else 0)   # HIGHEST within the class / NORMAL
    except Exception:
        pass


def apply_to(pid: int) -> None:
    """Give a newly started tool the current mode (processor priority is inherited on Windows, the
    graphics-card priority is not)."""
    if _mode != "spare":
        return
    try:
        import psutil
        _cpu_priority(psutil.Process(pid), True)
    except Exception:
        pass
    _gpu_priority(pid, True)


def set_mode(m: str) -> None:
    """Apply to this process, its UI thread and every tool already running. Call from the UI thread."""
    global _mode
    _mode = "spare" if m == "spare" else "full"
    low = _mode == "spare"
    try:
        import psutil
        me = psutil.Process(os.getpid())
        _cpu_priority(me, low)
        _gpu_priority(me.pid, low)
        for c in me.children(recursive=True):
            _cpu_priority(c, low)
            _gpu_priority(c.pid, low)
    except Exception:
        log.debug("set_mode", exc_info=True)
    _keep_ui_responsive(low)
    log.info("Computer use: %s", _mode)
    for fn in list(listeners):
        try:
            fn(_mode)
        except Exception:
            log.debug("power listener", exc_info=True)


def switch(settings, m: str) -> None:
    """Change and remember the mode (used by the Settings page and the bottom-bar switch)."""
    settings.set("app", "power_mode", m)
    if m != _mode:
        set_mode(m)


# ------------------------------------------------------------ idle
def idle_seconds() -> float | None:
    """Seconds since the last keyboard/mouse input (Windows), else None."""
    if sys.platform != "win32":
        return None
    try:
        import ctypes

        class LASTINPUTINFO(ctypes.Structure):
            _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]
        li = LASTINPUTINFO()
        li.cbSize = ctypes.sizeof(LASTINPUTINFO)
        if not ctypes.windll.user32.GetLastInputInfo(ctypes.byref(li)):
            return None
        now = ctypes.windll.kernel32.GetTickCount() & 0xFFFFFFFF
        return ((now - li.dwTime) & 0xFFFFFFFF) / 1000.0
    except Exception:
        return None


class IdleWatcher:
    """Pauses running/queued tasks while the PC is in use and resumes them (only those it paused)
    once there has been no keyboard/mouse input for `minutes`."""

    def __init__(self, manager, settings, idle_fn=idle_seconds, notify=None):
        from PySide6.QtCore import QTimer
        self.m, self.settings, self.idle_fn, self.notify = manager, settings, idle_fn, notify
        self.held: list[str] = []
        self.timer = QTimer()
        self.timer.setInterval(3000)
        self.timer.timeout.connect(self.tick)
        self.timer.start()

    @property
    def enabled(self) -> bool:
        return bool(self.settings.get("app", "pause_when_busy", False))

    @property
    def minutes(self) -> float:
        return float(self.settings.get("app", "idle_minutes", 5))

    def tick(self):
        if not self.enabled:
            self.release()
            return
        idle = self.idle_fn()
        if idle is None:
            return
        if idle < 5:                                   # someone is using the PC right now
            new = 0
            for t in list(self.m.active()):
                if t.status != "paused" and t.id not in self.held:
                    self.m.pause(t.id)
                    self.held.append(t.id)
                    new += 1
            if new and self.notify:
                self.notify(f"Tasks paused while you use the PC - they continue after {self.minutes:g} min idle")
        elif idle >= self.minutes * 60:
            self.release()

    def release(self):
        held, self.held = self.held, []
        for tid in held:
            t = self.m.get(tid)
            if t is not None and t.status == "paused":
                self.m.resume(tid)
        if held and self.notify:
            self.notify("The PC is idle - paused tasks continue")

    def status(self) -> str:
        return f"{len(self.held)} task(s) paused while you use the PC" if self.held else ""
