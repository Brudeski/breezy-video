"""Explanatory tooltips for every control (app setting "tooltips", on by default).

Controls that were given a tooltip where they are built keep it.  Anything
left without one is filled from TIPS, keyed by the form-row label or by the
button / tick box text.  A global event filter hides all tooltips when the
user turns them off in Settings.
"""
from __future__ import annotations

import re

from PySide6.QtCore import QEvent, QObject
from PySide6.QtWidgets import (QAbstractButton, QAbstractSlider, QAbstractSpinBox, QComboBox,
                               QFormLayout, QLabel, QLineEdit, QWidget)

CONTROLS = (QAbstractButton, QComboBox, QAbstractSpinBox, QAbstractSlider, QLineEdit)


def clean(text: str) -> str:
    t = (text or "").replace("&&", "\x00").replace("&", "").replace("\x00", "&")
    t = re.sub(r"<[^>]+>", "", t).strip().rstrip(":").strip()
    return t


def _forms(lay):
    if lay is None:
        return
    if isinstance(lay, QFormLayout):
        yield lay
    for i in range(lay.count()):
        it = lay.itemAt(i)
        if it.layout() is not None:
            yield from _forms(it.layout())


def _controls_in(item):
    w = item.widget()
    if w is not None:
        out = [w] if isinstance(w, CONTROLS) else []
        for T in CONTROLS:
            out += w.findChildren(T)
        return out
    lay = item.layout()
    out = []
    if lay is not None:
        for i in range(lay.count()):
            out += _controls_in(lay.itemAt(i))
    return out


def _is_inner(w) -> bool:
    """Line edits/buttons that are part of a spin box or combo box."""
    p = w.parentWidget()
    return isinstance(p, (QAbstractSpinBox, QComboBox))


def rows(root: QWidget):
    """(label widget, [controls]) for every form row under root."""
    widgets = [root] + root.findChildren(QWidget)
    seen = set()
    for wd in widgets:
        for form in _forms(wd.layout()):
            if id(form) in seen:
                continue
            seen.add(id(form))
            for r in range(form.rowCount()):
                lab = form.itemAt(r, QFormLayout.LabelRole)
                fld = form.itemAt(r, QFormLayout.FieldRole)
                if lab is None or fld is None or not isinstance(lab.widget(), QLabel):
                    continue
                yield lab.widget(), [c for c in _controls_in(fld) if not _is_inner(c)]


def apply(root: QWidget, tips: dict | None = None) -> None:
    tips = TIPS if tips is None else tips
    for lab, ctrls in rows(root):
        key = clean(lab.text())
        tip = lab.toolTip() or tips.get(key, "")
        if not tip:
            continue
        if not lab.toolTip():
            lab.setToolTip(tip)
        for c in ctrls:
            if not c.toolTip():
                # buttons inside a row (Browse…, Clear) get their own text tip if there is one
                own = tips.get(clean(c.text())) if isinstance(c, QAbstractButton) else None
                c.setToolTip(own or tip)
    for T in CONTROLS:
        for c in root.findChildren(T):
            if c.toolTip() or _is_inner(c):
                continue
            text = clean(c.text()) if hasattr(c, "text") and not isinstance(c, (QAbstractSpinBox,)) else ""
            if text and text in tips:
                c.setToolTip(tips[text])
            elif isinstance(c, QAbstractSlider) and type(c).__name__ == "QSlider" and c.parentWidget() is not None \
                    and type(c.parentWidget()).__name__ in ("PreviewPanel", "BeforeAfter", "ScrubPreview"):
                c.setToolTip("Drag to move through the video.")
            elif isinstance(c, QLineEdit):
                ph = c.placeholderText()
                c.setToolTip(ph if ph else "The folder used. Type a path or use Browse….")


def missing(root: QWidget):
    out = []
    for T in CONTROLS:
        for c in root.findChildren(T):
            if c.toolTip() or _is_inner(c) or not c.isVisibleTo(root) and not c.isEnabled():
                continue
            if type(c).__name__ in ("QScrollBar",):
                continue
            out.append(c)
    return out


class TooltipGate(QObject):
    """Swallows tooltip events when the user has turned tooltips off."""

    def __init__(self, enabled: bool = True):
        super().__init__()
        self.enabled = enabled

    def eventFilter(self, obj, ev):  # noqa: N802
        if not self.enabled and ev.type() == QEvent.ToolTip:
            return True
        return False


TIPS: dict[str, str] = {
    # ---- shared ------------------------------------------------------------
    "Browse…": "Pick a folder or files from your PC.",
    "Add files…": "Pick one or more video files to add to the list.",
    "Clear": "Empty this box / list.",
    "Include subfolders": "Also look for videos inside folders within this folder.",
    "Open output folder": "Open the folder where this module saves its results. Finished files appear "
                          "here one by one as soon as each is complete.",
    "Save to": "Where finished videos go: the shared Breezy Output folder, next to the originals, "
               "or a folder of your choice.",
    "Custom folder": "The folder used when 'Save to' is set to a folder of your choice.",
    "Folder": "The folder (or files) to work on. You can also drag videos or folders onto the list.",
    "Folders": "How the sorted videos are arranged into folders.",
    "Encoder": "Which encoder makes the new video. Graphics-card encoders are much faster; the "
               "processor (CPU) encoder gives slightly smaller files at the same quality.",
    "Video format": "H.264 plays everywhere. H.265 makes files about 40% smaller but some older "
                    "devices can't play it. AV1 is smallest but slowest and newest.",
    "Re-encoded sound bitrate": "Sound quality when the audio has to be re-encoded. 192 kbps is "
                                "transparent for most video; higher only helps music.",
    "Sound bitrate": "Sound quality of the new file. 192 kbps is transparent for most video.",
    "Count as drifting from": "How far sound and picture may differ in length before it is treated "
                              "as drift and corrected.",
    "Fix audio drift (match the sound to the picture)": "Some cameras record sound that slowly runs "
        "ahead of or behind the picture. This stretches the sound very slightly so lips stay in sync.",
    "Fix audio drift (match each clip's sound to its picture)": "Some cameras record sound that slowly "
        "runs ahead of or behind the picture. This corrects each clip before joining so lips stay in sync.",
    "Use the graphics card to decode video": "Let the graphics card read (decode) the video. Faster and "
        "frees up the processor. Turned off automatically if it fails.",
    # ---- stitcher ----------------------------------------------------------
    "Scan": "Read the videos and work out which clips belong together in one recording.",
    "Compare scenes (end of one clip vs start of the next)": "Checks that the last frame of each clip "
        "looks like the first frame of the next, so clips from different cameras or recordings aren't joined.",
    "Use the graphics card for re-encoding (faster)": "When clips must be re-encoded to join, let the "
        "graphics card do it. Much faster; quality is set by the global quality preset.",
    "Check the result's length after joining": "After joining, confirm the new file is as long as all "
        "the clips added together, so nothing was lost.",
    "▲ Move up": "Move the selected clip earlier in its recording.",
    "▼ Move down": "Move the selected clip later in its recording.",
    "Remove from group": "Take the selected clip out of its recording so it is left as it is.",
    "Group selected": "Join the selected clips into one recording.",
    "Tick all": "Select every recording for stitching.",
    "Untick all": "Clear all selections.",
    "Stitch selected": "Join every ticked recording into one video each. Runs on the Tasks page.",
    "Files read at once": "How many videos are read at the same time while scanning. More is faster "
                          "on SSDs; fewer is gentler on hard drives and network drives.",
    "Scene checks at once": "How many end/start frame comparisons run at the same time.",
    # ---- motion ------------------------------------------------------------
    "Find motion": "Look through the videos for parts with movement. Runs on the Tasks page.",
    "Trim selected": "Save the ticked parts with motion as new videos. Runs on the Tasks page.",
    "▶ Play part": "Play the selected part of the video with motion.",
    "⟲ Replay": "Play the selected part again from the start.",
    "Use the graphics card to decode while analyzing": "Let the graphics card read the video while "
        "looking for motion. Faster and frees up the processor.",
    "Encoder at each cut": "Only a second or two around each cut is re-encoded; the rest is copied "
                           "losslessly. This picks which encoder does that small part.",
    "Re-encode quality": "Quality of the re-encoded parts (lower number = better quality, bigger file).",
    "Videos analyzed at once": "How many videos are checked for motion at the same time.",
    # ---- enhance -----------------------------------------------------------
    "Enhance selected": "Enhance every ticked video with these settings. Runs on the Tasks page.",
    "Keep the frame size (add black bars)": "When changing shape, keep the original frame size and fill "
                                            "the gap with black bars instead of cropping or stretching.",
    "Smooth out colour banding": "Removes the stepped 'bands' that appear in skies and smooth walls in "
                                 "compressed video.",
    "Auto white balance (remove colour casts)": "Removes blue, orange or green tints so whites look white.",
    "Low-light AI only for dark videos (from the check)": "Only use the low-light AI on videos the scan "
        "found to be dark, so bright videos aren't changed.",
    "Blur faces": "Find faces and blur them, for privacy.",
    "Blur licence plates": "Find car licence plates and blur them, for privacy.",
    "Even out the loudness": "Makes quiet and loud parts more even and brings the overall volume to a "
                             "standard level.",
    "Write subtitles from speech": "Listen to the speech and write subtitles automatically (AI).",
    "Translate into English": "Write the subtitles in English, whatever language is spoken.",
    "Save a .srt file next to the video": "Save the subtitles as a separate .srt file that most players "
                                          "load automatically.",
    "Add as a subtitle track (can be turned on/off in players)": "Put the subtitles inside the video as a "
                                                                 "track you can switch on or off.",
    "Burn into the picture (always visible)": "Draw the subtitles onto the picture so they always show, "
                                              "on any device.",
    "10-bit colour (less banding; uses H.265)": "Store more colour shades per pixel. Smoother gradients; "
                                                "needs H.265, which some older devices can't play.",
    "Run the AI on the graphics card": "Run the AI steps on the graphics card. Many times faster than "
                                       "the processor.",
    "Black borders": "Detect and remove black bars around the picture.",
    "Blur style": "How faces and plates are hidden when blurred.",
    "Hide them by": "How faces and plates are hidden.",
    "Brighten dark corners": "Lifts the darker edges and corners some lenses produce (vignetting).",
    "Brighten shadows": "Lifts dark areas without making the bright parts brighter.",
    "Recover highlights": "Brings back detail in bright areas that look washed out.",
    "Brightness": "Makes the whole picture brighter or darker.",
    "Contrast": "Difference between dark and bright parts. Higher looks punchier; lower looks flatter.",
    "Saturation": "How strong colours are. Higher is more vivid; lower is closer to black and white.",
    "Colour strength": "How strongly colour is added to black and white footage.",
    "Burned-in text size": "Size of subtitles drawn onto the picture.",
    "Custom look file": "A .cube colour look (LUT) file of your own.",
    "Look (LUT)": "Apply a ready-made colour look (LUT) to the video.",
    "Look strength": "How strongly the colour look is applied.",
    "Match colours to": "Make the colours match another video or picture.",
    "Match strength": "How strongly the colours are matched.",
    "Face strength": "How strongly the AI restores faces. Lower keeps a more natural look.",
    "Language": "The language spoken in the video. 'Detect' works it out automatically.",
    "Music kept": "How much of the background music is kept when separating voices from music.",
    "New frames by": "How extra frames are made when raising the frame rate or making slow motion.",
    "Noise removal method": "How grain and noise are removed. AI gives the best detail; the others "
                            "are faster.",
    "Remove noise/grain": "How strongly grain and noise are removed. Too much can look smooth or painted.",
    "Output size": "Make the video bigger (upscale) or keep its size.",
    "Target size": "The size to make the video, when upscaling.",
    "Reduce background noise": "Reduce hiss, wind, traffic and other noise behind voices.",
    "Remove compression blocks": "Smooths the square blocks that appear in heavily compressed video.",
    "Remove electrical hum": "Removes the low buzz from mains electricity picked up by some microphones.",
    "Sharpen": "Makes edges crisper. Too much adds halos.",
    "Slow-motion sound": "What happens to the sound when the video is slowed down.",
    # ---- tracker -----------------------------------------------------------
    "Make selected": "Make the chosen outputs for every ticked video. Runs on the Tasks page.",
    "◀ 1 s": "Jump back one second.",
    "1 s ▶": "Jump forward one second.",
    "Show the reframed result": "Show the preview the way the camera will follow the subjects.",
    "Use the graphics card for detection": "Find people and objects using the graphics card. Many times "
                                           "faster than the processor.",
    "Reframed video (camera follows the subjects)": "Make a new video where the frame follows the "
                                                    "people or objects found.",
    "Only the parts with subjects": "Make a lossless cut keeping only the parts where subjects appear.",
    "List of times with subjects (.csv)": "Save a spreadsheet of when subjects appear and leave.",
    "Exact sound cuts in the lossless cut": "Re-encode the sound at each cut so it starts and stops "
                                            "exactly with the picture.",
    "Border around subjects": "Extra space kept around the subjects in the frame.",
    "Border measured as": "Whether the border is a share of the subject's size or a fixed amount.",
    "Keep after they leave": "How long to keep recording after subjects leave.",
    "Keep before subjects appear": "How long to keep before subjects first appear.",
    "Merge gaps shorter than": "Join parts with subjects when the gap between them is shorter than this.",
    "Shape": "The shape of the reframed video, e.g. upright 9:16 for phones.",
    "Videos with nobody in them": "What to do with videos where no subjects are found.",
    "With several subjects": "How the frame behaves when there are several subjects.",
    # ---- organise / duplicates ----------------------------------------------
    "Read videos": "Read the date and camera of each video and preview the new names.",
    "Undo last move": "Put the files from the last rename & sort back where they were.",
    "Rename & sort": "Rename and move the ticked videos as shown.",
    "New names": "The pattern used to name each video.",
    "Put them": "Move the videos into new folders, or leave them where they are.",
    "Unticked copies go": "Where the copies you don't keep are moved: a 'Duplicates' folder (easy to "
                          "undo) or the Recycle Bin.",
    # ---- tasks -------------------------------------------------------------
    "Pause all": "Pause every running task.",
    "Resume all": "Resume every paused task.",
    "Clear finished": "Remove finished, failed and cancelled tasks from the list.",
    # ---- settings ----------------------------------------------------------
    "Theme": "Light, dark, or follow Windows.",
    "At most": "The most tasks that may run at the same time.",
    "Apply": "Use this folder from now on.",
    "Open": "Open this folder.",
    "Check again": "Check again which tools and AI engines are available.",
    "Install NVIDIA engine": "Download and install the faster NVIDIA (CUDA) AI engine for your graphics card.",
    "Scan my PC again": "Check your processor, memory and graphics card again and refresh the "
                        "hardware-specific optimisations.",
    "Check & repair now": "Check the app's files and tools, and repair anything missing or broken.",
    "Clear history": "Forget the list of finished tasks.",
    "Open log/settings folder": "Open the folder with the log files and settings.",
    "Open plugins folder": "Open the folder where extra plugin modules can be added.",
}


# "When to use" advice, appended to every tooltip (user's choice in 0.14.1: longer tooltips with tips).
USE: dict[str, str] = {
    # ---- shared
    "Include subfolders": "Tick it for a camera card or a folder sorted by date; untick it to work on one folder only.",
    "Save to": "Breezy Output keeps everything in one place; 'next to the originals' is handy when each "
               "folder is a separate event.",
    "Folder name": "Change it to keep different jobs apart, e.g. 'Holiday 2026'.",
    "Use output from…": "Use it to chain modules: e.g. stitch, then trim motion, then track - the next step "
                        "waits for the first to finish.",
    "Count as drifting from": "Leave at 0.10 s; raise it only if sound is being stretched on videos that were fine.",
    "Re-encoded sound bitrate": "Automatic is right for almost everything; pick 256-320 kbps for concerts and music.",
    "Sound bitrate": "Keep 192 kbps; use 256-320 kbps for music, 128 kbps to save space on speech.",
    "Encoder": "Use the graphics card for speed (big batches, long videos); the processor for the smallest "
               "files when time doesn't matter.",
    "Video format": "H.264 to share with anyone; H.265 to archive and save space; AV1 only for modern devices.",
    "Fix audio drift (match the sound to the picture)": "Leave on - it only changes videos whose sound "
        "really drifts (common with security cameras and cheap action cameras).",
    "Fix audio drift (match each clip's sound to its picture)": "Leave on - it only changes clips whose sound "
        "really drifts (common with security cameras and cheap action cameras).",
    "Use the graphics card to decode video": "Leave on. Turn off only if previews or results show green "
                                             "blocks or the graphics card is busy with a game.",
    "Open output folder": "Use it while a long job runs to start watching the finished videos.",
    # ---- stitcher
    "Max gap between clips": "Raise it for cameras that pause between files (some dash cams); lower it "
                             "if separate recordings get joined.",
    "Auto-tick groups from": "Raise it to check more groups yourself; lower it when you trust the grouping.",
    "Scene check weight": "Raise it when two cameras recorded at the same time; lower it for cameras that "
                          "change view between clips (pan/tilt cameras).",
    "Container": "'Same as source' is safest; MKV if some pieces have unusual sound or subtitles.",
    "If formats differ": "Only matters when clips differ in size or format - H.264 is the safe choice.",
    "Re-encode quality": "16-18 for keepsakes, 20-23 for everyday clips to save space.",
    "Files read at once": "Use 6-8 on SSDs, 2-3 on USB hard drives and network folders.",
    "Scene checks at once": "Lower it if the PC feels slow while scanning.",
    "Compare scenes (end of one clip vs start of the next)": "Leave on, especially with several cameras; "
        "turn off only for cameras whose view jumps between files.",
    "Keep different cameras apart": "Leave on when more than one camera records the same place.",
    "Use the graphics card for re-encoding (faster)": "Leave on unless you want the very smallest files.",
    "Check the result's length after joining": "Leave on - it catches damaged clips before you delete originals.",
    "Scan": "Start here after choosing the folder.",
    "Group selected": "Use it when the app missed that clips belong together.",
    "Remove from group": "Use it for a clip that doesn't belong to the recording.",
    # ---- duplicates
    "Count as the same from": "Raise it if different videos get grouped; lower it if obvious copies are missed.",
    "Unticked copies go": "Use the Duplicates folder the first time, so you can check before deleting.",
    "Also find the same footage in other files": "Turn on to find copies you re-exported or shrank for "
                                                 "sharing; off is faster for exact copies only.",
    # ---- motion
    "Sensitivity": "10 suits most cameras. Lower it for trees, rain or snow; raise it to catch small "
                   "movement far away.",
    "Keep before motion": "Raise it to see what happened just before (e.g. someone walking into view).",
    "Keep after motion": "Raise it so each clip doesn't end abruptly.",
    "Merge pauses shorter than": "Raise it to get fewer, longer clips; lower it for many short clips.",
    "Ignore motion shorter than": "Raise it if birds, insects or headlights create clips.",
    "Auto-ignore busy areas up to": "Leave on for cameras with a clock or date stamp in the picture.",
    "Analysis rate": "Lower = faster on long security recordings; higher catches very quick movement.",
    "Encoder at each cut": "The graphics card is fine - only a second or two is re-encoded.",
    "Cut quality": "Keep 16 - only a moment around each cut is affected.",
    "If a video must be re-encoded": "Only used for unusual files; leave the default.",
    "Videos analyzed at once": "Raise it on PCs with many processor cores; lower it if the PC is slow while working.",
    "Exact sound cuts (re-encode the trimmed sound once)": "Turn on if you hear a blip or missing sound at "
                                                           "the start of trimmed clips.",
    "Use the graphics card to decode while analyzing": "Leave on - analysis is several times faster.",
    "Find motion": "Start here; check the parts in the preview before trimming.",
    # ---- enhance
    "Content type": "Pick what the video is (or use the recommendation) - it adds the right fixes on top "
                    "of the global quality.",
    "Output size": "2x for SD/old video; Same size for HD that just needs cleaning; 4K only for big screens.",
    "Upscaling": "AI for old and low-quality video; classic when speed matters or the source is already sharp.",
    "AI strength": "70% looks natural for most video; raise it for very soft video, lower it if faces "
                   "or skin look painted.",
    "At 'Same as source' size": "Use the AI clean-up for compressed phone or web video; skip it for good HD.",
    "Deinterlace": "Leave on Automatic - it only acts on old TV, camcorder and DVD video.",
    "Black borders": "Use it for letterboxed or pillarboxed video (e.g. old TV recordings).",
    "Picture shape": "Use Automatic for old 4:3 video that looks stretched; choose a shape if it's still wrong.",
    "Wobble fix strength": "Stronger for cheap action and security cameras; normal for phones.",
    "Stabilise shaky video": "For handheld walking or vehicle video; off for tripod or fixed cameras.",
    "Remove noise/grain": "Higher for dark or night video; lower or off for clean daylight video.",
    "Noise removal method": "AI for the best detail when time allows; best-quality filter for big batches; "
                            "fast for previews.",
    "Remove compression blocks": "For heavily compressed web, messaging and phone video.",
    "AI denoise (very slow)": "For precious, very noisy footage (night, old camcorder); leave off for batches.",
    "AI denoise steadiness": "Raise it if leftover noise crawls or shimmers in still areas.",
    "Remove flicker": "For timelapses, indoor lights and video that pulses in brightness.",
    "Remove haze / fog": "For foggy, hazy or through-the-windshield video.",
    "Old film - dust  specks": "For scanned film; leave off for video (it can remove small real details).",
    "Longest freeze to fix": "Raise it if real frozen moments are being smoothed out.",
    "Fix stutter": "For video with dropped frames or jerky playback.",
    "Straighten fisheye bend": "For GoPro-type and dash cameras with bent lines at the edges.",
    "Fix colour fringes": "For cheap lenses with purple or green edges on high-contrast outlines.",
    "Brighten dark corners": "For lenses with dark corners (vignetting), common on action cameras.",
    "Auto exposure": "For dull or too-dark video; turn off for video that is already well exposed.",
    "Fix lighting  colour per scene": "For edited videos and compilations where scenes differ in brightness "
                                      "or colour.",
    "Brighten shadows": "For backlit people and dark indoor scenes.",
    "Recover highlights": "For bright skies or windows that look white.",
    "Brightness": "Small steps (±5) are usually enough; prefer Auto exposure for whole videos.",
    "Contrast": "Raise a little for flat, washed-out video; lower for harsh sunlight.",
    "Midtones": "Raise to brighten faces without blowing out the sky.",
    "Saturation": "Raise a little for faded old video; lower if colours look neon.",
    "Vibrance": "A gentler way to add colour than Saturation - safer with skin tones.",
    "Low-light AI": "For night and very dark indoor video; it can make bright video look washed out.",
    "Look (LUT)": "For a creative style (film, warm, cool); leave off for faithful restoration.",
    "Custom look file": "For a .cube look from a camera maker or an editing app.",
    "Look strength": "Lower it if the look is too strong.",
    "Match colours to": "To make videos from different cameras look alike.",
    "Match strength": "Lower it if the result looks odd.",
    "HDR": "HDR → SDR for washed-out iPhone/Android HDR videos; SDR → HDR only for HDR TVs.",
    "Restore faces": "For old or blurry footage of people; check the preview, as faces can change slightly.",
    "Face strength": "Lower it if faces look too smooth or slightly different from the person.",
    "Only faces at least": "Raise it if small background faces look odd.",
    "Colourise": "For black & white footage; 'only black & white' is safe for mixed folders.",
    "Colour strength": "Lower it if colours look too bright for old footage.",
    "Hide stamps / logos": "For date stamps, clocks and channel logos.",
    "Hide them by": "Blur keeps the scene readable; black box hides completely.",
    "Blur style": "Pixelate is the most obvious; strong blur looks smoother.",
    "Remove from the video": "To remove passers-by or cars from scenery video (slow).",
    "Fill the space with": "Automatic is best; AI fill for moving cameras.",
    "Extra margin": "Raise it if edges or shadows of removed things remain.",
    "Sharpen": "A little for soft video; avoid for noisy video (it sharpens the noise).",
    "AI deblur (very slow)": "For important blurry clips (shake, missed focus); leave off for batches.",
    "Add fine film grain": "After heavy noise removal or upscaling, to avoid a plastic look.",
    "Frame rate": "60 fps for smooth sports and gaming; keep the original for film-like video.",
    "Slow motion": "For action moments; 2x looks natural, 8x needs good light and sharp video.",
    "Slow-motion sound": "Mute is usually best; pitch-corrected works for speech at 2x.",
    "Level the horizon": "For handheld and boat/vehicle video that leans.",
    "Clean up voices (AI)": "For talking in noisy places; not for music.",
    "Rebuild sound (AI)": "For phone calls, security cameras and other thin, muffled sound.",
    "Voices  music (AI)": "To remove background music, or to keep only the music.",
    "Music kept": "25% keeps a little atmosphere; 0% for speech only.",
    "Repair distorted sound": "For loud concerts, shouting or wind that crackles.",
    "Remove wind noise": "For outdoor and action-camera video.",
    "Widen sound": "For mono recordings that sound narrow on headphones.",
    "Reduce background noise": "For hiss and steady noise; use 'Clean up voices' for busy places.",
    "Remove electrical hum": "When you hear a low buzz - 50 Hz in Europe, 60 Hz in North America.",
    "Even out the loudness": "For video with quiet speech and loud moments, or to match volume across videos.",
    "Speech model": "Medium for best accuracy; small or base for quick drafts.",
    "Language": "Set it when the language is known - detection can misjudge short clips.",
    "Write subtitles from speech": "For videos with talking, to search or share without sound.",
    "Translate into English": "For videos in another language.",
    "Burn into the picture (always visible)": "For sharing on apps that don't show subtitle tracks.",
    "Burned-in text size": "Bigger for phones, smaller for TVs.",
    "Before/after video": "To show someone the improvement or to compare settings.",
    "File size": "Aim at a size for messaging apps and email; use quality for keepsakes.",
    "Quality": "16 for keepsakes, 20-23 for everyday clips.",
    "10-bit colour (less banding; uses H.265)": "For skies, sunsets and gradients; off when sharing to old devices.",
    "AI tile size": "Lower it if the AI fails with an out-of-memory error.",
    "Videos at once": "Automatic is right; lower it if the PC stutters while enhancing.",
    "Run the AI on the graphics card": "Leave on - turn off only if the AI fails on this graphics card.",
    "Use the graphics card for slow filters (best-quality noise removal)": "Leave on - it is much faster.",
    "Long videos: keep the finished minutes if stopped": "Leave on, especially for long or overnight jobs.",
    "Skip AI upscaling for videos already 4K": "Leave on - AI on 4K is extremely slow for little gain.",
    "Check videos": "Videos are scanned automatically when added; use this to scan again.",
    "Preview with AI": "Use it before a long job to check faces, detail and the AI strength.",
    "Apply recommendation": "Use it for each new kind of video, then fine-tune if needed.",
    "Scan videos automatically when they're added": "Leave on; turn off for very big folders on slow drives.",
    "Adjust each video to its own scan automatically": "Turn on for mixed folders (day and night, colour and "
                                                       "black & white).",
    "Keep the frame size (add black bars)": "For players or editors that need the original size.",
    "Fix rolling-shutter wobble": "For phone, drone and action-camera video with jelly-like wobble.",
    "Smooth out colour banding": "For skies and walls that show steps in colour.",
    "Auto white balance (remove colour casts)": "For video that looks too blue, orange or green.",
    "Low-light AI only for dark videos (from the check)": "Leave on for mixed folders.",
    "Blur faces": "Before sharing video of people who didn't agree to be filmed.",
    "Blur licence plates": "Before sharing dash-cam or street video.",
    # ---- tracker
    "Detector": "Fast for big batches of close-up video; accurate for far-away or small subjects.",
    "Look for subjects": "More often for sports and pets; less often for slow scenes and long videos.",
    "Subjects": "Choose only what you want followed - fewer types means fewer false hits.",
    "Confidence at least": "Lower it if subjects are missed; raise it if the camera follows wrong things.",
    "Ignore subjects smaller than": "Raise it to ignore people far in the background.",
    "With several subjects": "'All' keeps everyone in frame; 'largest' for one main person.",
    "Border measured as": "Share of size suits most video; a fixed amount for consistent framing.",
    "Border around subjects": "More for action (room to move), less for tight portraits.",
    "Smoothness": "Higher for calm, cinematic movement; lower to follow fast action closely.",
    "Camera timing": "Anticipate looks the most natural.",
    "Max zoom": "Lower it for low-resolution video so it doesn't look blurry.",
    "When nobody is visible": "Longer for subjects that pop in and out of view.",
    "Shape": "9:16 for phones, TikTok and Reels; 1:1 for feeds; 16:9 for TV.",
    "Resolution": "1080 for sharing; lower for quick drafts.",
    "When both videos are ticked": "Combined for short highlight clips; separate to keep both versions.",
    "Videos with nobody in them": "Skip saves time and space on security recordings.",
    "Keep before subjects appear": "Raise it to see them arrive.",
    "Keep after they leave": "Raise it so clips don't end abruptly.",
    "Merge gaps shorter than": "Raise it for fewer, longer clips.",
    "Lossless cut edges": "Leave the default unless cuts look wrong.",
    "Use the graphics card for detection": "Leave on - detection is many times faster.",
    "Reframed video (camera follows the subjects)": "For turning wide video into phone-shaped clips.",
    "Only the parts with subjects": "For long recordings where people or animals appear now and then.",
    "List of times with subjects (.csv)": "To review or log activity in a spreadsheet.",
    "Exact sound cuts in the lossless cut": "Turn on if sound blips at the start of clips.",
    "Find subjects": "Use it to check the framing before making long videos.",
    # ---- organise
    "New names": "Date & time names sort correctly in every app.",
    "Name pattern": "Add {camera} when several cameras record the same day.",
    "Folders": "Year / month suits most collections; per day for busy cameras.",
    "Folder pattern": "Use / to make subfolders, e.g. {year}/{month}.",
    "Put them": "Copy the first time to check the result, move once you trust it.",
    "Read videos": "Start here; nothing moves until you press Rename & sort.",
    "Undo last move": "If the names or folders aren't what you wanted.",
    # ---- tasks
    "Notify me": "Leave on so you can work in other apps while long jobs run.",
    # ---- settings
    "Run side by side": "'When they don't compete' gets the most out of the PC; 'one at a time' if the "
                        "PC gets hot or slow.",
    "At most": "2-3 is a good balance.",
    "Engine": "NVIDIA CUDA on NVIDIA cards; DirectML for any other graphics card.",
    "Install NVIDIA engine": "Once, on PCs with an NVIDIA card - the AI is usually much faster.",
    "Scan my PC again": "After changing the graphics card or updating its driver.",
    "Download missing or damaged parts automatically": "Leave on.",
    "Check & repair now": "If a module reports a missing tool or model.",
}


def advise(root: QWidget, use: dict | None = None) -> None:
    """Append the 'When to use' advice to every tooltip (once)."""
    use = USE if use is None else use

    def add(w, key):
        tip = use.get(key)
        if not tip or w.property("breezyAdvised"):
            return
        w.setProperty("breezyAdvised", True)
        cur = w.toolTip()
        w.setToolTip(f"{cur}\n\nWhen to use: {tip}" if cur else f"When to use: {tip}")

    for lab, ctrls in rows(root):
        key = clean(lab.text())
        add(lab, key)
        for c in ctrls:
            own = clean(c.text()) if isinstance(c, QAbstractButton) else ""
            add(c, own if own in use else key)
    for c in root.findChildren(QAbstractButton):
        add(c, clean(c.text()))
    wrap(root)


def _wrap_text(text: str, width: int = 80) -> str:
    import textwrap
    if not text or text.lstrip().startswith("<"):
        return text           # rich text wraps by itself
    out = []
    for line in text.split("\n"):
        out.append(textwrap.fill(line, width) if len(line) > width else line)
    return "\n".join(out)


def wrap(root: QWidget) -> None:
    """Long plain-text tooltips would be one very wide line - break them at ~80 characters."""
    for w in [root] + root.findChildren(QWidget):
        t = w.toolTip()
        if t and any(len(line) > 80 for line in t.split("\n")):
            w.setToolTip(_wrap_text(t))
