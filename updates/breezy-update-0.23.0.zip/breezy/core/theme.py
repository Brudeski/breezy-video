"""Light / dark themes. 'auto' follows Windows (user's choice), switchable in Settings."""
from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtGui import QColor, QGuiApplication, QPalette

ACCENT = "#3b82f6"

LIGHT = dict(bg="#f3f5f9", panel="#ffffff", panel2="#f8fafc", border="#e2e7ef", text="#1f2937",
             muted="#6b7280", accent=ACCENT, accent_hover="#2563eb", accent_text="#ffffff",
             sidebar="#121826", sidebar_text="#cbd5e1", sidebar_sel="#1f2a44", input="#ffffff",
             good="#15803d", warn="#b45309", bad="#dc2626", chip="#eef2ff", alt="#f8fafc",
             sel="#dbeafe", sel_text="#1e3a8a")
DARK = dict(bg="#14171c", panel="#1b1f26", panel2="#20252d", border="#2c323c", text="#e5e7eb",
            muted="#9aa3b2", accent=ACCENT, accent_hover="#60a5fa", accent_text="#ffffff",
            sidebar="#0d1015", sidebar_text="#aab4c3", sidebar_sel="#1d2738", input="#12151a",
            good="#4ade80", warn="#fbbf24", bad="#f87171", chip="#1e293b", alt="#1e232b",
            sel="#1e3a5f", sel_text="#e0ecff")

_current = dict(LIGHT)


def colors() -> dict:
    return _current


def system_is_dark() -> bool:
    try:
        return QGuiApplication.styleHints().colorScheme() == Qt.ColorScheme.Dark
    except Exception:
        return False


def resolve(mode: str) -> bool:
    return system_is_dark() if mode == "auto" else mode == "dark"


def apply(app, mode: str = "auto") -> bool:
    dark = resolve(mode)
    c = DARK if dark else LIGHT
    _current.clear()
    _current.update(c)
    pal = QPalette()
    for role, key in ((QPalette.Window, "bg"), (QPalette.Base, "input"), (QPalette.AlternateBase, "alt"),
                      (QPalette.Text, "text"), (QPalette.WindowText, "text"), (QPalette.Button, "panel"),
                      (QPalette.ButtonText, "text"), (QPalette.ToolTipBase, "panel"),
                      (QPalette.ToolTipText, "text"), (QPalette.Highlight, "accent"),
                      (QPalette.HighlightedText, "accent_text"), (QPalette.PlaceholderText, "muted")):
        pal.setColor(role, QColor(c[key]))
    pal.setColor(QPalette.Disabled, QPalette.Text, QColor(c["muted"]))
    pal.setColor(QPalette.Disabled, QPalette.ButtonText, QColor(c["muted"]))
    pal.setColor(QPalette.Disabled, QPalette.WindowText, QColor(c["muted"]))
    app.setPalette(pal)
    app.setStyleSheet(qss(c) + _indicator_qss(c, dark))
    return dark


def _indicator_qss(c: dict, dark: bool) -> str:
    """Checkbox ticks and spin/combo arrows as small tinted images."""
    try:
        from breezy.core.icons import save_png
        from breezy.core.settings import app_data_dir
        d = app_data_dir() / "theme"
        d.mkdir(exist_ok=True)
        tag = "d" if dark else "l"
        tick = save_png("check", "#ffffff", 12, d / f"check_{tag}.png")
        dash = save_png("dash", "#ffffff", 12, d / f"dash_{tag}.png")
        up = save_png("caret_up", c["text"], 10, d / f"up_{tag}.png")
        down = save_png("caret_down", c["text"], 10, d / f"down_{tag}.png")
    except Exception:
        return ""
    return f"""
QCheckBox::indicator, QTreeWidget::indicator, QListWidget::indicator {{ width: 16px; height: 16px; border-radius: 4px;
  border: 1.5px solid {c['muted']}; background: {c['input']}; }}
QCheckBox::indicator:hover, QTreeWidget::indicator:hover, QListWidget::indicator:hover {{ border-color: {c['accent']}; }}
QCheckBox::indicator:checked, QTreeWidget::indicator:checked, QListWidget::indicator:checked {{ background: {c['accent']};
  border-color: {c['accent']}; image: url("{tick}"); }}
QListWidget::item {{ padding: 3px 4px; }}
QTreeWidget::indicator:indeterminate {{ background: {c['accent']}; border-color: {c['accent']}; image: url("{dash}"); }}
QCheckBox::indicator:disabled {{ background: {c['panel2']}; border-color: {c['border']}; }}
QAbstractSpinBox {{ padding-right: 22px; }}
QAbstractSpinBox::up-button, QAbstractSpinBox::down-button {{ subcontrol-origin: border; width: 20px;
  border: none; background: transparent; }}
QAbstractSpinBox::up-button {{ subcontrol-position: top right; margin-top: 2px; }}
QAbstractSpinBox::down-button {{ subcontrol-position: bottom right; margin-bottom: 2px; }}
QAbstractSpinBox::up-button:hover, QAbstractSpinBox::down-button:hover {{ background: {c['panel2']}; border-radius: 4px; }}
QAbstractSpinBox::up-arrow {{ image: url("{up}"); width: 10px; height: 10px; }}
QAbstractSpinBox::down-arrow {{ image: url("{down}"); width: 10px; height: 10px; }}
QComboBox::down-arrow {{ image: url("{down}"); width: 10px; height: 10px; }}
"""


def qss(c: dict) -> str:
    return f"""
* {{ font-family: "Segoe UI", "Inter", sans-serif; font-size: 10pt; }}
QMainWindow, QWidget#page, QWidget#content {{ background: {c['bg']}; color: {c['text']}; }}
QToolTip {{ background: {c['panel']}; color: {c['text']}; border: 1px solid {c['border']}; padding: 6px; }}

/* sidebar */
QWidget#sidebar {{ background: {c['sidebar']}; }}
QLabel#brand {{ color: white; font-size: 12pt; font-weight: 700; padding: 4px 6px; }}
QLabel#brandVersion {{ color: {c['sidebar_text']}; font-size: 8.5pt; padding: 0 8px; }}
QListWidget#nav {{ background: transparent; border: none; color: {c['sidebar_text']}; outline: 0; }}
QListWidget#nav::item {{ padding: 9px 10px; margin: 2px 8px; border-radius: 8px; }}
QListWidget#nav::item:hover {{ background: {c['sidebar_sel']}; color: white; }}
QListWidget#nav::item:selected {{ background: {c['accent']}; color: white; }}
QToolButton#collapse {{ background: transparent; border: none; color: {c['sidebar_text']}; padding: 6px; border-radius: 6px; }}
QToolButton#collapse:hover {{ background: {c['sidebar_sel']}; }}
QToolButton#qualityMore {{ background: transparent; border: 1px solid {c['sidebar_text']}; color: {c['sidebar_text']};
    border-radius: 5px; padding: 0px 5px; font-size: 12px; font-weight: 700; min-width: 16px; min-height: 16px; }}
QComboBox#qualityCombo {{ font-size: 12px; padding-left: 6px; }}
QToolButton#qualityMore:hover {{ background: {c['sidebar_sel']}; }}
QToolButton#powerSwitch {{ border: 1px solid {c['border']}; border-radius: 6px; padding: 2px 8px; margin-right: 8px; }}
QToolButton#powerSwitch:checked {{ background: {c['accent']}; color: white; border-color: {c['accent']}; }}
QToolButton#qualityMore::menu-indicator {{ image: none; width: 0; }}
QLabel#navBadge {{ color: {c['sidebar_text']}; font-size: 8.5pt; padding: 2px 12px; }}

/* page header */
QLabel#pageTitle {{ font-size: 18pt; font-weight: 700; color: {c['text']}; }}
QLabel#pageDesc {{ color: {c['muted']}; }}
QLabel#muted, QLabel[muted="true"] {{ color: {c['muted']}; }}
QLabel#sectionTitle {{ font-weight: 700; color: {c['text']}; font-size: 10.5pt; }}

/* cards */
QFrame#card {{ background: {c['panel']}; border: 1px solid {c['border']}; border-radius: 12px; }}
QFrame#card QLabel {{ background: transparent; }}
QLabel#cardTitle {{ font-weight: 700; font-size: 10.5pt; color: {c['text']}; }}
QScrollArea, QScrollArea > QWidget > QWidget {{ background: transparent; border: none; }}

/* inputs */
QLineEdit, QComboBox, QSpinBox, QDoubleSpinBox {{
  background: {c['input']}; color: {c['text']}; border: 1px solid {c['border']}; border-radius: 7px;
  padding: 5px 8px; selection-background-color: {c['accent']}; }}
QLineEdit:focus, QComboBox:focus, QSpinBox:focus, QDoubleSpinBox:focus {{ border: 1px solid {c['accent']}; }}
QComboBox::drop-down {{ border: none; width: 22px; }}
QComboBox QAbstractItemView {{ background: {c['panel']}; color: {c['text']}; border: 1px solid {c['border']};
  selection-background-color: {c['sel']}; selection-color: {c['sel_text']}; }}
QCheckBox, QRadioButton {{ color: {c['text']}; spacing: 8px; background: transparent; }}

QPushButton {{ background: {c['panel2']}; color: {c['text']}; border: 1px solid {c['border']};
  border-radius: 8px; padding: 7px 14px; }}
QPushButton:hover {{ border-color: {c['accent']}; }}
QPushButton:pressed {{ background: {c['sel']}; }}
QPushButton:disabled {{ color: {c['muted']}; background: {c['panel']}; border-color: {c['border']}; }}
QPushButton#primary {{ background: {c['accent']}; color: {c['accent_text']}; border: none; font-weight: 600; padding: 8px 18px; }}
QPushButton#primary:hover {{ background: {c['accent_hover']}; }}
QPushButton#primary:disabled {{ background: {c['border']}; color: {c['muted']}; }}
QPushButton#danger {{ color: {c['bad']}; }}
QToolButton {{ background: transparent; border: 1px solid transparent; border-radius: 6px; padding: 4px; color: {c['text']}; }}
QToolButton:hover {{ border-color: {c['border']}; background: {c['panel2']}; }}

/* lists */
QTreeWidget, QListWidget#plain, QTableWidget, QPlainTextEdit, QTextBrowser {{
  background: {c['panel']}; color: {c['text']}; border: 1px solid {c['border']}; border-radius: 10px;
  alternate-background-color: {c['alt']}; }}
QTreeWidget::item {{ padding: 3px 2px; }}
QTreeWidget::item:selected, QListWidget#plain::item:selected {{ background: {c['sel']}; color: {c['sel_text']}; }}
QHeaderView::section {{ background: {c['panel2']}; color: {c['muted']}; border: none;
  border-bottom: 1px solid {c['border']}; border-right: 2px solid {c['border']}; padding: 6px; font-weight: 600; }}
QHeaderView::section:hover {{ background: {c['panel']}; color: {c['text']}; }}
QPlainTextEdit {{ font-family: "Cascadia Mono", Consolas, monospace; font-size: 9pt; }}

/* progress */
QProgressBar {{ background: {c['panel2']}; border: 1px solid {c['border']}; border-radius: 7px;
  text-align: center; color: {c['text']}; min-height: 14px; }}
QProgressBar::chunk {{ background: {c['accent']}; border-radius: 6px; }}
QFrame#taskbar {{ background: {c['panel']}; border-top: 1px solid {c['border']}; }}
QLabel#taskTitle {{ font-weight: 600; color: {c['text']}; }}
QLabel#taskInfo {{ color: {c['muted']}; }}

QSlider::groove:horizontal {{ height: 6px; background: {c['border']}; border-radius: 3px; }}
QSlider::sub-page:horizontal {{ background: {c['accent']}; border-radius: 3px; }}
QSlider::handle:horizontal {{ background: white; border: 2px solid {c['accent']}; width: 14px; margin: -6px 0; border-radius: 8px; }}
QSplitter::handle {{ background: transparent; }}
QSplitter::handle:hover {{ background: {c['border']}; }}
QScrollBar:vertical {{ background: transparent; width: 10px; margin: 2px; }}
QScrollBar::handle:vertical {{ background: {c['border']}; border-radius: 4px; min-height: 30px; }}
QScrollBar:horizontal {{ background: transparent; height: 10px; margin: 2px; }}
QScrollBar::handle:horizontal {{ background: {c['border']}; border-radius: 4px; min-width: 30px; }}
QScrollBar::add-line, QScrollBar::sub-line {{ width: 0; height: 0; }}
QTabWidget::pane {{ border: none; }}
QTabBar::tab {{ background: transparent; color: {c['muted']}; padding: 6px 12px; border-bottom: 2px solid transparent; }}
QTabBar::tab:selected {{ color: {c['text']}; border-bottom: 2px solid {c['accent']}; }}
QMenu {{ background: {c['panel']}; color: {c['text']}; border: 1px solid {c['border']}; }}
QMenu::item:selected {{ background: {c['sel']}; color: {c['sel_text']}; }}
QDialog {{ background: {c['bg']}; color: {c['text']}; }}
"""
