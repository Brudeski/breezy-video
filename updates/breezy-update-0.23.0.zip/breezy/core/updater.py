"""Updates from the public GitHub repository (releases only, no login needed).

The repository holds:
    latest.json                         {"version", "notes": [...], "update": "<path>", "sha256", "installer"}
    updates/breezy-update-<ver>.zip     the program files (breezy/, main.py, scripts, requirements)
    installers/BreezyVideoSetup-<ver>.exe

Updating = download the zip, check its SHA-256, keep a backup of the current program files, copy the new
ones over them, restart. New components (requirements.txt) are installed by bootstrap on the next start.
The .venv, models, FFmpeg (bin) and plugins folders are never touched.
"""
from __future__ import annotations

import hashlib
import json
import shutil
import ssl
import sys
import tempfile
import time
import urllib.request
import zipfile
from pathlib import Path
from typing import Callable

from PySide6.QtCore import QObject, Signal

from breezy import __version__
from breezy.core.settings import app_data_dir

DEFAULT_REPO = "Brudeski/breezy-video"
APP_DIR = Path(__file__).resolve().parents[2]
_KEEP = {".venv", "bin", "plugins", "_to_delete", "dist", "build"}        # never replaced or removed
_ALLOWED_HOSTS = ("raw.githubusercontent.com", "github.com", "objects.githubusercontent.com")


def _ver(v: str):
    from packaging.version import Version
    try:
        return Version(v.lstrip("v"))
    except Exception:
        return Version("0")


def repo(settings) -> str:
    return (settings.get("app", "update_repo", "") if settings else "") or DEFAULT_REPO


def raw_url(settings, path: str) -> str:
    return f"https://raw.githubusercontent.com/{repo(settings)}/main/{path.lstrip('/')}"


def _get(url: str, timeout: int = 20) -> bytes:
    host = url.split("/")[2]
    if not url.startswith("https://") or host not in _ALLOWED_HOSTS:
        raise RuntimeError(f"refusing to download from {host}")
    req = urllib.request.Request(url, headers={"User-Agent": f"BreezyVideo/{__version__}"})
    with urllib.request.urlopen(req, timeout=timeout, context=ssl.create_default_context()) as r:
        return r.read()


def check(settings) -> dict | None:
    """The newest version's info if it's newer than this one, else None. Raises on network trouble."""
    info = json.loads(_get(raw_url(settings, "latest.json") + f"?t={int(time.time())}").decode("utf-8"))
    if _ver(info.get("version", "0")) > _ver(__version__):
        return info
    return None


def download(settings, info: dict, progress: Callable[[float], None] = lambda f: None) -> Path:
    url = raw_url(settings, info["update"])
    d = app_data_dir() / "updates"
    d.mkdir(parents=True, exist_ok=True)
    dest = d / Path(info["update"]).name
    host = url.split("/")[2]
    if host not in _ALLOWED_HOSTS:
        raise RuntimeError("bad update address")
    req = urllib.request.Request(url, headers={"User-Agent": f"BreezyVideo/{__version__}"})
    h = hashlib.sha256()
    with urllib.request.urlopen(req, timeout=60, context=ssl.create_default_context()) as r, open(dest, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        got = 0
        while True:
            chunk = r.read(1 << 16)
            if not chunk:
                break
            f.write(chunk)
            h.update(chunk)
            got += len(chunk)
            if total:
                progress(got / total)
    if info.get("sha256") and h.hexdigest().lower() != info["sha256"].lower():
        dest.unlink(missing_ok=True)
        raise RuntimeError("the download is damaged (its fingerprint doesn't match) - try again later")
    return dest


def can_update_in_place() -> str:
    """'' when this install can update itself, else why not."""
    if getattr(sys, "frozen", False):
        return "This is a built .exe version - download the new installer instead."
    if not (APP_DIR / "main.py").is_file() or not (APP_DIR / "breezy" / "__init__.py").is_file():
        return "The program folder wasn't found."
    probe = APP_DIR / "breezy" / ".write_test"
    try:
        probe.write_text("x")
        probe.unlink()
    except OSError:
        return "The program folder can't be written to."
    return ""


def _backup(dest: Path):
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for p in (APP_DIR / "breezy").rglob("*"):
            if p.is_file() and "__pycache__" not in p.parts and "models" not in p.relative_to(APP_DIR).parts[:2]:
                z.write(p, p.relative_to(APP_DIR))
        for p in APP_DIR.glob("*"):
            if p.is_file() and p.suffix.lower() in (".py", ".bat", ".ps1", ".txt", ".md"):
                z.write(p, p.relative_to(APP_DIR))


def apply(zip_path: Path, expect_version: str | None = None) -> str:
    """Copy the new program files over the current ones. Returns the version installed."""
    why = can_update_in_place()
    if why:
        raise RuntimeError(why)
    tmp = Path(tempfile.mkdtemp(prefix="breezy_update_"))
    try:
        with zipfile.ZipFile(zip_path) as z:
            for n in z.namelist():
                if n.startswith("/") or ".." in Path(n).parts:
                    raise RuntimeError("the update contains a bad file name")
            z.extractall(tmp)
        init = tmp / "breezy" / "__init__.py"
        if not (tmp / "main.py").is_file() or not init.is_file():
            raise RuntimeError("the update is incomplete")
        new_ver = next((ln.split("=", 1)[1].strip().strip('"\'') for ln in init.read_text("utf-8").splitlines()
                        if ln.startswith("__version__")), "")
        if expect_version and new_ver != expect_version:
            raise RuntimeError(f"the update is version {new_ver}, expected {expect_version}")
        bdir = app_data_dir() / "updates"
        bdir.mkdir(parents=True, exist_ok=True)
        _backup(bdir / f"backup-{__version__}.zip")
        # files of the old version that the new one doesn't have any more (removed modules)
        new_py = {p.relative_to(tmp) for p in (tmp / "breezy").rglob("*.py")}
        for p in (APP_DIR / "breezy").rglob("*.py"):
            rel = p.relative_to(APP_DIR)
            if rel not in new_py and "models" not in rel.parts[:2]:
                p.unlink(missing_ok=True)
        for src in tmp.rglob("*"):
            rel = src.relative_to(tmp)
            if rel.parts[0] in _KEEP:
                continue
            dst = APP_DIR / rel
            if src.is_dir():
                dst.mkdir(parents=True, exist_ok=True)
            else:
                dst.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, dst)
        for c in (APP_DIR / "breezy").rglob("__pycache__"):
            shutil.rmtree(c, ignore_errors=True)
        return new_ver
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


class UpdateChecker(QObject):
    """Checks in the background (at start and once a day) and tells the window."""
    found = Signal(dict)
    failed = Signal(str)
    nothing = Signal()

    def __init__(self, settings, parent=None):
        super().__init__(parent)
        self.settings = settings

    def check_soon(self, manual: bool = False):
        import threading
        if not manual:
            if not self.settings.get("app", "update_auto", True):
                return
            if time.time() - float(self.settings.get("app", "update_checked", 0) or 0) < 20 * 3600:
                return

        def work():
            try:
                info = check(self.settings)
                self.settings.set("app", "update_checked", time.time())
                if info:
                    self.found.emit(info)
                elif manual:
                    self.nothing.emit()
            except Exception as e:  # noqa - offline etc.
                if manual:
                    self.failed.emit(str(e).splitlines()[0] if str(e) else type(e).__name__)
        threading.Thread(target=work, daemon=True).start()
