"""Process tracking for tasks: instant pause/resume and cancel.

Every task runs inside a `Scope`. Any FFmpeg/FFprobe process started from a
thread bound to that scope is registered with it, so pausing the task freezes
those processes immediately (suspend), resuming continues them, and cancelling
kills them. Python-side loops call `checkpoint()` to wait while paused.
"""
from __future__ import annotations

import subprocess
import sys
import threading
from concurrent.futures import ThreadPoolExecutor
from typing import Optional

try:
    import psutil
except ImportError:  # pragma: no cover - pause then only affects Python loops
    psutil = None

NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


class Cancelled(RuntimeError):
    pass


class Scope:
    def __init__(self):
        self._procs: set[subprocess.Popen] = set()
        self._lock = threading.Lock()
        self.running = threading.Event()   # set = not paused
        self.running.set()
        self.cancel_event = threading.Event()
        self.enc_speed = "balanced"        # encoder speed of the task's quality level (quality | balanced | fast)

    # -------------------------------------------------------------- processes
    def add(self, p: subprocess.Popen):
        with self._lock:
            self._procs.add(p)
        if not self.running.is_set():
            _suspend(p)

    def remove(self, p: subprocess.Popen):
        with self._lock:
            self._procs.discard(p)

    def _each(self, fn):
        with self._lock:
            procs = list(self._procs)
        for p in procs:
            if p.poll() is None:
                fn(p)

    # ------------------------------------------------------------------ state
    @property
    def paused(self) -> bool:
        return not self.running.is_set()

    def pause(self):
        self.running.clear()
        self._each(_suspend)

    def resume(self):
        self._each(_resume)
        self.running.set()

    def cancel(self):
        self.cancel_event.set()
        self._each(_resume)
        self._each(lambda p: p.kill())
        self.running.set()

    def checkpoint(self):
        """Call from long loops: waits while paused, raises Cancelled if cancelled."""
        if self.cancel_event.is_set():
            raise Cancelled("Cancelled by user")
        self.running.wait()
        if self.cancel_event.is_set():
            raise Cancelled("Cancelled by user")


def _suspend(p):
    if psutil:
        try:
            psutil.Process(p.pid).suspend()
        except Exception:
            pass


def _resume(p):
    if psutil:
        try:
            psutil.Process(p.pid).resume()
        except Exception:
            pass


# ------------------------------------------------------------ thread binding
_local = threading.local()


def bind(scope: Optional[Scope]):
    _local.scope = scope


def current() -> Optional[Scope]:
    return getattr(_local, "scope", None)


def checkpoint():
    s = current()
    if s:
        s.checkpoint()


def pool(max_workers: int) -> ThreadPoolExecutor:
    """A thread pool whose threads belong to the caller's task scope."""
    return ThreadPoolExecutor(max_workers=max(1, max_workers), initializer=bind, initargs=(current(),))


# -------------------------------------------------------------- subprocesses
def popen(cmd: list[str], **kw) -> subprocess.Popen:
    kw.setdefault("creationflags", NO_WINDOW)
    p = subprocess.Popen(cmd, **kw)
    try:
        from breezy.core import power
        power.apply_to(p.pid)          # 'spare power only': lowest processor/graphics-card priority
    except Exception:
        pass
    s = current()
    if s:
        s.add(p)
    return p


def run(cmd: list[str], timeout: float | None = None, text: bool = False, **kw) -> subprocess.CompletedProcess:
    """subprocess.run equivalent that is pausable/cancellable inside a task."""
    s = current()
    if s:
        s.checkpoint()
    p = popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=text,
              **({"encoding": "utf-8", "errors": "replace"} if text else {}), **kw)
    try:
        out, err = p.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        p.kill()
        out, err = p.communicate()
        raise
    finally:
        if s:
            s.remove(p)
    if s and s.cancel_event.is_set():
        raise Cancelled("Cancelled by user")
    return subprocess.CompletedProcess(cmd, p.returncode, out, err)
