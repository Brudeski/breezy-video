"""What this PC has (graphics card, memory, processor) and how fast it runs the AI - and what that means
for the Enhance settings.

The scan runs as a normal task ("app.hwscan") once on first start (and again from Settings → Your PC);
the result is kept in the settings under app.hardware.
"""
from __future__ import annotations

import json
import os
import subprocess
import sys
import time

SCAN_VERSION = 1
NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0

# Minutes of work per minute of a typical old video (720x480, 30 fps) with Maximum restoration
FAST_LIMIT = 20.0          # up to this: everything as it is
MEDIUM_LIMIT = 90.0        # up to this: lighter AI upscaling, no AI deblur; above: also no AI denoise
# The user's choice (0.10.1): never lighten the AI steps - full quality however long it takes.
# The tiers only describe the PC; only performance settings (graphics card use, tile size) are fitted.
TIERS = {
    "fast": ("Runs Maximum restoration well", {}),
    "medium": ("Maximum restoration is slow here, but full quality is kept", {}),
    "slow": ("The processor does the AI here: full quality is kept, but it's very slow", {}),
}


def _run(cmd: list[str], timeout: int = 20) -> str:
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, creationflags=NO_WINDOW)
        return r.stdout or ""
    except Exception:
        return ""


def recommended_tile(settings) -> int | None:
    """AI tile size for this PC: bigger tiles overlap less (faster). Half precision needs half the memory,
    so cards that use it get one size larger."""
    hw = (settings.get("app", "hardware") if settings else None) or {}
    if not hw:
        return None
    gpu_ai = (hw.get("bench") or {}).get("device", "graphics card") == "graphics card"
    if not gpu_ai:
        return 256
    vram = max([g.get("vram_gb") or 0 for g in hw.get("hw", {}).get("gpus", [])] or [0])
    sizes = [(12, 768), (8, 512), (4, 384), (0, 256)]
    if half_supported(settings):
        sizes = [(12, 1024), (8, 768), (4, 512), (0, 384)]
    return next(t for v, t in sizes if vram >= v)


def half_supported(settings) -> bool:
    """Whether the AI should run in half precision: NVIDIA cards that are fast at it (RTX 20xx and newer,
    GTX 16xx, recent workstation cards - compute capability 7.0+) with the NVIDIA (CUDA) engine."""
    hw = (settings.get("app", "hardware") if settings else None) or {}
    for g in hw.get("hw", {}).get("gpus", []):
        cc = g.get("cc")
        if cc:
            try:
                if float(cc) >= 7.0:
                    return True
                continue
            except ValueError:
                pass
        name = (g.get("name") or "").upper()
        if "NVIDIA" in name and any(x in name for x in ("RTX", "GTX 16", "TITAN V", "TESLA T4", "TESLA V100")):
            return True
    return False


def gpus() -> list[dict]:
    """[{name, vram_gb}] - exact memory for NVIDIA (nvidia-smi), otherwise what Windows reports."""
    out = []
    smi = _run(["nvidia-smi", "--query-gpu=name,memory.total", "--format=csv,noheader,nounits"])
    caps = [c.strip() for c in _run(["nvidia-smi", "--query-gpu=compute_cap", "--format=csv,noheader"]).splitlines()]
    for k, line in enumerate(smi.splitlines()):
        parts = [p.strip() for p in line.split(",")]
        if len(parts) >= 2 and parts[0]:
            cc = caps[k] if k < len(caps) and caps[k].replace(".", "").isdigit() else None
            try:
                out.append({"name": parts[0], "vram_gb": round(float(parts[1]) / 1024, 1), "cc": cc})
            except ValueError:
                out.append({"name": parts[0], "vram_gb": None, "cc": cc})
    if sys.platform == "win32":
        txt = _run(["powershell", "-NoProfile", "-Command",
                    "Get-CimInstance Win32_VideoController | Select-Object Name,AdapterRAM | ConvertTo-Json"])
        try:
            data = json.loads(txt) if txt.strip() else []
            data = data if isinstance(data, list) else [data]
            for d in data:
                name = (d.get("Name") or "").strip()
                if not name or any(g["name"] == name for g in out) or "basic display" in name.lower():
                    continue
                ram = d.get("AdapterRAM") or 0
                # AdapterRAM stops at 4 GB, so treat 4 GB as "at least 4"
                out.append({"name": name, "vram_gb": round(ram / 2 ** 30, 1) if ram else None,
                            "vram_capped": bool(ram and ram >= 2 ** 32 - 2 ** 20)})
        except (ValueError, AttributeError):
            pass
    return out


def cpu_name() -> str:
    if sys.platform == "win32":
        try:
            import winreg
            k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r"HARDWARE\DESCRIPTION\System\CentralProcessor\0")
            return str(winreg.QueryValueEx(k, "ProcessorNameString")[0]).strip()
        except OSError:
            pass
    try:
        for line in open("/proc/cpuinfo", encoding="utf-8", errors="replace"):
            if line.startswith("model name"):
                return line.split(":", 1)[1].strip()
    except OSError:
        pass
    import platform
    return platform.processor() or "unknown processor"


def describe() -> dict:
    import psutil
    return {"gpus": gpus(), "cpu": cpu_name(), "cores": psutil.cpu_count(logical=False) or os.cpu_count(),
            "threads": psutil.cpu_count(logical=True) or os.cpu_count(),
            "ram_gb": round(psutil.virtual_memory().total / 2 ** 30, 1)}


def recommend(hw: dict, bench: dict, gpu_encoder: bool) -> dict:
    """Which speed tier this PC is, the Maximum-restoration time it implies, and performance settings."""
    from types import SimpleNamespace
    from breezy.features.enhance.bench import estimate_minutes
    from breezy.features.enhance.filters import tier_settings
    from breezy.features.enhance.render import make_plan
    s = tier_settings("max_quality")
    info = SimpleNamespace(video=SimpleNamespace(width=720, height=480, fps=30, duration=60, codec="h264", sar=1.0),
                           duration=60, audio=None)
    plan = make_plan(info, s, {"brightness": 100})
    minutes = estimate_minutes(s, plan, bench) or 0.0
    gpu_ai = bench.get("device") == "graphics card"
    tier = "fast" if gpu_ai and minutes <= FAST_LIMIT else "medium" if gpu_ai and minutes <= MEDIUM_LIMIT else "slow"
    vram = max([g.get("vram_gb") or 0 for g in hw.get("gpus", [])] or [0])
    tile = 256 if not gpu_ai else (768 if vram >= 12 else 512 if vram >= 8 else 384 if vram >= 4 else 256)
    perf = dict(ai_gpu=gpu_ai, enc_gpu=gpu_encoder, hwaccel=True, tile=tile)
    return {"tier": tier, "text": TIERS[tier][0], "adjust": dict(TIERS[tier][1]), "perf": perf,
            "max_minutes": round(minutes, 1)}


def duration_text(minutes: float) -> str:
    if minutes < 1:
        return "less than a minute"
    if minutes < 90:
        return f"about {minutes:.0f} min"
    return f"about {minutes / 60:.1f} hours"


def summary(result: dict) -> str:
    if not result:
        return "Not scanned yet."
    hw = result.get("hw", {})
    g = ", ".join(f"{x['name']}" + (f" ({x['vram_gb']:g} GB)" if x.get("vram_gb") else "") for x in hw.get("gpus", []))
    rec = result.get("rec", {})
    return (f"{g or 'No graphics card found'} · {hw.get('cpu', '?')} ({hw.get('cores', '?')} cores) · "
            f"{hw.get('ram_gb', '?')} GB memory\nAI runs on the {result.get('bench', {}).get('device', '?')}. "
            f"Maximum restoration of an old 720x480 video: {duration_text(rec.get('max_minutes', 0))} of work "
            f"per minute of video. {rec.get('text', '')}.")


# --------------------------------------------------------------- task runner
def run_hwscan(task, ctx):
    from breezy.core import encoders
    from breezy.features.enhance import bench
    ctx.set_items([["scan"]], [1], ["Your PC"])
    for _i, _it in ctx.items():
        ctx.log("Looking at the hardware…")
        hw = describe()
        for g in hw["gpus"]:
            ctx.log(f"Graphics card: {g['name']}" + (f", {g['vram_gb']:g} GB" if g.get("vram_gb") else ""))
        ctx.log(f"Processor: {hw['cpu']} ({hw['cores']} cores / {hw['threads']} threads), memory {hw['ram_gb']} GB")
        b = bench.measure(True, ctx.log, ctx.item_progress, ctx.checkpoint)
        ctx.log("AI speed (ms per megapixel): " + ", ".join(f"{k} {v}" for k, v in b.items() if k != "device")
                + f" - on the {b['device']}")
        enc = encoders.detect(ctx.ffmpeg, ctx.settings)
        rec = recommend(hw, b, bool(enc.get("hevc") or enc.get("h264")))
        from breezy.core import ai_engine
        result = {"version": SCAN_VERSION, "time": time.time(), "hw": hw, "bench": b, "rec": rec,
                  "engine": ai_engine.active}
        ctx.settings.set("app", "hardware", result)
        ctx.log("✔ " + summary(result).replace("\n", " "))


def register():
    from breezy.core.tasks import register_runner
    register_runner("app.hwscan", run_hwscan)


def needs_scan(settings) -> bool:
    from breezy.core import ai_engine
    r = settings.get("app", "hardware") or {}
    return r.get("version") != SCAN_VERSION or r.get("engine", "directml") != ai_engine.active
