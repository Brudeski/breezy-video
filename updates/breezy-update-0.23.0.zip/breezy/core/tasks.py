"""Task queue shared by all modules.

* Tasks run one at a time; the rest wait in the queue (user's choice).
* A task may take its input from another task's *future* output
  (`input_from`). It starts after that task ends and runs on whatever files
  it produced, even if it partly failed (user's choice).
* Pause is instant (FFmpeg processes are suspended); resume continues.
* Unfinished tasks are saved and offered again after a restart: finished
  items are kept, the item in progress restarts.
* Each task reports: progress, time left, finish clock time, elapsed time,
  speed (x real-time) and current file n/total.

A module registers a *runner* for each task kind:

    register_runner("motion.trim", fn)      # fn(task: Task, ctx: TaskContext) -> result

The runner works through `ctx.items()`, reports `ctx.item_progress(f)` and
records files with `ctx.add_output(path)`.
"""
from __future__ import annotations

import json
import threading
import time
import traceback
import uuid
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Callable, Iterator, Optional

from PySide6.QtCore import QObject, QTimer, Signal

from breezy.core import proc
from breezy.core.proc import Cancelled

QUEUED, RUNNING, PAUSED, DONE, FAILED, CANCELLED, SKIPPED = (
    "queued", "running", "paused", "done", "failed", "cancelled", "skipped")
ACTIVE = (QUEUED, RUNNING, PAUSED)
FINISHED = (DONE, FAILED, CANCELLED, SKIPPED)

_RUNNERS: dict[str, Callable] = {}


NOT_MEDIA = {".csv", ".txt", ".json", ".log", ".srt"}   # side files (lists, subtitles) are never fed on


def say_stage(progress, text: str) -> None:
    """Tell a progress callback what is being done now, if it understands labels
    (TaskContext.item_progress and the per-item progress of ctx.parallel do)."""
    if progress is None:
        return
    try:
        progress(None, text)
    except TypeError:
        pass


def register_runner(kind: str, fn: Callable) -> None:
    _RUNNERS[kind] = fn


@dataclass
class Task:
    kind: str                      # e.g. "motion.trim"
    module: str                    # feature id, e.g. "motion"
    title: str
    spec: dict = field(default_factory=dict)      # json-serialisable parameters
    items: list = field(default_factory=list)     # json-serialisable work items (files, groups...)
    weights: list = field(default_factory=list)   # per item, usually media seconds
    names: list = field(default_factory=list)     # per item, shown as "current file"
    costs: list = field(default_factory=list)     # per item, relative amount of work (default: the weights)
    input_from: Optional[str] = None              # take items from this task's outputs
    resumable: bool = True
    media: bool = True             # weights are media seconds (shows "x real-time" speed)
    id: str = field(default_factory=lambda: uuid.uuid4().hex[:10])
    status: str = QUEUED
    message: str = ""
    created: float = field(default_factory=time.time)
    started: float = 0.0
    finished: float = 0.0
    active_seconds: float = 0.0    # running time, pauses excluded
    done_items: list = field(default_factory=list)
    outputs: list = field(default_factory=list)
    errors: list = field(default_factory=list)
    # live (not essential to persist)
    progress: float = 0.0
    item_index: int = 0
    item_frac: float = 0.0
    current: str = ""
    stage: str = ""                # what is being done right now (e.g. "AI upscaling - part 3 of 12")
    position: float = -1.0         # seconds into the current video the current step has reached (-1 = from progress)
    log_lines: list = field(default_factory=list)
    parallel_media: float = -1.0   # >= 0 while items run side by side: media seconds in progress
    parallel_cost: float = -1.0    # the same in work units (costs)

    # ------------------------------------------------------------ stats
    @property
    def total_weight(self) -> float:
        return sum(self.weights) or float(len(self.items) or 1)

    def _w(self, i: int) -> float:
        return self.weights[i] if i < len(self.weights) else 1.0

    def media_done(self) -> float:
        done = sum(self._w(i) for i in set(self.done_items))
        if self.parallel_media >= 0:
            return done + self.parallel_media
        if self.status in (RUNNING, PAUSED) and self.item_index not in self.done_items:
            done += self._w(self.item_index) * self.item_frac
        return done

    # work units: a 4K AI upscale costs far more per second of video than a small clean-up, so progress
    # and time left are counted in work (costs), while speed stays in seconds of video
    def _c(self, i: int) -> float:
        return self.costs[i] if i < len(self.costs) else self._w(i)

    @property
    def total_cost(self) -> float:
        return sum(self._c(i) for i in range(len(self.items))) or self.total_weight

    def completed_cost(self) -> float:
        return sum(self._c(i) for i in set(self.done_items) if i < len(self.items))

    def cost_done(self) -> float:
        done = self.completed_cost()
        if self.parallel_cost >= 0:
            return done + self.parallel_cost
        if self.status in (RUNNING, PAUSED) and self.item_index not in self.done_items and self.items:
            done += self._c(self.item_index) * self.item_frac
        return done

    def compute_progress(self) -> float:
        if self.status == DONE:
            return 1.0
        if not self.items:
            return max(0.0, min(1.0, self.item_frac))
        tc = self.total_cost
        return max(0.0, min(1.0, self.cost_done() / tc)) if tc else 0.0

    def _base(self) -> tuple:
        """(active seconds, completed work, progress, media done) when this run started (resume aware)."""
        return getattr(self, "_run_base", (0.0, 0.0, 0.0, 0.0))

    def note_item_done(self):
        """Called when an item finishes: the time and work so far measure the real speed."""
        self._last_done = (self.active_seconds, self.completed_cost())

    def speed(self) -> Optional[float]:
        """Media seconds processed per wall second (x real-time), in this run."""
        b = self._base()
        run = self.active_seconds - b[0]
        if run < 2 or not self.weights:
            return None
        md = self.media_done() - b[3]
        return md / run if md > 0 else None

    def eta_seconds(self) -> Optional[float]:
        """Time left. Once a file has finished, from the real speed of the finished files (work per second),
        minus the time already spent on the file(s) in progress; before that, from the progress so far."""
        if self.status not in (RUNNING, PAUSED):
            return None
        b = self._base()
        run = self.active_seconds - b[0]
        p = self.compute_progress()
        if run < 10 or p <= 0.01:          # the first seconds (loading, warming up) say little
            return None
        learned = getattr(self, "_learned_rate", None)        # work per second on earlier tasks of this kind
        ld = getattr(self, "_last_done", None)
        if ld and not getattr(self, "_side_by_side", False) and ld[1] > b[1] and ld[0] - b[0] >= 1:
            rate = (ld[1] - b[1]) / (ld[0] - b[0])             # work per second of the finished files
            left = (self.total_cost - ld[1]) / rate - (self.active_seconds - ld[0])
            if left > 0:
                return left
            return max(0.0, (self.total_cost - self.cost_done()) / rate)   # current file slower than usual
        gained = p - b[2]
        from_progress = run / gained * (1 - p) if gained > 0.005 else None
        if learned:
            from_learned = max(0.0, (self.total_cost - self.cost_done()) / learned)
            if from_progress is None:
                return from_learned
            w = min(1.0, gained / 0.2) ** 2             # trust this run's own progress more as it grows
            return (1 - w) * from_learned + w * from_progress
        return from_progress

    def run_rate(self) -> Optional[float]:
        """Work per second in this run, measured on finished files (for learning)."""
        b = self._base()
        ld = getattr(self, "_last_done", None)
        if not ld or ld[1] <= b[1] or ld[0] - b[0] < 20:
            return None
        return (ld[1] - b[1]) / (ld[0] - b[0])

    def video_position(self) -> tuple[float, float] | None:
        """(seconds reached in the current video, its length) when one video is being worked on."""
        if self.status not in (RUNNING, PAUSED) or not self.items or self.parallel_media >= 0 and \
                "," in (self.current or ""):
            return None
        i = self.item_index
        if i >= len(self.weights) or not self.media:
            return None
        length = self._w(i)
        pos = self.position if self.position >= 0 else self.item_frac * length
        return max(0.0, min(pos, length)), length

    def to_json(self) -> dict:
        d = asdict(self)
        d["log_lines"] = d["log_lines"][-200:]
        return d

    @classmethod
    def from_json(cls, d: dict) -> "Task":
        known = {f for f in cls.__dataclass_fields__}
        return cls(**{k: v for k, v in d.items() if k in known})


class TaskContext:
    """What a runner uses to talk to the task system."""

    def __init__(self, manager: "TaskManager", task: Task, scope: proc.Scope):
        self.manager, self.task, self.scope = manager, task, scope
        self.ffmpeg = manager.ffmpeg
        self.settings = manager.settings
        self.cancel_event = scope.cancel_event

    def log(self, msg: str):
        self.task.log_lines.append(msg)
        if len(self.task.log_lines) > 2000:
            del self.task.log_lines[:500]
        self.manager._log.emit(self.task.id, msg)

    def checkpoint(self):
        self.scope.checkpoint()

    def set_items(self, items: list, weights: list | None = None, names: list | None = None,
                  costs: list | None = None):
        """weights = seconds of video per item (speed); costs = relative work per item (progress and time
        left; default the weights)."""
        t = self.task
        t.items = items
        t.weights = weights or [1.0] * len(items)
        t.names = names or [str(i) for i in items]
        t.costs = list(costs) if costs else []
        self.manager._touch(t)

    def items(self) -> Iterator[tuple[int, Any]]:
        t = self.task
        for i, item in enumerate(t.items):
            if i in t.done_items:
                continue
            self.checkpoint()
            t.item_index, t.item_frac = i, 0.0
            t.current = t.names[i] if i < len(t.names) else str(item)
            t.stage, t.position = "", -1.0
            self._learn_key(1)
            self.manager._touch(t)
            yield i, item
            if i not in t.done_items:
                t.done_items.append(i)
                t.note_item_done()
            t.item_frac = 0.0
            self.manager._touch(t, save=True)

    def _learn_key(self, workers: int):
        """Look up how fast earlier tasks of this kind went (with this many files at once)."""
        t = self.task
        tag = (t.spec or {}).get("learn_tag")
        key = f"{t.kind}{'/' + tag if tag else ''}|{max(1, workers)}"
        if getattr(t, "_learn", None) != key:
            t._learn = key
            t._learned_rate = self.manager.learned_rate(key)

    def parallel(self, fn: Callable, workers: int, only: list[int] | None = None) -> dict:
        """Run fn(index, item, progress) for every not-yet-done item (or just the indexes in `only`),
        `workers` at a time. progress(frac) reports that item's progress. Returns {index: result}."""
        import threading as _th
        t = self.task
        todo = [i for i in (range(len(t.items)) if only is None else only) if i not in t.done_items]
        fracs: dict[int, float] = {}
        stages: dict[int, str] = {}
        poss: dict[int, float] = {}
        self._learn_key(min(workers, max(1, len(todo))))
        lock = _th.Lock()
        out: dict = {}

        def update():
            t.parallel_media = sum(t._w(i) * f for i, f in fracs.items())
            t.parallel_cost = sum(t._c(i) * f for i, f in fracs.items())
            busy = [t.names[i] for i in sorted(fracs)][:3]
            t.current = ", ".join(busy) + (f" +{len(fracs) - 3}" if len(fracs) > 3 else "")
            live = [(t.names[i], stages[i]) for i in sorted(fracs) if stages.get(i)]
            t.stage = (live[0][1] if len(fracs) == 1 and live else
                       "  ·  ".join(f"{n}: {st}" for n, st in live[:3]))
            if len(fracs) == 1:
                k = next(iter(fracs))
                t.item_index, t.item_frac = k, fracs[k]
                t.position = poss.get(k, -1.0)
            self.manager._touch(t)

        def one(i):
            self.checkpoint()
            with lock:
                fracs[i] = 0.0
                stages.pop(i, None)
                update()

            def prog(f, label=None, pos=None, i=i):
                """f = this item's progress (None = unchanged); label = what it's doing now;
                pos = seconds into the video the current step has reached."""
                with lock:
                    if i in fracs:
                        if f is not None:
                            fracs[i] = max(0.0, min(1.0, f))
                        if label is not None:
                            stages[i] = label
                            poss.pop(i, None)
                        if pos is not None:
                            poss[i] = pos
                        update()
            try:
                return i, fn(i, t.items[i], prog)
            finally:
                with lock:
                    fracs.pop(i, None)
                    stages.pop(i, None)
                    poss.pop(i, None)
                    if not self.cancel_event.is_set():
                        t.done_items.append(i)
                        t.note_item_done()
                    update()

        t.parallel_media = t.parallel_cost = 0.0
        # several files at once: a finished file doesn't show the real throughput yet - use the progress
        t._side_by_side = workers > 1 and len(todo) > 1
        try:
            with proc.pool(workers) as ex:
                for i, r in ex.map(one, todo):
                    out[i] = r
        finally:
            t.parallel_media = t.parallel_cost = -1.0
            t.stage, t.position = "", -1.0
            self.manager._touch(t, save=True)
        return out

    def item_progress(self, frac: float | None, label: str | None = None, pos: float | None = None):
        """Progress of the current item; label = what is being done now (shown as the step);
        pos = seconds into the video the current step has reached."""
        if frac is not None:
            self.task.item_frac = max(0.0, min(1.0, frac))
        if label is not None:
            self.task.stage = label
            self.task.position = -1.0
        if pos is not None:
            self.task.position = pos
        self.manager._touch(self.task)

    def stage(self, label: str):
        self.item_progress(None, label)

    def add_output(self, path: str | Path):
        self.task.outputs.append(str(path))
        self.manager._touch(self.task, save=True)

    def error(self, msg: str):
        self.task.errors.append(msg)
        self.log("✖ " + msg)


# ------------------------------------------------------------ running side by side
def resource_of(t: "Task") -> str:
    """What a task mostly uses: 'gpu' (AI / graphics card), 'cpu' (processor), 'light' (disk, network,
    lossless joins) or 'exclusive' (must run alone - the PC speed test)."""
    k = t.kind
    if k == "app.hwscan":
        return "exclusive"
    if k.startswith("enhance."):
        return "gpu" if t.spec.get("ai_gpu", True) else "cpu"
    if k.startswith("tracker."):
        return "gpu" if t.spec.get("det_gpu", True) else "cpu"
    if k.startswith("motion."):
        return "cpu"
    return "light"          # stitcher scans/joins, repair downloads, ...


def _compatible(a: str, b: str) -> bool:
    """'When they don't compete': a graphics-card job next to a processor job, or anything light."""
    return "light" in (a, b) or {a, b} == {"gpu", "cpu"}


class TaskManager(QObject):
    changed = Signal(str)            # task id (throttled for progress)
    listChanged = Signal()           # added / removed / reordered
    finished = Signal(str)           # task id, after it ends (any final status)
    _log = Signal(str, str)          # task id, line
    _ended = Signal(str)

    def __init__(self, ffmpeg, settings, store: Path, history: "OutputHistory"):
        super().__init__()
        self.ffmpeg, self.settings, self.store, self.history = ffmpeg, settings, store, history
        self.tasks: list[Task] = []
        self.results: dict[str, Any] = {}          # in-memory results for pages (scan results...)
        self._runs: dict[str, tuple[Task, proc.Scope]] = {}   # running tasks (more than one with parallel mode)
        self._marks: dict[str, float] = {}
        self._last_emit: dict[str, float] = {}
        self._dirty = False
        self._ended.connect(self._on_ended)
        self.timer = QTimer(self, interval=500)
        self.timer.timeout.connect(self._tick)
        self.timer.start()
        self.finish_all_then: Optional[Callable] = None   # used by "finish first, then close"
        self._leftover: list[dict] = self._read_store()     # last session's unfinished tasks

    # ------------------------------------------------------------- queries
    def get(self, task_id: str) -> Optional[Task]:
        return next((t for t in self.tasks if t.id == task_id), None)

    def running(self) -> Optional[Task]:
        """The first running task (see running_all() when tasks run side by side)."""
        return next(iter(self._runs.values()))[0] if self._runs else None

    def running_all(self) -> list[Task]:
        return [t for t, _s in self._runs.values()]

    def is_running(self, t: Task) -> bool:
        return t.id in self._runs

    def _scope_of(self, t: Task) -> Optional[proc.Scope]:
        r = self._runs.get(t.id)
        return r[1] if r else None

    def active(self) -> list[Task]:
        return [t for t in self.tasks if t.status in ACTIVE]

    def for_module(self, module: str) -> list[Task]:
        return [t for t in self.tasks if t.module == module]

    # ------------------------------------------------------------- actions
    def submit(self, task: Task) -> Task:
        # remember the global quality level the task was made with (shown on the Tasks page)
        try:
            from breezy.core.quality import QUALITY_MODULES
            if task.module in QUALITY_MODULES and self.settings is not None and "quality_level" not in task.spec:
                task.spec["quality_level"] = self.settings.get("app", "quality", "") or ""
                task.spec.setdefault("enc_speed", self.settings.get(task.module, "enc_speed", "balanced"))
                if task.spec["quality_level"] == "custom":
                    task.spec["quality_base"] = self.settings.get("app", "quality_base", "") or ""
                if task.module == "enhance":
                    task.spec.setdefault("content_type", self.settings.get("enhance", "content", "general"))
        except Exception:
            pass
        self.tasks.append(task)
        self._save()
        self.listChanged.emit()
        QTimer.singleShot(0, self._schedule)
        return task

    def pause(self, task_id: str):
        t = self.get(task_id)
        if not t:
            return
        if self._scope_of(t):
            self._scope_of(t).pause()
            t.status = PAUSED
        elif t.status == QUEUED:
            t.status = PAUSED            # held: won't start until resumed
        self._touch(t, save=True, force=True)

    def resume(self, task_id: str):
        t = self.get(task_id)
        if not t or t.status != PAUSED:
            return
        if self._scope_of(t):
            t.status = RUNNING
            self._scope_of(t).resume()
        else:
            t.status = QUEUED
        self._touch(t, save=True, force=True)
        QTimer.singleShot(0, self._schedule)

    def pause_all(self):
        for t in self.active():
            self.pause(t.id)

    def cancel(self, task_id: str):
        t = self.get(task_id)
        if not t:
            return
        if self._scope_of(t):
            self._scope_of(t).cancel()    # runner thread ends -> _on_ended
        elif t.status in (QUEUED, PAUSED):
            t.status, t.message = CANCELLED, "Cancelled"
            t.finished = time.time()
            self._touch(t, save=True, force=True)
            self.finished.emit(t.id)
            QTimer.singleShot(0, self._schedule)

    def remove(self, task_id: str):
        t = self.get(task_id)
        if not t or self.is_running(t):
            return                      # cancel a running task first
        if t.status in ACTIVE:
            self.cancel(task_id)
        self.tasks.remove(t)
        self._save()
        self.listChanged.emit()

    def move(self, task_id: str, delta: int):
        t = self.get(task_id)
        if not t or t.status not in (QUEUED, PAUSED):
            return
        i = self.tasks.index(t)
        j = i + delta
        while 0 <= j < len(self.tasks) and self.tasks[j].status not in (QUEUED, PAUSED):
            j += delta
        if 0 <= j < len(self.tasks):
            self.tasks.insert(j, self.tasks.pop(i))
            self._save()
            self.listChanged.emit()

    def clear_finished(self):
        self.tasks = [t for t in self.tasks if t.status not in FINISHED]
        self._save()
        self.listChanged.emit()

    # ------------------------------------------------------------ scheduler
    def _dependency_state(self, t: Task) -> str:
        if not t.input_from:
            return "ready"
        dep = self.get(t.input_from)
        if dep is None:
            # from an earlier session: use what history knows
            return "ready"
        return "ready" if dep.status in FINISHED else "wait"

    def _limit(self) -> tuple[str, int]:
        if self.settings is None:
            return "off", 1
        mode = self.settings.get("app", "parallel_mode", "smart")      # off | smart | any
        n = int(self.settings.get("app", "parallel_max", 2) or 2)
        return mode, (1 if mode == "off" else 2 if mode == "smart" else max(1, n))

    def _fits(self, t: Task) -> bool:
        """May t start next to what is already running?"""
        if not self._runs:
            return True
        mode, limit = self._limit()
        if len(self._runs) >= limit:
            return False
        kinds = [resource_of(r) for r in self.running_all()]
        mine = resource_of(t)
        if mine == "exclusive" or "exclusive" in kinds:
            return False
        if mode == "any":
            return True
        return all(_compatible(mine, k) for k in kinds)

    def _schedule(self):
        started = True
        while started:
            started = False
            for t in self.tasks:
                if t.status == QUEUED and self._dependency_state(t) == "ready" and self._fits(t):
                    self._start(t)
                    started = True       # look again (a skipped task frees the slot it was given)
                    break
            if not started:
                break
        if self._runs:
            return
        if self.finish_all_then and not self.active():
            cb, self.finish_all_then = self.finish_all_then, None
            cb()

    def _start(self, t: Task):
        if t.input_from:
            dep = self.get(t.input_from)
            files = list(dep.outputs) if dep else self.history.outputs_of(t.input_from)
            files = [f for f in files if Path(f).is_file() and Path(f).suffix.lower() not in NOT_MEDIA
                     and not Path(f).stem.endswith("_compare")]      # before/after videos aren't passed on
            if not files:
                t.status, t.message = SKIPPED, "Skipped: the task it depends on produced no files"
                t.finished = time.time()
                self._touch(t, save=True, force=True)
                self.finished.emit(t.id)
                QTimer.singleShot(0, self._schedule)
                return
            t.spec = dict(t.spec, input_files=files)
        runner = _RUNNERS.get(t.kind)
        if runner is None:
            t.status, t.message = FAILED, f"This version can't run '{t.kind}' tasks"
            self._touch(t, save=True, force=True)
            QTimer.singleShot(0, self._schedule)
            return
        scope = proc.Scope()
        scope.enc_speed = (t.spec or {}).get("enc_speed", "balanced")
        self._runs[t.id] = (t, scope)
        t.status = RUNNING
        t.started = t.started or time.time()
        if t.active_seconds < 0:                            # repair a value from an older version
            t.active_seconds = 0.0
        t._run_base = (t.active_seconds, t.completed_cost(), t.compute_progress(), t.media_done())
        t._last_done = None
        t.message = ""
        self._marks[t.id] = time.monotonic()
        self._touch(t, save=True, force=True)
        ctx = TaskContext(self, t, scope)

        def work():
            proc.bind(scope)
            status, msg, result = DONE, "", None
            try:
                result = runner(t, ctx)
                if t.errors and not t.outputs:
                    status, msg = FAILED, t.errors[-1]
                elif t.errors:
                    status, msg = DONE, f"Finished with {len(t.errors)} problem(s)"
            except Cancelled:
                status, msg = CANCELLED, "Cancelled"
            except Exception as e:  # noqa
                ctx.log(traceback.format_exc())
                status, msg = FAILED, str(e).splitlines()[0] if str(e) else type(e).__name__
            finally:
                proc.bind(None)
            t._pending_end = (status, msg, result)
            self._ended.emit(t.id)

        threading.Thread(target=work, daemon=True, name=f"task-{t.id}").start()

    # ------------------------------------------------------------- learning how fast this PC is
    def learned_rate(self, key: str) -> Optional[float]:
        if self.settings is None:
            return None
        v = (self.settings.get("app", "learned_speed") or {}).get(key)
        return float(v) if v else None

    def _learn(self, t: Task):
        key = getattr(t, "_learn", None)
        rate = t.run_rate()
        if self.settings is None or not key or not rate:
            return
        table = dict(self.settings.get("app", "learned_speed") or {})
        old = table.get(key)
        table[key] = rate if not old else 0.5 * float(old) + 0.5 * rate     # follow changes, smooth out noise
        self.settings.set("app", "learned_speed", table)

    def _on_ended(self, task_id: str):
        t = self.get(task_id)
        if not t:
            return
        status, msg, result = t._pending_end
        self._account_time()
        try:
            self._learn(t)
        except Exception:
            pass
        self._runs.pop(t.id, None)
        self._marks.pop(t.id, None)
        t.status, t.message, t.finished = status, msg, time.time()
        if status == DONE:
            t.progress = 1.0
        if result is not None:
            self.results[t.id] = result
        if t.outputs:
            self.history.add(t)
        self._touch(t, save=True, force=True)
        self.finished.emit(t.id)
        QTimer.singleShot(0, self._schedule)

    # ------------------------------------------------------------- updates
    MAX_STEP = 5.0     # longer gaps between ticks (PC asleep, clock changes) don't count as working time

    def _account_time(self):
        # a steady clock: the PC's clock being set back (time sync, time zone, daylight saving) once made the
        # working time negative
        now = time.monotonic()
        for t in self.running_all():
            if t.status == RUNNING:
                step = now - self._marks.get(t.id, now)
                if step > 0:
                    t.active_seconds += min(step, self.MAX_STEP)
            if t.active_seconds < 0:                       # repair a value from an older version
                t.active_seconds = 0.0
                b = getattr(t, "_run_base", None)
                if b:
                    t._run_base = (0.0,) + tuple(b[1:])
                t._last_done = None
            self._marks[t.id] = now

    def _tick(self):
        self._account_time()
        for t in self.running_all():
            self._touch(t, force=True)
        if self._dirty:
            self._save()

    def _touch(self, t: Task, save: bool = False, force: bool = False):
        t.progress = t.compute_progress()
        now = time.monotonic()
        if force or now - self._last_emit.get(t.id, 0) > 0.2:
            self._last_emit[t.id] = now
            self.changed.emit(t.id)
        if save:
            self._dirty = True

    # --------------------------------------------------------- persistence
    def _save(self):
        self._dirty = False
        keep = [t.to_json() for t in self.tasks if t.status in ACTIVE and t.resumable] + self._leftover
        try:
            self.store.write_text(json.dumps(keep, indent=1), "utf-8")
        except OSError:
            pass

    def _read_store(self) -> list[dict]:
        try:
            data = json.loads(self.store.read_text("utf-8"))
            return [d for d in data if isinstance(d, dict) and d.get("status") in ACTIVE]
        except (OSError, ValueError, TypeError):
            return []

    def load_unfinished(self) -> list[Task]:
        """Tasks left from a previous session (read at start-up, not yet queued)."""
        out = []
        for d in self._leftover:
            try:
                t = Task.from_json(d)
            except TypeError:
                continue
            if t.status in ACTIVE:
                out.append(t)
        return out

    def restore(self, tasks: list[Task], paused: bool = False):
        ids = {t.id for t in tasks}
        self._leftover = [d for d in self._leftover if d.get("id") not in ids]
        for t in tasks:
            t.status = PAUSED if paused else QUEUED
            t.item_frac, t.message = 0.0, "Resumed from last session"
            self.tasks.append(t)
        self._save()
        self.listChanged.emit()
        QTimer.singleShot(0, self._schedule)

    def save_for_later(self):
        """Pause everything and store it so it can be resumed next time."""
        for t in self.active():
            if self._scope_of(t):
                self._scope_of(t).cancel()   # stop the processes; the item in progress restarts next time
            t.status = PAUSED
        self._save()

    def discard_saved(self):
        self._leftover = []
        self._save()


class OutputHistory(QObject):
    """Every file the app made, by run (kept until the user clears it)."""
    changed = Signal()

    def __init__(self, store: Path):
        super().__init__()
        self.store = store
        try:
            self.runs: list[dict] = json.loads(store.read_text("utf-8"))
        except (OSError, ValueError):
            self.runs = []

    def add(self, t: Task):
        self.runs = [r for r in self.runs if r.get("task_id") != t.id]
        self.runs.append({"task_id": t.id, "module": t.module, "kind": t.kind, "title": t.title,
                          "finished": time.time(), "outputs": list(t.outputs)})
        self._save()

    def outputs_of(self, task_id: str) -> list[str]:
        r = next((r for r in self.runs if r.get("task_id") == task_id), None)
        return list(r["outputs"]) if r else []

    def clear(self):
        self.runs = []
        self._save()

    def _save(self):
        try:
            self.store.write_text(json.dumps(self.runs, indent=1), "utf-8")
        except OSError:
            pass
        self.changed.emit()


# ---------------------------------------------------------------- formatting
def fmt_secs(sec: Optional[float]) -> str:
    if sec is None:
        return "–"
    sec = max(0, int(round(sec)))
    if sec < 60:
        return f"{sec}s"
    if sec < 3600:
        return f"{sec // 60}m {sec % 60:02d}s"
    return f"{sec // 3600}h {sec % 3600 // 60:02d}m"


def clock(sec: float) -> str:
    """Position in a video: 0:42, 3:15, 1:02:07."""
    sec = int(max(0, sec))
    h, m, s_ = sec // 3600, sec // 60 % 60, sec % 60
    return f"{h}:{m:02d}:{s_:02d}" if h else f"{m}:{s_:02d}"


def describe(t: Task) -> str:
    """One-line status: '41% · 8m 12s left (done 1:42 AM) · elapsed 3m 10s · 2.4× · file 14/52: name'"""
    from datetime import datetime, timedelta
    parts = []
    if t.status in (RUNNING, PAUSED):
        parts.append(f"{t.progress:.0%}")
        eta = t.eta_seconds()
        if t.status == PAUSED:
            parts.append("paused")
        elif eta is not None:
            done_at = (datetime.now() + timedelta(seconds=eta)).strftime("%I:%M %p").lstrip("0")
            parts.append(f"{fmt_secs(eta)} left (done {done_at})")
        else:
            parts.append("estimating time…")
        parts.append(f"elapsed {fmt_secs(t.active_seconds)}")
        sp = t.speed() if t.media else None
        if sp:
            parts.append(f"{sp:.1f}× real-time")
        if t.items:
            vp = t.video_position()
            parts.append(f"{len(t.items) and min(len(t.done_items) + 1, len(t.items))}/{len(t.items)}: {t.current}"
                         + (f" ({clock(vp[0])} of {clock(vp[1])})" if vp else ""))
        if t.stage:
            parts.append(t.stage)
    elif t.status == QUEUED:
        parts.append("waiting" + (" for an earlier task's output" if t.input_from else ""))
    else:
        took = fmt_secs(t.active_seconds) if t.active_seconds else ""
        parts.append((t.message or t.status.capitalize()) + (f" · took {took}" if took else ""))
        if t.outputs:
            parts.append(f"{len(t.outputs)} file(s) made")
    return "  ·  ".join(parts)
