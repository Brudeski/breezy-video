"""Saved pipelines: several modules one after the other (e.g. Trim Ends → Stabilizer → Enhance).

A pipeline is a list of steps; each step is a module and a snapshot of that page's settings taken when the
step was added (or updated). Running it queues one task per step: the first on the chosen files, each next
one on the files the previous step made (the task manager's input_from chaining).

In-between files are either kept (each step saves into its own usual folder) or made in a hidden working
folder that is deleted once the last step has finished.

Stored in settings: app / pipelines = {name: {"steps": [...], "keep_between": bool}}
"""
from __future__ import annotations

import shutil
import sys
import time
import uuid
from pathlib import Path

from PySide6.QtCore import QObject

from breezy.core.outputs import output_spec
from breezy.core.tasks import ACTIVE, Task

# module -> (auto task kind, how to read a step spec from its page, made media)
_PAGE_SPEC = {
    "stitcher": ("stitcher.auto", lambda w: dict(w._settings()), False),
    "motion": ("motion.auto", lambda w: dict(w._settings()), True),
    "ends": ("ends.auto", lambda w: dict(w._settings()), True),
    "stabilize": ("stabilize.auto", lambda w: dict(w._spec()), True),
    "enhance": ("enhance.auto", lambda w: dict(w._spec(), stamps=[]), True),
    "tracker": ("tracker.auto", lambda w: dict(w._settings()), True),
    "convert": ("convert.auto", lambda w: dict(w.spec_for([])), True),
    "transform": ("transform.auto", lambda w: dict(w.spec_for([]), per_file={}), True),
    "subtitles": ("subtitles.auto", lambda w: dict(w.spec_for([]), mode="direct"), True),
}


def step_modules() -> list[str]:
    return list(_PAGE_SPEC)


def default_folder(widget) -> str:
    mod = sys.modules.get(type(widget).__module__)
    return getattr(widget, "DEFAULT_FOLDER", None) or getattr(mod, "DEFAULT_FOLDER", "Output")


def snapshot(feature) -> dict | None:
    """A pipeline step from a page's current settings."""
    w = getattr(feature, "widget", None)
    if w is None or feature.id not in _PAGE_SPEC:
        return None
    kind, read, media = _PAGE_SPEC[feature.id]
    spec = read(w)
    spec.pop("files", None)
    spec.pop("output", None)
    q = getattr(feature.context, "quality", None)
    if q is not None and feature.id != "stitcher":
        try:
            from breezy.core.quality import level_name
            spec.setdefault("quality_level", level_name(q.current, feature.context.settings))
        except Exception:
            pass
    return {"module": feature.id, "name": feature.name, "kind": kind, "media": media, "spec": spec,
            "out_values": dict(w.out.values()), "folder": default_folder(w), "saved": time.time(),
            "summary": summary(feature.id, spec)}


def summary(module: str, s: dict) -> str:
    """A short description of a step's settings."""
    try:
        if module == "ends":
            return f"remove {s.get('head', 0):g} s from the start, {s.get('tail', 0):g} s from the end"
        if module == "motion":
            return f"sensitivity {s.get('sensitivity')}, merge pauses under {s.get('merge_gap', 0):g} s"
        if module == "stabilize":
            lv = {0: "off", 1: "light", 2: "medium", 3: "strong"}.get(s.get("stabilize"), "?")
            bits = [f"{lv}, {'lock still' if s.get('stab_mode') == 'lock' else 'smooth'}"]
            if s.get("rs_fix"):
                bits.append("wobble fix")
            if s.get("horizon"):
                bits.append(f"horizon {s['horizon']} %")
            return ", ".join(bits)
        if module == "convert":
            from breezy.features.convert.tasks import FORMATS
            size = {"quality": f"quality {s.get('crf')}", "target": f"{s.get('target_mb', 0):g} MB each",
                    "percent": f"{s.get('percent')} % of the size"}.get(s.get("size_mode"), "")
            res = f", {s['resolution']}p" if s.get("resolution") else ""
            return f"{FORMATS.get(s.get('format'), ('?',))[0]}, {size}{res}"
        if module == "transform":
            bits = []
            if s.get("rotate"):
                bits.append(f"turn {s['rotate']}°")
            if s.get("hflip"):
                bits.append("mirror")
            if s.get("vflip"):
                bits.append("flip")
            if s.get("crop"):
                bits.append(f"crop {s.get('aspect_name', '')}")
            return ", ".join(bits) or "nothing set"
        if module == "subtitles":
            what = [x for x, on in ((".srt", s.get("srt_place") != "off"), ("track", s.get("embed")),
                                    ("burned in", s.get("burn"))) if on]
            return f"{s.get('model')} model, " + " + ".join(what)
        if module == "enhance":
            return f"{s.get('quality_level', 'current settings')}"
    except Exception:
        pass
    return f"settings of {s.get('quality_level', 'the page')}"


def load_all(settings) -> dict:
    return dict(settings.get("app", "pipelines") or {})


def save_all(settings, pipes: dict):
    settings.set("app", "pipelines", pipes)


def _work_root(settings) -> Path:
    root = settings.get("app", "output_root") if settings is not None else None
    if root:
        return Path(root) / ".breezy-pipeline"
    from breezy.core.settings import app_data_dir
    return app_data_dir() / "pipeline_work"


class PipelineRunner(QObject):
    """Queues pipelines and deletes the in-between files once a run has finished."""

    def __init__(self, manager, settings, parent=None):
        super().__init__(parent)
        self.tm, self.settings = manager, settings
        manager.finished.connect(self._finished)
        self._clean_stale()

    def run(self, name: str, pipe: dict, files: list[str] | None = None, input_from: str | None = None,
            final_out: dict | None = None, parent=None, label: str = "") -> list[Task]:
        steps = pipe.get("steps", [])
        if not steps:
            return []
        keep = bool(pipe.get("keep_between", False))
        work = _work_root(self.settings) / uuid.uuid4().hex[:10]
        tasks: list[Task] = []
        prev = input_from
        n = len(steps)
        for i, st in enumerate(steps):
            last = i == n - 1
            if last and final_out:
                out = final_out
            elif last or keep:
                out = output_spec(self.settings, st["module"], st.get("folder", "Output"), parent,
                                  st.get("out_values") or {})
                if out is None:
                    return tasks
            else:
                out = {"mode": "custom", "custom": str(work / f"step{i + 1}")}
            spec = dict(st["spec"], output=out, pipeline=name)
            if i == 0 and files is not None:
                spec["input_files"] = list(files)
            title = f"{name}{' ' + label if label else ''} · {i + 1}/{n} {st.get('name', st['module'])}"
            t = Task(st["kind"], st["module"], title, spec=spec, input_from=prev, media=st.get("media", True))
            self.tm.submit(t)
            tasks.append(t)
            prev = t.id
        if not keep and n > 1:
            pending = dict(self.settings.get("app", "pipeline_cleanup") or {})
            pending[tasks[-1].id] = str(work)
            self.settings.set("app", "pipeline_cleanup", pending)
        return tasks

    def _finished(self, task_id: str):
        pending = dict(self.settings.get("app", "pipeline_cleanup") or {})
        if task_id in pending:
            self._delete(pending.pop(task_id))
            self.settings.set("app", "pipeline_cleanup", pending)

    def _clean_stale(self):
        """After a restart: delete working folders whose last step is no longer waiting or running."""
        pending = dict(self.settings.get("app", "pipeline_cleanup") or {})
        keep = {}
        for tid, d in pending.items():
            t = self.tm.get(tid)
            if t is not None and t.status in ACTIVE:
                keep[tid] = d
            else:
                self._delete(d)
        if keep != pending:
            self.settings.set("app", "pipeline_cleanup", keep)

    @staticmethod
    def _delete(d: str):
        p = Path(d)
        if p.is_dir() and p.parent.name in (".breezy-pipeline", "pipeline_work"):     # only our own folders
            shutil.rmtree(p, ignore_errors=True)
