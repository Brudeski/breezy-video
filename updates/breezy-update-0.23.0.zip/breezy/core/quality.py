"""Global quality setting: nine fixed levels (Max Quality … Max Performance), Custom, and the user's own saved ones.

A tier sets the quality/speed settings of every module (the same on every PC). Hardware optimisations
(graphics card for encoding / AI / decoding, OpenCL filters, AI tile size) are switched on wherever this PC
supports them, whatever the tier. Everything else the user sets on a page is kept until the global setting
is changed. Changing a tier-controlled setting on a page makes the global setting "Custom".
"""
from __future__ import annotations

TIERS = [("Max Quality", "max_quality"),
         ("Very High Quality", "very_high_quality"),
         ("High Quality", "high_quality"),
         ("Balanced Quality", "balanced_quality"),
         ("Balanced", "balanced"),
         ("Balanced Performance", "balanced_performance"),
         ("High Performance (no AI)", "high_performance"),
         ("Very High Performance (no AI)", "very_high_performance"),
         ("Max Performance (no AI)", "max_performance")]
TIER_KEYS = [k for _n, k in TIERS]
DEFAULT = "balanced"          # the middle level; the user's choice is remembered
TIERS_VERSION = 4             # 0.16.0 nine levels; 0.17.0 encoder speed; 0.20.0 stabilising moved - levels re-applied once

# AI each level uses: full (AI upscaling), light (no AI upscaling: small AI steps, level 4 also AI deblur),
# none. Used when a video's scan adds steps: no AI upscaling is added below 'full'.
AI_USE = dict(zip(TIER_KEYS, ["full", "full", "full", "light", "light", "light", "none", "none", "none"]))


# hover text for each level: (summary, what it does, what it leaves out, when to use it)
TIER_INFO = {
    "max_quality": (
        "The best result the app can make. Every AI step at its strongest.",
        "Full Real-ESRGAN AI upscaling to twice the size, AI noise and compression clean-up (SCUNet), AI deblur "
        "(NAFNet), lighting & colour per scene, AI stutter repair, AI frame rate (if a new frame rate "
        "is chosen), low-light AI for dark videos, colourising black & white, AI sound rebuild for poor sound, "
        "highest encoding quality.",
        "Nothing.",
        "Precious footage you can leave running for a long time (overnight or longer)."),
    "very_high_quality": (
        "Almost the best, about twice as fast as Max Quality.",
        "As Max Quality, but the fast AI upscaler (made for video) instead of the full one: AI clean-up (SCUNet), "
        "AI deblur, all the light AI steps.",
        "The full (slowest) AI upscaler.",
        "Important videos when Max Quality would take too long."),
    "high_quality": (
        "AI upscaling and AI deblur.",
        "Fast AI upscaling to twice the size, AI deblur, the best classic noise filter, lighting & colour per "
        "scene and all the light AI steps.",
        "AI noise clean-up (SCUNet) and the full AI upscaler.",
        "Old, small or blurry videos you want noticeably sharper and bigger."),
    "balanced_quality": (
        "AI deblur at the original size - the first level that runs a large AI model on every frame.",
        "AI deblur (sharper motion and focus), the best classic noise filter, lighting & colour per scene, "
        "and all the light AI steps. The size stays the same.",
        "AI upscaling and AI noise clean-up.",
        "HD videos that are a bit blurry (moving cameras, security cameras) and don't need to be bigger."),
    "balanced": (
        "Good clean-up without any large AI model - much faster than the levels above.",
        "Best classic noise filter, compression clean-up, lighting & colour per scene, white balance, "
        "flicker removal, and the light AI steps: low-light AI for dark videos, AI stutter repair, "
        "colourising black & white, AI sound rebuild for poor sound, and AI-made frames when a new frame rate is "
        "chosen on the Enhance page (that is the slowest part of this level - set 'New frames by' to blending to "
        "keep it fast).",
        "Every large AI model (upscaling, AI deblur, AI noise clean-up). The size stays the same.",
        "Everyday videos and big batches that should look clearly better without waiting hours."),
    "balanced_performance": (
        "As Balanced, a little faster.",
        "Fast noise filter, compression clean-up, lighting & colour per scene, low-light AI for dark "
        "videos, AI stutter repair, AI sound rebuild; a new frame rate is made by blending frames.",
        "The best (slower) noise filter, AI-made frames, colourising, flicker removal and every large AI model.",
        "Large batches that should still get the small AI steps."),
    "high_performance": (
        "Classic filters only - no AI.",
        "Noise filter, compression clean-up, lighting & colour per scene, white balance, frame "
        "blending for a new frame rate.",
        "All AI steps.",
        "Fast results on any PC, or when AI isn't wanted."),
    "very_high_performance": (
        "Lighter classic filters - no AI.",
        "Noise filter, compression clean-up, light lighting & colour fixes, white balance.",
        "AI, lighting & colour worked out per scene (one setting for the whole video instead).",
        "Big archives (e.g. security footage) where speed matters most."),
    "max_performance": (
        "The fastest: a quick tidy-up - no AI.",
        "Light noise filter and automatic levels; everything else is left as it is.",
        "AI, colour fixes, compression clean-up, per-scene lighting, shape fixes.",
        "Quick drafts, previews, or huge numbers of videos."),
}


QUALITY_MODULES = ("stitcher", "convert", "motion", "ends", "stabilize", "transform", "subtitles", "tracker",
                   "enhance")     # modules whose results the level changes


def level_name(key: str | None, settings=None) -> str:
    """Display name of a level key as stored with a task ('balanced', 'custom', 'user:Mine')."""
    if not key:
        return ""
    if key == "custom":
        return "Custom"
    if key.startswith("user:"):
        return "★ " + key[5:]
    return dict((k, n) for n, k in TIERS).get(key, key)


def _cols(*vals) -> dict:
    return dict(zip(TIER_KEYS, vals))


# module -> setting -> value per level (max quality ... max performance)
TABLE: dict[str, dict[str, dict]] = {
    "stitcher": {"crf": _cols(14, 15, 16, 17, 18, 19, 20, 22, 23),
                 "enc_speed": _cols(*["quality"] * 3, *["balanced"] * 3, *["fast"] * 3),
                 "verify": _cols(True, True, True, True, True, True, True, True, False)},
    "motion": {"analysis_fps": _cols(10.0, 10.0, 10.0, 8.0, 5.0, 5.0, 5.0, 3.0, 2.0),
               "sensitivity": _cols(*[10] * 9),
               "edge_crf": _cols(14, 15, 16, 17, 18, 19, 20, 22, 23),
               "full_crf": _cols(14, 15, 16, 17, 18, 19, 20, 22, 23),
               "exact_audio": _cols(True, True, True, True, True, False, False, False, False),
               "enc_speed": _cols(*["quality"] * 3, *["balanced"] * 3, *["fast"] * 3)},
    "ends": {"edge_crf": _cols(14, 15, 16, 17, 18, 19, 20, 22, 23),
             "full_crf": _cols(14, 15, 16, 17, 18, 19, 20, 22, 23),
             "exact_audio": _cols(True, True, True, True, True, False, False, False, False),
             "enc_speed": _cols(*["quality"] * 3, *["balanced"] * 3, *["fast"] * 3)},
    "convert": {"crf": _cols(16, 17, 18, 19, 20, 21, 22, 24, 26),
                "enc_speed": _cols(*["quality"] * 3, *["balanced"] * 3, *["fast"] * 3)},
    "transform": {"crf": _cols(14, 15, 16, 17, 18, 19, 20, 22, 23),
                  "enc_speed": _cols(*["quality"] * 3, *["balanced"] * 3, *["fast"] * 3)},
    "subtitles": {"crf": _cols(14, 15, 16, 17, 18, 19, 20, 22, 23),
                  "enc_speed": _cols(*["quality"] * 3, *["balanced"] * 3, *["fast"] * 3)},
    "stabilize": {"crf": _cols(14, 15, 16, 17, 18, 19, 20, 22, 23),
                  "enc_speed": _cols(*["quality"] * 3, *["balanced"] * 3, *["fast"] * 3)},
    "tracker": {"model": _cols("m", "m", "m", "m", "s", "s", "n", "n", "n"),
                "det_fps": _cols(10.0, 10.0, 8.0, 5.0, 5.0, 5.0, 3.0, 2.0, 2.0),
                "smooth": _cols(*[10.0] * 9), "crf": _cols(14, 15, 16, 17, 18, 19, 20, 22, 23),
                "enc_speed": _cols(*["quality"] * 3, *["balanced"] * 3, *["fast"] * 3)},
}

# Enhance: every level sets the same keys (so 'Custom' can be told apart).
# Spaced for 720p video: in the AI half each level takes about 2-2.6x as long as the next faster one; the
# five faster levels all take minutes (they differ in filters and small AI steps). Between them is the one
# bigger jump: the first level that runs a large AI network on every frame (AI deblur).
_FULL = dict(ai_strength=70, same_size_ai=True, deblock=2, deband=True, auto_levels=60,
             white_balance=True, per_scene=100, shadows=30, highlights=20, vibrance=15, sharpen=1, grain=1,
             colourise="auto", stutter="ai", fr_method="rife", deflicker=1, low_light=60, low_light_auto=True,
             declip=1, shape="auto", sound_ai="auto", audio_denoise=2, denoise_ai_temporal=1)
_LIGHT = dict(_FULL, size="same", upscaler="lanczos", same_size_ai=False, denoise_ai=0, deblur=0, deblock=1,
              grain=0, auto_levels=50, per_scene=80, shadows=20, highlights=10, vibrance=10, audio_denoise=1)
_NOAI = dict(_LIGHT, colourise="off", stutter="blend", fr_method="blend", low_light=0, declip=0, sound_ai="off",
             deflicker=0)
_ENH = {
    # 1: every AI step at its best - full Real-ESRGAN upscaling, AI denoise, AI deblur
    "max_quality": dict(_FULL, size="x2", upscaler="ai_best", denoise=0, denoise_method="nlmeans", denoise_ai=100,
                        deblur=100, crf=14),
    # 2: the fast AI upscaler (made for video) instead of the full one; AI denoise and deblur kept
    "very_high_quality": dict(_FULL, size="x2", upscaler="ai_fast", denoise=0, denoise_method="nlmeans",
                              denoise_ai=100, deblur=100, crf=15),
    # 3: fast AI upscaling + AI deblur; the best classic noise filter instead of AI denoise
    "high_quality": dict(_FULL, size="x2", upscaler="ai_fast", denoise=2, denoise_method="nlmeans", denoise_ai=0,
                         deblur=100, crf=16),
    # 4: AI deblur at the original size (no AI upscaling)
    "balanced_quality": dict(_LIGHT, denoise=2, denoise_method="nlmeans", deblur=100, deflicker=1, crf=17),
    # 5: no big AI network: small AI steps only (low light, stutter repair, AI frame rate, colourise B&W, sound)
    "balanced": dict(_LIGHT, denoise=2, denoise_method="nlmeans", deflicker=1, crf=18),
    # 6: as Balanced, without colourising and flicker removal
    "balanced_performance": dict(_LIGHT, denoise=2, denoise_method="hqdn3d", colourise="off",
                                 deflicker=0, declip=0, per_scene=70, fr_method="blend", crf=19),
    # 7-9: no AI at all
    "high_performance": dict(_NOAI, denoise=2, denoise_method="hqdn3d", per_scene=70, crf=20),
    "very_high_performance": dict(_NOAI, denoise=2, denoise_method="hqdn3d", per_scene=0, crf=22),
    "max_performance": dict(_NOAI, size="same", denoise=1, denoise_method="hqdn3d", deblock=0, deband=False,
                            white_balance=False, per_scene=0, shadows=10, highlights=0, vibrance=5,
                            stutter="off", shape="off", crf=23),
}
TABLE["enhance"] = {k: {t: _ENH[t][k] for t in TIER_KEYS} for k in _ENH["max_quality"]}
TABLE["enhance"]["enc_speed"] = _cols(*["quality"] * 3, *["balanced"] * 3, *["fast"] * 3)

# Enhance content types: what to fix, on top of the tier (the tier decides how much AI)
CONTENT = [("General", "general"), ("Old film & VHS", "oldfilm"), ("Phone & action camera", "phone"),
           ("Night & security camera", "night"), ("Upscale only (AI)", "upscale")]


def uses_ai(vals: dict) -> bool:
    """Whether a level's (or page's) values use any AI step."""
    return (vals.get("upscaler", "lanczos") != "lanczos" or bool(vals.get("low_light")) or bool(vals.get("deblur"))
            or bool(vals.get("denoise_ai")) or vals.get("sound_ai", "off") != "off"
            or vals.get("stutter") == "ai" or vals.get("fr_method") == "rife" or vals.get("colourise", "off") != "off")


def speed_class(vals: dict) -> str:
    """'heavy' (a large AI model on every frame), 'light' (small AI steps only) or 'none' - Enhance's speed is
    learned per class, so a quick no-AI run doesn't change the time expected for an AI one."""
    if vals.get("upscaler", "lanczos") != "lanczos" or vals.get("deblur") or vals.get("denoise_ai"):
        return "heavy"
    return "light" if uses_ai(vals) else "none"


def content_overlay(content: str, base: dict) -> dict:
    """What a content type adds on top of a level. On a level without AI, no AI steps are added."""
    over = _content_overlay(content, base)
    if not uses_ai(base):
        over.pop("colourise", None)
        over.pop("low_light", None)
        if over.get("upscaler") not in (None, "lanczos"):
            over["upscaler"] = "lanczos"
    return over


def _content_overlay(content: str, base: dict) -> dict:
    if content == "oldfilm":
        return dict(deinterlace="auto", crop="auto", shape="auto", dust=2, deflicker=2, colourise="auto", declip=2,
                    audio_denoise=2, grain=1)
    if content == "phone":
        return dict(wind=2)          # (the wobble fix, stabilising and horizon moved to the Stabilizer page)
    if content == "night":
        return dict(low_light=80, low_light_auto=True, shadows=30, highlights=20, vibrance=0,
                    denoise=max(3, base.get("denoise", 0)) if not base.get("denoise_ai") else base.get("denoise", 0),
                    audio_denoise=2)
    if content == "upscale":
        return dict(size="x2", upscaler=base.get("upscaler") if base.get("upscaler") != "lanczos" else "ai_fast",
                    denoise=0, denoise_ai=0, deblur=0, deblock=0, deband=False, auto_levels=0, per_scene=0,
                    shadows=0, highlights=0, vibrance=0, sharpen=0, grain=0, audio_denoise=0, loudness=False,
                    stutter="off", deflicker=0, low_light=0, declip=0)
    return {}


# graphics-card optimisations: on wherever this PC supports them (not part of the tiers)
def hardware_values(settings) -> dict[str, dict]:
    enc = settings.get("app", "gpu_encoders") or {}
    gpu_enc = bool(enc.get("hevc") or enc.get("h264"))
    hw = settings.get("app", "hardware") or {}
    gpu_ai = hw.get("bench", {}).get("device") == "graphics card" if hw.get("bench") else True
    tile = (hw.get("rec") or {}).get("perf", {}).get("tile")
    try:
        from breezy.core.hardware import recommended_tile
        tile = recommended_tile(settings) or tile
    except Exception:
        pass
    out = {"stitcher": {"use_gpu": gpu_enc}, "motion": {"full_gpu": gpu_enc, "hwaccel": True},
           "ends": {"full_gpu": gpu_enc},
           "stabilize": {"enc_gpu": gpu_enc, "hwaccel": True, "gpu_filters": True},
           "convert": {"enc_gpu": gpu_enc}, "transform": {"enc_gpu": gpu_enc},
           "subtitles": {"enc_gpu": gpu_enc, "ai_gpu": gpu_ai},
           "tracker": {"det_gpu": gpu_ai, "enc_gpu": gpu_enc, "hwaccel": True},
           "enhance": {"enc_gpu": gpu_enc, "ai_gpu": gpu_ai, "hwaccel": True, "gpu_filters": True}}
    try:
        from breezy.core.hardware import half_supported
        out["enhance"]["ai_half"] = bool(gpu_ai and half_supported(settings))
    except Exception:
        pass
    if tile:
        out["enhance"]["tile"] = int(tile)
    return out


def tier_values(name: str, settings) -> dict[str, dict]:
    """module -> {key: value} for a tier or a saved preset ('user:<name>')."""
    if name.startswith("user:"):
        saved = (settings.get("app", "global_presets") or {}).get(name[5:], {})
        return {m: dict(v) for m, v in saved.items()}
    if name not in TIER_KEYS:
        return {}
    return {m: {k: col[name] for k, col in keys.items()} for m, keys in TABLE.items()}


class QualityManager:
    """Applies the global setting to every module and notices when a page drifts from it ('Custom')."""

    def __init__(self, settings, features: list):
        self.settings, self.features = settings, features
        self.applying = False
        self.listeners = []          # called with the new current name

    @property
    def current(self) -> str:
        return self.settings.get("app", "quality", DEFAULT)

    def names(self) -> list[tuple[str, str]]:
        user = sorted((self.settings.get("app", "global_presets") or {}).keys())
        return TIERS + [(f"★ {n}", f"user:{n}") for n in user] + ([("Custom", "custom")] if self.current == "custom" else [])

    def expected(self, module: str) -> dict:
        cur = self.current
        if cur == "custom":
            return {}
        vals = dict(tier_values(cur, self.settings).get(module, {}))
        if module == "enhance":
            content = self.settings.get("enhance", "content", "general")
            vals.update(content_overlay(content, vals))
        return vals

    def apply(self, name: str):
        """Switch every module to a tier / saved preset (and the hardware optimisations)."""
        vals = tier_values(name, self.settings)
        hwv = hardware_values(self.settings)
        self.applying = True
        try:
            for module, kv in vals.items():
                kv = dict(kv)
                if module == "enhance" and "content" in kv:
                    self.settings.set("enhance", "content", kv.pop("content"))
                if module == "enhance":
                    kv.update(content_overlay(self.settings.get("enhance", "content", "general"), kv))
                for k, v in {**kv, **hwv.get(module, {})}.items():
                    self.settings.set(module, k, v)
            for module, kv in hwv.items():
                if module not in vals:
                    for k, v in kv.items():
                        self.settings.set(module, k, v)
            self.settings.set("app", "quality", name)
            for f in self.features:
                if hasattr(f, "reload_settings"):
                    try:
                        f.reload_settings()
                    except Exception:
                        import logging
                        logging.exception("reload_settings failed for %s", f.id)
        finally:
            self.applying = False
        self._notify()

    def changed(self, module: str, key: str, value):
        """Called whenever a page saves a setting."""
        if self.applying or self.current == "custom":
            return
        exp = self.expected(module)
        if key in exp and not _same(exp[key], value):
            self.settings.set("app", "quality_base", self.current)     # what the changes started from
            self.settings.set("app", "quality", "custom")
            self._notify()

    def save_as(self, name: str):
        """Save every module's tier-controlled settings under a name of the user's choosing."""
        snap = {}
        for module, keys in TABLE.items():
            snap[module] = {k: self.settings.get(module, k) for k in keys if self.settings.get(module, k) is not None}
        snap["enhance"]["content"] = self.settings.get("enhance", "content", "general")
        presets = dict(self.settings.get("app", "global_presets") or {})
        presets[name] = snap
        self.settings.set("app", "global_presets", presets)
        self.settings.set("app", "quality", f"user:{name}")
        self._notify()

    def delete(self, name: str):
        presets = dict(self.settings.get("app", "global_presets") or {})
        presets.pop(name, None)
        self.settings.set("app", "global_presets", presets)
        if self.current == f"user:{name}":
            self.settings.set("app", "quality", "custom")
        self._notify()

    def _notify(self):
        for cb in list(self.listeners):
            try:
                cb(self.current)
            except Exception:
                pass


def _same(a, b) -> bool:
    if isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool):
        return abs(float(a) - float(b)) < 1e-6
    return a == b
