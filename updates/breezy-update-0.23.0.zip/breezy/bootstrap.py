"""Install new components after an update, before the app starts.

The taskbar/desktop shortcut starts the app directly (not through run.bat), so the app itself
checks whether requirements.txt changed since components were last installed (same hash file
run.bat uses) and, if so, runs pip once with a small progress window.
"""
from __future__ import annotations

import hashlib
import subprocess
import sys
import threading
from pathlib import Path

APP_DIR = Path(__file__).resolve().parents[1]
REQ = APP_DIR / "requirements.txt"
REQ_NODEPS = APP_DIR / "requirements-nodeps.txt"
NO_WINDOW = 0x08000000 if sys.platform == "win32" else 0


def _venv_dir() -> Path | None:
    p = Path(sys.prefix)
    return p if (p / "pyvenv.cfg").is_file() and getattr(sys, "frozen", False) is False else None


def _wanted_hash() -> str:
    h = hashlib.sha256(REQ.read_bytes())
    if REQ_NODEPS.is_file():
        h.update(REQ_NODEPS.read_bytes())
    return h.hexdigest().upper()


def _python() -> Path:
    exe = Path(sys.executable)
    return exe.with_name("python.exe") if exe.name.lower() == "pythonw.exe" else exe


def pip_commands() -> list[list[str]]:
    base = [str(_python()), "-m", "pip", "install", "--disable-pip-version-check", "--only-binary", "av"]
    cmds = [base + ["-r", str(REQ)]]
    if REQ_NODEPS.is_file():
        cmds.append(base + ["--no-deps", "-r", str(REQ_NODEPS)])
    return cmds


def write_stamp() -> None:
    try:
        (_venv_dir() / "req.hash").write_text(_wanted_hash() + "\n", "utf-8")
    except (OSError, TypeError):
        pass


def needs_install() -> bool:
    venv = _venv_dir()
    if venv is None or not REQ.is_file():
        return False
    stamp = venv / "req.hash"
    try:
        have = stamp.read_text("utf-8", "replace").strip().upper()
    except OSError:
        have = ""
    return have != _wanted_hash()


def ensure_components() -> None:
    if not needs_install():
        return
    from PySide6.QtCore import Qt, QTimer
    from PySide6.QtWidgets import (QApplication, QDialog, QLabel, QMessageBox, QPlainTextEdit, QProgressBar,
                                   QVBoxLayout)
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Breezy.VideoEdit")
        except Exception:
            pass
    app = QApplication.instance() or QApplication(sys.argv)
    app.setStyle("Fusion")
    dlg = QDialog()
    dlg.setWindowTitle("Breezy Video - updating")
    dlg.setWindowFlag(Qt.WindowCloseButtonHint, False)
    dlg.resize(620, 340)
    v = QVBoxLayout(dlg)
    v.addWidget(QLabel("Installing new components for this version (one time only, a few minutes)…"))
    bar = QProgressBar()
    bar.setRange(0, 0)
    v.addWidget(bar)
    log = QPlainTextEdit(readOnly=True)
    v.addWidget(log, 1)
    state = {"lines": [], "rc": None}

    def work():
        try:
            rc = 0
            for cmd in pip_commands():
                p = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                     creationflags=NO_WINDOW, cwd=str(APP_DIR))
                for line in p.stdout:
                    state["lines"].append(line.rstrip())
                rc = p.wait()
                if rc:
                    break
            state["rc"] = rc
        except Exception as e:  # noqa
            state["lines"].append(str(e))
            state["rc"] = -1

    shown = [0]

    def poll():
        new = state["lines"][shown[0]:]
        shown[0] += len(new)
        for line in new:
            log.appendPlainText(line)
        if state["rc"] is not None:
            timer.stop()
            dlg.accept()

    threading.Thread(target=work, daemon=True).start()
    timer = QTimer(interval=200)
    timer.timeout.connect(poll)
    timer.start()
    dlg.exec()
    if state["rc"] == 0:
        write_stamp()
    else:
        QMessageBox.warning(None, "Breezy Video",
                            "Some new components could not be installed, so some features may not work.\n"
                            "Check your internet connection and start the app again (or run run.bat).\n\n"
                            + "\n".join(state["lines"][-8:]))


def console_install() -> int:
    """Used by run.bat: install in the console window when anything changed."""
    if not needs_install():
        return 0
    print("Installing new components, this can take a few minutes...", flush=True)
    for cmd in pip_commands():
        rc = subprocess.call(cmd, cwd=str(APP_DIR))
        if rc:
            return rc
    write_stamp()
    return 0


if __name__ == "__main__":
    sys.exit(console_install())
