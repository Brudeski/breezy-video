"""Breezy Video - a modular toolbox for working with video files."""

APP_NAME = "Breezy Video"
APP_ID = "BreezyVideoEdit"
__version__ = "0.23.0"
