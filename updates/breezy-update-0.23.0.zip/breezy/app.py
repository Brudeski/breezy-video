"""Main window: collapsible sidebar of modules, pages, and a task bar along the bottom."""
from __future__ import annotations

import logging
import subprocess
import sys
import threading
import traceback
from pathlib import Path

from PySide6.QtCore import QSize, Qt, QTimer, Signal
from PySide6.QtGui import QGuiApplication, QIcon
from PySide6.QtWidgets import (QApplication, QComboBox, QHBoxLayout, QLabel, QListWidget, QListWidgetItem,
                               QMainWindow, QMessageBox, QStackedWidget, QToolButton,
                               QVBoxLayout, QWidget)

from breezy import APP_NAME, __version__
from breezy.changelog import since
from breezy.core import encoders, hardware, repair, theme
from breezy.core.ffmpeg import FFmpeg, _app_root
from breezy.core.icons import icon
from breezy.core.plugin import AppContext, discover_features
from breezy.core.settings import Settings, app_data_dir
from breezy.core.tasks import OutputHistory, TaskManager
from breezy.core.ui import TaskBar, page_header

SIDEBAR_WIDE, SIDEBAR_SLIM = 240, 64


class MainWindow(QMainWindow):
    repair_found = Signal(dict)
    cuda_needed = Signal()
    trt_needed = Signal()

    def __init__(self):
        super().__init__()
        self.setWindowTitle(f"{APP_NAME} {__version__}")
        self.resize(1600, 960)
        self._closing_after_tasks = False

        self.settings = Settings()
        ffmpeg = FFmpeg(self.settings.get("app", "ffmpeg_dir"))
        history = OutputHistory(app_data_dir() / "history.json")
        self.tasks = TaskManager(ffmpeg, self.settings, app_data_dir() / "tasks.json", history)
        self.context = AppContext(settings=self.settings, ffmpeg=ffmpeg, tasks=self.tasks,
                                  history=history, window=self,
                                  status=lambda m: self.statusBar().showMessage(m, 8000))
        theme.apply(QApplication.instance(), self.settings.get("app", "theme", "auto"))
        from breezy.core.quality import QualityManager
        self.features = []
        self.quality = QualityManager(self.settings, self.features)
        self.context.quality = self.quality
        from breezy.core.pipelines import PipelineRunner
        self.pipelines = PipelineRunner(self.tasks, self.settings, self)
        self.context.pipelines = self.pipelines
        from breezy.core.watch import WatchService
        self.watch = WatchService(self.settings, self.tasks, self.pipelines, history, self)
        from breezy.core.updater import UpdateChecker
        self.updates = UpdateChecker(self.settings, self)
        first_quality = self.settings.get("app", "quality") is None

        # ---- sidebar
        self.sidebar = QWidget(objectName="sidebar")
        sv = QVBoxLayout(self.sidebar)
        sv.setContentsMargins(6, 14, 6, 10)
        sv.setSpacing(6)
        brand = QHBoxLayout()
        self.logo = QLabel()
        ico = Path(__file__).resolve().parent / "assets" / "icon.png"
        if ico.is_file():
            self.logo.setPixmap(QIcon(str(ico)).pixmap(40, 40))
        brand.addWidget(self.logo)
        names = QVBoxLayout()
        names.setSpacing(0)
        self.brand = QLabel("Breezy Video", objectName="brand")
        self.brand_ver = QLabel(f"version {__version__}", objectName="brandVersion")
        names.addWidget(self.brand)
        names.addWidget(self.brand_ver)
        brand.addLayout(names, 1)
        sv.addLayout(brand)
        sv.addSpacing(6)
        self.quality_box = self._quality_widget()
        sv.addWidget(self.quality_box)
        sv.addSpacing(6)
        self.nav = QListWidget(objectName="nav")
        self.nav.setIconSize(QSize(20, 20))
        sv.addWidget(self.nav, 1)
        self.collapse = QToolButton(objectName="collapse")
        self.collapse.setToolTip("Collapse / expand the sidebar")
        self.collapse.clicked.connect(self.toggle_sidebar)
        sv.addWidget(self.collapse, 0, Qt.AlignLeft)

        # ---- pages
        self.pages = QStackedWidget()
        self.quality.applying = True          # pages saving their settings while being built isn't a change
        for cls in discover_features(_app_root() / "plugins"):
            try:
                feat = cls(self.context)
                page = self._wrap(feat, feat.create_widget())
            except Exception:
                logging.exception("Feature %s failed to start", cls)
                continue
            self.features.append(feat)
            item = QListWidgetItem(feat.name)
            item.setToolTip(feat.description)
            item.setData(Qt.UserRole, feat.name)
            self.nav.addItem(item)
            self.pages.addWidget(page)
        self.nav.currentRowChanged.connect(self.pages.setCurrentIndex)
        self.nav.setCurrentRow(0)
        self.quality.applying = False
        from breezy.core import tips
        for i in range(self.pages.count()):
            try:
                tips.apply(self.pages.widget(i))
                tips.advise(self.pages.widget(i))
            except Exception:
                logging.exception("tooltips")
        from breezy.core import power
        power.set_mode(self.settings.get("app", "power_mode", "full"))
        self.idle_watch = power.IdleWatcher(self.tasks, self.settings, notify=lambda m: self.context.status(m))
        self.tip_gate = tips.TooltipGate(bool(self.settings.get("app", "tooltips", True)))
        QApplication.instance().installEventFilter(self.tip_gate)
        from breezy.core.quality import TIER_KEYS, TIERS_VERSION
        tiers_changed = (self.settings.get("app", "tiers_version", 1) or 1) < TIERS_VERSION
        if tiers_changed:
            self.settings.set("app", "tiers_version", TIERS_VERSION)
            self._migrate_learned_speed()
        if first_quality or (tiers_changed and self.quality.current in TIER_KEYS):
            # first start, or the built-in levels changed (0.16.0: nine levels): use the level's new values
            self.quality.apply(self.quality.current)
        self._quality_refresh(self.quality.current)

        # ---- bottom task bar (always visible)
        self.bottom = TaskBar(self.tasks, None, bottom=True)
        from breezy.core.whendone import WhenDoneButton
        self.when_done = WhenDoneButton(self.settings, self)
        lay = self.bottom.layout()
        lay.insertWidget(lay.indexOf(self.bottom.power_btn), self.when_done)

        central = QWidget()
        outer = QVBoxLayout(central)
        outer.setContentsMargins(0, 0, 0, 0)
        outer.setSpacing(0)
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        row.setSpacing(0)
        row.addWidget(self.sidebar)
        row.addWidget(self.pages, 1)
        outer.addLayout(row, 1)
        outer.addWidget(self.bottom)
        self.setCentralWidget(central)
        self.statusBar().hide()

        self._slim = bool(self.settings.get("app", "sidebar_slim", False))
        self._apply_sidebar()
        self._refresh_icons()
        try:
            QGuiApplication.styleHints().colorSchemeChanged.connect(self._system_theme_changed)
        except Exception:
            pass

        threading.Thread(target=lambda: encoders.detect(ffmpeg, self.settings), daemon=True).start()
        QTimer.singleShot(300, self._startup_dialogs)
        repair.register()
        hardware.register()
        from breezy.core import ai_engine
        ai_engine.register()
        self.repair_found.connect(self._repair_found)
        self.cuda_needed.connect(self.install_cuda)
        self.trt_needed.connect(self.install_trt)
        self.tasks.finished.connect(self._task_finished)
        QTimer.singleShot(2500, self.check_repairs)
        QTimer.singleShot(6000, self._migrate_shortcuts)
        from breezy.core.notify import Notifier
        self.notifier = Notifier(self, self.settings)
        self.watch.started.connect(self._watch_started)
        self._tray_menu()
        self.updates.found.connect(self.offer_update)
        QTimer.singleShot(8000, self.updates.check_soon)
        self._update_timer = QTimer(self, interval=6 * 3600 * 1000)
        self._update_timer.timeout.connect(self.updates.check_soon)
        self._update_timer.start()

    # ------------------------------------------------------------- quality
    def _quality_widget(self) -> QWidget:
        from breezy.core.quality import TIER_INFO, TIERS
        w = QWidget(objectName="qualityBox")
        v = QVBoxLayout(w)
        v.setContentsMargins(4, 0, 4, 0)
        v.setSpacing(2)
        self.quality_label = QLabel("Quality", objectName="brandVersion")
        top = QHBoxLayout()
        top.setContentsMargins(0, 0, 0, 0)
        top.addWidget(self.quality_label, 1)
        v.addLayout(top)
        row = QHBoxLayout()
        row.setSpacing(4)
        self.quality_combo = QComboBox(objectName="qualityCombo")
        self.quality_combo.setToolTip(
            "One setting for every module - how much quality vs. speed:\n"
            + "\n".join(f"• {n} - {TIER_INFO[k][0]}" for n, k in TIERS) +
            "\n\nThe levels are the same on every PC; the graphics card is used wherever this PC supports it.\n"
            "Hover over a level in the open list for details and how long it takes here.\n"
            "Changing a setting on a page makes this 'Custom'. ★ = your own saved ones.\n\n"
            "When to use: Balanced suits most videos. Pick a higher level for keepsakes you can leave\n"
            "running for hours, a lower one for big batches or quick drafts.")
        self.quality_combo.activated.connect(self._quality_chosen)
        self.quality_menu_btn = QToolButton(objectName="qualityMore")
        self.quality_menu_btn.setText("⋯")
        self.quality_menu_btn.setToolTip("Save the current settings under your own name, or delete a saved one")
        self.quality_menu_btn.setPopupMode(QToolButton.InstantPopup)
        from PySide6.QtWidgets import QMenu
        self.quality_menu = QMenu(self.quality_menu_btn)
        self.quality_menu.aboutToShow.connect(self._quality_menu_show)
        self.quality_menu_btn.setMenu(self.quality_menu)
        row.addWidget(self.quality_combo, 1)
        top.addWidget(self.quality_menu_btn)          # on the label's line, so the level name has the full width
        v.addLayout(row)
        self.quality.listeners.append(self._quality_refresh)
        return w

    def _quality_refresh(self, current: str):
        c = self.quality_combo
        c.blockSignals(True)
        c.clear()
        for name, key in self.quality.names():
            c.addItem(name, key)
            c.setItemData(c.count() - 1, self._level_tooltip(name, key), Qt.ToolTipRole)
        c.setCurrentIndex(max(0, c.findData(current)))
        c.blockSignals(False)
        try:
            c.view().setMinimumWidth(c.view().sizeHintForColumn(0) + 30)    # the open list shows full names
        except Exception:
            pass

    def _level_tooltip(self, name: str, key: str) -> str:
        """Detailed hover text for one level in the open list (with how long it takes on this PC)."""
        import textwrap
        from breezy.core.quality import TIER_INFO, TIER_KEYS
        if key == "custom":
            return "Your own changes to the settings of the last level (not saved).\nUse ⋯ to save them under a name."
        if key.startswith("user:"):
            return f"Your own saved settings '{key[5:]}'. ⋯ deletes them."
        if key not in TIER_INFO:
            return ""
        summary, does, leaves, use = TIER_INFO[key]
        n = TIER_KEYS.index(key) + 1
        w = lambda t: textwrap.fill(t, 78)          # noqa: E731
        lines = [f"{name}  (level {n} of {len(TIER_KEYS)})", w(summary), "", w("Does: " + does),
                 w("Leaves out: " + leaves), w("When to use: " + use)]
        try:
            from breezy.core.hardware import duration_text
            from breezy.features.enhance.bench import level_minutes
            mins = level_minutes(key, self.settings)
            if mins:
                fr = self.settings.get("enhance", "frame_rate", "same") or "same"
                lines += ["", w(f"Enhance on this PC: {duration_text(mins)} of work per minute of 720p video "
                                f"(estimate{', with the frame rate set on the Enhance page' if fr != 'same' else ''}"
                                f"; it gets more accurate as tasks finish).")]
        except Exception:
            pass
        return "\n".join(lines)

    def _migrate_learned_speed(self):
        """Speeds learned before 0.16.0 were all from AI-upscaling runs: file them as 'heavy'."""
        table = dict(self.settings.get("app", "learned_speed") or {})
        changed = False
        for k in list(table):
            kind, sep, w = k.partition("|")
            if "/" not in kind and kind.startswith("enhance."):
                table.setdefault(f"{kind}/heavy|{w}", table.pop(k))
                changed = True
        if changed:
            self.settings.set("app", "learned_speed", table)

    def _quality_chosen(self, *_):
        key = self.quality_combo.currentData()
        if key == "custom":
            self._quality_refresh(self.quality.current)
            return
        if key == self.quality.current:
            return
        if self.quality.current == "custom" and not self._quality_keep_custom():
            self._quality_refresh(self.quality.current)
            return
        self.quality.apply(key)
        self.context.status(f"Quality: {self.quality_combo.currentText()} - applied to every module")

    def _quality_menu_show(self):
        m = self.quality_menu
        m.clear()
        m.addAction("Save current settings as…", self._quality_save)
        cur = self.quality.current
        if cur.startswith("user:"):
            m.addAction(f"Delete '{cur[5:]}'", lambda: self.quality.delete(cur[5:]))

    def _quality_keep_custom(self) -> bool:
        """Leaving Custom: offer to save the changes first. False = stay on Custom."""
        from PySide6.QtWidgets import QMessageBox
        r = QMessageBox.question(self, "Quality",
                                 "You have changed settings (Custom). Save your custom settings first?\n\n"
                                 "Yes = save them under a name, No = switch without saving.",
                                 QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel, QMessageBox.Yes)
        if r == QMessageBox.Cancel:
            return False
        if r == QMessageBox.Yes:
            before = self.quality.current
            self._quality_save()
            if self.quality.current == before:        # name dialog cancelled
                return False
        return True

    def _quality_save(self):
        from PySide6.QtWidgets import QInputDialog
        cur = self.quality.current
        name, ok = QInputDialog.getText(self, "Save quality preset", "Name for the current settings of every module:",
                                        text=cur[5:] if cur.startswith("user:") else "")
        name = (name or "").strip()
        if ok and name:
            self.quality.save_as(name)

    # ----------------------------------------------------------------- pages
    def _wrap(self, feat, widget: QWidget) -> QWidget:
        page = QWidget(objectName="page")
        v = QVBoxLayout(page)
        v.setContentsMargins(22, 16, 22, 10)
        v.setSpacing(10)
        v.addWidget(page_header(feat.name, feat.description))
        v.addWidget(widget, 1)
        return page

    def show_feature(self, feature_id: str):
        for i, f in enumerate(self.features):
            if f.id == feature_id:
                self.nav.setCurrentRow(i)

    # --------------------------------------------------------------- sidebar
    def toggle_sidebar(self):
        self._slim = not self._slim
        self.settings.set("app", "sidebar_slim", self._slim)
        self._apply_sidebar()

    def _apply_sidebar(self):
        self.sidebar.setFixedWidth(SIDEBAR_SLIM if self._slim else SIDEBAR_WIDE)
        self.brand.setVisible(not self._slim)
        self.brand_ver.setVisible(not self._slim)
        self.quality_box.setVisible(not self._slim)
        for i in range(self.nav.count()):
            it = self.nav.item(i)
            it.setText("" if self._slim else it.data(Qt.UserRole))
        self._refresh_icons()

    def _refresh_icons(self):
        c = theme.colors()
        for i, f in enumerate(self.features):
            self.nav.item(i).setIcon(icon(f.icon, c["sidebar_text"], 20))
        self.collapse.setIcon(icon("chev_right" if self._slim else "chev_left", c["sidebar_text"], 18))
        self.bottom.refresh()

    # ----------------------------------------------------------------- theme
    def set_theme(self, mode: str):
        self.settings.set("app", "theme", mode)
        theme.apply(QApplication.instance(), mode)
        self._refresh_icons()
        for f in self.features:
            try:
                f.theme_changed()
            except Exception:
                logging.exception("theme_changed failed for %s", f.id)

    def _system_theme_changed(self, *_):
        if self.settings.get("app", "theme", "auto") == "auto":
            self.set_theme("auto")

    # -------------------------------------------------------------- startup
    def _startup_dialogs(self):
        # What's new (once after an update)
        seen = self.settings.get("app", "last_seen_version")
        had_settings = bool(self.settings.get("stitcher", "last_folder")) or bool(self.settings.get("motion", "last_folder"))
        if seen != __version__ and (seen or had_settings):
            self.show_whats_new(since(seen))
        self.settings.set("app", "last_seen_version", __version__)
        # Unfinished tasks from last time
        left = self.tasks.load_unfinished()
        if left:
            names = "\n".join(f"• {t.title} ({len(t.done_items)}/{len(t.items) or '?'} done)" for t in left[:10])
            box = QMessageBox(self)
            box.setWindowTitle("Unfinished tasks")
            box.setText(f"{len(left)} task(s) didn't finish last time:\n\n{names}\n\n"
                        "Resume them? Finished files are kept. Enhance continues a long video from its last "
                        "finished minute; other files that were in progress start again.")
            resume = box.addButton("Resume now", QMessageBox.AcceptRole)
            later = box.addButton("Add paused", QMessageBox.ActionRole)
            box.addButton("Discard", QMessageBox.RejectRole)
            box.exec()
            if box.clickedButton() is resume:
                self.tasks.restore(left)
                self.show_feature("tasks")
            elif box.clickedButton() is later:
                self.tasks.restore(left, paused=True)
                self.show_feature("tasks")
            else:
                self.tasks.discard_saved()

    # ---------------------------------------------------------------- repair
    def check_repairs(self, force: bool = False):
        """Look for missing/damaged models and missing FFmpeg filters in the background."""
        ff = self.context.ffmpeg

        def work():
            try:
                found = repair.problems(ff, self.settings)
            except Exception as e:  # noqa
                logging.exception("repair check failed")
                found = {"models": [], "ffmpeg": [], "error": str(e)}
            found["force"] = force
            self.repair_found.emit(found)
        threading.Thread(target=work, daemon=True).start()

    def _repair_found(self, found: dict):
        self.last_repair_check = found
        need = bool(found.get("models") or found.get("ffmpeg"))
        busy = any(t.kind == "app.repair" for t in self.tasks.active())
        auto = self.settings.get("app", "auto_repair", True)
        if need and not busy and not found.get("after") and (found.get("force") or auto):
            from breezy.core.tasks import Task
            parts = []
            if found["models"]:
                parts.append(f"{len(found['models'])} AI model file(s)")
            if found["ffmpeg"]:
                parts.append("FFmpeg")
            t = Task("app.repair", "app", "Download missing parts: " + " and ".join(parts),
                     spec={"models": found["models"], "ffmpeg": found["ffmpeg"]}, resumable=False, media=False)
            self.tasks.submit(t)
            logging.info("repair queued: %s", found)
        for f in self.features:
            if hasattr(f, "repair_checked"):
                f.repair_checked(found)
        if not getattr(self, "_hw_checked", False):
            self._hw_checked = True            # after the first repair check, so downloads run first
            QTimer.singleShot(0, self._maybe_install_cuda)
            QTimer.singleShot(0, self._first_hw_scan)

    # -------------------------------------------------------------- rename (0.14.0)
    def _migrate_shortcuts(self):
        """Once: the desktop shortcut 'Breezy Video Edit' becomes 'Breezy Video' (the icon file keeps its name,
        so pinned taskbar buttons get the new logo too)."""
        if sys.platform != "win32" or self.settings.get("app", "shortcut_name") == "Breezy Video":
            return
        self.settings.set("app", "shortcut_name", "Breezy Video")
        root = Path(__file__).resolve().parents[1]
        ps = (f"$d=[Environment]::GetFolderPath('Desktop'); $old=Join-Path $d 'Breezy Video Edit.lnk';"
              f"if (Test-Path $old) {{ Remove-Item $old -Force; & '{root / 'create_shortcut.ps1'}' }};"
              "$pin=Join-Path $env:APPDATA 'Microsoft\\Internet Explorer\\Quick Launch\\User Pinned\\TaskBar';"
              "$sh=New-Object -ComObject WScript.Shell;"
              "Get-ChildItem $pin -Filter *.lnk -ErrorAction SilentlyContinue | ForEach-Object {"
              " $l=$sh.CreateShortcut($_.FullName); if ($l.Description -eq 'Breezy Video Edit') {"
              f" $l.Description='Breezy Video'; $l.IconLocation='{root / 'breezy' / 'assets' / 'icon.ico'},0'; $l.Save() }} }}")
        try:
            subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", ps],
                             creationflags=0x08000000)
        except Exception:
            logging.exception("shortcut rename failed")

    # -------------------------------------------------------------- hardware
    def _maybe_install_cuda(self):
        """NVIDIA card that supports it + engine 'Automatic': download the CUDA engine once (background)."""
        from breezy.core import ai_engine

        def check():
            try:
                need = ai_engine.should_install(self.settings) and not self.settings.get("app", "cuda_declined")
                need_trt = (not need and ai_engine.should_install_trt(self.settings)
                            and not self.settings.get("app", "trt_declined"))
            except Exception:
                need = need_trt = False
            if need:
                self.cuda_needed.emit()
            elif need_trt:
                self.trt_needed.emit()
        threading.Thread(target=check, daemon=True).start()

    def _offer_restart(self, what: str = "NVIDIA AI engine"):
        box = QMessageBox(self)
        box.setWindowTitle(f"{what} ready")
        box.setText(f"{what} is installed and works on your graphics card.\n"
                    "It's used from the next start of Breezy.")
        now = box.addButton("Restart now", QMessageBox.AcceptRole) if not self.tasks.active() else None
        box.addButton("Later", QMessageBox.RejectRole)
        box.exec()
        if now is not None and box.clickedButton() is now:
            self.restart()

    def restart(self):
        """Start a new Breezy and close this one (the new one must not find this one still running)."""
        from PySide6.QtCore import QProcess
        srv = getattr(QApplication.instance(), "_breezy_server", None)
        if srv is not None:
            srv.close()
        QProcess.startDetached(sys.executable, [a for a in sys.argv if a != "--tray"])
        self.quit_app()

    def install_trt(self):
        from breezy.core.tasks import Task
        if any(t.kind == "app.trt" for t in self.tasks.active()):
            return
        self.tasks.submit(Task("app.trt", "app", "Download NVIDIA TensorRT (2-3x faster AI)", spec={},
                               resumable=False, media=False))

    def install_cuda(self):
        from breezy.core.tasks import Task
        if any(t.kind == "app.cuda" for t in self.tasks.active()):
            return
        self.tasks.submit(Task("app.cuda", "app", "Download the NVIDIA AI engine (faster AI)", spec={},
                               resumable=False, media=False))

    def _first_hw_scan(self):
        """Once (and again when the scan itself changes): measure this PC. Queued after any repair
        downloads, so the AI models it times are there."""
        if hardware.needs_scan(self.settings) and not any(t.kind == "app.hwscan" for t in self.tasks.active()):
            self.scan_hardware()

    def scan_hardware(self):
        from breezy.core.tasks import Task
        self.tasks.submit(Task("app.hwscan", "app", "Scan my PC (graphics card, memory, AI speed)", spec={},
                               resumable=False, media=False))

    def _task_finished(self, task_id: str):
        t = self.tasks.get(task_id)
        if t and t.kind in ("app.cuda", "app.trt"):
            for f in self.features:
                if hasattr(f, "engine_changed"):
                    f.engine_changed()
            from breezy.core import ai_engine
            ok = (ai_engine.selftest_result() if t.kind == "app.cuda" else ai_engine.trt_selftest_result()).get("ok")
            if t.status == "done" and ok:
                self._offer_restart("NVIDIA TensorRT" if t.kind == "app.trt" else "NVIDIA AI engine")
            return
        if t and t.kind not in ("app.repair", "app.hwscan"):
            try:
                self.notifier.task_done(t, not self.tasks.active())
            except Exception:
                logging.exception("notify failed")
        if t and t.kind == "app.hwscan":
            for f in self.features:
                if hasattr(f, "hardware_scanned"):
                    try:
                        f.hardware_scanned(self.settings.get("app", "hardware") or {})
                    except Exception:
                        logging.exception("hardware_scanned failed for %s", f.id)
            return
        if not t or t.kind != "app.repair":
            return
        if t.spec.get("ffmpeg_installed"):
            ff = self.context.ffmpeg
            ff.ffmpeg, ff.ffprobe = FFmpeg._locate(self.settings.get("app", "ffmpeg_dir"))
            from breezy.features.enhance import filters as _ef
            _ef._filters = None
            encoders._found.clear()
            threading.Thread(target=lambda: encoders.detect(ff, self.settings), daemon=True).start()
        QTimer.singleShot(500, self.check_repairs_quiet)

    def check_repairs_quiet(self):
        """Re-check after a repair (updates Settings) without queuing again automatically."""
        ff = self.context.ffmpeg

        def work():
            found = repair.problems(ff, self.settings)
            found["after"] = True
            self.repair_found.emit(found)
        threading.Thread(target=work, daemon=True).start()

    def show_whats_new(self, changes):
        if not changes:
            return
        text = ""
        for v, items in changes:
            text += f"<h3>Version {v}</h3><ul>" + "".join(f"<li>{i}</li>" for i in items) + "</ul>"
        box = QMessageBox(self)
        box.setWindowTitle(f"What's new in {APP_NAME} {__version__}")
        box.setTextFormat(Qt.RichText)
        box.setText(text)
        box.exec()

    # ---------------------------------------------------------------- updates
    def offer_update(self, info: dict, manual: bool = False):
        from breezy.core import updater
        ver = info.get("version", "?")
        if not manual and self.settings.get("app", "update_skip") == ver:
            return
        notes = "".join(f"<li>{n}</li>" for n in (info.get("notes") or [])[:12])
        box = QMessageBox(self)
        box.setWindowTitle("Update available")
        box.setTextFormat(Qt.RichText)
        why = updater.can_update_in_place()
        box.setText(f"<b>Breezy Video {ver}</b> is available (you have {__version__}).<ul>{notes}</ul>" +
                    (f"<p>{why}</p>" if why else ""))
        now = box.addButton("Update now", QMessageBox.AcceptRole) if not why else None
        box.addButton("Later", QMessageBox.RejectRole)
        skip = box.addButton("Skip this version", QMessageBox.DestructiveRole)
        box.exec()
        if box.clickedButton() is skip:
            self.settings.set("app", "update_skip", ver)
        elif now is not None and box.clickedButton() is now:
            self.install_update(info)

    def install_update(self, info: dict):
        import threading
        from PySide6.QtWidgets import QProgressDialog
        from breezy.core import updater
        dlg = QProgressDialog("Downloading the update…", "", 0, 100, self)
        dlg.setWindowTitle("Updating Breezy")
        dlg.setCancelButton(None)
        dlg.setMinimumDuration(0)
        dlg.setValue(0)
        result: dict = {}

        def work():
            try:
                z = updater.download(self.settings, info, lambda f: result.__setitem__("p", f))
                result["ver"] = updater.apply(z, info.get("version"))
            except Exception as e:  # noqa
                result["err"] = str(e).splitlines()[0] if str(e) else type(e).__name__
            result["done"] = True
        th = threading.Thread(target=work, daemon=True)
        th.start()
        while not result.get("done"):
            dlg.setValue(int(100 * result.get("p", 0)))
            QApplication.processEvents()
            th.join(0.05)
        dlg.close()
        if "err" in result:
            QMessageBox.warning(self, "Update", f"The update couldn't be installed: {result['err']}\n\n"
                                "Nothing was changed.")
            return
        if self.tasks.active():
            box = QMessageBox(self)
            box.setWindowTitle("Update installed")
            box.setText(f"Version {result['ver']} is installed. It starts when Breezy restarts.\n"
                        "Tasks are still running - restart when they're done?")
            after = box.addButton("Restart when tasks are done", QMessageBox.AcceptRole)
            box.addButton("I'll restart later", QMessageBox.RejectRole)
            box.exec()
            if box.clickedButton() is after:
                self.tasks.finish_all_then = self.restart
            return
        QMessageBox.information(self, "Update installed", f"Version {result['ver']} is installed. Breezy restarts now.")
        self.restart()

    # ---------------------------------------------------------------- tray / watch folders
    def _tray_menu(self):
        tray = getattr(self.notifier, "tray", None)
        if tray is None:
            return
        from PySide6.QtWidgets import QMenu
        m = QMenu(self)
        m.addAction("Open Breezy", self.bring_up)
        self._pause_watch = m.addAction("Pause watch folders")
        self._pause_watch.setCheckable(True)
        self._pause_watch.toggled.connect(self.watch.set_paused)
        m.addSeparator()
        m.addAction("Quit Breezy", self.quit_app)
        tray.setContextMenu(m)
        tray.activated.connect(lambda reason: reason == tray.ActivationReason.Trigger and self.bring_up())
        self.watch.changed.connect(self._tray_tip)
        self._tray_tip()

    def _tray_tip(self):
        tray = getattr(self.notifier, "tray", None)
        if tray is None:
            return
        n = len(self.watch.active())
        state = "paused" if self.watch.paused else f"watching {n} folder(s)" if n else ""
        tray.setToolTip("Breezy Video" + (f" - {state}" if state else ""))

    def _watch_started(self, folder: str, n: int, pipe: str):
        tray = getattr(self.notifier, "tray", None)
        if tray is not None and self.settings.get("app", "notify", True):
            tray.showMessage("Watch folder", f"{n} new video(s) in {Path(folder).name} → '{pipe}'")

    def bring_up(self):
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def keeps_running_in_tray(self) -> bool:
        return (getattr(self.notifier, "tray", None) is not None and bool(self.watch.active())
                and bool(self.settings.get("app", "close_to_tray", True)))

    # ---------------------------------------------------------------- close
    def quit_app(self):
        """Close Breezy for real (also when it would otherwise stay in the tray)."""
        self._really_quit = True
        self.close()

    def closeEvent(self, e):
        self._close_event(e)
        if e.isAccepted():
            QTimer.singleShot(0, QApplication.quit)
        else:
            self._really_quit = False

    def _close_event(self, e):
        if not getattr(self, "_really_quit", False) and self.keeps_running_in_tray():
            e.ignore()
            self.hide()
            if not self.settings.get("app", "tray_hint_shown", False):
                self.settings.set("app", "tray_hint_shown", True)
                self.notifier.tray.showMessage("Breezy is still watching your folders",
                                               "It keeps running in the tray. Right-click its icon to quit.")
            return
        if self._closing_after_tasks or not self.tasks.active():
            self._shutdown()
            e.accept()
            return
        n = len(self.tasks.active())
        box = QMessageBox(self)
        box.setWindowTitle("Tasks are still running")
        box.setText(f"{n} task(s) are running or waiting. What would you like to do?")
        finish = box.addButton("Finish them, then close", QMessageBox.AcceptRole)
        save = box.addButton("Pause && save for next time", QMessageBox.ActionRole)
        quit_ = box.addButton("Quit now", QMessageBox.DestructiveRole)
        box.addButton("Cancel", QMessageBox.RejectRole)
        box.exec()
        clicked = box.clickedButton()
        if clicked is finish:
            e.ignore()
            self._closing_after_tasks = True
            self.setWindowTitle(f"{APP_NAME} {__version__} - will close when tasks finish")
            self.tasks.finish_all_then = self.close
        elif clicked is save:
            self.tasks.save_for_later()
            self._shutdown()
            e.accept()
        elif clicked is quit_:
            for t in list(self.tasks.active()):
                self.tasks.cancel(t.id)
            self.tasks.discard_saved()
            self._shutdown()
            e.accept()
        else:
            e.ignore()

    def _shutdown(self):
        for f in self.features:
            try:
                getattr(f, "shutdown", lambda: None)()
            except Exception:
                pass


def _excepthook(exc_type, exc, tb):
    text = "".join(traceback.format_exception(exc_type, exc, tb))
    logging.error(text)
    QMessageBox.critical(None, APP_NAME, f"Unexpected error:\n\n{exc}\n\nDetails were written to the log.")


def main():
    logging.basicConfig(filename=str(app_data_dir() / "breezy.log"), level=logging.INFO,
                        format="%(asctime)s %(levelname)s %(name)s: %(message)s")
    if sys.platform == "win32":
        try:
            import ctypes
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID("Breezy.VideoEdit")
        except Exception:
            pass
    app = QApplication.instance() or QApplication(sys.argv)
    app.setApplicationName(APP_NAME)
    app.setApplicationVersion(__version__)
    app.setStyle("Fusion")
    ico = Path(__file__).resolve().parent / "assets" / "icon.ico"
    if ico.is_file():
        app.setWindowIcon(QIcon(str(ico)))
    sys.excepthook = _excepthook
    server = _single_instance(app)
    if server is None:
        return                                  # Breezy was already running: it has been brought up
    app._breezy_server = server
    win = MainWindow()
    server.newConnection.connect(lambda: (server.nextPendingConnection(), win.bring_up()))
    app.setQuitOnLastWindowClosed(False)        # the window may hide in the tray; quitting is explicit
    if not ("--tray" in sys.argv and win.keeps_running_in_tray()):
        win.show()
    sys.exit(app.exec())


def _single_instance(app):
    """Only one Breezy at a time (it may be running in the tray): a second start shows the first one."""
    from PySide6.QtNetwork import QLocalServer, QLocalSocket
    import getpass
    name = f"BreezyVideo-{getpass.getuser()}"
    sock = QLocalSocket()
    sock.connectToServer(name)
    if sock.waitForConnected(300):
        sock.write(b"show")
        sock.flush()
        sock.waitForBytesWritten(300)
        sock.disconnectFromServer()
        return None
    QLocalServer.removeServer(name)
    server = QLocalServer(app)
    server.listen(name)
    return server
