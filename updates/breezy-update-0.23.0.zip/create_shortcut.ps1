# Creates a "Breezy Video" shortcut on the Desktop (run automatically once by run.bat).
# The shortcut carries the same AppUserModelID as the app window (Breezy.VideoEdit), so when
# it's pinned to the taskbar the pin and the running app share one taskbar button.
$ErrorActionPreference = 'Stop'
$app = Split-Path -Parent $MyInvocation.MyCommand.Path
$desktop = [Environment]::GetFolderPath('Desktop')
$path = Join-Path $desktop 'Breezy Video.lnk'

$shell = New-Object -ComObject WScript.Shell
$lnk = $shell.CreateShortcut($path)
$lnk.TargetPath = Join-Path $app '.venv\Scripts\pythonw.exe'
$lnk.Arguments = '"' + (Join-Path $app 'main.py') + '"'
$lnk.WorkingDirectory = $app
$lnk.IconLocation = (Join-Path $app 'breezy\assets\icon.ico') + ',0'
$lnk.Description = 'Breezy Video'
$lnk.Save()
Write-Host "Desktop shortcut created: $path"

try {
    Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
[ComImport, Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
public interface IBreezyPropertyStore {
    void GetCount(out uint c);
    void GetAt(uint i, out BreezyPropKey k);
    void GetValue(ref BreezyPropKey k, out BreezyPropVariant v);
    void SetValue(ref BreezyPropKey k, ref BreezyPropVariant v);
    void Commit();
}
[StructLayout(LayoutKind.Sequential, Pack = 4)]
public struct BreezyPropKey { public Guid fmtid; public uint pid; }
[StructLayout(LayoutKind.Explicit, Size = 16)]
public struct BreezyPropVariant { [FieldOffset(0)] public ushort vt; [FieldOffset(8)] public IntPtr p; }
public static class BreezyAumid {
    [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
    static extern void SHGetPropertyStoreFromParsingName(string path, IntPtr pbc, int flags,
        ref Guid iid, [MarshalAs(UnmanagedType.Interface)] out IBreezyPropertyStore ps);
    public static void Set(string lnk, string id) {
        Guid iid = new Guid("886D8EEB-8CF2-4446-8D02-CDBA1DBDCF99");
        IBreezyPropertyStore ps;
        SHGetPropertyStoreFromParsingName(lnk, IntPtr.Zero, 2, ref iid, out ps); // GPS_READWRITE
        BreezyPropKey key = new BreezyPropKey();
        key.fmtid = new Guid("9F4C2855-9F79-4B39-A8D0-E1D42DE1D5F3"); key.pid = 5; // AppUserModel.ID
        BreezyPropVariant pv = new BreezyPropVariant();
        pv.vt = 31; pv.p = Marshal.StringToCoTaskMemUni(id);                     // VT_LPWSTR
        try { ps.SetValue(ref key, ref pv); ps.Commit(); }
        finally { Marshal.FreeCoTaskMem(pv.p); Marshal.ReleaseComObject(ps); }
    }
}
"@
    [BreezyAumid]::Set($path, 'Breezy.VideoEdit')
    Write-Host "Taskbar ID set."
} catch {
    Write-Host "Note: could not set taskbar ID ($($_.Exception.Message)). The shortcut still works."
}
